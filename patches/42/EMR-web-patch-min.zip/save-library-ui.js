import {SaveLibrary,installLegacySaveBridge} from './engine/save-library.js';

const bridge=installLegacySaveBridge();
const lib=bridge?.lib||new SaveLibrary(localStorage);
const $=s=>document.querySelector(s);
let mode='continue';
let originalNew=null,originalContinue=null;

function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function ensureDialog(){
 let d=$('#save-library-dialog');if(d)return d;
 d=document.createElement('dialog');d.id='save-library-dialog';d.className='save-library-dialog';
 d.innerHTML='<div class="save-library-shell"><div id="save-library-body"></div><button id="save-library-close" class="quiet">Cerrar</button></div>';
 document.body.appendChild(d);$('#save-library-close').onclick=()=>d.close();return d;
}
function activeProfile(){lib.reload();return lib.profile();}
function activeUniverse(){return lib.universe();}
function activeStory(){return lib.story();}
function portableFilename(){return `el-mundo-recuerda-save-${new Date().toISOString().slice(0,10)}.json`;}
function downloadBundle(){
 const blob=new Blob([lib.exportBundle()],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download=portableFilename();a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),0);
}
async function importBundleFile(file){if(!file)throw new Error('SAVE_LIBRARY_FILE_REQUIRED');const text=await file.text();lib.importBundle(text);lib.reload();return lib.data;}
function renderPortableControls(){return `<hr><div class="save-library-portable"><h3>Copia portátil</h3><p>Guarda perfiles, universos e historias en un archivo local o restáuralos en este dispositivo.</p><div class="save-library-portable-actions"><button id="save-library-export" class="secondary">Exportar copia</button><button id="save-library-import" class="secondary">Importar copia</button></div><input id="save-library-import-file" type="file" accept="application/json,.json" hidden><p id="save-library-portable-status" class="status" aria-live="polite"></p></div>`;}
function wirePortableControls(){
 const exp=$('#save-library-export'),imp=$('#save-library-import'),file=$('#save-library-import-file'),status=$('#save-library-portable-status');
 if(exp)exp.onclick=()=>{try{downloadBundle();if(status)status.textContent='Copia exportada. Guárdala donde puedas recuperarla.';}catch{if(status)status.textContent='No se ha podido exportar la copia.';}};
 if(imp&&file){imp.onclick=()=>file.click();file.onchange=async()=>{const selected=file.files?.[0];if(!selected)return;if(status)status.textContent='Comprobando copia…';try{await importBundleFile(selected);renderProfiles('Copia restaurada correctamente.');}catch{if(status)status.textContent='No se ha importado nada: el archivo no es una copia válida de El Mundo Recuerda.';}finally{file.value='';}};}
}
function renderProfiles(message=''){
 const d=ensureDialog(),body=$('#save-library-body'),ps=lib.reload().profiles;
 body.innerHTML=`<p class="eyebrow">BIBLIOTECA DE PARTIDAS</p><h2>¿Quién juega?</h2><p>Cada perfil conserva sus propios universos e historias en este dispositivo.</p>${message?`<p class="status">${esc(message)}</p>`:''}<div class="save-library-list">${ps.map(p=>`<button class="secondary" data-profile="${p.id}">${esc(p.name)}</button>`).join('')||'<p>Aún no hay perfiles.</p>'}</div><hr><label>Crear perfil<input id="save-profile-name" maxlength="40" placeholder="Nombre del jugador"></label><button id="save-profile-create">Crear perfil</button>${renderPortableControls()}`;
 body.querySelectorAll('[data-profile]').forEach(b=>b.onclick=()=>{lib.activateProfile(b.dataset.profile);renderUniverses();});
 $('#save-profile-create').onclick=()=>{const v=$('#save-profile-name').value.trim();if(!v)return;lib.createProfile(v);renderUniverses();};
 wirePortableControls();if(!d.open)d.showModal();
}
function renderUniverses(){
 const p=activeProfile();if(!p)return renderProfiles();const body=$('#save-library-body'),us=lib.universes(p.id);
 body.innerHTML=`<p class="eyebrow">${esc(p.name)}</p><h2>${mode==='new'?'¿Dónde empieza la nueva historia?':'Elige un universo'}</h2><div class="save-library-list">${us.map(u=>`<button class="secondary" data-universe="${u.id}"><strong>${esc(u.name)}</strong><span>${lib.stories(u.id).length} historia(s)</span></button>`).join('')||'<p>Aún no hay universos.</p>'}</div>${mode==='new'?`<hr><label>Nuevo universo<input id="save-universe-name" maxlength="60" placeholder="Nombre del universo"></label><button id="save-universe-create">Crear universo nuevo</button>`:''}<button id="save-back-profiles" class="quiet">Cambiar perfil / copias</button>`;
 body.querySelectorAll('[data-universe]').forEach(b=>b.onclick=()=>{lib.activateUniverse(b.dataset.universe);mode==='new'?renderNewStory():renderStories();});
 $('#save-back-profiles').onclick=()=>renderProfiles();
 const create=$('#save-universe-create');if(create)create.onclick=()=>{const name=$('#save-universe-name').value.trim()||'Mi universo';lib.createUniverse({profileId:p.id,name});renderNewStory();};
}
function renderStories(){
 const u=activeUniverse();if(!u)return renderUniverses();const body=$('#save-library-body'),ss=lib.stories(u.id).sort((a,b)=>String(b.lastPlayedAt||b.updatedAt).localeCompare(String(a.lastPlayedAt||a.updatedAt)));
 body.innerHTML=`<p class="eyebrow">${esc(u.name)}</p><h2>Historias guardadas</h2><div class="save-library-list">${ss.map(s=>`<button class="secondary" data-story="${s.id}"><strong>${esc(s.name)}</strong><span>${s.lastPlayedAt?'Última partida '+new Date(s.lastPlayedAt).toLocaleString():'Preparada'}</span></button>`).join('')||'<p>Este universo todavía no tiene historias.</p>'}</div><button id="save-new-story-here">Nueva historia en este universo</button><button id="save-back-universes" class="quiet">Volver a universos</button>`;
 body.querySelectorAll('[data-story]').forEach(b=>b.onclick=()=>{lib.activateStory(b.dataset.story);ensureDialog().close();originalContinue?.();});
 $('#save-new-story-here').onclick=()=>{mode='new';renderNewStory();};$('#save-back-universes').onclick=renderUniverses;
}
function renderNewStory(){
 const u=activeUniverse();if(!u)return renderUniverses();const body=$('#save-library-body');
 body.innerHTML=`<p class="eyebrow">${esc(u.name)}</p><h2>Crear una historia</h2><label>Nombre de la historia<input id="save-story-name" maxlength="80" placeholder="Ej. La primera memoria"></label><p>Esta historia tendrá su propio guardado y no sobrescribirá las demás.</p>${u.baseSave?'<p class="status">Este universo ya tiene una base congelada: puedes iniciar una nueva rama desde el mismo mundo.</p>':'<p class="status">La función de bifurcar desde un mundo ya formado se activará cuando el universo alcance su punto de congelación canónico.</p>'}<button id="save-story-create">Empezar historia</button><button id="save-back-universes" class="quiet">Volver</button>`;
 $('#save-story-create').onclick=()=>{const name=$('#save-story-name').value.trim()||'Nueva historia';const s=u.baseSave?lib.forkStory({universeId:u.id,name}):lib.createStory({universeId:u.id,name});lib.activateStory(s.id);ensureDialog().close();originalNew?.();};
 $('#save-back-universes').onclick=renderUniverses;
}
function openLibrary(nextMode){mode=nextMode;lib.reload();if(!lib.profiles().length)return renderProfiles();const p=lib.profile()||lib.profiles()[0];if(!lib.profile())lib.activateProfile(p.id);if(nextMode==='continue'){const u=lib.universe();if(u)return renderStories();return renderUniverses();}return renderUniverses();}
function install(){
 const n=$('#home-new'),c=$('#home-continue');if(!n||!c)return;
 originalNew=n.onclick;originalContinue=c.onclick;
 n.onclick=e=>{e?.preventDefault?.();openLibrary('new');};
 c.onclick=e=>{e?.preventDefault?.();openLibrary('continue');};
 const style=document.createElement('style');style.textContent=`.save-library-dialog{width:min(94vw,620px);border:1px solid rgba(255,255,255,.18);border-radius:20px;background:#171d26;color:#f3ede2;padding:0}.save-library-dialog::backdrop{background:rgba(3,6,10,.78);backdrop-filter:blur(5px)}.save-library-shell{padding:24px}.save-library-shell label{display:grid;gap:8px;margin:12px 0}.save-library-shell input:not([type=file]){font:inherit;padding:13px;border-radius:12px;border:1px solid rgba(255,255,255,.2);background:#0f141b;color:#fff}.save-library-list{display:grid;gap:10px;margin:16px 0}.save-library-list button{display:flex;justify-content:space-between;gap:14px;align-items:center;text-align:left}.save-library-list span{opacity:.72;font-size:.85em}.save-library-shell hr{border:0;border-top:1px solid rgba(255,255,255,.14);margin:20px 0}.save-library-portable h3{margin-bottom:6px}.save-library-portable-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px}.save-library-portable .status{min-height:1.2em}`;document.head.appendChild(style);
 const migrated=lib.migrateLegacy();if(migrated){const hs=$('#home-status');if(hs)hs.textContent='Tu partida anterior se ha conservado en la nueva Biblioteca de partidas.';}
}
install();
export {lib as saveLibrary};
