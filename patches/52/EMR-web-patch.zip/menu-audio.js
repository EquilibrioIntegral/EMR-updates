const home=document.querySelector('#home');
const setup=document.querySelector('#setup');
const audio=document.querySelector('#menu-theme');

if(audio){
  const TARGET_VOLUME=0.72;
  // Android WebView can resolve the first play() and suspend it again while the
  // activity is still settling. Keep a short watchdog alive through cold start.
  const BOOT_RETRY_DELAYS=[0,180,480,950,1650,2600,3800,5200];
  const COLD_START_STABILITY_MS=6200;
  let fadeFrame=0;
  let retryTimers=[];
  let gestureArmed=false;
  let pauseTimer=0;
  let stableTimer=0;
  audio.volume=0;
  audio.loop=true;
  audio.preload='auto';

  // The updater owns this flag in the real app. Keep the audio module robust in
  // isolated/non-DOM harnesses: only an explicit "pending" gate may suppress audio.
  const updateGateReady=()=>document.documentElement?.dataset?.updateGate!=='pending';
  const inMenuZone=()=>updateGateReady()&&document.visibilityState!=='hidden'&&((home&&!home.hidden)||(setup&&!setup.hidden));
  const cancelFade=()=>{if(fadeFrame){cancelAnimationFrame(fadeFrame);fadeFrame=0;}};
  const clearRetries=()=>{retryTimers.forEach(clearTimeout);retryTimers=[];};
  const cancelPause=()=>{if(pauseTimer){clearTimeout(pauseTimer);pauseTimer=0;}};
  const cancelStable=()=>{if(stableTimer){clearTimeout(stableTimer);stableTimer=0;}};
  const fadeTo=(target,duration=650,onDone)=>{
    cancelFade();
    const from=audio.volume,start=performance.now();
    const tick=now=>{
      const t=Math.min(1,(now-start)/duration);
      audio.volume=from+(target-from)*(t*(2-t));
      if(t<1)fadeFrame=requestAnimationFrame(tick);else{fadeFrame=0;onDone?.();}
    };
    fadeFrame=requestAnimationFrame(tick);
  };
  const fadeOutAndPause=()=>{
    clearRetries();cancelStable();cancelPause();
    if(audio.paused){audio.volume=0;return;}
    fadeTo(0,780,()=>{pauseTimer=setTimeout(()=>{if(!inMenuZone())audio.pause();pauseTimer=0;},20);});
  };

  const removeGestureFallback=()=>{
    if(!gestureArmed)return;
    gestureArmed=false;
    for(const name of ['pointerdown','touchstart','keydown','click'])window.removeEventListener(name,onFirstGesture,true);
  };
  const armGestureFallback=()=>{
    if(gestureArmed)return;
    gestureArmed=true;
    for(const name of ['pointerdown','touchstart','keydown','click'])window.addEventListener(name,onFirstGesture,{capture:true,passive:true});
  };
  const markStable=()=>{
    cancelStable();
    stableTimer=setTimeout(()=>{
      stableTimer=0;
      if(inMenuZone()&&!audio.paused){clearRetries();removeGestureFallback();}
    },COLD_START_STABILITY_MS);
  };
  const play=async({fromGesture=false}={})=>{
    if(!inMenuZone())return false;
    cancelPause();
    try{
      if(audio.paused){cancelFade();audio.volume=0;await audio.play();}
      if(!fadeFrame&&audio.volume<TARGET_VOLUME-0.02)fadeTo(TARGET_VOLUME,fromGesture?360:560);
      if(fromGesture)removeGestureFallback();
      markStable();
      return true;
    }catch{armGestureFallback();return false;}
  };
  async function onFirstGesture(){await play({fromGesture:true});}

  const scheduleRecovery=()=>{
    if(!inMenuZone())return;
    clearRetries();cancelPause();armGestureFallback();
    BOOT_RETRY_DELAYS.forEach(delay=>retryTimers.push(setTimeout(()=>{
      if(!inMenuZone())return;
      if(audio.paused)play();
      else if(!fadeFrame&&audio.volume<TARGET_VOLUME-0.02)fadeTo(TARGET_VOLUME,420);
    },delay)));
  };
  const bootstrap=()=>{if(inMenuZone())scheduleRecovery();};
  const sync=()=>{if(inMenuZone())bootstrap();else fadeOutAndPause();};
  const recoverUnexpectedPause=()=>{if(!inMenuZone())return;cancelStable();scheduleRecovery();};

  if(home)new MutationObserver(sync).observe(home,{attributes:true,attributeFilter:['hidden']});
  if(setup)new MutationObserver(sync).observe(setup,{attributes:true,attributeFilter:['hidden']});
  audio.addEventListener('loadeddata',()=>play(),{once:true});
  audio.addEventListener('canplay',()=>play(),{once:true});
  audio.addEventListener('pause',recoverUnexpectedPause);
  window.addEventListener('emr:update-gate-ready',bootstrap);
  window.addEventListener('pageshow',bootstrap);
  window.addEventListener('focus',bootstrap);
  document.addEventListener('visibilitychange',sync);

  try{audio.load();}catch{}
  bootstrap();
}
