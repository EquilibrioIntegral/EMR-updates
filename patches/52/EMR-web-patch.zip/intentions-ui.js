import {assignIntentionDecks,playerIntentionLabel} from './engine/intention-decks.js';

const KEY='emr.hybrid.intentions.v1';
let setup={count:1,names:[]};
try{setup={...setup,...JSON.parse(localStorage.getItem(KEY)||'{}')};}catch{}
const save=()=>localStorage.setItem(KEY,JSON.stringify(setup));
const assignments=()=>assignIntentionDecks((setup.names||[]).slice(0,setup.count));

function captureName(){
  const input=document.querySelector('#preshow-name');
  const progress=document.querySelector('.preshow-progress')?.textContent||'';
  const m=progress.match(/Jugador\s+(\d+)\s+de\s+(\d+)/i);
  if(!input||!m)return;
  const i=Number(m[1])-1; setup.count=Number(m[2]);
  const name=input.value.trim().replace(/\s+/g,' ');
  if(name){setup.names[i]=name;save();}
}

document.addEventListener('click',e=>{
  const count=e.target.closest?.('[data-player-count]');
  if(count){setup={count:Number(count.dataset.playerCount),names:[]};save();return;}
  if(e.target.closest?.('#preshow-next'))captureName();
},true);
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&document.activeElement?.id==='preshow-name')captureName();},true);

function intentionBadge(a){const span=document.createElement('span');span.className=`intent-player intent-${a.colorToken}`;span.dataset.intentCode=a.code;span.textContent=`${a.code} ${a.name} · ${a.colorName}`;return span;}

function injectReady(){
  const ready=document.querySelector('.preshow-ready');
  if(!ready||ready.querySelector('[data-intention-setup]'))return;
  const a=assignments();if(setup.count<=1||a.length===0)return;
  const start=ready.querySelector('#new-game');start.hidden=true;
  const box=document.createElement('section');box.className='intention-setup physical';box.dataset.intentionSetup='1';
  let i=0;
  const draw=()=>{const x=a[i];box.className=`intention-setup physical intent-${x.colorToken}`;box.innerHTML=`<p class="preshow-progress">Preparación ${i+1} de ${a.length}</p><h2>${x.playerName}: prepara tus Intenciones</h2><p>Ve a <strong>Biblioteca → Intenciones</strong>. Busca la etiqueta clasificadora <strong>${x.code} · ${x.name} · ${x.colorName}</strong>.</p><p>Toma exactamente estas cartas: <strong>${x.cards.join(' · ')}</strong>.</p><p>Déjalas junto a tu <strong>meeple ${x.colorName}</strong>. No mezcles tus cartas con las de otro jugador.</p><button id="intention-player-next">${i+1===a.length?'Preparación terminada':'Siguiente jugador →'}</button>`;box.querySelector('#intention-player-next').onclick=()=>{if(i+1<a.length){i++;draw();}else{box.innerHTML='<h2>Intenciones preparadas</h2><p>Todos los jugadores tienen ya su juego de Intenciones junto a su meeple.</p>';start.hidden=false;start.focus();}};};
  draw();ready.insertBefore(box,start);
}

function decoratePlayerLabels(){const a=assignments();if(a.length===0)return;const root=document.querySelector('#boot');if(!root||root.hidden)return;const candidates=root.querySelectorAll('label,p,h1,h2,strong');for(const node of candidates){if(node.dataset.intentDecorated)return;const text=(node.childNodes[0]?.textContent||node.textContent||'').trim();const hit=a.find(x=>text===x.playerName||text.startsWith(`${x.playerName} `)||text.startsWith(`${x.playerName}:`));if(!hit)continue;node.dataset.intentDecorated='1';node.classList.add(`intent-${hit.colorToken}`);node.append(' ');node.appendChild(intentionBadge(hit));node.setAttribute('aria-label',playerIntentionLabel(hit.playerName,hit));}}
const refresh=()=>{injectReady();decoratePlayerLabels();};
new MutationObserver(refresh).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['hidden']});refresh();
