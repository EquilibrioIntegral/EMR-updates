const KIND_ORDER=['SOURCE','ROLE','RELATION','TRANSFORM'];

function hash32(text='') {
  let h=2166136261 >>> 0;
  for (let i=0;i<text.length;i++) { h ^= text.charCodeAt(i); h = Math.imul(h,16777619) >>> 0; }
  return h >>> 0;
}

function choose(seq,key) {
  if (!Array.isArray(seq) || !seq.length) throw new Error('REALIZER_EMPTY_LEXICON');
  return seq[hash32(String(key)) % seq.length];
}

function renderFragment(text,bindings) {
  const missing=[];
  const out=String(text ?? '').replace(/\{([A-Z0-9_]+)\}/g,(m,k)=>{
    const v=bindings[k];
    if (v == null || String(v).trim()==='') { missing.push(k); return m; }
    return String(v);
  });
  if (missing.length) throw new Error(`REALIZER_UNRESOLVED:${[...new Set(missing)].sort().join(',')}`);
  return out;
}

function normalizeText(text) {
  let out=String(text ?? '').replace(/\s+([,.;:!?])/g,'$1').replace(/\s+/g,' ').trim();
  out=out.replace(/\bde el\b/gi,'del').replace(/\ba el\b/gi,'al');
  if (out) out=out[0].toUpperCase()+out.slice(1);
  return out;
}

export function buildVisibleBindings({primitive,realizer,sceneKey,bindings={}}) {
  const actions=realizer?.visible_lexicon?.actions ?? {};
  const consequences=realizer?.visible_lexicon?.consequences ?? {};
  const actionKey=primitive.REALIZER_ACTION_KEY;
  const change=primitive.CHANGE_SIGNATURE;
  if (!actions[actionKey]) throw new Error(`REALIZER_ACTION_UNKNOWN:${actionKey}`);
  if (!consequences[change]) throw new Error(`REALIZER_CHANGE_UNKNOWN:${change}`);
  return {
    ...bindings,
    ACTION_TEXT: choose(actions[actionKey],`${sceneKey}|action|${actionKey}`),
    REACTION_TEXT: choose(actions[actionKey],`${sceneKey}|reaction|${actionKey}`),
    CONSEQUENCE: choose(consequences[change],`${sceneKey}|consequence|${change}`)
  };
}

export function realizeTyped({domain,bindings,realizer}) {
  const records=(realizer?.realizer_records ?? []).filter(r=>r.domain===domain);
  const chain=KIND_ORDER.map(kind=>records.find(r=>r.kind===kind));
  if (chain.some(x=>!x)) throw new Error(`REALIZER_CHAIN_MISSING:${domain}`);
  let prev=null;
  for (let i=0;i<chain.length;i++) {
    const r=chain[i];
    if (i) {
      const accepts=(r.accepts ?? []).filter(Boolean);
      if (accepts.length && !accepts.includes(prev)) throw new Error(`REALIZER_TYPE_MISMATCH:${prev}->${r.id}`);
    }
    prev=r.output_type;
  }
  const fragments=chain.map(r=>renderFragment(r.content,bindings));
  return {
    text:normalizeText(fragments.filter(Boolean).join(' ')),
    provenance:chain.map(r=>({recordId:r.id,kind:r.kind,authority:r.source_authority}))
  };
}
