// GEN-R5.7 — thin compatibility adapter from weighted Genesis Legacy v3
// to the existing BOOT01 consumer contract. It maps causal evidence only;
// it does not resolve authority or invent later geography/climate.
const clone=x=>structuredClone(x);

const HOOK_TO_BOOT01=Object.freeze({DENSE_CORE:'NUCLEO_DOMINANTE',OUTER_ARC:'SISTEMA_DISTRIBUIDO',SHIFTED_ARC:'SISTEMA_DISTRIBUIDO',PRESERVED_FRAGMENT:'SISTEMA_DISTRIBUIDO',STABLE_ORBIT:'ORBITAS_ESTABLES',PRIMORDIAL_LINK:'VINCULO_IMPERSONAL',CONSCIOUS_IMPRINT:'HUELLA_CONSCIENTE',FRACTURE:'FRACTURA_PRIMORDIAL'});
const ACTION_TO_BOOT01=Object.freeze({ATTRACT:'NUCLEO_DOMINANTE',ACCRETE:'NUCLEO_DOMINANTE',COHERE:'COHESION_PRIMORDIAL',LINK:'VINCULO_IMPERSONAL',IMPRINT:'HUELLA_CONSCIENTE'});

export function adaptWeightedGenesisLegacyToBoot01(legacy,{id='LEGADO-GENESIS-PONDERADO'}={}){
 if(legacy?.schema!=='EMR_PRIMORDIAL_LEGACY_v3') throw new Error('GENESIS_WEIGHTED_LEGACY_V3_REQUIRED');
 const causalChain=[];
 for(const a of legacy.memory||[]){if(a?.type!=='GEN_INDIVIDUAL_ACTION')continue;const hookTags=(a.futureHooks||[]).map(h=>HOOK_TO_BOOT01[h]).filter(Boolean),actionTag=ACTION_TO_BOOT01[a.operation],tags=[...new Set([...hookTags,...(actionTag?[actionTag]:[])])];for(const resultTag of tags)causalChain.push({source:a.actorId,sourceKind:a.sourceKind,transformId:`GEN-${a.operation}-${a.targetId??'WORLD'}`,resultTag,outcome:'SUCCESS'});}
 const residues=[];for(const relation of legacy.relations||[])for(const e of relation.exceptions||[])if(e?.residue)residues.push({id:`GEN-EXCEPTION-${residues.length+1}`,status:'ACTIVE',source:e.actorId||'WILL',outcome:'SUCCESS',resultTag:'HUELLA_CONSCIENTE',detail:e.residue});
 const fingerprint=JSON.stringify({signature:legacy.signature,causalChain:causalChain.map(x=>[x.source,x.transformId,x.resultTag]),residues:residues.map(x=>[x.source,x.resultTag,x.detail])});
 return {id,consumer:'BOOT01_FORMACION_MUNDO',fingerprint,causalFingerprint:fingerprint,common:{residues:clone(residues),causalChain:clone(causalChain),provenance:{causalFingerprint:fingerprint}},extensions:{weightedGenesis:clone(legacy)}};
}

export function installWeightedGenesisHandoffForBoot01(state,handoff){
 if(!state?.session)throw new Error('BOOT_STATE_SESSION_REQUIRED');
 if(!['EMR_GENESIS_TO_BOOT01_v2','EMR_GENESIS_TO_BOOT01_v3'].includes(handoff?.schema))throw new Error('GENESIS_BOOT01_HANDOFF_V2_OR_V3_REQUIRED');
 state.session.boot??={};const adapted=adaptWeightedGenesisLegacyToBoot01(handoff.legacy);
 state.session.boot.weightedGenesis=clone(handoff);state.session.boot.legadoPrimordial=clone(adapted);state.session.boot.primordialLegacy=clone(handoff.legacy);
 if(handoff.playableSystem!=null)state.session.boot.playableSystem=clone(handoff.playableSystem);
 const selectedPlanetId=handoff.selectedPlanetId??handoff.selectedPlanet?.id??handoff.playableSystem?.selectedPlanet?.id??null;
 const selectedPlanet=handoff.selectedPlanet??handoff.playableSystem?.selectedPlanet??null;
 if(selectedPlanetId!=null)state.session.boot.selectedPlanetId=selectedPlanetId;
 if(selectedPlanet!=null)state.session.boot.selectedPlanet=clone(selectedPlanet);
 // Preserve Genesis' qualitative spatial consequence as evidence. BOOT01 may
 // consume it later through its own authority rules; this adapter never turns
 // proximity directly into a climate or geography result.
 const env=handoff.playableSystem?.preliminaryEnvironment??null;
 if(env!=null){state.session.boot.genesisEnvironmentEvidence=clone(env);state.session.boot.primordialEvidence??=[];state.session.boot.primordialEvidence.push({type:'STELLAR_PROXIMITY',value:env.stellarProximity,orbitalBand:env.orbitalBand,producerId:env.authority||'GENESIS_CAUSAL_SPATIAL_RELATION',sourcePlanetId:selectedPlanetId});}
 state.session.boot.phase='BOOT01_READY';state.eventLog??=[];state.eventLog.push({type:'WEIGHTED_GENESIS_LEGACY_INSTALLED_FOR_BOOT01',gameTime:state.meta?.gameTime??0,legacyId:adapted.id,causalFingerprint:adapted.causalFingerprint,selectedPlanetId,genesisEnvironmentEvidence:env?true:false});return adapted;
}