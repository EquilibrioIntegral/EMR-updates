import { beginBoot01, commitBoot01Intentions, compileBoot01World, commitBoot01PublicFeature, advanceBoot01ToBoot02 } from './boot01-hybrid.js';
import { ensureBootState } from './boot.js';

const INTENTION_LABELS={1:'Extender',2:'Quebrar',3:'Entrelazar'};
const clone=x=>structuredClone(x);
const d6=x=>{x=Number(x);if(!Number.isInteger(x)||x<1||x>6)throw new Error('BOOT01_D6_INVALID');return x;};

function genesisContinuityText(b){
  const name=b?.genesisR5?.selectedWorldPublicName;
  return name?`${name} ya existe alrededor de su estrella. Ahora su materia debe tomar forma y convertirse en geografía.`:'La realidad ya existe. Ahora la materia del mundo debe tomar forma.';
}

export function createBoot01PlayerExperience(state){
  const b=ensureBootState(state);
  if(b.phase==='BOOT01_READY') beginBoot01(state);
  else if(b.phase!=='BOOT01_INTENTION') throw new Error('BOOT01_PLAYER_START_PHASE_INVALID');
  b.boot01Player??={version:'EMR_BOOT01_PLAYER_EXPERIENCE_v1',entry:0,secretIntentions:{},revealed:null,visible:[genesisContinuityText(b)],narrative:[],materializationConfirmed:false};
  return getBoot01PlayerView(state);
}

export function getBoot01PlayerView(state){
  const b=ensureBootState(state),x=b.boot01Player;
  if(!x) throw new Error('BOOT01_PLAYER_EXPERIENCE_REQUIRED');
  return {phase:b.phase,entry:x.entry,visible:[...x.visible],narrative:[...x.narrative],revealed:x.revealed?clone(x.revealed):null,selectedWorldPublicName:b.genesisR5?.selectedWorldPublicName??null,tableMaterialized:x.materializationConfirmed===true,territory:b.phase==='BOOT01_FEATURE_NAMING'||b.phase==='BOOT01_CLOSED'||b.phase==='BOOT02_READY'?publicTerritory(b.boot01?.territory):null};
}

export function submitBoot01SecretIntention(state,playerIndex,intention){
  const b=ensureBootState(state),x=b.boot01Player,players=state.session?.players??[];
  if(b.phase!=='BOOT01_INTENTION'||!x) throw new Error('BOOT01_PLAYER_INTENTION_PHASE_INVALID');
  playerIndex=Number(playerIndex); intention=Number(intention);
  if(!Number.isInteger(playerIndex)||playerIndex<0||playerIndex>=players.length) throw new Error('BOOT01_PLAYER_INVALID');
  if(!INTENTION_LABELS[intention]) throw new Error('BOOT01_INTENTION_INVALID');
  x.secretIntentions[playerIndex]=intention;
  x.entry=Object.keys(x.secretIntentions).length;
  return {accepted:true,complete:x.entry===players.length,nextPlayer:x.entry<players.length?x.entry:null};
}

export function revealBoot01Intentions(state){
  const b=ensureBootState(state),x=b.boot01Player,players=state.session?.players??[];
  if(!x||Object.keys(x.secretIntentions).length!==players.length) throw new Error('BOOT01_ALL_INTENTIONS_REQUIRED');
  x.revealed=players.map((p,i)=>({player:p.name??`Jugador ${i+1}`,intention:INTENTION_LABELS[x.secretIntentions[i]]}));
  x.visible.push('Las Intenciones se revelan a la vez. La forma del mundo responderá a su encuentro.');
  return clone(x.revealed);
}

export function resolveBoot01PlayerIntentions(state,die=null){
  const b=ensureBootState(state),x=b.boot01Player,players=state.session?.players??[];
  if(!x?.revealed) throw new Error('BOOT01_REVEAL_REQUIRED');
  const intentions=players.map((_,i)=>x.secretIntentions[i]);
  const unique=new Set(intentions);
  const resolved=commitBoot01Intentions(state,intentions,unique.size===1?null:d6(die));
  x.visible.push(unique.size===1?`La materia obedece a una Intención común: ${INTENTION_LABELS[resolved.id]}.`:`Las Intenciones chocan. La incertidumbre decide qué impulso prevalece: ${INTENTION_LABELS[resolved.id]}.`);
  return {needsDie:unique.size>1,result:resolved.label,secondary:[...resolved.secondary]};
}

export function resolveBoot01SoloIntention(state,intention){
  const b=ensureBootState(state),players=state.session?.players??[],x=b.boot01Player;
  if(players.length!==1)throw new Error('BOOT01_SOLO_ONE_PLAYER_REQUIRED');
  if(b.phase!=='BOOT01_INTENTION'||!x)throw new Error('BOOT01_PLAYER_INTENTION_PHASE_INVALID');
  intention=Number(intention);
  if(!INTENTION_LABELS[intention])throw new Error('BOOT01_INTENTION_INVALID');
  const resolved=commitBoot01Intentions(state,[intention],null);
  x.soloIntention=intention;
  x.revealed=[{player:players[0]?.name??'Jugador 1',intention:INTENTION_LABELS[intention]}];
  x.visible.push(`Tu decisión queda fijada: ${INTENTION_LABELS[intention]}. La app la incorpora al Legado y continúa con la formación del mundo.`);
  return {needsDie:false,result:resolved.label,secondary:[...resolved.secondary]};
}

export function formBoot01World(state,dice){
  const b=ensureBootState(state),x=b.boot01Player;
  if(!x) throw new Error('BOOT01_PLAYER_EXPERIENCE_REQUIRED');
  const territory=compileBoot01World(state,{dice:dice.map(d6)}),p=territory.profile;
  const narrative=territoryNarrative(p);
  const physical=territoryPhysicalPlan(p);
  x.narrative.push(narrative);
  x.visible.push('La forma resultante debe existir ahora sobre la mesa.');
  x.physical=physical;
  x.materializationConfirmed=false;
  return {narrative,physical,territory:publicTerritory(territory)};
}

export function nameBoot01Feature(state,{refId,featureType,scope,displayName}){
  const b=ensureBootState(state),x=b.boot01Player;
  if(!Array.isArray(x?.physical)||!x.physical.length)throw new Error('BOOT01_PHYSICAL_PLAN_REQUIRED');
  const fact=commitBoot01PublicFeature(state,{refId,featureType,scope,displayName});
  x.materializationConfirmed=true;
  b.boot01.geoObligation={...b.boot01.geoObligation,status:'MATERIALIZED',materializedAtGameTime:state.meta?.gameTime??0,materializationSource:'PLAYER_CONFIRMED_BY_FEATURE_COMMIT'};
  state.eventLog??=[];
  state.eventLog.push({type:'BOOT01_TABLE_MATERIALIZATION_CONFIRMED',gameTime:state.meta?.gameTime??0,refId:fact.REF_ID,featureType:fact.FEATURE_TYPE,scope:fact.SCOPE});
  x.narrative.push(`${fact.DISPLAY_NAME} queda inscrito en la geografía del mundo.`);
  x.visible.push(`${fact.DISPLAY_NAME} queda asociado a la geografía que ya has materializado sobre la mesa.`);
  return {displayName:fact.DISPLAY_NAME,instruction:`${fact.DISPLAY_NAME} queda fijado en ${fact.SCOPE} como parte de la geografía materializada.`};
}

export function finishBoot01PlayerExperience(state){
  const b=ensureBootState(state),x=b.boot01Player;
  if(x?.materializationConfirmed!==true||b.boot01?.geoObligation?.status!=='MATERIALIZED')throw new Error('BOOT01_TABLE_MATERIALIZATION_REQUIRED');
  const handoff=advanceBoot01ToBoot02(state);
  x.visible.push('La primera geografía queda fijada. El mundo recordará cómo nació cuando aparezca la vida.');
  return {phase:handoff.phase,visible:x.visible.at(-1),worldFact:clone(handoff.worldFact),geoObligation:clone(handoff.geoObligation)};
}

export function getBoot01PhysicalPlan(state){
  const x=ensureBootState(state).boot01Player;
  return x?.physical?clone(x.physical):[];
}

function publicTerritory(t){
  if(!t?.profile)return null; const p=t.profile;
  return {distribution:p.DISTRIBUCION_MASAS,fragmentation:p.FRAGMENTACION,relief:p.RELIEVE,littorality:p.LITORALIDAD,hydrographicPotential:p.POTENCIAL_HIDROGRAFICO,connectivity:p.CONECTIVIDAD_NATURAL,barriers:p.BARRERAS_NATURALES};
}
function territoryNarrative(p){
  const dist=p.DISTRIBUCION_MASAS==='CONCENTRADA'?'La materia se reúne en grandes extensiones':p.DISTRIBUCION_MASAS==='DISPERSA'?'La materia queda repartida en dominios separados':'Grandes masas y fragmentos menores comparten el mundo';
  const relief=['ABRUPTO','EXTREMO'].includes(p.RELIEVE)?'El relieve se alza y rompe los horizontes.':'El relieve deja amplios pasos entre sus elevaciones.';
  const sea=['ALTA','DOMINANTE'].includes(p.LITORALIDAD)?'El agua y los bordes costeros separan muchas regiones.':'Las tierras mantienen una continuidad extensa.';
  return `${dist}. ${relief} ${sea}`;
}
function territoryPhysicalPlan(p){
  const plan=[];
  plan.push(p.DISTRIBUCION_MASAS==='CONCENTRADA'?'Agrupa la mayor parte de las piezas de territorio en una masa principal.':p.DISTRIBUCION_MASAS==='DISPERSA'?'Separa las piezas de territorio en varias masas sin unirlas todas.':'Forma una masa principal y deja al menos un grupo territorial separado.');
  if(['ALTA','EXTREMA'].includes(p.FRAGMENTACION)) plan.push('Deja cortes visibles entre varias piezas: la fragmentación del mundo debe poder leerse en la mesa.');
  if(['ABRUPTO','EXTREMO'].includes(p.RELIEVE)) plan.push('Reserva bordes o pasos estrechos donde el relieve impida una conexión directa.');
  plan.push('No inventes clima, pueblos ni nombres todavía: solo materializa la forma territorial indicada.');
  return plan;
}