import {applyRuntimeAgencyActionR5} from './genesis-runtime-r5.js';
import {forecastNextCosmicEpochR520} from './genesis-causal-forecast-r520.js';
import {invisibleWorldOptionsR512} from './genesis-invisible-world-r512.js';
import {genesisCausalSituationR520,choiceForecastTextR520,forecastTextR520} from './genesis-player-facing-r520.js';
import {visibleGenesisCellR515} from './genesis-board-display-r515.js';
// GEN-R5.8 — Narrative-first Genesis Guionista. Earlier beats can become later causes.
export const GENESIS_GUI_SCHEMA='EMR_GENESIS_GUIONISTA_v3';
export const GENESIS_GUI_VOTE_R57_SCHEMA='EMR_GENESIS_GUI_VOTE_R57_v1';
export const GENESIS_GUI_SHARED_R58_SCHEMA='EMR_GENESIS_GUI_SHARED_DECISION_R58_v1';
const pick=(xs,n)=>xs[Math.abs(Number(n)||0)%xs.length];
const name=x=>x?.name||x?.publicName||x?.id||'algo aún sin nombre';
const ACTION_TEXT={PHYSICS:{ATTRACT:['La materia cercana cede a la atracción. Lo disperso empieza a buscar un centro.'],DISPERSE:['La materia se abre. Lo que iba a reunirse puede tomar otro destino.'],DISSIPATE_HEAT:['La agitación disminuye. Algo empieza a conservar forma.'],STABILIZE_RELATION:['Dos regiones adquieren una relación duradera.']},MYSTIC:{BIND:['Algo sin voluntad enlaza lo separado. La distancia ya no significa desconexión.'],TRANSFORM_RELATION:['El vínculo cambia de naturaleza. Lo que ocurra aquí podrá resonar en otra parte.']},WILL:{PRESERVE:['Una voluntad se niega a que esto desaparezca sin dejar rastro.'],CREATE:['Una voluntad introduce una posibilidad que antes no existía.'],TRANSFORM:['Una voluntad fuerza un cambio y acepta consecuencias que no controlará por completo.'],OPPOSE:['Una voluntad se enfrenta al curso que parecía inevitable. El universo tendrá que responder.']},NO_INTERVENE:['Nadie interviene. El universo continúa sin pedir permiso.']};
export function interpretGenesisAction({state,action,rng=0}){const agency=(state.agencies||[]).find(a=>a.id===action.agencyId)||{},target=(state.entities||state.bodies||[]).find(e=>e.id===action.targetId),op=action.operation||'NO_INTERVENE',text=pick(op==='NO_INTERVENE'?ACTION_TEXT.NO_INTERVENE:ACTION_TEXT[agency.kind]?.[op]||['Algo cambia, y el universo conservará la consecuencia.'],rng);return{schema:GENESIS_GUI_SCHEMA,type:'ACTION_INTERPRETATION',agencyId:agency.id||action.agencyId,operation:op,targetId:target?.id||null,publicText:target?`${text} ${name(target)} queda implicado.`:text,causalTags:[agency.kind||'UNIVERSE',op],materializationHint:materialization(op,target),memory:{causeId:action.id||null,agencyId:agency.id||null,targetId:target?.id||null,operation:op}};}
export function getGenesisDramaCandidates({state,round}={}){const history=(state?.eventLog||[]).filter(e=>!round||e.round===round),free=history.filter(e=>e.type==='FREE_ACTION'),ops=free.map(e=>e.operation),agencies=state?.agencies||[],will=agencies.filter(a=>a.kind==='WILL'),mystic=agencies.filter(a=>a.kind==='MYSTIC'),threats=state?.narrativeThreats||[],memory=state?.narrativeMemory||[],physical=state?.physicalSignals||[];const out=[];
 if(will.length>=2&&new Set(free.filter(e=>will.some(a=>a.id===e.agencyId)).map(e=>e.operation)).size>=2)out.push(beat('DIVINE_CONFLICT',100,'CONFLICT','Dos voluntades han intentado conducir la creación hacia cambios distintos. Eso crea una tensión jugable, pero todavía no inventa alianza, rivalidad ni jerarquía entre ellas.',{actors:will.map(a=>a.id),memoryTags:['WILL_CONFLICT'],decisionPrompt:'¿Qué decidís hacer estas Voluntades con la divergencia: cooperáis, pactáis, os oponéis explícitamente o dejáis que siga sin vínculo persistente?'}));
 if(mystic.length&&ops.includes('BIND')&&ops.includes('OPPOSE'))out.push(beat('LATENT_SPIRITUAL_MALICE',90,'THREAT','La oposición queda atrapada dentro de un vínculo. No posee todavía rostro ni nombre, pero algo hostil puede aprender a persistir allí donde el mundo recuerde.',{memoryTags:['LATENT_SPIRITUAL_THREAT','HIDDEN'],createsThreat:{id:`THREAT-SPIRIT-${round||1}`,kind:'SPIRITUAL_LATENT',status:'LATENT',knownToPlayers:false,createdRound:round||1},decisionPrompt:'Podéis intentar contener la huella, transformarla o ignorarla.'}));
 if(threats.some(t=>t.kind==='SPIRITUAL_LATENT'&&t.status==='LATENT'&&(t.createdRound??0)<(round||1)))out.push(beat('SPIRITUAL_STIRRING',95,'ESCALATION','Una huella antigua responde a los cambios de la creación. Lo que parecía un residuo empieza a comportarse como una amenaza. No nació ahora: esta consecuencia procede de una oposición que el mundo conservó.',{memoryTags:['SPIRITUAL_THREAT_ESCALATES','REMEMBERED_CAUSE'],decisionPrompt:'La amenaza aún puede ser contenida antes de adquirir una forma propia.'}));
 const oldConflict=[...memory].reverse().find(m=>(m.tags||[]).includes('WILL_CONFLICT')&&m.round<(round||1));
 if(oldConflict&&!ops.includes('NO_INTERVENE'))out.push(beat('DIVINE_CONFLICT_ECHO',88,'CONSEQUENCE','Una divergencia de una edad anterior no desapareció. Las nuevas intervenciones la vuelven relevante y permiten que, si los jugadores lo deciden mediante una causa real, se convierta ahora en pacto, cooperación, oposición o ruptura persistente.',{memoryTags:['WILL_CONFLICT_ECHO','REMEMBERED_CAUSE'],causeMemoryKind:oldConflict.kind,decisionPrompt:'La creación recuerda aquella divergencia: ¿queréis convertirla ahora en una relación real?'}));
 if(physical.some(x=>x.type==='INCOMING_BODY'||x.type==='METEOROID'))out.push(beat('INCOMING_METEOR',85,'PHYSICAL_CRISIS','Desde la oscuridad llega un cuerpo errante. Su trayectoria amenaza una formación existente y obliga a decidir si el universo seguirá su curso o alguien intervendrá.',{memoryTags:['PHYSICAL_CRISIS','INCOMING_BODY'],materializationHint:{instruction:'COLOCA_CUERPO_ENTRANTE',componentType:'PRIMORDIAL_BODY'},decisionPrompt:'Podéis desviarlo, aprovechar el impacto, proteger otro cuerpo o no intervenir.'}));
 if(ops.includes('ATTRACT')&&ops.includes('BIND'))out.push(beat('RESONANT_CONVERGENCE',70,'DISCOVERY','Mientras la materia se reúne, un vínculo atraviesa la separación. Lo que nazca de esta concentración no quedará aislado.',{memoryTags:['ATTRACT','BIND']}));
 if(ops.includes('DISPERSE')&&ops.includes('PRESERVE'))out.push(beat('PRESERVED_FRAGMENT',70,'PROMISE','La dispersión habría borrado una posibilidad, pero una voluntad conserva un fragmento. Su importancia todavía no puede conocerse.',{memoryTags:['DISPERSE','PRESERVE']}));
 if(ops.length&&ops.every(x=>x==='NO_INTERVENE'))out.push(beat('UNWATCHED_EVOLUTION',60,'CALM','Durante una edad nadie interviene. El universo escribe una parte de su historia sin testigos.',{memoryTags:['NO_INTERVENE']}));
 if(!out.length)out.push(beat('CAUSAL_AFTERSHOCK',20,'TRANSITION',pick(['Las intervenciones dejan de ser actos aislados. Sus consecuencias empiezan a encontrarse.','Pasa una edad. Algunas consecuencias se apagan; otras, inesperadamente, se refuerzan.'],round||0),{memoryTags:[...new Set(ops)]}));return out.sort((a,b)=>b.priority-a.priority||a.kind.localeCompare(b.kind));}
export function composeGenesisEvent({state,round,rng=0}){const candidates=getGenesisDramaCandidates({state,round}),top=candidates[0],ties=candidates.filter(x=>x.priority===top.priority),event=ties[Math.abs(Number(rng)||0)%ties.length];return{schema:GENESIS_GUI_SCHEMA,type:'NARRATIVE_EVENT',round:round||state?.genesisTurn?.round||1,kind:event.kind,dramaticRole:event.dramaticRole,publicText:event.publicText,decisionPrompt:event.decisionPrompt||null,materializationHint:event.materializationHint||null,createsThreat:event.createsThreat||null,memoryTags:event.memoryTags||[],causeMemoryKind:event.causeMemoryKind||null,debug:{candidateKinds:candidates.map(x=>x.kind),selectedPriority:event.priority}};}
export function applyGenesisNarrativeEvent(state,event){const s=structuredClone(state);s.narrativeMemory??=[];s.narrativeMemory.push({round:event.round,kind:event.kind,tags:event.memoryTags,publicText:event.publicText,causeMemoryKind:event.causeMemoryKind||null});if(event.createsThreat){s.narrativeThreats??=[];if(!s.narrativeThreats.some(t=>t.id===event.createsThreat.id))s.narrativeThreats.push(structuredClone(event.createsThreat));}return s;}
export function narrateCosmicPassage({fromLabel='el comienzo',toLabel='una edad posterior',event}){return `${fromLabel} queda atrás. ${toLabel}, ${event.publicText.charAt(0).toLowerCase()}${event.publicText.slice(1)}`;}

// R5.8 bridge: the Guionista frames one shared situation and freezes up to four
// meanings. Physical Intention cards keep every player's decision secret until
// simultaneous reveal. The full profile is resolved; there is no majority winner.
export function composeGenesisSharedDecisionR58(live){
 const represented=new Set((live?.players||[]).map(p=>p.nature)),round=live?.round||1,opts=[];
 const parcels=(live?.runtime?.cosmogony?.matter?.parcels||[]).filter(p=>['FREE','DISK'].includes(p.state));
 const free=parcels.filter(p=>p.state==='FREE');
 const planetValue=p=>Number(p.hidden?.refractories||0)+Number(p.hidden?.volatiles||0)+Number(p.hidden?.mass||0)/3;
 const starTarget=[...free].sort((a,b)=>Number(b.hidden?.mass||0)-Number(a.hidden?.mass||0)||a.id.localeCompare(b.id))[0]||null;
 const worldTarget=[...parcels].sort((a,b)=>planetValue(b)-planetValue(a)||a.id.localeCompare(b.id))[0]||null;
 const recent=(live?.history||[]).filter(e=>e.type==='GEN_LIVE_R5_AGENCY_CHOICE'&&e.round===round&&e.optionId!=='WAIT');
 const willPlayers=new Map((live?.players||[]).filter(p=>p.nature==='WILL').map(p=>[p.id,p]));
 const willActions=recent.filter(e=>willPlayers.has(e.playerId)).map(e=>{const [kind,targetId]=String(e.optionId||'').split(':');const agency=live.runtime.binding.agencies.find(a=>a.playerId===e.playerId);return{...e,kind,targetId,volitionEntityId:agency?.volitionEntityId||null};}).filter(x=>x.volitionEntityId&&x.targetId);
 const sharedTarget=findSharedWillTarget(willActions);
 let publicText='La creación ha cambiado con vuestras intervenciones. El Guionista reúne ahora consecuencias que pueden convertirse en decisiones distintas, compatibles o enfrentadas.';
 let decisionPrompt='Elegid en secreto una carta de Intención. Reveladlas a la vez. No buscáis una mayoría: el mundo resolverá el perfil completo de decisiones.';
 const add=x=>opts.push(x);
 const sharedLive={...live,phase:'AGENCY_ACTIONS'};
 const invisible=new Map();
 for(const agency of live?.runtime?.binding?.agencies||[]){
  for(const o of invisibleWorldOptionsR512(sharedLive,agency)){
   if(invisible.has(o.id))continue;
   const axis=o.primitive.startsWith('POST_MORTEM')?'POST_MORTEM':o.primitive.startsWith('REBIRTH')?'REBIRTH':o.primitive.startsWith('MORAL_CAUSALITY')?'MORAL_CAUSALITY':['JUDGMENT_AUTHORITY','IMPERSONAL_NORMATIVE_MECHANISM'].includes(o.primitive)?'JUDGMENT':o.primitive;
   invisible.set(o.id,{id:'JOINT-'+o.id,title:o.label,attempt:o.hint,consequence:o.publicText,effect:'INVISIBLE_WORLD',requiredNature:agency.nature,invisibleSpec:{option:o,playerId:agency.playerId,producerEntityId:agency.volitionEntityId||agency.mysticForceId||null,round},resolution:{targetKey:'INVISIBLE:'+axis,effectKey:o.id,cooperationKey:o.id,conflictKey:'INVISIBLE:'+axis},causalConsumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME']});
  }
 }
 const cellRef=id=>{const parcel=parcels.find(p=>p.id===id);return parcel?'la materia de la casilla '+visibleGenesisCellR515(live.runtime.cosmogony.board,parcel.cell):'la misma concentración de materia';};
 if(sharedTarget){
  const [a,b]=sharedTarget.actions.slice(0,2).sort((x,y)=>x.volitionEntityId.localeCompare(y.volitionEntityId));
  const samePurpose=a.kind===b.kind;publicText=`Dos Voluntades han actuado sobre ${cellRef(sharedTarget.targetId)}. El mundo recuerda ambos actos, pero todavía no existe entre ellas un vínculo persistente. Cada Voluntad puede intentar convertir esa coincidencia en una relación real o dejar que siga siendo solo una coincidencia.`;
  const relationType=samePurpose?'COOPERATES_WITH':'PACTED_WITH',effectKey=`VOLITION_RELATION:${relationType}:${a.volitionEntityId}:${b.volitionEntityId}`;
  add({id:`JOINT-VOLITION-RELATE:${a.volitionEntityId}:${b.volitionEntityId}`,title:samePurpose?'HACER DE LA COINCIDENCIA UNA COOPERACIÓN':'PACTAR SOBRE UNA CREACIÓN COMPARTIDA',attempt:samePurpose?'Convertir dos intervenciones compatibles sobre el mismo objetivo en cooperación persistente y limitada.':'Establecer un pacto concreto entre las dos Voluntades acerca del objetivo sobre el que ambas han intervenido.',effect:'VOLITION_RELATION',requiredNature:'WILL',relationSpec:{fromEntityId:a.volitionEntityId,toEntityId:b.volitionEntityId,type:relationType,symmetry:'SYMMETRIC',producerIds:[a.volitionEntityId,b.volitionEntityId,`GENESIS_SHARED_R${round}`],scope:`TARGET:${sharedTarget.targetId}`,provenance:`GENESIS_GUI_SHARED_R58:R${round}`,visibility:'PUBLIC',knownToPlayerIds:[a.playerId,b.playerId],futureConsumers:['BOOT03','FUTURE_BOOTS','RUNTIME']},resolution:{targetKey:`VOLITION_PAIR:${a.volitionEntityId}:${b.volitionEntityId}`,effectKey,cooperationKey:effectKey},causalConsumers:['BOOT03','FUTURE_BOOTS','RUNTIME']});
 }
 if(represented.has('PHYSICS')&&starTarget)add({id:'JOINT-STAR-FEED',title:'ALIMENTAR EL COLAPSO',attempt:'Favorecer que una concentración adecuada se incorpore a la formación estelar.',effect:'CONCENTRATE_BEST',requiredNature:'PHYSICS',resolution:{targetKey:`MAT:${starTarget.id}`,effectKey:'CONCENTRATE_BEST',cooperationKey:`STAR_FEED:${starTarget.id}`,conflictKey:`MATTER_DESTINY:${starTarget.id}`},causalConsumers:['BOOT01','FUTURE_BOOTS']});
 if((represented.has('PHYSICS')||represented.has('WILL'))&&worldTarget)add({id:'JOINT-PRESERVE-DISK',title:'PRESERVAR MATERIA PARA LOS MUNDOS',attempt:'Mantener una concentración valiosa fuera del colapso central para el futuro disco.',effect:'PRESERVE_BEST',requiredNature:represented.has('PHYSICS')?'PHYSICS':'WILL',resolution:{targetKey:`MAT:${worldTarget.id}`,effectKey:'PRESERVE_BEST',cooperationKey:`PRESERVE_WORLD:${worldTarget.id}`,conflictKey:`MATTER_DESTINY:${worldTarget.id}`},causalConsumers:['BOOT01','BOOT02','FUTURE_BOOTS']});
 if(represented.has('MYSTIC')&&worldTarget)add({id:'JOINT-MYSTIC-PERSIST',title:'HACER PERSISTIR UNA HUELLA',attempt:'Vincular una huella mística a materia con potencial de sobrevivir a la transformación.',effect:'IMPRINT_BEST',requiredNature:'MYSTIC',resolution:{targetKey:`MAT:${worldTarget.id}`,effectKey:'IMPRINT_BEST',cooperationKey:`MYSTIC_IMPRINT:${worldTarget.id}`},causalConsumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME']});
 if(represented.has('WILL')&&worldTarget)add({id:'JOINT-WILL-PROTECT',title:'PROTEGER UNA POSIBILIDAD',attempt:'Una Voluntad intenta preservar una concentración con futuro planetario.',effect:'PROTECT_BEST',requiredNature:'WILL',resolution:{targetKey:`MAT:${worldTarget.id}`,effectKey:'PROTECT_BEST',cooperationKey:`WILL_PROTECT:${worldTarget.id}`,conflictKey:`MATTER_DESTINY:${worldTarget.id}`},causalConsumers:['BOOT01','BOOT03','FUTURE_BOOTS','RUNTIME']});
 if(!opts.length&&parcels.length)add({id:'JOINT-CONTINUE-NATURAL',title:'DEJAR QUE LA FORMACIÓN CONTINÚE',attempt:'No imponer una dirección compartida adicional y permitir que la causalidad ya establecida siga actuando.',effect:'NONE',requiredNature:null,resolution:{targetKey:`GENESIS:R${round}`,effectKey:'CONTINUE_NATURAL',cooperationKey:`CONTINUE_NATURAL:R${round}`},causalConsumers:['BOOT01']});
 // Freeze one invisible question (including its incompatible alternatives) alongside
 // concrete material choices. The physical 1–4 deck remains a four-option contract.
 const invisibleRows=[...invisible.values()];
 const axis=invisibleRows[0]?.resolution.targetKey;
 const question=invisibleRows.filter(o=>o.resolution.targetKey===axis).slice(0,2);
 const required={CONCENTRATE_BEST:1,PRESERVE_BEST:4,PROTECT_BEST:1,IMPRINT_BEST:2};
 const material=opts.filter(o=>o.effect!=='VOLITION_RELATION'&&Number(live?.runtime?.signatureRecord?.signature?.[o.requiredNature]??6)>=(o.effect==='PRESERVE_BEST'&&o.requiredNature==='WILL'?1:required[o.effect]||0));
 const relation=opts.filter(o=>o.effect==='VOLITION_RELATION');
 const selected=[...relation,...question,...material].slice(0,4);
 for(const option of selected){
  const id=option.resolution?.targetKey?.startsWith('MAT:')?option.resolution.targetKey.slice(4):null;
  if(id){
   option.attempt=cellRef(id)+'. '+option.attempt;
   const actor=live.runtime.binding.agencies.find(a=>a.nature===option.requiredNature);
   const kind=({CONCENTRATE_BEST:'CONCENTRATE',PRESERVE_BEST:option.requiredNature==='WILL'?'PROTECT':'PRESERVE_DISK',PROTECT_BEST:'PROTECT',IMPRINT_BEST:'IMPRINT'})[option.effect];
   try{
    const baseline=forecastNextCosmicEpochR520(live.runtime.cosmogony);
    const runtime=applyRuntimeAgencyActionR5(live.runtime,{playerId:actor.playerId,kind,targetId:id,principle:kind==='IMPRINT'?'PERSISTENCE_TRACE':null});
    const branch=forecastNextCosmicEpochR520(runtime.cosmogony);
    option.attempt+=' '+forecastTextR520(live,baseline,{targetId:id});
    option.consequence=choiceForecastTextR520(live,{kind,targetId:id},{mode:'SIMULATED_MATERIAL_BRANCH',baseline,branch});
   }catch{option.consequence='La intervención se resolverá junto con las demás causas. No hay una proyección fiable para prometer un resultado concreto.';}
  }
 }
 const situation=live?.runtime?.cosmogony?genesisCausalSituationR520(live):null;
 if(!sharedTarget)publicText=[situation?.text,question.length?'Las intervenciones anteriores han abierto una posibilidad invisible. Puedes darle continuidad o dejarla sin resolver; la materia seguirá evolucionando.':'La siguiente intervención puede cambiar ese curso. La materia destinada al núcleo dejará de estar disponible para futuros mundos.'].filter(Boolean).join(' ');
 return{schema:GENESIS_GUI_SHARED_R58_SCHEMA,decisionId:`GENESIS-SHARED-R${round}`,actionZone:`GENESIS:R${round}`,round,narrative:{publicText,decisionPrompt,soloDecisionPrompt:question.length?'¿Qué posibilidad quieres hacer real? También puedes dejarla abierta.':'¿Cómo quieres intervenir en el próximo cambio del sistema?'},options:selected,noIntervene:{id:'JOINT-NO-INTERVENE',title:'NO INTERVENIR',attempt:'No añades una intervención a esta situación. Esto no veta las decisiones de los demás ni te impide presenciar lo que sea observable.'},truthContract:{worldTruthSeparate:true,playerVisibleSeparate:true,hiddenFactsAllowed:true,relationsRequirePlayedCause:true},consumerContract:{everyPersistedOutcomeNeedsConsumerOrHistoricalValue:true,targets:['BOOT01','BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME']}};
}

// Compatibility alias for R5.7 callers. Semantics are R5.8; do not interpret it as a vote.
export function composeGenesisJointVoteR57(live){return composeGenesisSharedDecisionR58(live);}

function findSharedWillTarget(actions){const groups=new Map();for(const a of actions){if(!groups.has(a.targetId))groups.set(a.targetId,[]);groups.get(a.targetId).push(a);}return[...groups.entries()].filter(([,xs])=>xs.length>=2).sort((a,b)=>b[1].length-a[1].length||a[0].localeCompare(b[0])).map(([targetId,xs])=>({targetId,actions:xs}))[0]||null;}
function beat(kind,priority,dramaticRole,publicText,extra={}){return{kind,priority,dramaticRole,publicText,...extra};}
function materialization(op,target){if(!target)return null;if(op==='ATTRACT')return{instruction:'ACERCA',targetId:target.id};if(op==='DISPERSE')return{instruction:'SEPARA',targetId:target.id};if(op==='PRESERVE')return{instruction:'MARCA_COMO_PRESERVADO',targetId:target.id};if(op==='BIND')return{instruction:'VINCULA',targetId:target.id};return null;}
