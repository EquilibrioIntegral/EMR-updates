import { SeededRng } from './rng.js';
import { evalCondition } from './conditions.js';
import { applyDeltas } from './delta.js';
import { makeState, serializeState, deserializeState, validateState } from './state.js';
import { GenerativeDirector } from './generative.js';
import { createMapState } from './map.js';
import { ingestWorldEventR512 } from './epistemic-propagation-r512.js';

function nowGame(state){ return state.meta.gameTime ?? 0; }
function worldEventTypeForPrimitive(primitive={}) {
  if (primitive.WORLD_EVENT_TYPE) return primitive.WORLD_EVENT_TYPE;
  const raw=primitive.FAMILY ?? primitive.CHANGE_SIGNATURE ?? primitive.PRIMITIVE_ID ?? 'WORLD_CHANGE';
  const token=String(raw).replace(/^PRIM-/,'').replace(/[^A-Za-z0-9]+/g,'_').replace(/^_+|_+$/g,'').toUpperCase() || 'WORLD_CHANGE';
  return `GEN_${token}`;
}
function generatedEventLocation(state,current={}) {
  const target=state.entities?.[current.targetId];
  if (target) return target.LOCATION_REF ?? (target.ENTITY_TYPE==='LOCATION'?current.targetId:null) ?? null;
  const relation=state.relations?.[current.targetId];
  if (relation) {
    const a=state.entities?.[relation.SOURCE_REF], b=state.entities?.[relation.TARGET_REF];
    return a?.LOCATION_REF ?? b?.LOCATION_REF ?? null;
  }
  const source=state.entities?.[current.sourceId];
  return source?.LOCATION_REF ?? (source?.ENTITY_TYPE==='LOCATION'?current.sourceId:null) ?? null;
}

export class HybridEngine {
  constructor(data, seed='EMR-A1-HYB') {
    this.data=data;
    this.state=makeState(data,seed);
    if (data.mapCatalog && !this.state.mapState) this.state.mapState=createMapState(data.mapCatalog);
    this.rng=new SeededRng(seed);
    this.traceSeq=1;
    this.generative=(data.gen04 && data.realizerV3) ? new GenerativeDirector({gen04:data.gen04,realizerV3:data.realizerV3}) : null;
  }

  static fromSave(data, text) {
    const state=deserializeState(text);
    const engine=new HybridEngine(data,state.meta.seed);
    engine.state=state;
    engine.state.session ??= {};
    engine.state.session.players ??= [];
    engine.state.session.physicalResults ??= [];
    engine.state.session.pendingPhysicalResolution ??= null;
    engine.state.session.boot ??= { phase: 'CI00_CHECK', ci00: {}, boot00: null, saveState0: null };
    if (data.mapCatalog && !engine.state.mapState) engine.state.mapState=createMapState(data.mapCatalog);
    if (Number.isFinite(state.meta?.rngState)) engine.rng.state=Number(state.meta.rngState) >>> 0;
    else {
      const n=(state.eventLog ?? []).filter(x=>x.type==='SELECT').length;
      for(let i=0;i<n;i++) engine.rng.next();
    }
    const maxTrace=(state.eventLog ?? []).reduce((m,x)=>{ const v=Number(String(x.TRACE_ID ?? '').replace('TRACE-','')); return Number.isFinite(v)?Math.max(m,v):m; },0);
    engine.traceSeq=maxTrace+1;
    return engine;
  }

  log(type,payload={}) {
    this.state.eventLog.push({
      TRACE_ID:`TRACE-${String(this.traceSeq++).padStart(4,'0')}`,
      type,
      gameTime:nowGame(this.state),
      turn:this.state.meta.turn,
      ...payload
    });
  }

  inferWitnesses(locationId) {
    if (!locationId) return [];
    const witnesses=[];
    for (const [entityId,entity] of Object.entries(this.state.entities ?? {})) {
      if (entity?.LOCATION_REF!==locationId) continue;
      if (!['ACTOR','NPC','PC','PLAYER'].includes(entity?.ENTITY_TYPE ?? '')) continue;
      witnesses.push({
        entityId,
        cultureId:entity.CULTURE_ID ?? entity.ATTRIBUTES?.cultureId ?? null,
        perceptionReliability:Number.isFinite(Number(entity.PERCEPTION_RELIABILITY))?Number(entity.PERCEPTION_RELIABILITY):1,
        public:false
      });
    }
    return witnesses;
  }

  recordWorldEvent(event={}) {
    const normalized={...event};
    normalized.id ??= `WE-${String(this.state.meta.turn).padStart(4,'0')}-${String(this.traceSeq).padStart(4,'0')}`;
    normalized.gameTime ??= nowGame(this.state);
    if (!Array.isArray(normalized.witnesses) || normalized.witnesses.length===0) normalized.witnesses=this.inferWitnesses(normalized.locationId);
    this.log('WORLD_EVENT_RECORDED',{
      worldEventId:normalized.id,
      worldEventType:normalized.type,
      locationId:normalized.locationId??null,
      witnessCount:normalized.witnesses.length,
      producerRef:normalized.producerRef??null,
      targetRef:normalized.targetRef??null,
      causeRef:normalized.causeRef??null,
      priorWorldEventId:normalized.priorWorldEventId??null,
      primitiveId:normalized.primitiveId??null,
      changeSignature:normalized.changeSignature??null
    });
    const epistemic=ingestWorldEventR512(this.state,normalized);
    if (epistemic.observation) this.log('WORLD_EVENT_EPISTEMIC_INGESTED',{worldEventId:normalized.id,observationId:epistemic.observation.id,memoryCount:epistemic.memories.length});
    return {event:normalized,...epistemic};
  }

  emitGeneratedWorldEvent(spec={}) {
    if (!spec?.type) return null;
    return this.recordWorldEvent({
      id:spec.id,
      type:spec.type,
      locationId:spec.locationId??null,
      observability:spec.observability??1,
      witnesses:spec.witnesses,
      producerRef:spec.producerRef??null,
      targetRef:spec.targetRef??null,
      causeRef:spec.causeRef??null,
      priorWorldEventId:spec.priorWorldEventId??null,
      primitiveId:spec.primitiveId??null,
      changeSignature:spec.changeSignature??null
    });
  }

  loadModule(moduleId) {
    const module=this.data.modules.find(m=>m.MODULE_ID===moduleId);
    if (!module) throw new Error(`MODULE_NOT_FOUND:${moduleId}`);
    const allowed=new Set(module.ALLOWED_KERNEL_OPS ?? []);
    for (const required of ['K-01','K-02','K-03','K-04','K-05','K-06','K-07']) {
      if (!allowed.has(required)) throw new Error(`MODULE_MISSING_KERNEL_OP:${required}`);
    }
    this.module=module;
    this.log('K-01 LOAD_MODULE',{moduleId});
    return module;
  }

  readState() {
    if (!this.module) throw new Error('MODULE_NOT_LOADED');
    const visible={};
    for (const [id,obj] of Object.entries(this.state.entities ?? {})) {
      if (obj.VISIBILITY !== 'HIDDEN') visible[id]=obj;
    }
    this.log('K-02 READ_STATE',{visibleEntityCount:Object.keys(visible).length});
    return visible;
  }

  queryCandidates(triggerType='ANY') {
    const candidates=this.data.scenes.filter(s =>
      (s.moduleId===this.module.MODULE_ID || s.moduleId==='*') &&
      (s.triggerTypes?.includes(triggerType) || s.triggerTypes?.includes('ANY'))
    );
    this.log('K-03 QUERY_CANDIDATES',{triggerType,candidateRefs:candidates.map(x=>x.id)});
    return candidates;
  }

  filterLegal(candidates) {
    const accepted=[], rejected=[];
    for (const scene of candidates) {
      const cd=this.state.sceneCooldowns?.[scene.id];
      if (cd != null && nowGame(this.state) < cd) {
        rejected.push({id:scene.id,reason:`COOLDOWN:${cd}`});
        continue;
      }
      const c=evalCondition(this.state,scene.conditions);
      if (!c.ok) { rejected.push({id:scene.id,reason:c.reason}); continue; }
      const hiddenLeak=(scene.bindRefs ?? []).find(id=>this.state.entities?.[id]?.VISIBILITY==='HIDDEN' || this.state.facts?.[id]?.VISIBILITY==='HIDDEN');
      if (hiddenLeak) { rejected.push({id:scene.id,reason:`HIDDEN_REF:${hiddenLeak}`}); continue; }
      accepted.push(scene);
    }
    this.log('K-04 FILTER_LEGAL',{legalRefs:accepted.map(x=>x.id),rejected});
    return accepted;
  }

  select01N(legal) {
    if (!legal.length) { this.log('K-05 SELECT_01N',{returnCode:'ZERO'}); return null; }
    const maxPriority=Math.max(...legal.map(x=>Number(x.priority ?? 0)));
    const top=legal.filter(x=>Number(x.priority ?? 0)===maxPriority);
    const selected=top.length===1 ? top[0] : this.rng.pickWeighted(top, x=>x.weight ?? 1);
    this.log('SELECT',{selectedRef:selected.id,legalCount:legal.length,topRefs:top.map(x=>x.id)});
    return selected;
  }

  realize(scene) {
    const realization={
      sceneId:scene.id,
      title:scene.title,
      text:scene.text,
      physical:scene.physical ?? [],
      choices:scene.choices.map(c=>({id:c.id,label:c.label,inputKind:c.inputKind ?? 'DECISION'}))
    };
    this.log('N-04/N-05 REALIZE_EMIT',{sceneId:scene.id});
    this.state.currentSceneId=scene.id;
    return realization;
  }

  nextSituation(triggerType='ANY') {
    if (!this.module) this.loadModule('M-HYB-VS01');
    this.readState();
    const candidates=this.queryCandidates(triggerType);
    const legal=this.filterLegal(candidates);
    const selected=this.select01N(legal);
    if (!selected) {
      this.log('K-07 RETURN_CONTROL',{returnCode:'ZERO'});
      return {returnCode:'ZERO', situation:null};
    }
    return {returnCode:'RETURN_OK', situation:this.realize(selected)};
  }

  resolveChoice(sceneId, choiceId) {
    const scene=this.data.scenes.find(s=>s.id===sceneId);
    if (!scene) throw new Error(`SCENE_NOT_FOUND:${sceneId}`);
    const choice=scene.choices.find(c=>c.id===choiceId);
    if (!choice) throw new Error(`CHOICE_NOT_FOUND:${choiceId}`);
    this.log('PLAYER_RESOLUTION',{sceneId,choiceId});
    applyDeltas(this.state,choice.deltas ?? []);
    this.log('K-06 APPLY_DELTA',{deltaIds:(choice.deltas ?? []).map(x=>x.DELTA_ID)});
    if (scene.cooldown) this.state.sceneCooldowns[sceneId]=nowGame(this.state)+scene.cooldown;
    this.state.history.push({sceneId,choiceId,gameTime:nowGame(this.state)});
    this.state.meta.turn += 1;
    this.state.currentSceneId=null;
    this.updateLifecycle();
    this.log('K-07 RETURN_CONTROL',{returnCode:'RETURN_OK'});
    return this.state;
  }

  updateLifecycle() {
    for (const [id,p] of Object.entries(this.state.promises ?? {})) {
      if (p.STATUS==='PENDING' && p.MATURITY_TIME != null && nowGame(this.state) >= p.MATURITY_TIME) {
        p.STATUS='MATURE';
        this.log('N-07 ADVANCE_LIFECYCLE',{ref:id,from:'PENDING',to:'MATURE'});
      }
    }
    for (const ev of this.state.eventQueue ?? []) {
      if (ev.status==='PENDING' && nowGame(this.state) >= ev.dueTime) {
        ev.status='ELIGIBLE';
        this.log('EVENT_MATURED',{eventId:ev.id});
      }
      if (ev.status==='ELIGIBLE' && ev.worldEventType && ev.epistemicProcessed!==true) {
        this.recordWorldEvent({id:ev.id,type:ev.worldEventType,locationId:ev.locationId??null,observability:ev.observability??1,witnesses:ev.witnesses});
        ev.epistemicProcessed=true;
      }
    }
  }

  advanceTime(amount=1) {
    applyDeltas(this.state,[{
      DELTA_ID:`DELTA-TIME-${this.state.meta.turn}-${nowGame(this.state)}`,
      CAUSE_REF:'SYSTEM-TIME', OPERATION:'ADVANCE_TIME', TARGET_REF:'WORLD-TIME', AFTER:Number(amount), AUTHORITY_ID:'ENGINE-TIME'
    }]);
    this.updateLifecycle();
    return this.state.meta.gameTime;
  }

  installGenerativeFixture(fixture) {
    if (!this.generative) throw new Error('GENERATIVE_DATA_NOT_LOADED');
    return this.generative.installFixture(this.state,fixture);
  }

  nextGeneratedSituation() {
    if (!this.generative) throw new Error('GENERATIVE_DATA_NOT_LOADED');
    return this.generative.makeSituation(this);
  }

  resolveGeneratedChoice(sceneId,choiceId) {
    if (!this.generative) throw new Error('GENERATIVE_DATA_NOT_LOADED');
    const current=this.state.generative?.current ? structuredClone(this.state.generative.current) : null;
    const primitive=current ? this.data.gen04?.primitives?.find(p=>p.PRIMITIVE_ID===current.primitiveId) : null;
    const result=this.generative.resolve(this,sceneId,choiceId);
    if (choiceId==='ALLOW' && current && primitive) {
      const rawObservability=Number(primitive.OBSERVABILITY);
      this.emitGeneratedWorldEvent({
        id:`WE-${current.sceneId}`,
        type:worldEventTypeForPrimitive(primitive),
        locationId:generatedEventLocation(this.state,current),
        observability:Number.isFinite(rawObservability)?rawObservability:1,
        producerRef:current.sourceId,
        targetRef:current.targetId,
        causeRef:current.sceneId,
        priorWorldEventId:current.contextWorldEventId??null,
        primitiveId:current.primitiveId,
        changeSignature:primitive.CHANGE_SIGNATURE??null
      });
    }
    return result;
  }

  saveText() {
    this.state.meta.rngState=this.rng.state >>> 0;
    const errors=validateState(this.state);
    if (errors.length) throw new Error(`STATE_INVALID:${errors.join(',')}`);
    return serializeState(this.state);
  }
}