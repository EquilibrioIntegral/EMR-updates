import {primordialEmergenceNarrative,signatureNarrativeHierarchy,universeSignatureExplanation} from './genesis-signature-narrative.js';
import {primordialActorNameR513,visibleGenesisCellR513} from './genesis-player-facing-r513.js';
import {genesisCausalSituationR520} from './genesis-player-facing-r520.js';

export const GENESIS_PLAYER_FACING_R516='EMR_GENESIS_PLAYER_FACING_R516_v1';

export function genesisWorldBriefR516(live){
  const c=live?.runtime?.cosmogony,temporal=cosmicTimeNarrativeR516(live);
  if(!c)return{title:'El sistema está naciendo',text:`${temporal} La app conserva el estado físico oculto del sistema y solo mostrará cambios con valor jugable.`,next:'El universo seguirá evolucionando aunque nadie intervenga.'};
  const free=c.matter?.parcels?.filter(p=>p.state==='FREE')||[];
  const disk=c.matter?.parcels?.filter(p=>p.state==='DISK')||[];
  const starMass=Number(c.star?.mass||0);
  const phase=c.phase||'COLLAPSE';
  if(phase==='COLLAPSE'){
    const board=c.board,center=board?.center;
    const cellFor=p=>board?.cells?.find(cell=>cell.code===p.cell)||null;
    const near=free.filter(p=>{const cell=cellFor(p);return center&&cell&&hexDistance(cell,center)<=2;}).length;
    const orbital=free.filter(p=>Number(p.hidden?.angularMomentum||0)>=5).length;
    const massive=free.filter(p=>Number(p.hidden?.mass||0)>=5).length;
    const fallback=starMass>0?'Si no intervienes, la acreción seguirá aumentando la masa y la energía del núcleo hasta acercarlo a la ignición.':'Si no intervienes, la materia seguirá cayendo, calentándose y redistribuyéndose; parte puede quedar en órbita en vez de terminar en la estrella.';
    return{title:'La nube está colapsando',text:`${temporal} La gravedad está concentrando materia hacia la región central. ${near?`${near} concentraciones ya están cerca del núcleo.`:'El núcleo todavía está reuniendo masa.'}${massive?` ${massive} reservas son especialmente masivas.`:''}${orbital?` ${orbital} tienden a conservar movimiento suficiente para alimentar un futuro disco.`:''}`,next:exactNextR520(live,fallback)};
  }
  if(phase==='DISK')return{title:'La estrella ya ha nacido',text:`${temporal} El núcleo ha entrado en ignición como ${stellarFamilyLabelR516(c.star?.family)}. La materia que no quedó atrapada en la estrella está reorganizándose en un disco.`,next:exactNextR520(live,`Quedan ${disk.length} concentraciones de materia capaces de condicionar los cuerpos que se formen después.`)};
  if(phase==='PLANETS'||phase==='CLOSED')return{title:'El disco está formando mundos',text:`${temporal} La estrella estable condiciona ahora el reparto térmico y orbital del sistema. La materia remanente está formando ${c.planets?.length||0} cuerpo${(c.planets?.length||0)===1?'':'s'} planetario${(c.planets?.length||0)===1?'':'s'}.`,next:exactNextR520(live,'Masa, composición, distancia, historia térmica e intervenciones anteriores quedarán en la genealogía del mundo elegido.')};
  return{title:'El sistema sigue evolucionando',text:`${temporal} La materia continúa respondiendo a gravedad, colisiones, energía y a las causas extraordinarias que existan.`,next:exactNextR520(live,'No intervenir nunca congela el universo.')};
}

export function genesisOriginNarrativeR516(live){
  const sig=live?.runtime?.signatureRecord||{};
  const hierarchy=signatureNarrativeHierarchy(sig);
  const origin=hierarchy.originNature||hierarchy.ordered?.[0]||null;
  const named=(live?.players||[]).find(p=>p.controller!=='APP'&&p.nature===origin&&p.primordialNarrativeRef);
  return primordialEmergenceNarrative({...sig,namedOriginRef:named?primordialActorNameR513(named):null});
}

export function universeSignatureBriefR516(live){
  const signature=live?.runtime?.signatureRecord?.signature||live?.entryProvenance?.signature||{PHYSICS:0,MYSTIC:0,WILL:0};
  const effectiveCount=Number(live?.entryProvenance?.soloEmergence?.effectiveCount||live?.players?.length||1);
  const context={signature:{...signature},mode:live?.entryProvenance?.mode,soloEmergence:live?.entryProvenance?.soloEmergence||null};
  return{signature:{...signature},effectiveCount,label:`Física / Mística / Voluntad: ${Number(signature.PHYSICS||0)} / ${Number(signature.MYSTIC||0)} / ${Number(signature.WILL||0)}`,explanation:universeSignatureExplanation(signature,context)};
}

export function universeAwakeningIllustrationR516(){
  const nodes=[[120,115,9],[235,190,14],[350,115,7],[465,255,18],[585,155,11],[720,235,15],[805,110,7],[170,390,12],[330,345,8],[540,395,13],[690,360,9],[805,430,11]];
  const stars=Array.from({length:52},(_,i)=>`<circle cx="${(i*173)%860+20}" cy="${(i*97)%520+20}" r="${i%4===0?2:1}" opacity="${i%3===0?.85:.5}"/>`).join('');
  const bubbles=nodes.map(([x,y,r],i)=>`<g><circle cx="${x}" cy="${y}" r="${r*3}" fill="none" stroke="#d7b56b" stroke-opacity=".18"/><circle cx="${x}" cy="${y}" r="${r}" fill="#f4dda0" opacity=".85"/><circle cx="${x+18}" cy="${y-12}" r="${Math.max(2,r/3)}" fill="#fff4c9" opacity=".7"/></g>${i<nodes.length-1?`<path d="M${x} ${y} Q${(x+nodes[i+1][0])/2} ${(y+nodes[i+1][1])/2-45} ${nodes[i+1][0]} ${nodes[i+1][1]}" fill="none" stroke="#9f83c8" stroke-width="${2+(i%3)}" stroke-opacity=".34"/>`:''}`).join('');
  return `<svg class="genesis-book-illustration" viewBox="0 0 900 560" role="img" aria-label="El universo joven expandiéndose y formando sus primeras estructuras" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="awake-bg" cx="48%" cy="52%"><stop offset="0" stop-color="#4d315f"/><stop offset=".5" stop-color="#17152d"/><stop offset="1" stop-color="#050812"/></radialGradient><filter id="awake-glow"><feGaussianBlur stdDeviation="7" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="900" height="560" fill="url(#awake-bg)"/><g fill="#ffffff">${stars}</g><g filter="url(#awake-glow)">${bubbles}</g><path d="M60 300 C180 240 260 285 375 245 S590 210 845 300" fill="none" stroke="#d9b46b" stroke-opacity=".18" stroke-width="18"/><path d="M85 455 C245 385 420 470 560 410 S735 365 855 390" fill="none" stroke="#6f58a0" stroke-opacity=".22" stroke-width="24"/></svg>`;
}

export function stellarFamilyLabelR516(family){return ({M_RED_DWARF:'una estrella roja pequeña y longeva',K_ORANGE:'una estrella anaranjada estable',G_YELLOW:'una estrella amarilla de masa intermedia',F_A_WHITE_YELLOW:'una estrella blanca-amarillenta caliente',B_O_BLUE_MASSIVE:'una estrella azul muy masiva y energética'})[family]||'una estrella estable';}

export function cosmicTimeNarrativeR516(live){
  const clock=live?.cosmicClock,tick=Number(clock?.tick||0),epoch=Number(live?.runtime?.cosmogony?.epoch||0),phase=live?.runtime?.cosmogony?.phase||'COLLAPSE';
  if(tick<=0)return'El tiempo cósmico apenas ha comenzado a contarse.';
  if(phase==='COLLAPSE'&&epoch===0)return tick===1?'Ha transcurrido un primer intervalo cósmico.':'Han transcurrido varios intervalos mientras la nube continúa reorganizándose.';
  if(phase==='COLLAPSE')return'Mucho tiempo después, el colapso sigue transformando el sistema.';
  if(phase==='DISK')return'Tras una larga evolución, la estrella ya organiza el sistema que la rodea.';
  return'La historia cósmica del sistema ya abarca varias etapas de formación.';
}

export function identityConfirmationCopyR516(profile={}){
  if(profile.kind!=='WILL')return null;
  const named=Boolean(profile.trueName),anthropomorphic=profile.manifestation==='ANTHROPOMORPHIC',gender=profile.grammaticalGender||'UNSPECIFIED',name=profile.trueName||'';
  if(anthropomorphic&&gender==='MASCULINE'&&named)return`El Dios ${name} ha fijado un nombre y una forma en la verdad del mundo. Muchísimo tiempo después, ese nombre podrá ser invocado, temido, olvidado o deformado, y su figura podrá manifestarse entre los seres del mundo. Pero lo ocurrido aquí seguirá formando parte de su historia.`;
  if(anthropomorphic&&gender==='MASCULINE')return'Un Dios primordial ha fijado su forma en la verdad del mundo, pero ha permanecido sin nombre. Muchísimo tiempo después, podrá manifestarse entre los seres del mundo aunque nadie recuerde cómo fue llamado por primera vez. Pero lo ocurrido aquí seguirá formando parte de su historia.';
  if(anthropomorphic&&gender==='FEMININE'&&named)return`La Diosa ${name} ha fijado un nombre y una forma en la verdad del mundo. Muchísimo tiempo después, ese nombre podrá ser venerado, deformado, olvidado o susurrado, y su figura podrá manifestarse entre los seres del mundo. Pero lo ocurrido aquí seguirá formando parte de su historia.`;
  if(anthropomorphic&&gender==='FEMININE')return'Una Diosa primordial ha fijado su forma en la verdad del mundo, pero ha permanecido sin nombre. Muchísimo tiempo después, podrá manifestarse entre los seres del mundo aunque nadie conserve el nombre que nunca quiso revelar. Pero lo ocurrido aquí seguirá formando parte de su historia.';
  if(anthropomorphic&&named)return`La Deidad ${name} ha fijado un nombre y una forma en la verdad del mundo. Muchísimo tiempo después, ese nombre podrá ser recordado, transformado u olvidado, y su presencia podrá manifestarse entre los seres del mundo bajo una forma reconocible. Pero lo ocurrido aquí seguirá formando parte de su historia.`;
  if(anthropomorphic)return'Una deidad primordial ha fijado su forma en la verdad del mundo, pero ha permanecido sin nombre. Muchísimo tiempo después, podrá manifestarse entre los seres del mundo aunque ninguna palabra llegue a contenerla por completo. Pero lo ocurrido aquí seguirá formando parte de su historia.';
  if(named)return`La Voluntad ${name} ha fijado su nombre en la verdad del mundo, pero no ha adoptado una forma antropomorfa. Muchísimo tiempo después, su presencia podrá sentirse, interpretarse o temerse, aunque jamás llegue a encarnarse como una figura humana. Pero lo ocurrido aquí seguirá formando parte de su historia.`;
  return'Una Voluntad primordial ha entrado en la verdad del mundo sin nombre y sin forma antropomorfa. Muchísimo tiempo después, su presencia podrá intuirse en signos, presagios y fuerzas invisibles, aunque nadie pueda señalar un rostro ni un nombre verdaderos. Pero lo ocurrido aquí seguirá formando parte de su historia.';
}

export function identityIllustrationR516(profile={}){
  const kind=profile.kind||'';let illustration;
  if(kind==='MYSTIC')illustration=mysticSvg();else if(kind==='WILL'&&profile.manifestation==='ANTHROPOMORPHIC')illustration=humanoidSvg(profile.grammaticalGender||'UNSPECIFIED');else if(kind==='WILL')illustration=willSvg();else illustration=cosmicSvg();
  const copy=identityConfirmationCopyR516(profile);if(!copy)return illustration;
  return `${illustration}<style>.genesis-identity-copy + .genesis-copy{display:none}</style><p class="genesis-copy genesis-identity-copy">${escapeHtml(copy)}</p>`;
}

export function setupActorLineR516(live,player,position){const board=live?.runtime?.cosmogony?.board||null;return `${primordialActorNameR513(player)} — casilla ${visibleGenesisCellR513(position,board)}`;}
function exactNextR520(live,fallback){try{return genesisCausalSituationR520(live)?.text||fallback;}catch{return fallback;}}
function hexDistance(a,b){const aq=Number(a?.q)||0,ar=Number(a?.r)||0,bq=Number(b?.q)||0,br=Number(b?.r)||0;return (Math.abs(aq-bq)+Math.abs(ar-br)+Math.abs((aq+ar)-(bq+br)))/2;}
function escapeHtml(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function shell(inner,label){return `<svg class="genesis-book-illustration" viewBox="0 0 900 560" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="g" cx="50%" cy="42%"><stop offset="0" stop-color="#d7b56b" stop-opacity=".9"/><stop offset=".3" stop-color="#5e4d82" stop-opacity=".5"/><stop offset="1" stop-color="#080b18"/></radialGradient></defs><rect width="900" height="560" fill="url(#g)"/><g fill="#fff" opacity=".75">${Array.from({length:28},(_,i)=>`<circle cx="${(i*137)%870+15}" cy="${(i*83)%520+20}" r="${i%3+1}"/>`).join('')}</g>${inner}</svg>`;}
function humanoidSvg(gender='UNSPECIFIED'){const feminine=gender==='FEMININE',masculine=gender==='MASCULINE',curve=feminine?72:masculine?55:63,label=feminine?'Una deidad primordial antropomorfa femenina':masculine?'Una deidad primordial antropomorfa masculina':'Una deidad primordial antropomorfa';return shell(`<g transform="translate(450 280)" fill="none" stroke="#f2d58c" stroke-width="8" stroke-linecap="round"><circle cy="-105" r="58" fill="#c59b5d" fill-opacity=".22"/><path d="M0-45 C-${curve} 10 -85 105 -95 205 M0-45 C${curve} 10 85 105 95 205 M-68 32 L68 32 M-95 205 L-38 88 M95 205 L38 88"/><circle cy="-105" r="92" stroke-opacity=".25"/></g>`,label);}
function willSvg(){return shell('<g transform="translate(450 280)" fill="none" stroke="#f3d690" stroke-width="7"><path d="M-180 20 C-105-150 70-160 180-20 C75 120-80 155-180 20Z"/><path d="M-85 5 C-25-65 55-60 92 10 C35 72-34 70-85 5Z"/><circle r="18" fill="#f3d690"/><path d="M0-220 V-120 M0 120 V220 M-250 0 H-150 M150 0 H250" stroke-opacity=".5"/></g>','Una Voluntad primordial no antropomorfa');}
function mysticSvg(){return shell('<g transform="translate(450 280)" fill="none" stroke="#c8b6ff" stroke-width="6" opacity=".9"><path d="M-230 0 C-160-190 -30 190 40 0 S220-170 245 25"/><path d="M-220 70 C-120-90 -20 210 85 50 S205-80 235 80" stroke-opacity=".55"/><circle cx="-120" cy="-30" r="18"/><circle cx="105" cy="10" r="13"/></g>','Una fuerza mística primordial');}
function cosmicSvg(){return shell('<circle cx="450" cy="280" r="110" fill="#f3d690" fill-opacity=".22" stroke="#f3d690" stroke-width="5"/><circle cx="450" cy="280" r="165" fill="none" stroke="#f3d690" stroke-opacity=".35" stroke-width="3"/>','Una presencia primordial');}
