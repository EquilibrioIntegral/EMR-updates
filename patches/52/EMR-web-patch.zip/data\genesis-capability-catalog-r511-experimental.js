export const GENESIS_CAPABILITY_CATALOG_R511_EXPERIMENTAL_SCHEMA='EMR_GENESIS_CAPABILITY_CATALOG_R511_EXPERIMENTAL_v1';
export const GENESIS_CAPABILITY_CATALOG_R511_STATUS='PROPOSAL_NOT_CANONICAL';

const E={
 ladder:'D-GEN-R5.3-POWER-LADDER01',
 r51:'GENESIS_R5_1_CONTRATO_ONTOLOGICO_Y_HANDOFF_BOOT_APROBADO_2026-09-08',
 r3:'GENESIS_R3_ACCIONES_CIERRE_Y_CONSUMIDORES',
 stellar:'GENESIS_R5_CONTRATO_ESTELAR_MATERIA_PRIMORDIAL_BORRADOR_2026-09-08',
 r510:'D-GEN-R5.10-SPATIAL-AGENCY01'
};

const CAPABILITIES=[
 {id:'PHYSICS-1-CONCENTRATE',nature:'PHYSICS',requiredLevel:1,package:'CONCENTRATE',verbs:['ATTRACT','CONCENTRATE'],reach:'LOCAL',remotePermission:'NONE',gates:['ELIGIBLE_MATTER','PHYSICAL_CAUSALITY'],evidenceRefs:[E.r3,E.stellar],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'PHYSICS-2-REDISTRIBUTE',nature:'PHYSICS',requiredLevel:2,package:'REDISTRIBUTE',verbs:['DISPERSE','SEPARATE','REDISTRIBUTE'],reach:'LOCAL',remotePermission:'NONE',gates:['ELIGIBLE_MATTER','PHYSICAL_CAUSALITY'],evidenceRefs:[E.r3,E.stellar],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'PHYSICS-3-TRANSFER-ENERGY',nature:'PHYSICS',requiredLevel:3,package:'TRANSFER_ENERGY',verbs:['DISSIPATE','COOL','HEAT'],reach:'CAPABILITY_SPECIFIC',remotePermission:'CAPABILITY_SPECIFIC',gates:['ENERGY_TRANSFER_MECHANISM','DOMAIN_SUPPORTS_EFFECT'],evidenceRefs:[E.r3,E.stellar,E.r510],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'PHYSICS-4-STABILIZE-CAPTURE',nature:'PHYSICS',requiredLevel:4,package:'STABILIZE_CAPTURE',verbs:['STABILIZE','CAPTURE'],reach:'CAPABILITY_SPECIFIC',remotePermission:'CAPABILITY_SPECIFIC',gates:['DYNAMIC_RELATION_ELIGIBLE','DOMAIN_SUPPORTS_EFFECT'],evidenceRefs:[E.r3,E.stellar,E.r510],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'PHYSICS-5-NUCLEAR-CHANGE',nature:'PHYSICS',requiredLevel:5,package:'ACTIVATE_NUCLEAR_CHANGE',verbs:['ACTIVATE_NUCLEAR_CHANGE'],reach:'LOCAL',remotePermission:'NONE',gates:['COMPOSITION_ELIGIBLE','PRESSURE_ELIGIBLE','TEMPERATURE_ELIGIBLE'],evidenceRefs:[E.stellar],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'PHYSICS-6-SYSTEMIC-APPLICATION',nature:'PHYSICS',requiredLevel:6,package:'SYSTEMIC_APPLICATION',verbs:['APPLY_UNLOCKED_PHYSICAL_CAPABILITY_SYSTEMICALLY'],reach:'INHERITED',remotePermission:'INHERITED_ONLY',gates:['CONNECTED_ELIGIBLE_TARGET_SET','LOWER_CAPABILITY_UNLOCKED'],evidenceRefs:[E.ladder,E.r51,E.r510],evidenceStrength:'PROPOSAL_SYNTHESIS'},

 {id:'MYSTIC-1-BIND',nature:'MYSTIC',requiredLevel:1,package:'BIND',verbs:['BIND'],reach:'LOCAL_ADJACENT',remotePermission:'NONE',gates:['MYSTIC_SUBSTRATE_PRESENT','ELIGIBLE_REFERENTS'],evidenceRefs:[E.r51,E.r3],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'MYSTIC-2-PERSIST-IMPRINT',nature:'MYSTIC',requiredLevel:2,package:'PERSIST_IMPRINT',verbs:['PERSIST','IMPRINT'],reach:'LOCAL',remotePermission:'NONE',gates:['MYSTIC_SUBSTRATE_PRESENT','TRANSFORMATION_OR_REFERENT_ELIGIBLE'],evidenceRefs:[E.r51,E.stellar],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'MYSTIC-3-RESONATE-MARK',nature:'MYSTIC',requiredLevel:3,package:'RESONATE_MARK',verbs:['RESONATE','MARK'],reach:'MYSTIC_TOPOLOGY',remotePermission:'CAPABILITY_SPECIFIC',gates:['MYSTIC_SUBSTRATE_PRESENT','ESTABLISHED_MYSTIC_TOPOLOGY_OR_LINK'],evidenceRefs:[E.r51,E.r510],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'MYSTIC-4-CONDITIONAL-TRANSFORM',nature:'MYSTIC',requiredLevel:4,package:'CONDITIONAL_TRANSFORM',verbs:['TRANSFORM'],reach:'LOCAL_OR_LINKED',remotePermission:'CAPABILITY_SPECIFIC',gates:['CONCRETE_MYSTIC_PRINCIPLE','ACTIVATION_CONDITION'],evidenceRefs:[E.r51,E.stellar,E.r510],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'MYSTIC-5-CYCLE-ENTANGLE',nature:'MYSTIC',requiredLevel:5,package:'CYCLE_ENTANGLE',verbs:['CREATE_CYCLE','ENTANGLE_CAUSALITIES'],reach:'MYSTIC_TOPOLOGY',remotePermission:'CAPABILITY_SPECIFIC',gates:['MYSTIC_SUBSTRATE_PRESENT','ESTABLISHED_MYSTIC_TOPOLOGY_OR_LINK'],evidenceRefs:[E.r51,E.stellar,E.r510],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'MYSTIC-6-BRIDGE-CONSCIOUSNESS-MATTER',nature:'MYSTIC',requiredLevel:6,package:'BRIDGE_CONSCIOUSNESS_MATTER',verbs:['CONNECT_CONSCIOUSNESS_MATTER'],reach:'ONTOLOGICAL_RELATIONAL',remotePermission:'NON_SPATIAL',gates:['SUBSTRATE_ALLOWS_CONSCIOUSNESS_INTERACTION','ONTOLOGY_COMPATIBLE'],evidenceRefs:[E.r51],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},

 {id:'WILL-1-PROTECT-CLAIM-REJECT',nature:'WILL',requiredLevel:1,package:'PROTECT_CLAIM_REJECT',verbs:['PROTECT','CLAIM','REJECT'],reach:'LOCAL_ADJACENT',remotePermission:'NONE',gates:['VOLITION_ENTITY','ELIGIBLE_REFERENT','DOMAIN_COMPATIBLE'],evidenceRefs:[E.r51,E.ladder],evidenceStrength:'RECOVERED_BAND_PROPOSED_LEVEL'},
 {id:'WILL-2-DESIGNATE-IMPRINT-PURPOSE',nature:'WILL',requiredLevel:2,package:'DESIGNATE_IMPRINT_PURPOSE',verbs:['DESIGNATE','IMPRINT_PURPOSE','BLESS','CURSE'],reach:'LOCAL_ADJACENT',remotePermission:'NONE',gates:['VOLITION_ENTITY','PRODUCER_CONSUMER_CONTRACT','DOMAIN_COMPATIBLE'],evidenceRefs:[E.r51,E.ladder],evidenceStrength:'RECOVERED_BAND_PROPOSED_LEVEL'},
 {id:'WILL-3-REVEAL-HIDE',nature:'WILL',requiredLevel:3,package:'REVEAL_HIDE',verbs:['REVEAL','HIDE'],reach:'ONTOLOGICAL_RELATIONAL',remotePermission:'NON_SPATIAL',gates:['VOLITION_ENTITY','KNOWLEDGE_RELATION_ELIGIBLE'],evidenceRefs:[E.r51],evidenceStrength:'RECOVERED_FAMILY_PROPOSED_LEVEL'},
 {id:'WILL-4-PACT-OPPOSE-RELATE',nature:'WILL',requiredLevel:4,package:'PACT_OPPOSE_RELATE',verbs:['PACT','OPPOSE_VOLITION','ESTABLISH_RELATION'],reach:'RELATIONAL',remotePermission:'NON_SPATIAL',gates:['VOLITION_ENTITY','LEGAL_RELATION_TARGET','DOMAIN_COMPATIBLE'],evidenceRefs:[E.r51,E.ladder],evidenceStrength:'RECOVERED_BAND_PROPOSED_LEVEL'},
 {id:'WILL-5-AUTOLIMIT-CONTINUITY',nature:'WILL',requiredLevel:5,package:'AUTOLIMIT_CONTINUITY',verbs:['AUTOLIMIT','GRANT_CONTINUITY','DENY_CONTINUITY'],reach:'SELF_ONTOLOGICAL',remotePermission:'NON_SPATIAL',gates:['VOLITION_ENTITY','DOMAIN_OR_ORIGIN_AUTHORITY'],evidenceRefs:[E.r51,E.ladder],evidenceStrength:'DOCUMENT_AMBIGUITY_EXPLICIT_PROPOSAL'},
 {id:'WILL-6-DECREE-EMANATE',nature:'WILL',requiredLevel:6,package:'DECREE_EMANATE',verbs:['DECREE_LAW','EMANATE_VOLITION'],reach:'ONTOLOGICAL',remotePermission:'NON_SPATIAL',gates:['VOLITION_ENTITY','COSMOGONIC_OR_CREATOR_AUTHORITY'],evidenceRefs:[E.r51,E.ladder],evidenceStrength:'RECOVERED_HIGH_BAND_PROPOSED_LEVEL'}
];

export const GENESIS_CAPABILITY_CATALOG_R511_PROPOSAL=Object.freeze(CAPABILITIES.map(x=>Object.freeze({...x,verbs:Object.freeze([...x.verbs]),gates:Object.freeze([...x.gates]),evidenceRefs:Object.freeze([...x.evidenceRefs])})));

export function proposedCapabilitiesForR511(nature,intensity){
 if(!['PHYSICS','MYSTIC','WILL'].includes(nature))throw new Error('GEN_R511_NATURE_INVALID');
 if(!Number.isInteger(intensity)||intensity<0||intensity>6)throw new Error('GEN_R511_INTENSITY_INVALID');
 return GENESIS_CAPABILITY_CATALOG_R511_PROPOSAL.filter(c=>c.nature===nature&&c.requiredLevel<=intensity);
}

export function proposedRemoteCapR511(capability,intensity){
 if(!capability||!GENESIS_CAPABILITY_CATALOG_R511_PROPOSAL.some(c=>c.id===capability.id))throw new Error('GEN_R511_CAPABILITY_UNKNOWN');
 if(!Number.isInteger(intensity)||intensity<0||intensity>6)throw new Error('GEN_R511_INTENSITY_INVALID');
 if(intensity<capability.requiredLevel)return null;
 if(capability.remotePermission!=='CAPABILITY_SPECIFIC')return null;
 return intensity<=2?1:intensity<=4?2:3;
}

export function proposalMetadataR511(){
 return{schema:GENESIS_CAPABILITY_CATALOG_R511_EXPERIMENTAL_SCHEMA,status:GENESIS_CAPABILITY_CATALOG_R511_STATUS,liveIntegrated:false,decisionRequired:true,count:GENESIS_CAPABILITY_CATALOG_R511_PROPOSAL.length};
}
