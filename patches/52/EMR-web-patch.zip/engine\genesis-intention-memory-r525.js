import {primordialActorNameR513} from './genesis-player-facing-r513.js';
import {recordRevealedLiveIntentionsR5 as recordLegacyIntentionsR5} from './genesis-live-r510-legacy.js';

export const GENESIS_INTENTION_MEMORY_R525='EMR_GENESIS_INTENTION_MEMORY_R525_v1';

/**
 * P10 contract.
 * Public declarations are safe to project to the player. APP commitments and motives
 * live in a private ledger. actualSlot is exposed only as a non-enumerable compatibility
 * property so the existing R5.24 UI can seed contextual.simulatedCommitments without
 * persisting the secret inside playerFacingFlow.publicIntentions.
 */
export function publicAndHiddenIntentionsR525(live){
  const options=[...(live?.contextual?.options||[])];
  const players=live?.players||[];
  const decisionId=String(live?.contextual?.decisionId||`GEN-R${live?.round||1}`);
  const publicRows=[];
  const privateRows=[];

  for(const p of players){
    const ranked=rankOptionsForNature(options,p.nature);
    const publicSlot=String(ranked[0]?.slot??'N');
    let actualSlot=publicSlot;
    let reasonCode='ALIGNED_PRIMARY_PRIORITY';

    if(p.controller==='APP'){
      const roll=hash(`${live.seed}:${live.round}:${decisionId}:${p.id}:PRIVATE_INTENTION`)%5;
      if(roll===0&&ranked[1]){
        actualSlot=String(ranked[1].slot);
        reasonCode='PRIVATE_SECONDARY_PRIORITY';
      }else if(roll===1){
        actualSlot='N';
        reasonCode='PRIVATE_RESTRAINT';
      }
    }

    const publicRow={playerId:p.id,actor:primordialActorNameR513(p),nature:p.nature,publicSlot,controller:p.controller,publicReason:publicReason(p.nature,ranked[0])};
    Object.defineProperty(publicRow,'actualSlot',{value:actualSlot,enumerable:false,writable:false,configurable:false});
    publicRows.push(publicRow);

    if(p.controller==='APP')privateRows.push({
      schema:GENESIS_INTENTION_MEMORY_R525,
      round:Number(live.round||1),decisionId,playerId:p.id,actor:primordialActorNameR513(p),nature:p.nature,
      publicSlot,actualSlot,aligned:actualSlot===publicSlot,reasonCode,hiddenReason:hiddenReason(reasonCode,p.nature),visibility:'PRIVATE_UNTIL_REVEAL'
    });
  }

  if(live?.contextual)live.contextual.privateIntentLedgerR525=privateRows;
  return publicRows;
}

/** Wrap the established R5.8 reveal/resolution input without replacing it. */
export function recordRevealedLiveIntentionsR525(live,selections=[]){
  return applyIntentMemoryAfterRevealR525(live,recordLegacyIntentionsR5(live,selections));
}

/** Pure-enough finalizer used by the live wrapper and directly by P10 QA fixtures. */
export function applyIntentMemoryAfterRevealR525(before,revealedState){
  const n=structuredClone(revealedState);
  const decisionId=String(before?.contextual?.decisionId||n?.jointPlan?.decisionId||`GEN-R${before?.round||1}`);
  const privateRows=[...(before?.contextual?.privateIntentLedgerR525||[])];
  const publicRows=[...(before?.playerFacingFlow?.publicIntentions||[])];
  const revealed=new Map((n.revealedSelections||[]).map(x=>[x.playerId,String(x.slot)]));
  const publicById=new Map(publicRows.map(x=>[x.playerId,x]));
  const privateById=new Map(privateRows.map(x=>[x.playerId,x]));

  n.intentMemoryR525??={schema:GENESIS_INTENTION_MEMORY_R525,entries:[],relationshipSeeds:[]};
  const existing=new Set(n.intentMemoryR525.entries.map(x=>`${x.round}:${x.decisionId}:${x.playerId}`));

  for(const p of n.players||[]){
    const publicRow=publicById.get(p.id);
    const privateRow=privateById.get(p.id);
    const actualSlot=String(revealed.get(p.id)??privateRow?.actualSlot??'N');
    const publicSlot=String(publicRow?.publicSlot??privateRow?.publicSlot??actualSlot);
    const key=`${Number(before?.round||1)}:${decisionId}:${p.id}`;
    if(existing.has(key))continue;
    const aligned=actualSlot===publicSlot;
    n.intentMemoryR525.entries.push({
      schema:GENESIS_INTENTION_MEMORY_R525,round:Number(before?.round||1),decisionId,playerId:p.id,actor:primordialActorNameR513(p),controller:p.controller,nature:p.nature,
      publicSlot,actualSlot,aligned,declarationObserved:true,voteObserved:true,motiveKnown:false,
      hiddenReasonCode:privateRow?.reasonCode||null,hiddenReason:privateRow?.hiddenReason||null
    });
    existing.add(key);

    if(p.controller==='APP'&&!aligned){
      const seedId=`INTENT-DIVERGENCE:${key}`;
      if(!n.intentMemoryR525.relationshipSeeds.some(x=>x.id===seedId))n.intentMemoryR525.relationshipSeeds.push({
        id:seedId,type:'DECLARATION_DIVERGENCE',sourceId:p.id,round:Number(before?.round||1),decisionId,publicSlot,actualSlot,
        observedBy:(n.players||[]).filter(x=>x.id!==p.id).map(x=>x.id),motiveKnown:false,status:'LATENT'
      });
    }
  }

  n.history??=[];
  n.history.push({
    type:'GEN_R525_INTENTION_MEMORY_RECORDED',round:Number(before?.round||1),decisionId,
    entries:n.intentMemoryR525.entries.filter(x=>x.round===Number(before?.round||1)&&x.decisionId===decisionId).map(x=>({playerId:x.playerId,publicSlot:x.publicSlot,actualSlot:x.actualSlot,aligned:x.aligned})),
    divergenceSeedIds:n.intentMemoryR525.relationshipSeeds.filter(x=>x.round===Number(before?.round||1)&&x.decisionId===decisionId).map(x=>x.id)
  });
  return n;
}

export function intentRevealNarrativeR525(live){
  const round=Number(live?.round||1);
  const decisionId=String(live?.jointPlan?.decisionId||live?.contextual?.decisionId||'');
  const entries=(live?.intentMemoryR525?.entries||[]).filter(x=>x.round===round&&(!decisionId||x.decisionId===decisionId));
  return entries.map(x=>x.aligned
    ?`${x.actor} mantuvo la intención que había anunciado.`
    :`${x.actor} había anunciado la opción ${x.publicSlot}, pero al revelarse la decisión eligió ${x.actualSlot}. El cambio es observable; el motivo no lo es.`);
}

function rankOptionsForNature(options,nature){
  const score=o=>{
    let s=o.requiredNature===nature?20:o.requiredNature?0:5;
    const k=String(o.effect||o.id||'');
    if(nature==='PHYSICS'&&/CONCENTRATE|PRESERVE|PHYS|STAR|ENERGY|STABIL/i.test(k))s+=8;
    if(nature==='MYSTIC'&&/INVISIBLE|IMPRINT|MYSTIC|BIND|RESON|CYCLE|CONDITIONAL/i.test(k))s+=8;
    if(nature==='WILL'&&/VOLITION|PROTECT|RELATION|PURPOSE|MORAL|JUDG|POST_MORTEM|REBIRTH/i.test(k))s+=8;
    return s;
  };
  return [...options].sort((a,b)=>score(b)-score(a)||String(a.id).localeCompare(String(b.id)));
}

function publicReason(n,o){
  if(!o)return'No encuentra una intervención que considere propia y se inclina por no intervenir.';
  if(n==='PHYSICS')return'Busca una evolución material coherente con su manera de actuar sobre masa, energía, estabilidad y trayectoria.';
  if(n==='MYSTIC')return'Busca dejar una regla o vínculo invisible que pueda sobrevivir a la transformación de la materia.';
  return'Busca introducir una decisión consciente, una relación o un propósito que pueda tener consecuencias futuras.';
}

function hiddenReason(code,nature){
  if(code==='PRIVATE_RESTRAINT')return nature==='WILL'?'Prefiere reservar su voluntad antes que comprometerla en esta situación.':nature==='MYSTIC'?'Su regla invisible favorece no fijar todavía una transformación.':'Su prioridad material favorece dejar actuar al sistema sin añadir otra perturbación.';
  if(code==='PRIVATE_SECONDARY_PRIORITY')return nature==='WILL'?'Su interés privado favorece una relación o consecuencia distinta de la que declaró.':nature==='MYSTIC'?'Una segunda prioridad invisible pesa más en su compromiso real que en su declaración pública.':'Una prioridad material secundaria pesa más en su compromiso real que en su declaración pública.';
  return'La prioridad que expresa públicamente coincide con su compromiso real.';
}

function hash(s){let h=2166136261>>>0;for(const ch of String(s)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0;}return h>>>0;}
