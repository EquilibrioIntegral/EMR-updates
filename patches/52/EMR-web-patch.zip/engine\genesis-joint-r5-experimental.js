// Experimental resolver for GEN-R5 joint Intention calibration.
// NOT CANONICAL. Keeping this module separate prevents a balance hypothesis from
// silently becoming an A1 rule. Physical cards determine direction; S/A/V remains
// ontological authority and is never summed by player count.

export const GENESIS_JOINT_R5_EXPERIMENTAL_SCHEMA='EMR_GENESIS_JOINT_R5_EXPERIMENTAL_v1';

export function resolveRevealedJointDirectionR5({options=[],selections=[],tieDie=null}={}){
 if(!Array.isArray(options)||!Array.isArray(selections)||!selections.length)throw new Error('GEN_JOINT_R5_INPUT_REQUIRED');
 const bySlot=new Map(options.map(o=>[String(o.slot),o]));
 const counts=new Map();let noIntervene=0;
 for(const s of selections){const slot=String(s.slot);if(slot==='N'){noIntervene++;continue;}if(!bySlot.has(slot))throw new Error('GEN_JOINT_R5_SLOT_ILLEGAL');counts.set(slot,(counts.get(slot)||0)+1);}
 if(counts.size===0)return{schema:GENESIS_JOINT_R5_EXPERIMENTAL_SCHEMA,experimental:true,mode:'NO_INTERVENE',winner:null,noIntervene,selections:[...selections]};
 const max=Math.max(...counts.values()),leaders=[...counts.entries()].filter(([,n])=>n===max).map(([slot])=>slot).sort((a,b)=>Number(a)-Number(b));
 let chosen=leaders[0],dieUsed=false;
 if(leaders.length>1){if(!Number.isInteger(tieDie)||tieDie<1||tieDie>6)return{schema:GENESIS_JOINT_R5_EXPERIMENTAL_SCHEMA,experimental:true,mode:'TIE_DIE_REQUIRED',leaders,counts:Object.fromEntries(counts),noIntervene};chosen=leaders[(tieDie-1)%leaders.length];dieUsed=true;}
 return{schema:GENESIS_JOINT_R5_EXPERIMENTAL_SCHEMA,experimental:true,mode:leaders.length>1?'PLURALITY_TIE_DIE':'PLURALITY',winner:{...bySlot.get(chosen)},counts:Object.fromEntries(counts),noIntervene,dieUsed,tieDie:dieUsed?tieDie:null,selections:[...selections],warning:'Reference calibration only; G6 remains open until authority/cooperation resolution is approved.'};
}
