import {storySituation} from './genesis-story.js';
import {EPISODES,BODY_LABELS} from '../data/genesis-director.js';
import {hexDistance} from './primordial-gravity.js';
export const bodyLabel=id=>BODY_LABELS[id]||'el cuerpo presente';
const hash=s=>{let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;};
// Same pipeline as the GPF contract: STATE -> legal focus -> scope/relevance ->
// dramatic change -> Realizer -> consequence -> memory/promise. No runtime NPC fixture.
export function directGenesis(s){
 const masses=Object.values(s.gravity.masses),c=[];
 for(let i=0;i<masses.length;i++)for(let j=i+1;j<masses.length;j++){
  const a=masses[i],b=masses[j],d=hexDistance(a,b);c.push({kind:d===1?'CONTACT':'APPROACH',a:a.id,b:b.id,score:d===1?30:20,reason:`distance=${d}`});
 }
 for(const p of s.promises.filter(p=>p.status==='MATURE'&&s.gravity.masses[p.target]))c.push({kind:'CALLBACK',a:p.target,score:200,origin:p.origin,promiseId:p.id,reason:'PROMISE_MATURE'});
 if(s.signature.MYSTIC>0)for(const m of masses)if(!s.imprints.some(x=>x.target===m.id))c.push({kind:'IMPRINT',a:m.id,score:25,reason:'IMPERSONAL_POTENTIAL'});
 if(s.signature.WILL>0)for(const m of masses)if(!s.preserved.includes(m.id))c.push({kind:'PRESERVE',a:m.id,score:24,reason:'PERSISTENT_INDIVIDUALITY'});
 if(!c.length)c.push({kind:'SETTLE',a:masses[0]?.id,score:10,reason:'FORMATION_EXISTS'});
 const recent=s.scenes.slice(-2).map(x=>x.kind);
 for(const x of c)x.score-=recent.includes(x.kind)?15:0;
 c.sort((a,b)=>b.score-a.score||hash(`${s.seed}:${s.round}:${a.kind}:${a.a}:${a.b}`)-hash(`${s.seed}:${s.round}:${b.kind}:${b.a}:${b.b}`));
 const narrative=storySituation(s);if(narrative)c.push({kind:'STORY',a:narrative.focus,score:narrative.kind==='REVELATION'?120:65+(narrative.pressure||1)*5,reason:'PERSISTENT_AGENT_PURPOSE_AND_THREAD',narrative});c.sort((a,b)=>b.score-a.score);
 const selected=c[0],template=selected.narrative?{texts:[selected.narrative.text],title:selected.narrative.title,need:'CONFLICT'}:EPISODES[selected.kind],cause=s.memory.find(m=>m.id===selected.origin)?.text||'';
 let text=template.texts[hash(`${s.seed}:${s.round}:${selected.a}`)%template.texts.length];
 text=text.replaceAll('{a}',bodyLabel(selected.a)).replaceAll('{b}',bodyLabel(selected.b)).replaceAll('{cause}',cause);
 const linkedReveal=selected.kind==='CALLBACK'&&narrative?.kind==='REVELATION'&&narrative.focus===selected.a?narrative:null;
 if(linkedReveal)text=`${cause} ${linkedReveal.text}`.trim();
 // Selection does not manufacture a new event or add thread pressure.
 // Its physical consumer is the convergence subject and spatial presence.
 if(selected.kind!=='CALLBACK'&&s.memory.length)text=s.memory.at(-1).text+' '+text;
 const scene={id:`G${s.round}`,kind:selected.narrative?.kind||selected.kind,title:template.title,text,focus:selected.a,secondary:selected.b||null,promiseId:selected.promiseId||null,causeRefs:selected.narrative?.causeRefs||(selected.origin?[selected.origin]:s.memory.slice(-1).map(m=>m.id)),threadId:selected.narrative?.threadId||linkedReveal?.threadId||null,transformations:linkedReveal?['CALLBACK','REVELATION']:[selected.narrative?.kind||selected.kind]};
 s.trace.push({event:'DIRECT',sceneId:scene.id,legalCandidates:c,selected:{...selected},need:template.need});
 s.scenes.push(scene);s.scene=scene;const revealId=selected.narrative?.revealId||linkedReveal?.revealId;if(revealId){s.story.reveals.find(r=>r.secretId===revealId).consumed=true;}
 if(selected.promiseId){const promise=s.promises.find(p=>p.id===selected.promiseId);promise.status='CONSUMED';promise.consumedBy=scene.id;s.trace.push({event:'CALLBACK_EFFECT',scene:scene.id,origin:promise.origin,trigger:promise.triggerEvent,consumer:'CONVERGENCE_SUBJECT_AND_PRESENCE',target:promise.target});}
 return scene;
}
