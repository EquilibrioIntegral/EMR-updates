import {queryPrimordialCandidates,selectPrimordialIntentions,resolvePrimordialAction,applyPrimordialResolution,serializePrimordialState,deserializePrimordialState} from './primordial-causal.js';
import {getPrimordialSituation} from './primordial-grid.js';
import {compilePrimordialLegacyV2} from './primordial-legacy-v2.js';
import {reconcilePrimordialPlanetSelection,getPrimordialPlanetClosureStatus} from './primordial-planet.js';
const clone=x=>JSON.parse(JSON.stringify(x));
const activeResidues=s=>(s.residues||[]).filter(r=>r.status==='ACTIVE');

export function beginPrimordialLoop(state){
 const s=clone(state); s.primordialLoop??={scene:0,phase:'S01',trace:[],causalDomains:[],resultTags:[]};
 return compilePrimordialScene(s);
}

export function compilePrimordialScene(state,{actorEntityId=null,targetEntityId=null}={}){
 const candidates=queryPrimordialCandidates(state,{actorEntityId,targetEntityId});
 return {state:clone(state),situation:getPrimordialSituation(state),intentions:selectPrimordialIntentions(candidates),rejected:candidates.filter(c=>!c.legal).map(c=>({id:c.id,reasons:c.rejectionReasons}))};
}

export function resolvePrimordialScene(state,{action,roll}){
 let s=applyPrimordialResolution(state,resolvePrimordialAction(state,{action,roll}));
 s.primordialLoop??={scene:0,phase:'S01',trace:[],causalDomains:[],resultTags:[]};
 s.primordialLoop.scene+=1;
 s.primordialLoop.trace.push({scene:s.primordialLoop.scene,transformId:action.transformId,domain:action.causalDomain??action.domain,outcome:s.history.at(-1)?.outcome,deltaId:s.history.at(-1)?.deltaId});
 const domain=action.causalDomain??action.domain; if(domain&&!s.primordialLoop.causalDomains.includes(domain))s.primordialLoop.causalDomains.push(domain);
 const tag=s.deltas.at(-1)?.resultTag; if(tag&&!s.primordialLoop.resultTags.includes(tag))s.primordialLoop.resultTags.push(tag);
 s=reconcilePrimordialPlanetSelection(s);
 s.primordialLoop.phase=evaluatePrimordialProgression(s).phase;
 return {state:s,progress:evaluatePrimordialProgression(s)};
}

export function evaluatePrimordialProgression(state){
 const loop=state.primordialLoop??{scene:0,causalDomains:[],resultTags:[]};
 const persistent=(state.deltas||[]).length+activeResidues(state).length;
 const diversity=new Set([...(loop.causalDomains||[]),...(loop.resultTags||[])]).size;
 if(loop.scene<2)return {phase:'S01',canClose:false,reasons:['INSUFFICIENT_SCENES']};
 if(loop.scene<4||persistent<4)return {phase:'S02',canClose:false,reasons:['CAUSAL_DEVELOPMENT_INCOMPLETE']};
 if(diversity<3)return {phase:'S03',canClose:false,reasons:['CAUSAL_DIVERSITY_INCOMPLETE']};
 const planet=getPrimordialPlanetClosureStatus(state);
 if(!planet.ready)return {phase:'S03',canClose:false,reasons:planet.reasons,planetCandidates:planet.candidates};
 return {phase:'S03',canClose:true,reasons:[],selectedPlanet:planet.selectedPlanet,planetCandidates:planet.candidates};
}

export function compilePrimordialLegacy(state,{seedKind='PHYSICS'}={}){
 const reconciled=reconcilePrimordialPlanetSelection(state);
 const progress=evaluatePrimordialProgression(reconciled); if(!progress.canClose)throw new Error(`PRIMORDIAL_CLOSURE_NOT_READY:${progress.reasons.join(',')}`);
 const selectedPlanetId=progress.selectedPlanet?.id??reconciled.selectedPlanetId;
 if(!selectedPlanetId)throw new Error('PRIMORDIAL_SELECTED_PLANET_REQUIRED');
 const legacy=compilePrimordialLegacyV2(reconciled,{focusBodyId:selectedPlanetId,seedKind});
 legacy.common.selectedPlanetId=selectedPlanetId;
 legacy.common.selectedPlanet=clone(progress.selectedPlanet);
 const s=clone(reconciled);s.selectedPlanetId=selectedPlanetId;s.phase='PRIMORDIAL_CLOSED';s.primordialLoop.phase='CLOSED';s.consumables??=[];s.consumables.push(clone(legacy));return {state:s,legacy};
}

export function savePrimordialLoop(state,{gameVersion='A1-HYB',build='DEV'}={}){return JSON.stringify({SCHEMA_VERSION:'EMR_PRIMORDIAL_LOOP_SAVE_v1',GAME_VERSION:gameVersion,BUILD:build,SEED:state.seed,STATE:JSON.parse(serializePrimordialState(state))});}
export function loadPrimordialLoop(json){const x=JSON.parse(json);if(x.SCHEMA_VERSION!=='EMR_PRIMORDIAL_LOOP_SAVE_v1')throw new Error('PRIMORDIAL_LOOP_SAVE_SCHEMA_INVALID');const s=deserializePrimordialState(JSON.stringify(x.STATE));if(x.SEED!==s.seed)throw new Error('PRIMORDIAL_LOOP_SAVE_SEED_MISMATCH');return s;}
