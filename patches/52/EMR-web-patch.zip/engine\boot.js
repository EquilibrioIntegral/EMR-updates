const CAUSAL_LABEL={1:'SOLO LEYES NATURALES',2:'SOBRENATURAL SIN VOLUNTAD',3:'SOBRENATURAL CON AGENCIA'};
function checkD6(x,code='CI03_D6_INVALID'){ x=Number(x); if(!Number.isInteger(x)||x<1||x>6) throw new Error(code); return x; }
export function resolveCi03Solo(chosen,dice=[]){
  chosen=Number(chosen); if(![1,2,3].includes(chosen)) throw new Error('CI03_CHOICE_INVALID');
  if(!Array.isArray(dice)||dice.length<2) throw new Error('CI03_SOLO_TWO_D6_REQUIRED');
  const sig={1:0,2:0,3:0}; sig[chosen]=3; const order=[chosen%3+1,(chosen+1)%3+1]; const used=new Set([3]);
  const trace=[];
  order.forEach((opt,i)=>{ const d=checkD6(dice[i]); let v=0; if((d===1||d===2)&&!used.has(d)){v=d; used.add(d);} sig[opt]=v; trace.push({option:opt,die:d,value:v}); });
  return {mode:'SOLO',chosen,signature:sig,labels:CAUSAL_LABEL,dice:dice.slice(0,2).map(Number),trace,next:'PRIMORDIAL_GUIÓN_S01'};
}
export function resolveCi03Multi(choices,dice=[]){
  if(!Array.isArray(choices)||choices.length<2||choices.length>4) throw new Error('CI03_PLAYER_COUNT_INVALID');
  const vals=choices.map(Number); if(vals.some(x=>![1,2,3].includes(x))) throw new Error('CI03_CHOICE_INVALID');
  const counts={1:0,2:0,3:0}; vals.forEach(x=>counts[x]++); const ranked=[]; let pool=[1,2,3], di=0;
  while(pool.length){ const max=Math.max(...pool.map(x=>counts[x])); let tied=pool.filter(x=>counts[x]===max); let pick;
    if(tied.length===1) pick=tied[0];
    else if(tied.length===2){ const d=checkD6(dice[di++],'CI03_TIE_D6_REQUIRED'); pick=d<=3?Math.min(...tied):Math.max(...tied); }
    else { const d=checkD6(dice[di++],'CI03_TRIPLE_TIE_D6_REQUIRED'); pick=d<=2?1:d<=4?2:3; }
    ranked.push(pick); pool=pool.filter(x=>x!==pick);
  }
  const sig={1:0,2:0,3:0}; [3,2,1].forEach((v,i)=>sig[ranked[i]]=v);
  return {mode:'MULTI',choices:vals,counts,ranking:ranked,signature:sig,labels:CAUSAL_LABEL,dice:dice.slice(0,di).map(Number),next:'PRIMORDIAL_GUIÓN_S01'};
}
export function compilePrimordialConfig(result){
  return {version:'EMR-PRIMORDIAL-CONFIG-0.2',causalSignature:result.signature,causalFamilies:{1:CAUSAL_LABEL[1],2:CAUSAL_LABEL[2],3:CAUSAL_LABEL[3]},routeCapacity:{1:result.signature[1],2:result.signature[2],3:result.signature[3]},next:result.next};
}
export function ensureBootState(state){ state.session??={}; state.session.boot??={phase:'CI00_CHECK',ci00:{},ci03:null,primordialConfig:null}; return state.session.boot; }
export function setBootPhase(state,phase,patch={}){ const b=ensureBootState(state); b.phase=phase; Object.assign(b,patch); return b; }

const BOOT01_LABEL={1:'EXTENDER',2:'QUEBRAR',3:'ENTRELAZAR'};
export function resolveBoot01Intentions(intentions,die=null){
  if(!Array.isArray(intentions)||intentions.length<1||intentions.length>4) throw new Error('BOOT01_PLAYER_COUNT_INVALID');
  const vals=intentions.map(Number); if(vals.some(x=>![1,2,3].includes(x))) throw new Error('BOOT01_INTENTION_INVALID');
  const unique=[...new Set(vals)].sort((a,b)=>a-b); let winner;
  if(unique.length===1) winner=unique[0];
  else { die=Number(die); if(!Number.isInteger(die)||die<1||die>6) throw new Error('BOOT01_D6_REQUIRED'); if(unique.length===2) winner=die<=3?unique[0]:unique[1]; else winner=die<=2?1:die<=4?2:3; }
  return {id:winner,label:BOOT01_LABEL[winner],intentions:vals,die:unique.length===1?null:die,secondary:unique.filter(x=>x!==winner).map(x=>BOOT01_LABEL[x]),authorityOrder:['HARD','INTENTION','RNG']};
}
function ord(v,arr){ const i=arr.indexOf(String(v).toUpperCase()); if(i<0) throw new Error('BOOT01_PROFILE_DOMAIN_INVALID:'+v); return i; }
export function rankBoot01LegalSet(legalSet,intent,entropy=0){
  if(!Array.isArray(legalSet)||legalSet.length===0) return {ok:false,reason:'NO_LEGAL_SET'};
  intent=String(intent).toUpperCase(); if(!['EXTENDER','QUEBRAR','ENTRELAZAR'].includes(intent)) throw new Error('BOOT01_INTENT_INVALID');
  const score=p=>{ const f=ord(p.fragmentation??p.FRAGMENTACION,['BAJA','MEDIA','ALTA','EXTREMA']); const b=ord(p.barriers??p.BARRERAS,['BAJAS','MEDIAS','ALTAS']); const c=ord(p.connectivity??p.CONECTIVIDAD,['ABIERTA','CORREDORES','COMPARTIMENTADA','AISLADA']); if(intent==='EXTENDER') return f+b+c; if(intent==='QUEBRAR') return (3-f)+(2-b)+(3-c); return Math.abs(f-1)+Math.abs(b-1)+Math.abs(c-1); };
  const scored=legalSet.map((p,i)=>({p,i,cost:score(p)})); const min=Math.min(...scored.map(x=>x.cost)); const best=scored.filter(x=>x.cost===min).sort((a,b)=>String(a.p.id??a.i).localeCompare(String(b.p.id??b.i))); const idx=((Number(entropy)||0)%best.length+best.length)%best.length;
  return {ok:true,intent,minCost:min,bestCount:best.length,index:idx,selected:best[idx].p,trace:{legalCount:legalSet.length,bestIds:best.map(x=>x.p.id??x.i),entropy:Number(entropy)||0}};
}

const BT_DOMAINS={
  DISTRIBUCION_MASAS:['CONCENTRADA','MIXTA','DISPERSA'],
  FRAGMENTACION:['BAJA','MEDIA','ALTA','EXTREMA'],
  GEODINAMICA:['ESTABLE','ACTIVA','MUY_ACTIVA','CATASTROFICA_RARA'],
  DIVERSIDAD_SUSTRATO:['HOMOGENEA','MODERADA','DIVERSA','MUY_DIVERSA'],
  RELIEVE:['SUAVE','MIXTO','ABRUPTO','EXTREMO'],
  LITORALIDAD:['BAJA','MEDIA','ALTA','DOMINANTE'],
  POTENCIAL_HIDROGRAFICO:['BAJO','MEDIO','ALTO','COMPLEJO'],
  CONECTIVIDAD_NATURAL:['ABIERTA','CORREDORES','COMPARTIMENTADA','AISLADA'],
  BARRERAS_NATURALES:['BAJAS','MEDIAS','ALTAS']
};
const strip=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
function formValue(form,...keys){ for(const k of keys){ if(form?.[k]!=null) return strip(form[k]); } return ''; }
function btProfileKey(p){ return ['DISTRIBUCION_MASAS','FRAGMENTACION','GEODINAMICA','DIVERSIDAD_SUSTRATO','RELIEVE','LITORALIDAD','POTENCIAL_HIDROGRAFICO','CONECTIVIDAD_NATURAL','BARRERAS_NATURALES','POTENCIAL_RECURSOS_ABIOTICOS'].map(k=>p[k]).join('|'); }
function btCanonicalCompare(a,b){
  for(const key of Object.keys(BT_DOMAINS)){
    const d=BT_DOMAINS[key], delta=d.indexOf(a[key])-d.indexOf(b[key]); if(delta) return delta;
  }
  return String(a.POTENCIAL_RECURSOS_ABIOTICOS).localeCompare(String(b.POTENCIAL_RECURSOS_ABIOTICOS));
}
export function encodeBoot01Entropy(dice){
  if(!Array.isArray(dice)||dice.length!==7) throw new Error('BOOT01_BT_SEVEN_D6_REQUIRED');
  return dice.reduce((acc,d)=>acc*6+(checkD6(d,'BOOT01_BT_D6_INVALID')-1),0);
}
export function compileBoot00Territory(form,dice){
  if(!form||typeof form!=='object') throw new Error('BOOT01_FORM_REQUIRED');
  if(!Array.isArray(dice)||dice.length!==7) throw new Error('BOOT01_BT_SEVEN_D6_REQUIRED');
  const d=dice.map(x=>checkD6(x,'BOOT01_BT_D6_INVALID'));
  const distribution=formValue(form,'DISTRIBUCION','distribution');
  const integrity=formValue(form,'INTEGRIDAD','integrity');
  const dynamics=formValue(form,'DINAMICA','dynamics');
  const differentiation=formValue(form,'DIFERENCIACION','differentiation');
  if(!['CONCENTRADA','DISTRIBUIDA'].includes(distribution)||!['COHESIONADA','TENSIONADA','FRACTURADA'].includes(integrity)||!['ESTABLE','MOVIL_CAMBIANTE','CICLICA_ORBITAL'].includes(dynamics)||!['HOMOGENEA','ESTRATIFICADA'].includes(differentiation)) throw new Error('BOOT01_FORM_DOMAIN_INVALID');

  let masses=distribution==='CONCENTRADA'?(d[0]<=4?'CONCENTRADA':'MIXTA'):(d[0]<=2?'MIXTA':'DISPERSA');
  let frag;
  if(integrity==='COHESIONADA') frag=d[1]<=4?'BAJA':'MEDIA';
  else if(integrity==='TENSIONADA') frag=d[1]===1?'BAJA':d[1]<=4?'MEDIA':'ALTA';
  else frag=d[1]===1?'MEDIA':d[1]<=5?'ALTA':'EXTREMA';
  if(masses==='DISPERSA'&&frag==='BAJA') frag='MEDIA';
  if(masses==='CONCENTRADA'&&frag==='EXTREMA'&&!(integrity==='FRACTURADA'&&d[1]===6)) frag='ALTA';

  let geo=dynamics==='ESTABLE'?(d[2]<=5?'ESTABLE':'ACTIVA'):dynamics==='MOVIL_CAMBIANTE'?(d[2]===1?'ESTABLE':d[2]<=5?'ACTIVA':'MUY_ACTIVA'):(d[2]===1?'ACTIVA':d[2]<=5?'MUY_ACTIVA':'CATASTROFICA_RARA');
  let substrate=differentiation==='HOMOGENEA'?(d[3]<=4?'HOMOGENEA':'MODERADA'):(d[3]===1?'MODERADA':d[3]<=4?'DIVERSA':'MUY_DIVERSA');
  if(['MUY_ACTIVA','CATASTROFICA_RARA'].includes(geo)&&substrate==='HOMOGENEA') substrate='MODERADA';

  let relief=geo==='ESTABLE'?(d[4]<=4?'SUAVE':'MIXTO'):geo==='ACTIVA'?(d[4]===1?'SUAVE':d[4]<=4?'MIXTO':'ABRUPTO'):geo==='MUY_ACTIVA'?(d[4]===1?'MIXTO':d[4]<=5?'ABRUPTO':'EXTREMO'):(d[4]<=2?'ABRUPTO':'EXTREMO');
  if(integrity==='FRACTURADA'&&relief==='SUAVE') relief='MIXTO';

  const B=({CONCENTRADA:-1,MIXTA:0,DISPERSA:1}[masses])+({BAJA:-1,MEDIA:0,ALTA:1,EXTREMA:2}[frag]);
  let littoral=B<=-1?(d[5]<=4?'BAJA':'MEDIA'):B===0?(d[5]<=2?'BAJA':d[5]<=5?'MEDIA':'ALTA'):B===1?(d[5]===1?'MEDIA':d[5]<=5?'ALTA':'DOMINANTE'):(d[5]<=2?'ALTA':'DOMINANTE');

  const H=({SUAVE:0,MIXTO:1,ABRUPTO:2,EXTREMO:2}[relief])+({HOMOGENEA:0,MODERADA:0,DIVERSA:1,MUY_DIVERSA:2}[substrate])+({CONCENTRADA:0,MIXTA:1,DISPERSA:1}[masses]);
  const hydro=H===0?(d[6]<=4?'BAJO':'MEDIO'):H<=2?(d[6]===1?'BAJO':d[6]<=4?'MEDIO':'ALTO'):H===3?(d[6]===1?'MEDIO':d[6]<=5?'ALTO':'COMPLEJO'):(d[6]<=2?'ALTO':'COMPLEJO');

  const C=({BAJA:0,MEDIA:1,ALTA:2,EXTREMA:3}[frag])+({SUAVE:0,MIXTO:1,ABRUPTO:2,EXTREMO:3}[relief])+(masses==='DISPERSA'?1:0);
  const connectivity=C<=1?'ABIERTA':C<=3?'CORREDORES':C<=5?'COMPARTIMENTADA':'AISLADA';
  const I=Math.max({BAJA:0,MEDIA:1,ALTA:2,EXTREMA:3}[frag],{SUAVE:0,MIXTO:1,ABRUPTO:2,EXTREMO:3}[relief]);
  const barriers=I<=1?'BAJAS':I===2?'MEDIAS':'ALTAS';
  const barrierTags=[];
  if(['ALTA','DOMINANTE'].includes(littoral)||masses==='DISPERSA') barrierTags.push('MARITIMA');
  if(['ABRUPTO','EXTREMO'].includes(relief)) barrierTags.push('OROGRAFICA');
  barrierTags.push('HIDROGRAFICA_PENDIENTE_DE_CLIMA');

  const A=({HOMOGENEA:0,MODERADA:1,DIVERSA:2,MUY_DIVERSA:3}[substrate])+({ESTABLE:0,ACTIVA:1,MUY_ACTIVA:2,CATASTROFICA_RARA:2}[geo])+({SUAVE:0,MIXTO:0,ABRUPTO:1,EXTREMO:1}[relief]);
  const resources=A<=1?'AMPLITUD_BAJA':A<=3?'MEDIA':A<=5?'ALTA':'MUY_ALTA';
  const profile={DISTRIBUCION_MASAS:masses,FRAGMENTACION:frag,GEODINAMICA:geo,DIVERSIDAD_SUSTRATO:substrate,RELIEVE:relief,LITORALIDAD:littoral,POTENCIAL_HIDROGRAFICO:hydro,CONECTIVIDAD_NATURAL:connectivity,BARRERAS_NATURALES:barriers,BARRERAS_TAGS:barrierTags,POTENCIAL_RECURSOS_ABIOTICOS:resources};
  profile.id='BT:'+btProfileKey(profile);
  return {profile,dice:d,derived:{B,H,C,I,A}};
}
export function enumerateBoot00TerritoryLegalSet(form){
  const unique=new Map();
  for(let a=1;a<=6;a++) for(let b=1;b<=6;b++) for(let c=1;c<=6;c++) for(let d=1;d<=6;d++) for(let e=1;e<=6;e++) for(let f=1;f<=6;f++) for(let g=1;g<=6;g++){
    const out=compileBoot00Territory(form,[a,b,c,d,e,f,g]); const key=btProfileKey(out.profile);
    if(!unique.has(key)) unique.set(key,out.profile);
  }
  return [...unique.values()].sort(btCanonicalCompare);
}
export function compileBoot01Territory(form,intent,dice){
  intent=String(intent).toUpperCase(); if(!['EXTENDER','QUEBRAR','ENTRELAZAR'].includes(intent)) throw new Error('BOOT01_INTENT_INVALID');
  const legalSet=enumerateBoot00TerritoryLegalSet(form);
  const score=p=>{
    const f=BT_DOMAINS.FRAGMENTACION.indexOf(p.FRAGMENTACION), b=BT_DOMAINS.BARRERAS_NATURALES.indexOf(p.BARRERAS_NATURALES), c=BT_DOMAINS.CONECTIVIDAD_NATURAL.indexOf(p.CONECTIVIDAD_NATURAL);
    if(intent==='EXTENDER') return f+b+c;
    if(intent==='QUEBRAR') return (3-f)+(2-b)+(3-c);
    return Math.abs(f-1)+Math.abs(b-1)+Math.abs(c-1);
  };
  const minCost=Math.min(...legalSet.map(score));
  const bestSet=legalSet.filter(p=>score(p)===minCost).sort(btCanonicalCompare);
  const entropy=encodeBoot01Entropy(dice), index=entropy%bestSet.length, selected=bestSet[index];
  return {ok:true,authorityOrder:['HARD','INTENTION','RNG'],intent,legalCount:legalSet.length,minCost,bestCount:bestSet.length,entropy,index,selected,bestIds:bestSet.map(p=>p.id),dice:dice.map(Number)};
}
