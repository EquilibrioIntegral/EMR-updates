function arr(v){ return Array.isArray(v) ? v : (v == null ? [] : [v]); }
export function validateRuiDataset(catalog, contract){
  const errors=[]; const ids=new Set();
  if (!contract?.scales?.R || !contract?.scales?.U || !contract?.scales?.I) errors.push('RUI_SCALES_MISSING');
  for (const r of catalog?.records ?? []) {
    if (!r.id) errors.push('RUI_ID_MISSING');
    else if (ids.has(r.id)) errors.push(`RUI_DUPLICATE_ID:${r.id}`); else ids.add(r.id);
    if (!contract?.scales?.[r.scale]) errors.push(`RUI_SCALE_INVALID:${r.id}`);
    if (!r.family) errors.push(`RUI_FAMILY_MISSING:${r.id}`);
  }
  return errors;
}
export function connectorCompatible(a,b,contract,{scale='U'}={}){
  if (a == null || b == null) return true;
  const A=String(a).toUpperCase(), B=String(b).toUpperCase();
  const grammar=scale==='I' ? contract.connectorGrammars.I_CURRENT : contract.connectorGrammars.U_HISTORICAL_CANDIDATE;
  return arr(grammar?.[A]).includes(B);
}
export function choosePreferenceTier(candidates=[]){
  for (const tier of ['PREFERENTE','COMPATIBLE','RARA']) {
    const group=candidates.filter(x=>(x.preferenceTier ?? 'COMPATIBLE')===tier);
    if (group.length) return {tier,candidates:group};
  }
  return {tier:null,candidates:[]};
}
export function deterministicTieBreak(candidates=[],rng){
  if (!candidates.length) return null;
  const ordered=[...candidates].sort((a,b)=>String(a.id).localeCompare(String(b.id)));
  if (ordered.length===1) return ordered[0];
  if (!rng?.next) throw new Error('RUI_RNG_REQUIRED');
  return ordered[Math.floor(rng.next()*ordered.length)];
}
export function querySpatialFacts({record,worldState={},knowledge='PLAYER'}={}){
  if (!record) return null;
  const out={id:record.id,scale:record.scale,family:record.family,feature:record.feature ?? null};
  const dynamic=worldState?.locations?.[record.id] ?? {};
  out.publicState=dynamic.publicState ?? null;
  if (knowledge==='INTERNAL') out.hiddenState=dynamic.hiddenState ?? null;
  return out;
}
export function selectRuiCandidate({records=[],scale,families=[],requiredConnectors=[],contract,rng,availableIds=null}={}){
  const familySet=new Set(families); const available=availableIds ? new Set(availableIds) : null;
  const rejected=[];
  const legal=records.filter(r=>{
    const reasons=[];
    if (scale && r.scale!==scale) reasons.push('SCALE');
    if (familySet.size && !familySet.has(r.family)) reasons.push('FAMILY');
    if (available && !available.has(r.id)) reasons.push('PHYSICAL_UNAVAILABLE');
    for (const req of requiredConnectors) {
      const own=arr(r.connectors ?? r.geometry?.currentConnectors);
      if (!own.some(x=>connectorCompatible(x,req,contract,{scale:r.scale}))) reasons.push(`CONNECTOR:${req}`);
    }
    if(reasons.length){ rejected.push({id:r.id,reasons}); return false; }
    return true;
  });
  const tier=choosePreferenceTier(legal);
  const selected=deterministicTieBreak(tier.candidates,rng);
  return {returnCode:selected?'RETURN_OK':'RETURN_ZERO',selected,tier:tier.tier,legalCount:legal.length,rejected};
}
