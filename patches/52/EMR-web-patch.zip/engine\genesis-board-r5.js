// GEN-R5 board reference topologies. Geometry is experimental/balance data, not canon.
// The engine consumes arbitrary cell lists so A61/A60/B76 can be compared without rewriting rules.

export const GENESIS_BOARD_R5_SCHEMA='EMR_GENESIS_BOARD_R5_v1';

export function axialDistance(a,b){
 const aq=Number(a?.q)||0,ar=Number(a?.r)||0,bq=Number(b?.q)||0,br=Number(b?.r)||0;
 return (Math.abs(aq-bq)+Math.abs(ar-br)+Math.abs((aq+ar)-(bq+br)))/2;
}

function cellCode(index){return `H${String(index).padStart(3,'0')}`;}

function panelForHexCell(q,r,radius){
 const x=q+r/2;
 const normalized=(x+radius)/(radius*2||1);
 return Math.min(4,Math.max(1,Math.floor(normalized*4)+1));
}

function regularHex(radius,{id='CUSTOM_HEX'}={}){
 if(!Number.isInteger(radius)||radius<1)throw new Error('GEN_BOARD_RADIUS_INVALID');
 const cells=[];
 const push=(q,r)=>{
  const number=cells.length+1;
  cells.push({q,r,code:cellCode(number),visibleNumber:number,panel:panelForHexCell(q,r,radius)});
 };
 // Numbering is stable and player-readable after projection: center first, then
 // complete concentric rings. Radius 4 therefore yields 1+6+12+18+24 = 61.
 push(0,0);
 const directions=[[1,0],[0,1],[-1,1],[-1,0],[0,-1],[1,-1]];
 for(let ring=1;ring<=radius;ring++){
  let q=0,r=-ring;
  for(const [dq,dr] of directions){
   for(let step=0;step<ring;step++){
    push(q,r);
    q+=dq;r+=dr;
   }
  }
 }
 return{schema:GENESIS_BOARD_R5_SCHEMA,id,width:radius*2+1,height:radius*2+1,radius,cells,cellCount:cells.length,center:cells[0],shape:'REGULAR_HEX'};
}

function centeredRect(width,height,{trimCorners=0,id='CUSTOM'}={}){
 if(!Number.isInteger(width)||!Number.isInteger(height)||width<2||height<2)throw new Error('GEN_BOARD_DIMENSIONS_INVALID');
 const q0=Math.floor((width-1)/2),r0=Math.floor((height-1)/2),cells=[];
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const corner=(x===0||x===width-1)&&(y===0||y===height-1);
  if(trimCorners>0&&corner)continue;
  const q=x-q0,r=y-r0,number=cells.length+1;
  cells.push({q,r,code:cellCode(number),visibleNumber:number,panel:Math.min(4,Math.floor(x*4/width)+1)});
 }
 return{schema:GENESIS_BOARD_R5_SCHEMA,id,width,height,trimCorners,cells,cellCount:cells.length,center:closestToOrigin(cells)};
}

function closestToOrigin(cells){return [...cells].sort((a,b)=>axialDistance(a,{q:0,r:0})-axialDistance(b,{q:0,r:0})||a.code.localeCompare(b.code))[0];}

export function makeBoardPreset(id='B76'){
 if(id==='A61')return regularHex(4,{id:'A61'});
 if(id==='A60')return centeredRect(10,6,{id:'A60'}); // legacy human-test geometry retained for old saves/comparison
 if(id==='B76')return centeredRect(10,8,{id:'B76',trimCorners:1}); // 80 - 4 corners = 76
 if(id==='C48')return centeredRect(8,6,{id:'C48'});
 if(id==='D91'){
  // 13x7 rectangular reference for the larger control condition.
  return centeredRect(13,7,{id:'D91'});
 }
 throw new Error('GEN_BOARD_PRESET_UNKNOWN');
}

export function boardCell(board,code){
 const c=board?.cells?.find(x=>x.code===code);if(!c)throw new Error('GEN_BOARD_CELL_UNKNOWN');return c;
}

export function nearestCells(board,origin,count=1,{excludeCodes=[]}={}){
 if(!board?.cells?.length)throw new Error('GEN_BOARD_INVALID');
 const excluded=new Set(excludeCodes);
 return [...board.cells].filter(c=>!excluded.has(c.code)).sort((a,b)=>axialDistance(a,origin)-axialDistance(b,origin)||a.code.localeCompare(b.code)).slice(0,count);
}

export function boardMetrics(board){
 if(!board?.cells?.length)throw new Error('GEN_BOARD_INVALID');
 const center=board.center||closestToOrigin(board.cells),distances=board.cells.map(c=>axialDistance(c,center));
 return{cellCount:board.cells.length,maxRadius:Math.max(...distances),meanRadius:distances.reduce((a,b)=>a+b,0)/distances.length,panels:new Set(board.cells.map(c=>c.panel)).size};
}
