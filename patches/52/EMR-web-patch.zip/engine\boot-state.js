import { compileBoot01Territory, ensureBootState } from './boot.js';

const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();

const BASE_DOMAINS={
  DISTRIBUCION:['CONCENTRADA','DISTRIBUIDA'],
  INTEGRIDAD:['COHESIONADA','TENSIONADA','FRACTURADA'],
  DINAMICA:['ESTABLE','MOVIL_CAMBIANTE','CICLICA_ORBITAL'],
  DIFERENCIACION:['HOMOGENEA','ESTRATIFICADA']
};

function checkedBase(base){
  const out={
    DISTRIBUCION:norm(base?.DISTRIBUCION ?? base?.distribution),
    INTEGRIDAD:norm(base?.INTEGRIDAD ?? base?.integrity),
    DINAMICA:norm(base?.DINAMICA ?? base?.dynamics),
    DIFERENCIACION:norm(base?.DIFERENCIACION ?? base?.differentiation)
  };
  for(const [k,domain] of Object.entries(BASE_DOMAINS)) if(!domain.includes(out[k])) throw new Error(`PRIMORDIAL_BASE_INVALID:${k}`);
  return out;
}

const TRANSFORMS={
  DISTRIBUCION:{REUNIR:'CONCENTRADA',CONCENTRAR:'CONCENTRADA',DISPERSAR:'DISTRIBUIDA',SEPARAR:'DISTRIBUIDA'},
  INTEGRIDAD:{UNIR:'COHESIONADA',COHESIONAR:'COHESIONADA',TENSAR:'TENSIONADA',ROMPER:'FRACTURADA',FRACTURAR:'FRACTURADA'},
  DINAMICA:{ESTABILIZAR:'ESTABLE',MOVER:'MOVIL_CAMBIANTE',TRANSFORMAR:'MOVIL_CAMBIANTE',CICLAR:'CICLICA_ORBITAL',ORBITAR:'CICLICA_ORBITAL'},
  DIFERENCIACION:{MEZCLAR:'HOMOGENEA',HOMOGENEIZAR:'HOMOGENEA',DIFERENCIAR:'ESTRATIFICADA',ESTRATIFICAR:'ESTRATIFICADA'}
};

export function compilePrimordialForm(baseForm, trace=[]){
  const form=checkedBase(baseForm);
  const provenance={
    DISTRIBUCION:{source:'BASE_FORM'}, INTEGRIDAD:{source:'BASE_FORM'},
    DINAMICA:{source:'BASE_FORM'}, DIFERENCIACION:{source:'BASE_FORM'}
  };
  for(const [index,event] of (trace??[]).entries()){
    if(event?.physical!==true) continue;
    const axis=norm(event.axis);
    const transform=norm(event.transform);
    const value=TRANSFORMS[axis]?.[transform];
    if(!value) continue;
    form[axis]=value;
    provenance[axis]={source:event.id ?? `TRACE-${index+1}`,transform};
  }
  return {version:'WG-STATE-PRIMORDIAL-FORM-1',...form,provenance};
}

export function commitPrimordialForm(state, baseForm, trace=[]){
  const b=ensureBootState(state);
  const form=compilePrimordialForm(baseForm,trace);
  b.primordialForm=form;
  b.phase='BOOT01_INTENTION';
  state.eventLog??=[];
  state.eventLog.push({type:'WG_PRIMORDIAL_FORM_COMPILED',gameTime:state.meta?.gameTime??0,form:{DISTRIBUCION:form.DISTRIBUCION,INTEGRIDAD:form.INTEGRIDAD,DINAMICA:form.DINAMICA,DIFERENCIACION:form.DIFERENCIACION}});
  return form;
}

export function commitBoot01Territory(state, intent, dice){
  const b=ensureBootState(state);
  if(!b.primordialForm) throw new Error('BOOT01_PRIMORDIAL_FORM_MISSING');
  const compiled=compileBoot01Territory(b.primordialForm,intent,dice);
  if(!compiled?.ok) throw new Error(`BOOT01_TERRITORY_COMPILE_FAILED:${compiled?.reason??'UNKNOWN'}`);
  b.boot01??={};
  b.boot01.intent=String(intent).toUpperCase();
  b.boot01.territory={
    schemaVersion:'WG-STATE-TERRITORY-0.1',
    profile:compiled.selected,
    hardLegalCount:compiled.legalCount,
    bestSetCount:compiled.bestCount,
    minCost:compiled.minCost,
    entropy:compiled.entropy,
    dice:[...dice]
  };
  b.phase='BOOT01_TERRITORY_COMPILED';
  state.eventLog??=[];
  state.eventLog.push({type:'BOOT01_TERRITORY_COMPILED',gameTime:state.meta?.gameTime??0,intent:b.boot01.intent,hardLegalCount:b.boot01.territory.hardLegalCount,bestSetCount:b.boot01.territory.bestSetCount,profileId:b.boot01.territory.profile.id});
  return b.boot01.territory;
}
