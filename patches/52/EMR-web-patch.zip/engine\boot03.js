import {compileBoot03CulturalInterpretationsR512,playerSafeBoot03InterpretationsR512} from './boot-metaphysics-r512.js';
import {collectCultureObservationsR512,deriveDoctrineSeedsR512,commitDoctrineSeedsR512} from './epistemic-propagation-r512.js';

const FUNCTIONS=['ORGANIZAR','INTERCAMBIAR','TRANSFORMAR','CONSAGRAR'];
const TARGETS={ORGANIZAR:'GOBIERNO',INTERCAMBIAR:'ECONOMIA',TRANSFORMAR:'DESARROLLO_MATERIAL',CONSAGRAR:'RELIGION_CREENCIAS'};
const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
function d6(v){v=Number(v);if(!Number.isInteger(v)||v<1||v>6)throw new Error('BOOT03_D6_INVALID');return v;}
export function compileBoot03Civilization(intentions,die){
 if(!Array.isArray(intentions)||intentions.length<1||intentions.length>4)throw new Error('BOOT03_PLAYER_COUNT_INVALID');
 const vals=intentions.map(norm);if(vals.some(v=>!FUNCTIONS.includes(v)))throw new Error('BOOT03_INTENTION_INVALID');
 const variant=d6(die),pressures=Object.fromEntries(FUNCTIONS.map(k=>[k,0]));vals.forEach(v=>pressures[v]++);
 const levels=[...new Set(Object.values(pressures).filter(v=>v>0))].sort((a,b)=>b-a);
 const precedence=levels.map(weight=>({weight,functions:FUNCTIONS.filter(k=>pressures[k]===weight)}));
 const civ=Object.fromEntries(FUNCTIONS.map(k=>[TARGETS[k],{primary:k,weight:pressures[k],provided:pressures[k]>0,mode:'BIAS_NOT_QUANTITY'}]));
 const traces=FUNCTIONS.filter(k=>pressures[k]>0).map(k=>({id:`BOOT03-${k}`,function:k,target:TARGETS[k],weight:pressures[k],classification:'UNCLASSIFIED_UNTIL_MATERIALIZED'}));
 return {schemaVersion:'WG-STATE-BOOT03-0.1',pressures,variant,civ,precedence,traces,hardRules:['BOOT00_PRIMORDIAL','BOOT01_WORLD','BOOT02_PEOPLES','SAVE0_FACTS'],authorityOrder:['HARD','BOOT03_BIAS','CONSUMER_PREFERENCE','CONSUMER_TIEBREAK']};
}
export function commitBoot03(state,intentions,die,{observations,cultureId='CULTURE-1'}={}){
 const boot=state?.session?.boot;if(!boot?.boot01?.territory)throw new Error('BOOT03_TERRITORY_REQUIRED');if(!boot?.boot02)throw new Error('BOOT03_PEOPLES_REQUIRED');
 const out=compileBoot03Civilization(intentions,die);
 const genesisSource=state.session?.genesisLegacy||state.session?.genesis||state.genesisLegacy||state.genesis||null;
 if(genesisSource){
  const resolvedObservations=Array.isArray(observations)?observations:collectCultureObservationsR512(state,cultureId);
  out.culturalInterpretations=compileBoot03CulturalInterpretationsR512(genesisSource,{observations:resolvedObservations,cultureId});
  out.playerSafeInterpretations=playerSafeBoot03InterpretationsR512(out.culturalInterpretations);
  out.doctrineSeeds=deriveDoctrineSeedsR512(out.culturalInterpretations);
  commitDoctrineSeedsR512(state,out.doctrineSeeds);
  out.observationSource=Array.isArray(observations)?'EXPLICIT_TEST_OR_IMPORT':'PROPAGATED_KNOWLEDGE';
  out.knowledgeDecisionId='D-GEN-R5.12-BOOT-KNOWLEDGE01';
 }
 boot.boot03=out;boot.phase='BOOT03_COMPILED';
 state.eventLog??=[];state.eventLog.push({type:'BOOT03_CIVILIZATION_COMPILED',gameTime:state.meta?.gameTime??0,pressures:{...out.pressures},variant:out.variant,causalTraceIds:out.traces.map(x=>x.id),culturalBeliefCount:out.culturalInterpretations?.beliefs?.length||0,doctrineSeedCount:out.doctrineSeeds?.length||0,observationSource:out.observationSource||null});return out;
}
export function validateBoot03Materialization(candidate,context={}){
 if(!candidate||candidate.legal===false)return {ok:false,reason:'HARD_ILLEGAL'};
 if(candidate.kind==='OBJECTIVE_SUPERNATURAL'&&context.primordialSupernatural!==true)return {ok:false,reason:'BOOT00_SUPERNATURAL_ABSENT'};
 if(candidate.hidden===true&&candidate.public===true)return {ok:false,reason:'SPOILER_LEAK'};
 if(candidate.knowledgeClass==='CULTURAL_INTERPRETATION'&&candidate.objectiveTruthDisclosed===true)return {ok:false,reason:'SPOILER_LEAK'};
 if(candidate.knowledgeClass==='CULTURAL_DOCTRINE_SEED'&&candidate.objectiveTruthDisclosed===true)return {ok:false,reason:'SPOILER_LEAK'};
 return {ok:true};
}
export function materializeBoot03Fact(state,candidate,context={}){
 const check=validateBoot03Materialization(candidate,context);if(!check.ok)throw new Error(`BOOT03_${check.reason}`);
 state.save0??={facts:[]};state.save0.facts??=[];
 const fact={id:candidate.id,kind:candidate.kind,public:!!candidate.public,knowledgeClass:candidate.knowledgeClass??(candidate.public?'PUBLIC':'WORLD_TRUTH'),source:'BOOT03'};
 if(candidate.knowledgeClass==='CULTURAL_INTERPRETATION'||candidate.knowledgeClass==='CULTURAL_DOCTRINE_SEED'){
  fact.claimId=candidate.claimId||null;fact.cultureId=candidate.cultureId||null;fact.evidenceIds=[...(candidate.evidenceIds||[])];fact.truthStatus='UNKNOWN_TO_CULTURE';
  if(candidate.knowledgeClass==='CULTURAL_DOCTRINE_SEED'){fact.status=candidate.status||'LATENT';fact.religionCreated=false;}
 }
 state.save0.facts.push(fact);return fact;
}
export function advanceBoot03ToBoot04(state){if(!state?.session?.boot?.boot03)throw new Error('BOOT03_NOT_COMPILED');state.session.boot.phase='BOOT04_READY';return state.session.boot.phase;}
