import {NATURE_LABELS} from '../data/genesis-director.js';
import {startTable,startScene,tableBrief,legalPawnCells,movePawn,legalTableActions,describeAction,proposeTableAction,confirmTableAction,submitTableVote,revealTableVotes,resolveTableRound,confirmTableRound,nextTableScene,finishTable,validateTable} from '../engine/genesis-table.js';
import {resolveTableNarrativeBeat,publicNarrativeBeat} from '../engine/genesis-table-guionista.js';
import {getTableClosureStatus,chooseTablePlanet,closeTableIntoBoot01} from '../engine/genesis-table-closure.js';
import {installWeightedGenesisHandoffForBoot01} from '../engine/genesis-boot01-adapter.js';
import {renderGenesisUi as renderLegacy} from './genesis-ui-legacy.js';
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot',"'":'&#39;'}[c]));
const intentionLabels={CONCENTRATE:'Concentrar',TRANSFORM:'Transformar',PRESERVE:'Preservar'};
export function renderGenesisUi(ctx){
 const {state,host,persist,rerender}=ctx,s=state.session.genesisTable;if(!s)return renderLegacy(ctx);validateTable(s);
 const player=s.agencies.players[s.actor],name=i=>s.names[i]||`Jugador ${i+1}`;
 const button=(id,text)=>`<button id="${id}">${text}</button>`;
 const layout=(title,body)=>{host.innerHTML=`<article class="genesis-reader"><p class="preshow-progress">GÉNESIS · ${esc(s.round===1?'EL PRIMER DESPERTAR':'EL MUNDO RECUERDA')}</p><h2>${esc(title)}</h2>${body}<p id="gen-error" role="alert" class="form-error"></p><details class="table-rebuild"><summary>Reconstruir la mesa / consultar posiciones</summary>${brief()}</details></article>`;};
 const brief=()=>{const b=tableBrief(s);return `<ul>${b.masses.map(m=>`<li>${esc(m.label)} → casilla <strong>${m.cell}</strong>${(m.members?.length||1)>1?' · '+m.members.join(' + ')+' apiladas':''}</li>`).join('')}${b.pawns.map(p=>`<li>${esc(p.name)} (${esc(p.id)}) → <strong>${p.cell}</strong></li>`).join('')}</ul>`;};
 const bind=(id,fn)=>host.querySelector('#'+id)?.addEventListener('click',()=>{try{fn();persist();rerender();}catch(e){host.querySelector('#gen-error').textContent=e.message;}});
 const list=lines=>`<ol class="physical-instructions">${lines.map(t=>`<li>${esc(t)}</li>`).join('')}</ol>`;
 if(s.phase==='SETUP'){
  layout('Antes de que exista un mundo',`<p>Abre el tablero primordial: el espacio de juego empieza vacío de estrella propia. Coloca únicamente la materia y los peones que indique esta partida; la estrella y los mundos deben surgir jugando.</p><p>Cada peón representa la agencia que ese jugador puede ejercer, todavía no un protagonista.</p>${brief()}<p>Ten a mano las Intenciones y un dado de seis caras. La aplicación conserva las huellas ocultas: no necesitas apuntarlas.</p>${button('gen-ready','La mesa está preparada')}`);bind('gen-ready',()=>startTable(s));return;
 }
 if(s.phase==='SCENE'){
  layout(s.scene.title,`<div class="genesis-story"><p>${esc(s.scene.text)}</p></div><p class="table-cue">Mirad la mesa. Hablad de lo que queréis conservar o cambiar antes de actuar.</p>${button('gen-scene','Volver a la mesa y actuar')}`);bind('gen-scene',()=>startScene(s));return;
 }
 if(s.phase==='ACTION'){
  if(s.pending){layout('Materializa lo ocurrido',`<p>${esc(s.pending.result.text)}</p>${list(s.pending.result.instructions)}${button('gen-confirm','Hecho en la mesa')}`);bind('gen-confirm',()=>confirmTableAction(s));return;}
  const actions=legalTableActions(s),moves=legalPawnCells(s);const seen=new Set(),suggested=actions.filter(a=>a.action!=='WAIT'&&!seen.has(a.action)&&seen.add(a.action)).slice(0,4);suggested.push(actions.find(a=>a.action==='WAIT'));
  layout(`${name(s.actor)} · ${NATURE_LABELS[player.nature]}`,`${s.lastOutcome?`<p class="previous-consequence">${esc(s.lastOutcome)}</p>`:''}<p>Tu peón determina dónde puedes intervenir. Puedes moverlo a una casilla vecina antes de actuar, o dejarlo donde está.</p>${!s.moved?`<label>Casilla del peón<select id="gen-cell">${moves.map(c=>`<option value="${c.code}" ${c.q===player.position.q&&c.r===player.position.r?'selected':''}>${c.code}</option>`).join('')}</select></label>${button('gen-move','He colocado mi peón ahí')}`:'<p>Reposicionamiento registrado.</p>'}<label>¿Qué haces en la mesa?<select id="gen-action">${suggested.map(a=>`<option value="${esc(a.id)}">${esc(describeAction(a))}</option>`).join('')}</select></label><p>Elige entre las acciones legales desde tu posición. La app indicará el cambio exacto; tú lo realizarás con las fichas.</p>${button('gen-act','Resolver esta acción')}<details><summary>Otra acción / intención propia</summary><p>Puedes expresar tu intención con tus palabras. Concreta su efecto sobre los cuerpos presentes: el motor comprobará ese efecto, sin inventar reglas para interpretar el texto.</p><label>Mi intención<input id="gen-declaration" maxlength="300"></label><label>Efecto en la mesa<select id="gen-other-action">${actions.map(a=>`<option value="${esc(a.id)}">${esc(describeAction(a))}</option>`).join('')}</select></label>${button('gen-other','Resolver mi intención')}</details>`);
  bind('gen-other',()=>{const d=host.querySelector('#gen-declaration').value.trim();if(!d)throw new Error('Expresa tu intención antes de resolverla.');proposeTableAction(s,host.querySelector('#gen-other-action').value,d);});bind('gen-move',()=>movePawn(s,host.querySelector('#gen-cell').value));bind('gen-act',()=>proposeTableAction(s,host.querySelector('#gen-action').value));return;
 }
 if(s.phase==='VOTE'){
  layout('Elegid la dirección del cambio',`<p>${s.agencies.players.length===1?"En solitario elige la dirección del cambio. No necesitas cartas físicas.":"Todos elegís primero una Intención física boca abajo: <strong>1 Concentrar · 2 Transformar · 3 Preservar</strong>. Cuando todos la tengáis, pasad el dispositivo para registrar vuestra carta sin enseñarla."}</p><h3>${esc(name(s.voteActor))}, registra tu carta</h3><div class="choices">${Object.entries(intentionLabels).map(([id,l],i)=>button('gen-vote-'+id,`${i+1} · ${l}`)).join('')}</div><p>${s.agencies.players.length===1?"Después resolverás la convergencia.":"Los demás apartan la mirada. La elección se oculta al pasar al siguiente jugador."}</p>`);for(const id of Object.keys(intentionLabels))bind('gen-vote-'+id,()=>submitTableVote(s,id));return;
 }
 if(s.phase==='REVEAL'){
  layout('Las Intenciones están elegidas',`<p>${s.agencies.players.length===1?'Tu Intención está elegida. Comprueba la mesa antes de resolver lo que provoca.':'Revelad las cartas físicas a la vez. Ahora podéis volver a mirar juntos la pantalla.'}</p>${button('gen-reveal',s.agencies.players.length===1?'Resolver mi Intención':'Ya están reveladas')}`);bind('gen-reveal',()=>revealTableVotes(s));return;
 }
 if(s.phase==='RESOLVE'||s.phase==='DIE'){
  layout('La creación responde',`<ul>${s.agencies.players.map((p,i)=>`<li>${esc(name(i))}: ${intentionLabels[s.votes[p.id]]}</li>`).join('')}</ul>${s.phase==='DIE'?'<p>Ninguna causa prevalece de forma suficiente. Lanza 1d6 en la mesa e introduce su resultado.</p><label>Resultado del dado<select id="gen-die"><option value="">Elige el resultado</option>'+[1,2,3,4,5,6].map(n=>`<option>${n}</option>`).join('')+'</select></label>':'<p>Las Intenciones compatibles pueden coexistir. Las incompatibles se resuelven por la autoridad presente; el dado solo interviene si hace falta.</p>'}${button('gen-resolve','Resolver la convergencia')}`);bind('gen-resolve',()=>{const d=host.querySelector('#gen-die');if(d&&!d.value)throw new Error('Introduce el resultado que ha salido en la mesa.');resolveTableRound(s,d?Number(d.value):null);});return;
 }
 if(s.phase==='ROUND_CONFIRM'){
  layout('El cambio llega a la mesa',`<p>${esc(s.pending.result.text)}</p>${list(s.pending.result.instructions.length?s.pending.result.instructions:['Conserva las posiciones actuales. El cambio queda en la memoria del mundo.'])}${button('gen-round-confirm','La mesa refleja el resultado')}`);bind('gen-round-confirm',()=>{const completedRound=s.round;confirmTableRound(s);resolveTableNarrativeBeat(s,completedRound,completedRound);});return;
 }
 if(s.phase==='OUTCOME'){
  const closure=getTableClosureStatus(s);
  if(closure.requiresPlanetSelection){
   const options=closure.planetCandidates.map(p=>`<option value="${esc(p.id)}">${esc(p.name||p.id)}${p.cell?` · ${esc(p.cell)}`:''}</option>`).join('');
   layout('Elegid el mundo que continuará',`<p>La creación ya contiene una estrella y uno o más mundos nacidos de lo ocurrido en la mesa. Elegid cuál heredará el resto de la historia.</p><label>Mundo<select id="gen-planet">${options}</select></label><label>Su primer nombre<input id="gen-planet-name" maxlength="80" placeholder="Nombre del mundo"></label><p>Este nombre y las causas que formaron el planeta pasarán a Formación del Mundo.</p>${button('gen-choose-planet','Elegir este mundo')}`);
   bind('gen-choose-planet',()=>{const id=host.querySelector('#gen-planet').value,n=host.querySelector('#gen-planet-name').value.trim();if(!n)throw new Error('Da un nombre al mundo antes de continuar.');chooseTablePlanet(s,id,n);});return;
  }
  const beat=publicNarrativeBeat(s);const drama=beat?`<section class="genesis-story"><h3>Lo que ocurre</h3><p>${esc(beat.publicText)}</p>${beat.decisionPrompt?`<p class="table-cue">${esc(beat.decisionPrompt)}</p>`:''}${beat.materializationHint?.instruction==='COLOCA_CUERPO_ENTRANTE'?'<p class="table-cue"><strong>En la mesa:</strong> coloca un cuerpo primordial entrante en el borde indicado por la situación.</p>':''}</section>`:'';
  layout('Una consecuencia que permanece',`<div class="genesis-story"><p>${esc(s.lastOutcome)}</p></div>${drama}<p class="table-cue">${closure.stage==='FORMING_STAR'?'La estrella aún no ha nacido. La creación continúa.':closure.stage==='FORMING_PLANETS'?'La estrella existe, pero todavía debe quedar un mundo con historia causal propia.':'La creación continúa.'}</p>${button('gen-next','Escuchar lo que ocurre después')}`);bind('gen-next',()=>{s.closedReason=null;nextTableScene(s);});return;
 }
 if(s.phase==='CLOSED'){
  const closure=getTableClosureStatus(s);if(!closure.ready)throw new Error('Génesis no puede cerrarse hasta que exista un planeta formado y elegido.');
  layout('El mundo ya tiene un pasado',`<p><strong>${esc(s.selectedPlanetName||closure.selectedPlanet?.name)}</strong> continuará hacia la Formación del Mundo.</p><p>La estrella, los otros cuerpos y las decisiones que los cambiaron no desaparecen: pasan como pasado causal de la campaña.</p><div class="genesis-story">${s.memory.filter(m=>m.event==='CONVERGENCE').map(m=>`<p>${esc(m.text)}</p>`).join('')}</div><p>Puedes guardar y cerrar ahora, o continuar. Las huellas quedarán en la partida.</p>${button('gen-finish','Continuar a la Formación del Mundo')}`);bind('gen-finish',()=>{const base=finishTable(s),handoff=closeTableIntoBoot01(s,base);installWeightedGenesisHandoffForBoot01(state,handoff);state.session.boot.genesisNarrativeMemory=handoff.narrativeMemory;state.session.boot.genesisPotentials=handoff.imprints;state.session.boot.genesisStory=handoff.story;});return;
 }
 throw new Error('Fase de Génesis no reconocida.');
}
