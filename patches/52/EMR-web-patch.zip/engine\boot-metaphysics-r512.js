// BOOT consumers for Genesis R5.12 invisible-world truth.
// The engine may use objective metaphysics as hard hidden constraints, but cultures
// never receive that truth automatically. BOOT03 only creates interpretations from
// evidence actually available to a culture/player.

export const BOOT_METAPHYSICS_R512_SCHEMA='EMR_BOOT_METAPHYSICS_R512_v1';

const clone=x=>structuredClone(x);
const established=x=>x?.status==='ESTABLISHED';

export function readGenesisMetaphysicsR512(source){
 const ontology=source?.runtime?.ontology||source?.ontology||null;
 const consciousness=ontology?.consciousnessMetaphysics||source?.consciousnessMetaphysics||null;
 const normative=ontology?.normativeMetaphysics||source?.normativeMetaphysics||null;
 const supernatural=source?.supernaturalLegacy||{};
 const hiddenFacts=ontology?.hiddenGenesisFacts||supernatural?.hiddenGenesisFacts||[];
 const objectiveFacts=ontology?.objectiveSupernaturalFacts||supernatural?.objectiveSupernaturalFacts||[];
 return {consciousness:clone(consciousness),normative:clone(normative),hiddenFacts:clone(hiddenFacts),objectiveFacts:clone(objectiveFacts)};
}

export function compileBoot02MetaphysicalConstraintsR512(source){
 const truth=readGenesisMetaphysicsR512(source);
 const cm=truth.consciousness||{};
 const nm=truth.normative||{};
 const constraints={
  schema:BOOT_METAPHYSICS_R512_SCHEMA,
  visibility:'ENGINE_ONLY',
  materialInvisiblePermeability:established(cm.materialInvisiblePermeability)?cm.materialInvisiblePermeability.mode||'CONDITIONAL':'UNDETERMINED',
  postMortem:established(cm.postMortemPersistence)?'PERSISTENCE_POSSIBLE':established(cm.postMortemDissolution)?'DISSOLUTION_WITH_SUPPORT':'UNDETERMINED',
  memoryContinuity:established(cm.memoryContinuity)?cm.memoryContinuity.mode||'UNSPECIFIED':'UNDETERMINED',
  rebirth:established(cm.rebirthAllowed)?'ALLOWED_CONDITIONALLY':established(cm.rebirthForbidden)?'FORBIDDEN':'UNDETERMINED',
  moralCausality:established(nm.moralCausality)?'OBJECTIVE_CAUSAL_EFFECT':established(nm.moralCausalityAbsent)?'ABSENT':'UNDETERMINED',
  judgment:established(nm.judgmentAuthority)?{mode:'VOLITION_AUTHORITY',producerEntityId:nm.judgmentAuthority.producerEntityId||null}:established(nm.impersonalNormativeMechanism)?{mode:'IMPERSONAL_MECHANISM',producerEntityId:null}:{mode:'UNDETERMINED',producerEntityId:null},
  sourceFactIds:[...new Set([...truth.objectiveFacts,...truth.hiddenFacts].filter(f=>f?.factId).map(f=>f.factId))].sort(),
  culturalDoctrineCreated:false,
  playerVisible:false
 };
 constraints.futureEffects=deriveFutureEffects(constraints);
 return constraints;
}

function deriveFutureEffects(c){
 const effects=[];
 if(c.materialInvisiblePermeability!=='UNDETERMINED')effects.push('CONSCIOUSNESS_MAY_HAVE_NON_MATERIAL_INTERACTIONS');
 if(c.postMortem==='PERSISTENCE_POSSIBLE')effects.push('DEATH_NEED_NOT_TERMINATE_ENTITY_CONTINUITY');
 if(c.postMortem==='DISSOLUTION_WITH_SUPPORT')effects.push('DEATH_TERMINATES_ENTITY_CONTINUITY');
 if(c.memoryContinuity==='PRESERVED')effects.push('IDENTITY_MEMORY_CAN_CROSS_TRANSITIONS');
 if(c.memoryContinuity==='LOST_BETWEEN_TRANSITIONS')effects.push('IDENTITY_MAY_CONTINUE_WITHOUT_ACCESSIBLE_PRIOR_MEMORY');
 if(c.rebirth==='ALLOWED_CONDITIONALLY')effects.push('NEW_MATERIAL_SUPPORT_MAY_INHERIT_PERSISTENT_CONSCIOUSNESS');
 if(c.rebirth==='FORBIDDEN')effects.push('PERSISTENT_CONSCIOUSNESS_CANNOT_REENTER_MATERIAL_SUPPORT');
 if(c.moralCausality==='OBJECTIVE_CAUSAL_EFFECT')effects.push('ACTIONS_CAN_AFFECT_FUTURE_CONSCIOUSNESS_STATE');
 if(c.moralCausality==='ABSENT')effects.push('NO_OBJECTIVE_MORAL_CAUSAL_CHANNEL');
 if(c.judgment.mode==='VOLITION_AUTHORITY')effects.push('NORMATIVE_EVALUATION_CAN_BE_MEDIATED_BY_VOLITION');
 if(c.judgment.mode==='IMPERSONAL_MECHANISM')effects.push('NORMATIVE_EVALUATION_IS_IMPERSONAL');
 return effects;
}

const OBSERVATION_TO_BELIEFS={
 POST_MORTEM_ANOMALY:[
  {claimId:'BELIEF-CONTINUITY-AFTER-DEATH',claim:'Algo de una persona puede continuar tras la muerte.',topic:'AFTERLIFE'},
  {claimId:'BELIEF-DEATH-ILLUSION',claim:'La muerte quizá no sea una frontera absoluta.',topic:'AFTERLIFE'}
 ],
 REBIRTH_MEMORY_CLAIM:[
  {claimId:'BELIEF-RETURN-OF-CONSCIOUSNESS',claim:'Algunas vidas podrían estar relacionadas con vidas anteriores.',topic:'REBIRTH'},
  {claimId:'BELIEF-ANCESTRAL-ECHO',claim:'Los recuerdos extraños podrían proceder de ecos de los antepasados.',topic:'REBIRTH'}
 ],
 MORAL_CONSEQUENCE_PATTERN:[
  {claimId:'BELIEF-ACTS-HAVE-BEYOND-CONSEQUENCES',claim:'Los actos podrían producir consecuencias que sobreviven al momento en que se realizan.',topic:'MORAL_CAUSALITY'},
  {claimId:'BELIEF-MORAL-PATTERN-COINCIDENCE',claim:'Las coincidencias morales quizá sean solo patrones que las personas desean ver.',topic:'MORAL_CAUSALITY'}
 ],
 VOLITION_INTERVENTION_TRACE:[
  {claimId:'BELIEF-PERSONAL-JUDGMENT',claim:'Una voluntad superior podría intervenir en el destino de algunas conciencias.',topic:'JUDGMENT'},
  {claimId:'BELIEF-IMPERSONAL-ORDER',claim:'El orden invisible podría funcionar sin una voluntad que lo juzgue.',topic:'JUDGMENT'}
 ],
 MATERIAL_INVISIBLE_EVENT:[
  {claimId:'BELIEF-INVISIBLE-PERMEABILITY',claim:'Lo material y lo invisible podrían afectarse mutuamente.',topic:'PERMEABILITY'}
 ]
};

export function compileBoot03CulturalInterpretationsR512(source,{observations=[],cultureId='CULTURE-1'}={}){
 if(!Array.isArray(observations))throw new Error('BOOT03_R512_OBSERVATIONS_REQUIRED');
 const truth=compileBoot02MetaphysicalConstraintsR512(source);
 const byKey=new Map();
 for(const obs of observations){
  if(!obs?.id||!obs?.type||obs.known!==true)continue;
  for(const template of OBSERVATION_TO_BELIEFS[obs.type]||[]){
   const key=`${cultureId}:${template.claimId}`;
   const existing=byKey.get(key);
   if(existing){
    if(!existing.evidenceIds.includes(obs.id))existing.evidenceIds.push(obs.id);
    existing.public=existing.public||obs.public===true;
    existing.confidence=Math.max(existing.confidence,normalizeConfidence(obs.confidence));
    continue;
   }
   byKey.set(key,{id:key,cultureId,claimId:template.claimId,topic:template.topic,claim:template.claim,evidenceIds:[obs.id],knowledgeClass:'CULTURAL_INTERPRETATION',public:obs.public===true,confidence:normalizeConfidence(obs.confidence),objectiveTruthDisclosed:false,truthRelation:hiddenTruthRelation(template.claimId,truth)});
  }
 }
 const beliefs=[...byKey.values()];
 return {schema:BOOT_METAPHYSICS_R512_SCHEMA,cultureId,beliefs,engineTruthRef:{visibility:'ENGINE_ONLY',sourceFactIds:[...truth.sourceFactIds]},knowledgeContract:{worldTruthSeparated:true,culturalBeliefIsNotFact:true,noAutomaticDisclosure:true,religionNotAutoCreated:true}};
}

export function playerSafeBoot03InterpretationsR512(compiled){
 return {schema:compiled?.schema||BOOT_METAPHYSICS_R512_SCHEMA,cultureId:compiled?.cultureId||null,beliefs:(compiled?.beliefs||[]).filter(b=>b.public===true).map(b=>({id:b.id,cultureId:b.cultureId,claimId:b.claimId,topic:b.topic,claim:b.claim,evidenceIds:[...(b.evidenceIds||[])],knowledgeClass:b.knowledgeClass,confidence:b.confidence}))};
}

function normalizeConfidence(v){const n=Number(v);if(!Number.isFinite(n))return 1;return Math.max(0,Math.min(1,n));}
function hiddenTruthRelation(claimId,t){
 const matches={
  'BELIEF-CONTINUITY-AFTER-DEATH':t.postMortem==='PERSISTENCE_POSSIBLE',
  'BELIEF-DEATH-ILLUSION':t.postMortem==='PERSISTENCE_POSSIBLE',
  'BELIEF-RETURN-OF-CONSCIOUSNESS':t.rebirth==='ALLOWED_CONDITIONALLY',
  'BELIEF-ANCESTRAL-ECHO':false,
  'BELIEF-ACTS-HAVE-BEYOND-CONSEQUENCES':t.moralCausality==='OBJECTIVE_CAUSAL_EFFECT',
  'BELIEF-MORAL-PATTERN-COINCIDENCE':t.moralCausality==='ABSENT',
  'BELIEF-PERSONAL-JUDGMENT':t.judgment.mode==='VOLITION_AUTHORITY',
  'BELIEF-IMPERSONAL-ORDER':t.judgment.mode==='IMPERSONAL_MECHANISM',
  'BELIEF-INVISIBLE-PERMEABILITY':t.materialInvisiblePermeability!=='UNDETERMINED'
 };
 return {visibility:'ENGINE_ONLY',status:matches[claimId]===true?'SUPPORTED_BY_WORLD_TRUTH':matches[claimId]===false?'NOT_SUPPORTED_BY_WORLD_TRUTH':'UNRESOLVED'};
}
