import * as legacy from './genesis-live-r510-legacy.js';
import {runtimeAgencyR5} from './genesis-runtime-r5.js';
import {chooseAutonomousAgencyOptionR59} from './genesis-autonomous-agencies-r59.js';
import {GENESIS_SPATIAL_R510_DECISION,GENESIS_AGENCY_MOVEMENT_R510,classifyAgencyPresenceR510} from './genesis-spatial-policy-r510.js';
import {contextualAgencyActionsR511,curateContextualAgencyActionsR511,applyContextualCapabilityActionR511} from './genesis-capability-live-r511.js';

const clone=x=>structuredClone(x);

export function createGenesisLiveR5(args={}){
 const live=legacy.createGenesisLiveR5(args);
 // R5.11 is a capability-policy revision, not a save/live schema revision.
 // Preserve the R5.10 live version until dev031 itself is promoted/versioned.
 live.version='R5.10-dev031';
 live.capabilityPolicy={decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01',implementationStage:2,playerFacingPowerMenu:false,humanFunBalanceValidation:'PENDING'};
 live.history.push({type:'GEN_LIVE_R511_CAPABILITY_POLICY_ACTIVE',decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01',implementationStage:2,humanValidation:'PENDING'});
 return live;
}

export function deserializeGenesisLiveR5(json){
 const live=legacy.deserializeGenesisLiveR5(json);
 live.version='R5.10-dev031';
 live.capabilityPolicy??={decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01',implementationStage:2,playerFacingPowerMenu:false,humanFunBalanceValidation:'PENDING'};
 return live;
}

export function liveAgencyOptionsR5(live){
 const agency=legacy.currentLiveAgencyR5(live);if(!agency)return[];
 const p=live.players[live.actorIndex],position=p?.position||p?.spawn?.cell;if(!position)return[];
 return agencyOptionsAtPositionR511(live,agency,position);
}

export function simulatedAgencyDecisionR59(live){
 if(live?.phase!=='AGENCY_ACTIONS')return null;const p=live.players[live.actorIndex];if(!p||p.controller!=='APP')return null;
 if(!legacy.agencyNeedsRepositionR510(live)){
  const option=chooseAutonomousAgencyOptionR59(live,liveAgencyOptionsR5(live));
  return{playerId:p.id,playerName:p.name,nature:p.nature,option:clone(option),controller:'APP',movement:{from:p.position,to:p.position,distance:0,limit:GENESIS_AGENCY_MOVEMENT_R510},spatialDecisionId:GENESIS_SPATIAL_R510_DECISION};
 }
 const plans=simulatedAgencyPlansR511(live),chosen=chooseAutonomousAgencyOptionR59(live,plans);
 return{playerId:p.id,playerName:p.name,nature:p.nature,option:clone(chosen),controller:'APP',movement:{from:p.position||p.spawn?.cell,to:chosen.moveTo,distance:chosen.movementDistance,limit:GENESIS_AGENCY_MOVEMENT_R510},spatialDecisionId:GENESIS_SPATIAL_R510_DECISION};
}

export function applyLiveAgencyOptionR5(live,optionId){
 if(live?.phase!=='AGENCY_ACTIONS')throw new Error('GEN_LIVE_R5_ACTION_PHASE');
 const planned=simulatedAgencyPlansR511(live).find(x=>x.id===optionId);
 if(planned){const moved=legacy.repositionLiveAgencyR510(live,planned.moveTo);return applyLiveAgencyOptionR5(moved,planned.originalOptionId);}
 let working=live;
 if(legacy.agencyNeedsRepositionR510(working))working=autoRepositionForRequestedOptionR511(working,optionId);
 const options=liveAgencyOptionsR5(working),o=options.find(x=>x.id===optionId);if(!o)throw new Error('GEN_LIVE_R5_ACTION_ILLEGAL');
 const n=clone(working),player=n.players[n.actorIndex],agency=runtimeAgencyR5(n.runtime,player.id);n.pendingAgencyActions??=[];
 if(o.kind!=='WAIT')n.pendingAgencyActions.push({seq:n.pendingAgencyActions.length,round:n.round,playerId:player.id,controller:player.controller,agencyId:agency.id,nature:agency.nature,intensity:agency.universeIntensity,optionId:o.id,kind:o.kind,targetId:o.targetId,otherId:o.otherId||null,principle:o.principle||null,mode:o.mode||null,capabilityId:o.capabilityId,capabilityLevel:o.capabilityLevel,payload:clone(o.payload||null),remoteReach:o.remoteReach||null,remotePathAuthorized:o.remotePathAuthorized===true,spatialTargetIds:clone(o.spatialTargetIds||null),agencyPosition:player.position,spatial:clone(o.spatial||null),spatialDecisionId:GENESIS_SPATIAL_R510_DECISION});
 n.history.push({type:'GEN_LIVE_R5_AGENCY_CHOICE',round:n.round,playerId:player.id,controller:player.controller,optionId:o.id,capabilityId:o.capabilityId||null,agencyPosition:player.position,spatial:clone(o.spatial||null),spatialDecisionId:GENESIS_SPATIAL_R510_DECISION});
 narrate(n,'AGENCY_CHOICE',o.kind==='WAIT'?`${player.name} decide no intervenir. La omisión no borra la causalidad ya existente: el universo seguirá avanzando.`:`${player.controller==='APP'?'La app hace actuar a':'El jugador hace actuar a'} ${natureAgentLabel(agency.nature)} (${player.name}): ${o.label}. La familia R5.11 queda oculta como lógica de autorización; la decisión mostrada sigue siendo una acción concreta sobre el mundo.`);
 n.actorIndex++;
 if(n.actorIndex>=n.players.length){n.actorIndex=0;applyPendingAgencyBatchR511(n);n.contextual=legacy.compileLiveContextualIntentionsR5(n);n.phase='PHYSICAL_INTENTION_CHOICE';narrate(n,'JOINT_INTENTION_FRAME',n.contextual.narrative.publicText);}
 return n;
}

export function capabilityDebugProjectionR511(live){
 if(!live?.players?.length)return[];
 return live.players.map(p=>{const a=runtimeAgencyR5(live.runtime,p.id),actions=contextualAgencyActionsR511(live,a);return{playerId:p.id,nature:a.nature,intensity:a.universeIntensity,capabilityIds:[...new Set(actions.map(x=>x.capabilityId))],concreteActionCount:actions.length,humanValidation:'PENDING'};});
}

function agencyOptionsAtPositionR511(live,agency,position){
 const board=live.runtime.cosmogony.board,parcels=live.runtime.cosmogony.matter.parcels,raw=contextualAgencyActionsR511(live,agency),out=[];
 raw.push({id:'WAIT',kind:'WAIT',targetId:null,label:'No intervenir con esta agencia',capabilityId:null,noIntervene:true,decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01'});
 for(const option of raw){
  if(option.kind==='WAIT'){out.push({...option,spatial:{decisionId:GENESIS_SPATIAL_R510_DECISION,from:position,presence:'NONE'}});continue;}
  const ids=(option.spatialTargetIds?.length?option.spatialTargetIds:[option.targetId,option.otherId]).filter(Boolean),targets=[];let legal=true;
  for(const id of ids){const parcel=parcels.find(p=>p.id===id);if(!parcel){legal=false;break;}const status=classifyAgencyPresenceR510({board,from:position,target:parcel.cell,intensity:agency.universeIntensity,option});targets.push({id,cell:parcel.cell,...status});if(status.presence==='OUT_OF_REACH')legal=false;}
  if(legal)out.push({...option,spatial:{decisionId:GENESIS_SPATIAL_R510_DECISION,from:position,targets,presence:targets[0]?.presence||'NONE',effectiveReach:targets.length?Math.max(...targets.map(t=>t.effectiveReach),1):1}});
 }
 // R5.11 must not erase a concrete legal action merely because global scoring ranked
 // another target first. Preserve the previously-proven concrete target set for the
 // canonical-equivalent low families, but only at their R5.11 unlock level.
 const supplemental=legacyEquivalentOptionsR511(live,agency,position);
 const curated=curateContextualAgencyActionsR511(out);
 const merged=new Map();for(const o of [...supplemental,...curated])merged.set(o.id,o);
 return[...merged.values()];
}

function legacyEquivalentOptionsR511(live,agency,position){
 const temp=clone(live),p=temp.players[temp.actorIndex];p.position=position;p.lastRepositionRound=temp.round;
 const mapping={
  PHYSICS:{CONCENTRATE:{level:1,capabilityId:'PHYSICS_CONCENTRATE'},PRESERVE_DISK:{level:4,capabilityId:'PHYSICS_STABILIZE_CAPTURE'}},
  MYSTIC:{LINK:{level:1,capabilityId:'MYSTIC_BIND'},IMPRINT:{level:2,capabilityId:'MYSTIC_PERSIST_IMPRINT'}},
  WILL:{PROTECT:{level:1,capabilityId:'WILL_PROTECT_CLAIM_REJECT'},CLAIM:{level:1,capabilityId:'WILL_PROTECT_CLAIM_REJECT'}}
 };
 const allowed=mapping[agency.nature]||{};
 return legacy.liveAgencyOptionsR5(temp).filter(o=>o.kind!=='WAIT'&&allowed[o.kind]&&agency.universeIntensity>=allowed[o.kind].level).map(o=>({...o,capabilityId:allowed[o.kind].capabilityId,capabilityLevel:allowed[o.kind].level,requiredLevel:allowed[o.kind].level,decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01',playerFacingCapabilityMenu:false,legacyEquivalentContract:true}));
}

function simulatedAgencyPlansR511(live){
 if(live?.phase!=='AGENCY_ACTIONS')return[];const p=live.players[live.actorIndex];if(!p||p.controller!=='APP'||!legacy.agencyNeedsRepositionR510(live))return[];const agency=runtimeAgencyR5(live.runtime,p.id),movement=legacy.liveAgencyMovementR510(live),plans=[];
 for(const dest of movement.destinations){for(const option of agencyOptionsAtPositionR511(live,agency,dest.code).filter(o=>o.kind!=='WAIT'))plans.push({...option,id:`R511-PLAN:${dest.code}:${option.id}`,originalOptionId:option.id,moveTo:dest.code,movementDistance:dest.distance,label:`${dest.distance?`Mover a ${dest.code} y `:'Sin mover: '}${option.label}`});}
 if(plans.length)return plans;
 return[{id:`R511-PLAN:${movement.from}:WAIT`,originalOptionId:'WAIT',moveTo:movement.from,movementDistance:0,kind:'WAIT',targetId:null,label:'No intervenir con esta agencia'}];
}

function autoRepositionForRequestedOptionR511(live,optionId){
 const p=live.players[live.actorIndex],agency=runtimeAgencyR5(live.runtime,p.id),movement=legacy.liveAgencyMovementR510(live),candidates=[];
 for(const dest of movement.destinations){const option=agencyOptionsAtPositionR511(live,agency,dest.code).find(o=>o.id===optionId);if(option)candidates.push({dest,option});}
 if(!candidates.length)throw new Error('GEN_LIVE_R511_ACTION_UNREACHABLE_AFTER_MOVE');const chosen=candidates.sort((a,b)=>a.dest.distance-b.dest.distance||a.dest.code.localeCompare(b.dest.code))[0];return legacy.repositionLiveAgencyR510(live,chosen.dest.code);
}

function applyPendingAgencyBatchR511(live){
 const actions=[...(live.pendingAgencyActions||[])];if(!actions.length){live.pendingAgencyActions=[];return;}
 const signature=live.runtime.signatureRecord.signature,defeated=new Set(),precedence=new Map();
 for(let i=0;i<actions.length;i++)for(let j=i+1;j<actions.length;j++){
  const a=actions[i],b=actions[j];if(!crossNatureIncompatibleR53(a,b))continue;
  const ai=Number(signature[a.nature]||0),bi=Number(signature[b.nature]||0);if(ai===bi)throw new Error('GEN_LIVE_R53_CAUSAL_TIE_INVALID');
  const winner=ai>bi?a:b,loser=ai>bi?b:a;defeated.add(loser.seq);const key=`${winner.targetId}:${winner.nature}>${loser.nature}`;
  if(!precedence.has(key))precedence.set(key,{type:'GEN_R53_CAUSAL_PRECEDENCE',round:live.round,targetId:winner.targetId,winnerNature:winner.nature,loserNature:loser.nature,winnerIntensity:ai>bi?ai:bi,loserIntensity:ai>bi?bi:ai,winnerPlayerIds:new Set(),defeatedPlayerIds:new Set(),defeatedOptionIds:new Set()});
  const r=precedence.get(key);r.winnerPlayerIds.add(winner.playerId);r.defeatedPlayerIds.add(loser.playerId);r.defeatedOptionIds.add(loser.optionId);
 }
 const order={CONCENTRATE:1,REDISTRIBUTE:2,TRANSFER_ENERGY:3,PRESERVE_DISK:4,ACTIVATE_NUCLEAR_CHANGE:5,SYSTEMIC_APPLICATION:6,PROTECT:7,CLAIM:8,DESIGNATE_PURPOSE:9,MANIFEST_TRACE:10,VOLITION_RELATION:11,AUTOLIMIT:12,BOUNDED_DECREE:13,IMPRINT:14,LINK:15,RESONATE_MARK:16,CONDITIONAL_TRANSFORM:17,CYCLE_ENTANGLE:18,BRIDGE_CONSCIOUSNESS_MATTER:19};
 const applied=actions.filter(a=>!defeated.has(a.seq)).sort((a,b)=>String(a.targetId||'').localeCompare(String(b.targetId||''))||(order[a.kind]??99)-(order[b.kind]??99)||String(a.nature).localeCompare(String(b.nature))||String(a.playerId).localeCompare(String(b.playerId)));
 let runtime=live.runtime;for(const a of applied)runtime=applyContextualCapabilityActionR511(runtime,a);
 for(const raw of precedence.values()){
  const event={...raw,winnerPlayerIds:[...raw.winnerPlayerIds].sort(),defeatedPlayerIds:[...raw.defeatedPlayerIds].sort(),defeatedOptionIds:[...raw.defeatedOptionIds].sort()};runtime.eventLog.push(clone(event));runtime.cosmogony.history.push({type:'CAUSAL_OPPOSITION_RESIDUE',round:live.round,targetId:event.targetId,winnerNature:event.winnerNature,loserNature:event.loserNature,winnerIntensity:event.winnerIntensity,loserIntensity:event.loserIntensity,defeatedPlayerIds:[...event.defeatedPlayerIds]});live.history.push(clone(event));
 }
 live.runtime=runtime;live.pendingAgencyActions=[];
}

function crossNatureIncompatibleR53(a,b){
 if(a.targetId!==b.targetId||a.nature===b.nature)return false;const pair=new Set([a.nature,b.nature]);if(!(pair.has('PHYSICS')&&pair.has('WILL')))return false;
 return(a.kind==='CONCENTRATE'&&b.kind==='PROTECT')||(a.kind==='PROTECT'&&b.kind==='CONCENTRATE');
}
function natureAgentLabel(n){return n==='PHYSICS'?'una fuerza física':n==='MYSTIC'?'un principio místico':'una Voluntad';}
function narrate(live,kind,publicText){live.currentNarrative=publicText;live.narrativeLog??=[];live.narrativeLog.push({round:live.round,kind,publicText});}
