import {deriveSignatureR53,deriveSoloSignatureR59,bindAgenciesToSignatureR53,actionTierR53} from './genesis-signature-r53.js';
import {createCosmogonyR5,applyCosmogonyIntervention,advanceCosmicEpoch,cosmogonySummary} from './genesis-cosmogony-r5.js';
import {analyzeOntologyR5,bootstrapVolitionDomainsR5,availableVolitionActionsR5,GENESIS_LAW_ORIGIN_GATE_R54_SCHEMA,LAW_ORIGIN_MODES_R54} from './genesis-ontology-r5.js';
import {compileGenesisLegacyR5,createOntologyR5} from './genesis-legacy-r5.js';
import {adaptR5LegacyToBoot01Envelope} from './genesis-legacy-r5-adapter.js';
import {recordWillMysticRelationR56,relationsForVolitionR56} from './genesis-will-mystic-r56.js';
import {establishVolitionRelationR57,relationsForVolitionR57,relationsBetweenVolitionsR57,projectVolitionRelationsForPlayersR57} from './genesis-volition-relations-r57.js';

export const GENESIS_RUNTIME_R5_SCHEMA='EMR_GENESIS_RUNTIME_R5_v1';
const clone=x=>structuredClone(x);

export function createGenesisRuntimeR5({choices,signatureRolls={},signatureRecordOverride=null,seed='EMR',boardPreset='B76',matterCount=10,playerIds=[],agencyNatures=null}={}){
 if(!Array.isArray(choices)||!choices.length)throw new Error('GEN_R5_CHOICES_REQUIRED');
 // 0.31.7 may resolve the solo primordial signature privately in the entry layer.
 // Legacy callers still derive through the established R5.9 path when no override exists.
 const signatureRecord=signatureRecordOverride?validatedSignatureOverride(signatureRecordOverride):(choices.length===1?deriveSoloSignatureR59(choices[0],signatureRolls):deriveSignatureR53(choices,signatureRolls));
 const boundNatures=Array.isArray(agencyNatures)&&agencyNatures.length?agencyNatures:choices;
 if(playerIds.length&&playerIds.length!==boundNatures.length)throw new Error('GEN_R5_AGENCY_IDS_MISMATCH');
 if(boundNatures.some(n=>Number(signatureRecord.signature[n]||0)<=0))throw new Error('GEN_R5_ABSENT_AGENCY_FORBIDDEN');
 const binding=bindAgenciesToSignatureR53(boundNatures,signatureRecord.signature,{playerIds});
 const ontologyAnalysis=analyzeOntologyR5({signature:signatureRecord.signature,binding});
 const ontology=createOntologyR5({signature:signatureRecord.signature,binding});
 const domainBootstrap=bootstrapVolitionDomainsR5({signature:signatureRecord.signature,binding});
 for(const d of domainBootstrap){const e=ontology.volitionEntities.find(x=>x.entityId===d.entityId);if(e)e.domains.push(...d.domains);}
 const cosmogony=createCosmogonyR5({seed,boardPreset,matterCount});
 return{schema:GENESIS_RUNTIME_R5_SCHEMA,version:'R5.9-dev031',seed:String(seed),boardPreset,matterCount,choices:[...choices],agencyNatures:[...boundNatures],signatureRecord,binding,ontologyAnalysis,ontology,lawOriginResolution:null,cosmogony,phase:'PLAY',turn:0,eventLog:[{type:'GEN_R5_RUNTIME_CREATED',signature:clone(signatureRecord.signature),signatureMode:signatureRecord.mode,rolls:clone(signatureRecord.rolls||{}),agencyNatures:[...boundNatures],boardPreset,matterCount}],selectedPlanetId:null,legacy:null,boot01Envelope:null};
}

function validatedSignatureOverride(record){
 const r=clone(record);if(!r?.signature)throw new Error('GEN_R5_SIGNATURE_OVERRIDE_INVALID');
 for(const n of ['PHYSICS','MYSTIC','WILL'])if(!Number.isInteger(r.signature[n])||r.signature[n]<0||r.signature[n]>6)throw new Error('GEN_R5_SIGNATURE_OVERRIDE_INVALID');
 r.rolls??={};r.counts??={PHYSICS:0,MYSTIC:0,WILL:0};r.mode??='ENTRY_RESOLVED';return r;
}

export function runtimeAgencyR5(state,playerId){
 validateRuntime(state);const a=state.binding.agencies.find(x=>x.playerId===playerId);if(!a)throw new Error('GEN_R5_PLAYER_UNKNOWN');
 const domains=a.volitionEntityId?(state.ontology.volitionEntities.find(v=>v.entityId===a.volitionEntityId)?.domains||[]):[];
 const willMysticRelations=a.volitionEntityId&&state.ontology.willMysticGraph?relationsForVolitionR56(state.ontology.willMysticGraph,a.volitionEntityId):null;
 const volitionRelations=a.volitionEntityId&&state.ontology.volitionRelationGraph?relationsForVolitionR57(state.ontology.volitionRelationGraph,a.volitionEntityId):[];
 return{...clone(a),domains,willMysticRelations,volitionRelations,volitionActions:a.nature==='WILL'?availableVolitionActionsR5({intensity:a.universeIntensity,domains}):[]};
}

export function runtimeVolitionPairR5(state,fromEntityId,toEntityId){validateRuntime(state);return relationsBetweenVolitionsR57(state.ontology.volitionRelationGraph,fromEntityId,toEntityId);}
export function projectRuntimeVolitionRelationsForPlayersR5(state,playerIds=[]){validateRuntime(state);return projectVolitionRelationsForPlayersR57(state.ontology.volitionRelationGraph,{playerIds});}

export function establishVolitionRelationR5(state,{fromEntityId,toEntityId,type,symmetry='DIRECTED',producerIds=[],scope='RELATIONAL',conditions=[],limits=[],provenance,visibility='PUBLIC',knownToPlayerIds=[],futureConsumers=[]}={}){
 validateRuntime(state);if(state.phase!=='PLAY')throw new Error('GEN_R5_PHASE_INVALID');
 const next=clone(state);const beforeCount=next.ontology.volitionRelationGraph.edges.length;
 next.ontology.volitionRelationGraph=establishVolitionRelationR57(next.ontology.volitionRelationGraph,{fromEntityId,toEntityId,type,symmetry,producerIds,scope,conditions,limits,createdAt:next.turn,provenance,visibility,knownToPlayerIds,futureConsumers});
 const relation=clone(next.ontology.volitionRelationGraph.edges[beforeCount]);
 const fact={factId:`FACT-${relation.relationId}`,type:'VOLITION_RELATION_ESTABLISHED',relationId:relation.relationId,fromEntityId,toEntityId,relationType:type,producerIds:[...relation.producerIds],scope,provenance,visibility};
 next.ontology.objectiveSupernaturalFacts.push(clone(fact));
 if(visibility==='PUBLIC')next.ontology.publicGenesisFacts.push(clone(fact));else next.ontology.hiddenGenesisFacts.push(clone(fact));
 const hook={hookId:`HOOK-${relation.relationId}`,sourceFactId:fact.factId,type:'VOLITION_RELATION_CONSEQUENCE',consumers:[...new Set(futureConsumers.length?futureConsumers:['BOOT03','FUTURE_BOOTS','RUNTIME'])],visibility:'ENGINE_ONLY',status:'AVAILABLE'};
 next.ontology.futureHooks.push(hook);
 next.eventLog.push({type:'GEN_R57_VOLITION_RELATION_ESTABLISHED',relation:clone(relation),factId:fact.factId,hookId:hook.hookId});
 return next;
}

function causalProducerEntityIdR5(agency){
 if(agency?.nature==='MYSTIC'&&agency.mysticForceId)return agency.mysticForceId;
 if(agency?.nature==='WILL'&&agency.volitionEntityId)return agency.volitionEntityId;
 return null;
}

export function applyRuntimeAgencyActionR5(state,{playerId,kind,targetId,otherId=null,principle=null}={}){
 validateRuntime(state);if(state.phase!=='PLAY')throw new Error('GEN_R5_PHASE_INVALID');
 const agency=runtimeAgencyR5(state,playerId);if(actionTierR53(agency.universeIntensity)<1)throw new Error('GEN_R5_AGENCY_NO_AUTHORITY');
 const producerEntityId=causalProducerEntityIdR5(agency);
 const next=clone(state);next.cosmogony=applyCosmogonyIntervention(next.cosmogony,{actorId:agency.id,producerEntityId,nature:agency.nature,kind,targetId,otherId,principle});
 next.eventLog.push({type:'GEN_R5_AGENCY_ACTION',playerId,agencyId:agency.id,producerEntityId,nature:agency.nature,kind,targetId,otherId,principle,epoch:next.cosmogony.epoch});next.turn++;
 return next;
}

export function recordVolitionDecreeR5(state,{playerId,decreeId='STABLE_MATERIAL_REGULARITIES',text=null}={}){
 validateRuntime(state);const next=clone(state),agency=runtimeAgencyR5(next,playerId);if(agency.nature!=='WILL')throw new Error('GEN_R5_VOLITION_REQUIRED');
 if(!agency.volitionActions.some(a=>a.id==='DECREE_LAW'))throw new Error('GEN_R5_DECREE_NOT_AUTHORIZED');
 const entity=next.ontology.volitionEntities.find(v=>v.entityId===agency.volitionEntityId);const fact={type:'VOLITION_DECREE',producerId:entity.entityId,decreeId,text:text||null};entity.facts.push(fact);next.ontology.objectiveSupernaturalFacts.push(fact);next.ontology.lawAuthority={physicalAutonomy:'ABSENT_AS_INDEPENDENT_AUTHORITY',originOfPhysicalRegularities:`DECREED_BY:${entity.entityId}`,originMode:'VOLITION_DECREED',producerIds:[entity.entityId],exceptionsAndSelfLimits:[]};next.eventLog.push({...fact,playerId});return next;
}

export function lawOriginGateR5(state){
 validateRuntime(state);if(state.ontologyAnalysis.lawMode!=='LAW_ORIGIN_GATE')return null;
 const signature=state.signatureRecord.signature,willAgencies=state.binding.agencies.filter(a=>a.nature==='WILL');
 const decreeCandidates=willAgencies.filter(a=>actionTierR53(a.universeIntensity)>=3).map(a=>({playerId:a.playerId,agencyId:a.id,volitionEntityId:a.volitionEntityId,authorityBand:a.authorityBand}));
 const relationCandidates=willAgencies.map(a=>({playerId:a.playerId,agencyId:a.id,volitionEntityId:a.volitionEntityId,authorityBand:a.authorityBand}));
 return{
  schema:GENESIS_LAW_ORIGIN_GATE_R54_SCHEMA,
  decisionId:'D-GEN-R5.4-LAW-ORIGIN-GATE01',
  state:state.lawOriginResolution?'RESOLVED':'UNSETTLED_CAUSALITY',
  signature:clone(signature),
  options:[
   {mode:'MYSTIC_DERIVED',legal:signature.MYSTIC>0,producerIds:['MYSTIC_SUBSTRATE']},
   {mode:'VOLITION_DECREED',legal:decreeCandidates.length>0,candidates:decreeCandidates},
   {mode:'RELATIONAL_CO_PRODUCED',legal:signature.MYSTIC>0&&relationCandidates.length>0,candidates:relationCandidates}
  ],
  resolution:clone(state.lawOriginResolution)
 };
}

export function establishLawOriginR5(state,{mode,playerId=null}={}){
 validateRuntime(state);if(state.phase!=='PLAY')throw new Error('GEN_R5_PHASE_INVALID');if(state.ontologyAnalysis.lawMode!=='LAW_ORIGIN_GATE')throw new Error('GEN_R5_LAW_ORIGIN_GATE_NOT_REQUIRED');if(state.lawOriginResolution)throw new Error('GEN_R5_LAW_ORIGIN_ALREADY_RESOLVED');
 if(!LAW_ORIGIN_MODES_R54.includes(mode))throw new Error('GEN_R5_LAW_ORIGIN_MODE_INVALID');
 const gate=lawOriginGateR5(state),option=gate.options.find(o=>o.mode===mode);if(!option?.legal)throw new Error('GEN_R5_LAW_ORIGIN_MODE_ILLEGAL');
 let next=clone(state),producerIds=[];
 if(mode==='MYSTIC_DERIVED'){
  producerIds=['MYSTIC_SUBSTRATE'];
  next.ontology.lawAuthority={physicalAutonomy:'ABSENT_AS_INDEPENDENT_AUTHORITY',originOfPhysicalRegularities:'MYSTIC_DERIVED:MYSTIC_SUBSTRATE',originMode:mode,producerIds,decisionId:'D-GEN-R5.4-LAW-ORIGIN-GATE01',exceptionsAndSelfLimits:[]};
  if(!next.ontology.mysticSubstrate.rules.includes('PRODUCES_STABLE_MATERIAL_REGULARITIES'))next.ontology.mysticSubstrate.rules.push('PRODUCES_STABLE_MATERIAL_REGULARITIES');
  next.ontology.objectiveSupernaturalFacts.push({type:'LAW_ORIGIN_ESTABLISHED',mode,producerIds:[...producerIds]});
 }
 if(mode==='VOLITION_DECREED'){
  const candidate=selectCandidate(option.candidates,playerId,'GEN_R5_LAW_ORIGIN_VOLITION_PLAYER_REQUIRED');
  const entity=next.ontology.volitionEntities.find(v=>v.entityId===candidate.volitionEntityId);if(!entity)throw new Error('GEN_R5_LAW_ORIGIN_VOLITION_UNKNOWN');
  if(!entity.domains.includes('COSMOGONIC_AUTHOR'))entity.domains.push('COSMOGONIC_AUTHOR');
  next=recordVolitionDecreeR5(next,{playerId:candidate.playerId,decreeId:'STABLE_MATERIAL_REGULARITIES'});producerIds=[candidate.volitionEntityId];
  next.ontology.lawAuthority.decisionId='D-GEN-R5.4-LAW-ORIGIN-GATE01';
  next.ontology.objectiveSupernaturalFacts.push({type:'LAW_ORIGIN_ESTABLISHED',mode,producerIds:[...producerIds]});
 }
 if(mode==='RELATIONAL_CO_PRODUCED'){
  const candidate=selectCandidate(option.candidates,playerId,'GEN_R5_LAW_ORIGIN_RELATION_PLAYER_REQUIRED');producerIds=['MYSTIC_SUBSTRATE',candidate.volitionEntityId];
  next.ontology.lawAuthority={physicalAutonomy:'ABSENT_AS_INDEPENDENT_AUTHORITY',originOfPhysicalRegularities:`CO_PRODUCED_BY:MYSTIC_SUBSTRATE+${candidate.volitionEntityId}`,originMode:mode,producerIds:[...producerIds],decisionId:'D-GEN-R5.4-LAW-ORIGIN-GATE01',exceptionsAndSelfLimits:['NO_GENERAL_OMNIPOTENCE_INFERRED']};
  const entity=next.ontology.volitionEntities.find(v=>v.entityId===candidate.volitionEntityId);if(!entity)throw new Error('GEN_R5_LAW_ORIGIN_VOLITION_UNKNOWN');
  entity.relations.push({type:'CO_PRODUCES_MATERIAL_REGULARITIES_WITH_MYSTIC_SUBSTRATE'});
  next.ontology.mysticSubstrate.rules.push(`CO_PRODUCES_MATERIAL_REGULARITIES_WITH:${candidate.volitionEntityId}`);
  next.ontology.willMysticGraph=recordWillMysticRelationR56(next.ontology.willMysticGraph,{type:'CO_PRODUCER_OF_MATERIAL_LAW',volitionEntityId:candidate.volitionEntityId,producerId:candidate.volitionEntityId,scope:'SYSTEMIC',limits:['MATERIAL_LAW_ONLY','NO_GENERAL_MYSTIC_ACCESS'],createdAt:next.turn,provenance:'D-GEN-R5.4-LAW-ORIGIN-GATE01',actorNature:'WILL',actorIntensity:next.signatureRecord.signature.WILL,requiredLevel:1});
  next.ontology.objectiveSupernaturalFacts.push({type:'LAW_ORIGIN_ESTABLISHED',mode,producerIds:[...producerIds]});
 }
 next.lawOriginResolution={schema:GENESIS_LAW_ORIGIN_GATE_R54_SCHEMA,decisionId:'D-GEN-R5.4-LAW-ORIGIN-GATE01',mode,producerIds:[...producerIds],playerId:playerId||null,establishedAtTurn:next.turn};
 next.eventLog.push({type:'GEN_R5_LAW_ORIGIN_ESTABLISHED',...clone(next.lawOriginResolution)});
 return next;
}

export function advanceRuntimeEpochR5(state){
 validateRuntime(state);if(state.phase!=='PLAY')throw new Error('GEN_R5_PHASE_INVALID');const next=clone(state);
 if(next.ontologyAnalysis.lawMode==='VOLITION_DECREED'&&!String(next.ontology.lawAuthority.originOfPhysicalRegularities||'').startsWith('DECREED_BY:'))throw new Error('GEN_R5_MATERIAL_LAWS_NOT_ESTABLISHED');
 if(next.ontologyAnalysis.lawMode==='LAW_ORIGIN_GATE'&&!next.lawOriginResolution)throw new Error('GEN_R5_LAW_ORIGIN_UNSETTLED');
 next.cosmogony=advanceCosmicEpoch(next.cosmogony);next.eventLog.push({type:'GEN_R5_COSMIC_EPOCH',epoch:next.cosmogony.epoch,summary:cosmogonySummary(next.cosmogony)});
 if(next.cosmogony.closed){next.phase='SELECT_PLANET';next.selectedPlanetId=next.cosmogony.planets[0]?.id||null;}
 return next;
}

export function selectRuntimePlanetR5(state,planetId){
 validateRuntime(state);if(state.phase!=='SELECT_PLANET')throw new Error('GEN_R5_PLANET_SELECTION_PHASE');if(!state.cosmogony.planets.some(p=>p.id===planetId))throw new Error('GEN_R5_PLANET_UNKNOWN');const next=clone(state);next.selectedPlanetId=planetId;next.eventLog.push({type:'GEN_R5_PLANET_SELECTED',planetId});return next;
}

export function closeGenesisRuntimeR5(state){
 validateRuntime(state);if(state.phase!=='SELECT_PLANET'||!state.selectedPlanetId)throw new Error('GEN_R5_NOT_CLOSABLE');const next=clone(state);
 next.legacy=compileGenesisLegacyR5({cosmogony:next.cosmogony,signatureRecord:next.signatureRecord,binding:next.binding,selectedPlanetId:next.selectedPlanetId,ontology:next.ontology});
 next.boot01Envelope=adaptR5LegacyToBoot01Envelope(next.legacy,{id:`LEGACY-${next.seed}`});next.phase='CLOSED';next.eventLog.push({type:'GEN_R5_CLOSED',selectedPlanetId:next.selectedPlanetId,legacyId:next.boot01Envelope.id});return next;
}

export function serializeGenesisRuntimeR5(state){validateRuntime(state);return JSON.stringify(state);}
export function deserializeGenesisRuntimeR5(json){const s=JSON.parse(json);validateRuntime(s);return s;}

function selectCandidate(candidates,playerId,errorCode){
 if(!Array.isArray(candidates)||!candidates.length)throw new Error(errorCode);
 if(playerId){const c=candidates.find(x=>x.playerId===playerId);if(!c)throw new Error(errorCode);return c;}
 if(candidates.length===1)return candidates[0];throw new Error(errorCode);
}
function validateRuntime(s){if(s?.schema!==GENESIS_RUNTIME_R5_SCHEMA)throw new Error('GEN_R5_RUNTIME_INVALID');}