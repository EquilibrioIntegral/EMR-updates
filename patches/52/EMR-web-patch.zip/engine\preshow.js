// PRESHOW / Guionista inter-BOOT · A1
// Authority: EMR_PRESHOW_GUIONISTA_SIMULADOR_A1_v0.7
// D-PRESHOW-GUIONISTA-UNIFIED-AGENCY01
// Situation -> contextual Intentions + free action -> resolution -> persistence -> future consumption.

const MAX_CONTEXTUAL_INTENTIONS=4;
const forbiddenKeys=new Set(['secret','worldTruth','spoiler','hiddenState']);

const clone=v=>structuredClone(v);
const freeze=v=>Object.freeze(v);

function assertPhase(phase){
 if(!/^BOOT0[0-8]/.test(String(phase??''))) throw new Error('PRESHOW_BOOT_PHASE_REQUIRED');
}

function safePlayerView(value){
 const walk=v=>{
  if(Array.isArray(v)) return v.map(walk);
  if(v&&typeof v==='object') return Object.fromEntries(Object.entries(v).filter(([k])=>!forbiddenKeys.has(k)).map(([k,x])=>[k,walk(x)]));
  return v;
 };
 return walk(value);
}

export function openPreshowSituation({phase,sourceIds,situation,intentions=[],allowFreeAction=true}){
 assertPhase(phase);
 if(!Array.isArray(sourceIds)||!sourceIds.length) throw new Error('PRESHOW_SOURCED_SITUATION_REQUIRED');
 if(!situation?.id||!situation?.text) throw new Error('PRESHOW_SITUATION_REQUIRED');
 if(intentions.length>MAX_CONTEXTUAL_INTENTIONS) throw new Error('PRESHOW_MAX_4_INTENTIONS');
 const contextual=intentions.map((x,i)=>freeze({id:x.id??`CTX-${i+1}`,label:x.label,standardAction:x.standardAction,sourceIds:[...(x.sourceIds??sourceIds)]}));
 return freeze({
  phase:'PRESHOW_SITUATION',bootPhase:phase,sourceIds:[...sourceIds],
  situation:freeze(safePlayerView(situation)),
  contextualIntentions:contextual,
  noIntervenir:freeze({id:'NO_INTERVENIR',label:'No intervenir'}),
  freeActionEnabled:allowFreeAction===true
 });
}

export function translateFreeAction({declaration,target=null,approach=null,opposition=null,risk=null}){
 const text=String(declaration??'').trim();
 if(!text) throw new Error('PRESHOW_FREE_ACTION_REQUIRED');
 const t=text.toLowerCase();
 let standardAction='INTERACT';
 if(/mover|viajar|ir |acerc|huir|cruz/.test(t)) standardAction='MOVE';
 else if(/mirar|observar|buscar|investig|examinar/.test(t)) standardAction='OBSERVE';
 else if(/hablar|preguntar|negoci|convencer|amenazar/.test(t)) standardAction='SOCIAL';
 else if(/tomar|usar|abrir|romper|constru|colocar/.test(t)) standardAction='MANIPULATE';
 else if(/atacar|combat|golpear|defender/.test(t)) standardAction='CONFLICT';
 return freeze({kind:'FREE_ACTION',declaration:text,standardAction,target,approach,opposition,risk});
}

export function resolvePreshow({preshow,choice,resolution}){
 if(preshow?.phase!=='PRESHOW_SITUATION') throw new Error('PRESHOW_OPEN_REQUIRED');
 if(!choice) throw new Error('PRESHOW_CHOICE_REQUIRED');
 if(!resolution?.id||!Array.isArray(resolution.sourceIds)||!resolution.sourceIds.length) throw new Error('PRESHOW_RESOLUTION_PROVENANCE_REQUIRED');
 const delta=clone(resolution.delta??{});
 const consumables=(resolution.consumables??[]).map((c,i)=>freeze({
  id:c.id??`PRESHOW-CONSUMABLE-${i+1}`,type:c.type??'STATE',payload:clone(c.payload??{}),
  sourceIds:[...(c.sourceIds??resolution.sourceIds)],consumed:false
 }));
 return freeze({
  phase:'PRESHOW_RESOLVED',bootPhase:preshow.bootPhase,choice:clone(choice),resolutionId:resolution.id,
  sourceIds:[...new Set([...preshow.sourceIds,...resolution.sourceIds])],delta,consumables,
  persistence:freeze({required:true,callbackMustReferenceProducer:true})
 });
}

export function handoffPreshowToBoot({resolved,nextBootPhase,state}){
 if(resolved?.phase!=='PRESHOW_RESOLVED') throw new Error('PRESHOW_RESOLVED_REQUIRED');
 assertPhase(nextBootPhase);
 const out=clone(state??{});
 out.session??={}; out.session.preshow??={}; out.eventLog??=[];
 out.session.preshow.lastResolution=clone(resolved);
 out.session.preshow.consumables=[...(out.session.preshow.consumables??[]),...resolved.consumables.map(clone)];
 out.session.boot??={}; out.session.boot.phase=nextBootPhase;
 out.eventLog.push({type:'PRESHOW_RESOLVED',from:resolved.bootPhase,to:nextBootPhase,resolutionId:resolved.resolutionId,sourceIds:[...resolved.sourceIds]});
 return out;
}

export function consumePreshowConsumable(state,{id,consumerId}){
 if(!id||!consumerId) throw new Error('PRESHOW_CONSUMER_REQUIRED');
 const list=state?.session?.preshow?.consumables??[];
 const item=list.find(x=>x.id===id);
 if(!item) throw new Error('PRESHOW_CONSUMABLE_NOT_FOUND');
 if(item.consumed) throw new Error('PRESHOW_CONSUMABLE_ALREADY_CONSUMED');
 item.consumed=true; item.consumerId=consumerId;
 state.eventLog??=[]; state.eventLog.push({type:'PRESHOW_CONSUMED',id,consumerId,sourceIds:[...item.sourceIds]});
 return item;
}
