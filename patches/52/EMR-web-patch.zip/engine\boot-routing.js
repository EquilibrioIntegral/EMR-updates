// Canonical BOOT chronology guard for A1 Hybrid.
// CI-03/BOOT-00 -> BOOT-01 -> ... -> BOOT-08 -> RUNTIME.
export const BOOT_RUNTIME_PHASE='RUNTIME';

export function buildPrimordialLegacy(result, primordialConfig){
  if(!result?.signature||!primordialConfig) throw new Error('PRIMORDIAL_LEGACY_INPUT_REQUIRED');
  return Object.freeze({
    schemaVersion:'EMR-LEGADO-PRIMORDIAL-0.1',
    causalSignature:result.signature,
    primordialConfig,
    facts:[{id:'FACT-PRIMORDIAL-ORIGIN',type:'PRIMORDIAL_ORIGIN',objective:true,public:true,source:'CI-03'}],
    residues:Array.isArray(result.residues)?[...result.residues]:[],
    threads:Array.isArray(result.threads)?[...result.threads]:[],
    promises:Array.isArray(result.promises)?[...result.promises]:[],
    nextPhase:'BOOT01_READY'
  });
}

export function closeCi03ToBoot01(state,result,primordialConfig){
  state.session??={}; state.session.boot??={};
  const boot=state.session.boot;
  boot.ci03=result;
  boot.primordialConfig=primordialConfig;
  boot.primordialLegacy=buildPrimordialLegacy(result,primordialConfig);
  boot.phase='BOOT01_READY';
  state.eventLog??=[];
  state.eventLog.push({type:'PRIMORDIAL_LEGACY_COMPILED',gameTime:state.meta?.gameTime??0,nextPhase:'BOOT01_READY'});
  return boot.primordialLegacy;
}

export function runtimeGate(state){
  const boot=state?.session?.boot;
  if(!boot) return {ok:false,reason:'BOOT_STATE_MISSING'};
  if(boot.phase!==BOOT_RUNTIME_PHASE) return {ok:false,reason:'BOOT_NOT_CLOSED',phase:boot.phase};
  const b8=boot.boot08;
  if(b8?.phase!=='BOOT08_CLOSED'||b8?.runtimeEnabled!==true||!b8?.historySeed) return {ok:false,reason:'BOOT08_HISTORY_SEED_REQUIRED'};
  return {ok:true,historySeed:b8.historySeed};
}

export function shouldLoadRuntimeModule(state){return runtimeGate(state).ok;}
