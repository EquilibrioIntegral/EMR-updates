const FUNCTIONS=['PROTEGER','CONTROLAR','PROYECTAR','DISPUTAR'];
const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
function d6(v){v=Number(v);if(!Number.isInteger(v)||v<1||v>6)throw new Error('BOOT04_D6_INVALID');return v;}
function legalActor(a){return !!a?.id&&a.legal!==false&&a.authority!==false&&a.capacity!==false&&a.causalPath!==false;}
export function compileBoot04PowerConflict(contributions,die=1){
 if(!Array.isArray(contributions)||contributions.length<1||contributions.length>4)throw new Error('BOOT04_PLAYER_COUNT_INVALID');
 const variant=d6(die);const traces=[];const objectives=[];const pending=[];
 for(let i=0;i<contributions.length;i++){
  const c=contributions[i]??{},fn=norm(c.function);if(!FUNCTIONS.includes(fn))throw new Error('BOOT04_INTENTION_INVALID');
  const actor=c.collective??{};const trace={id:`BOOT04-${i+1}-${fn}`,player:i+1,function:fn,collectiveId:actor.id??null,status:'PENDING_LEGALITY'};traces.push(trace);
  if(!legalActor(actor)){trace.status='NO_MATERIALIZATION';pending.push({traceId:trace.id,reason:'AUTHORITY_CAPACITY_OR_CAUSAL_PATH_MISSING'});continue;}
  const obj={id:c.objectiveId??`${trace.id}-OBJ`,traceId:trace.id,function:fn,collectiveId:actor.id,referentId:c.referentId??null,resourceId:c.resourceId??null,legal:true};objectives.push(obj);trace.status='VALID_OBJECTIVE';
 }
 const collisions=[];
 for(let i=0;i<objectives.length;i++)for(let j=i+1;j<objectives.length;j++){
  const a=objectives[i],b=objectives[j];const sameReferent=a.referentId&&a.referentId===b.referentId;const sameResource=a.resourceId&&a.resourceId===b.resourceId;
  const opposed=a.collectiveId!==b.collectiveId&&(a.function==='DISPUTAR'||b.function==='DISPUTAR');
  if((sameReferent||sameResource)&&opposed)collisions.push({a:a.id,b:b.id,status:'PENDING_CAUSAL_RESOLUTION'});
 }
 return {schemaVersion:'WG-STATE-BOOT04-0.1',variant,functions:[...FUNCTIONS],traces,objectives,collisions,pending,hardRules:['INTENTION_NOT_RESULT','NO_GLOBAL_MAJORITY','LEGALITY_BEFORE_PREFERENCE','RNG_ONLY_LEGAL_EQUIVALENTS','NO_ARTIFICIAL_WAR','NO_UNIVERSAL_FORCE_SCALE']};
}
export function deriveOrganizedForce(candidate,context={}){
 if(!candidate?.id)return {ok:false,reason:'REFERENT_REQUIRED'};
 const required=['government','population','economy','materialDevelopment','authority','resources'];
 if(required.some(k=>!context[k]))return {ok:false,reason:'CAUSAL_SUPPORT_MISSING'};
 return {ok:true,force:{id:candidate.id,kind:candidate.kind??'ORGANIZED_CAPABILITY',source:'BOOT04',scale:null}};
}
export function canMaterializeHistoricalConflict(a,b,context={}){
 if(!a||!b||a.collectiveId===b.collectiveId)return {ok:false,reason:'TWO_ACTORS_REQUIRED'};
 if(!context.incompatibleClaims)return {ok:false,reason:'INCOMPATIBLE_CLAIMS_REQUIRED'};
 if(!context.realCapacity||!context.causalPath)return {ok:false,reason:'CAPACITY_PATH_REQUIRED'};
 if(!context.concreteReferent&&!context.causalObligation)return {ok:false,reason:'REFERENT_REQUIRED'};
 return {ok:true};
}
export function commitBoot04(state,contributions,die=1){
 const boot=state?.session?.boot;if(!boot?.boot03)throw new Error('BOOT04_CIVILIZATION_REQUIRED');
 const out=compileBoot04PowerConflict(contributions,die);boot.boot04=out;boot.phase='BOOT04_COMPILED';
 state.eventLog??=[];state.eventLog.push({type:'BOOT04_POWER_CONFLICT_COMPILED',gameTime:state.meta?.gameTime??0,variant:out.variant,causalTraceIds:out.traces.map(x=>x.id),collisionCount:out.collisions.length});return out;
}
export function advanceBoot04ToBoot05(state){if(!state?.session?.boot?.boot04)throw new Error('BOOT04_NOT_COMPILED');state.session.boot.phase='BOOT05_READY';return state.session.boot.phase;}
