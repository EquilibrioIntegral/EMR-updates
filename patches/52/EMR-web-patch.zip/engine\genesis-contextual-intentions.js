import {compilePrimordialCandidates} from './primordial-causal-resolver.js';

export const GENESIS_CONTEXTUAL_INTENTIONS_SCHEMA='EMR_GENESIS_CONTEXTUAL_INTENTIONS_v1';
export const GENESIS_CONTEXTUAL_VOTE_SCHEMA='EMR_GENESIS_CONTEXTUAL_VOTE_v1';
const clone=x=>structuredClone(x);

function cardCode(deckCode,slot){
  if(!deckCode)throw new Error('GEN_CONTEXTUAL_INTENTION_DECK_REQUIRED');
  return `${deckCode}-${slot}`;
}

/**
 * Materializes the already-canonical 4 + NO INTERVENIR interface without
 * deciding the unresolved 0–6 force-resolution formula.
 *
 * The causal resolver owns legality/filtering. This adapter only assigns the
 * resulting contextual actions to the physical cards 1–4 and N for each
 * player's intention deck.
 */
export function compileContextualIntentionCards(causalState,intentionAssignments=[]){
  const {actions,noIntervene}=compilePrimordialCandidates(causalState,{limit:4});
  const visible=actions.map((action,index)=>({
    slot:index+1,
    ...clone(action)
  }));
  const players=intentionAssignments.map((assignment,index)=>({
    playerId:assignment.playerId||`P${index+1}`,
    playerName:assignment.playerName,
    deckCode:assignment.code,
    cards:visible.map(option=>({slot:option.slot,cardCode:cardCode(assignment.code,option.slot),actionId:option.id}))
      .concat([{slot:'N',cardCode:cardCode(assignment.code,'N'),actionId:noIntervene.id}])
  }));
  return {
    schema:GENESIS_CONTEXTUAL_INTENTIONS_SCHEMA,
    options:visible,
    noIntervene:{slot:'N',...clone(noIntervene)},
    players
  };
}

/** Freeze the card meanings for one concrete situation before players choose. */
export function createContextualIntentionVote(causalState,intentionAssignments=[],contextRef=null){
  const mapping=compileContextualIntentionCards(causalState,intentionAssignments);
  if(!mapping.players.length)throw new Error('GEN_CONTEXTUAL_VOTE_PLAYERS_REQUIRED');
  return {
    schema:GENESIS_CONTEXTUAL_VOTE_SCHEMA,
    contextRef,
    mapping,
    playerOrder:mapping.players.map(p=>p.playerId),
    submittedPlayerIds:[],
    secretSelections:{},
    revealed:false
  };
}

export function submitContextualIntentionCard(vote,{playerId,slot}={}){
  validateVote(vote);
  if(vote.revealed)throw new Error('GEN_CONTEXTUAL_VOTE_ALREADY_REVEALED');
  if(vote.submittedPlayerIds.includes(playerId))throw new Error('GEN_CONTEXTUAL_VOTE_ALREADY_SUBMITTED');
  const player=vote.mapping.players.find(p=>p.playerId===playerId);
  if(!player)throw new Error('GEN_CONTEXTUAL_VOTE_PLAYER_UNKNOWN');
  const normalized=slot==='N'?'N':Number(slot);
  const card=player.cards.find(c=>c.slot===normalized);
  if(!card)throw new Error('GEN_CONTEXTUAL_VOTE_CARD_ILLEGAL');
  const next=clone(vote);
  next.secretSelections[playerId]={slot:normalized,cardCode:card.cardCode,actionId:card.actionId};
  next.submittedPlayerIds.push(playerId);
  return next;
}

export function revealContextualIntentions(vote){
  validateVote(vote);
  if(vote.submittedPlayerIds.length!==vote.playerOrder.length)throw new Error('GEN_CONTEXTUAL_VOTE_INCOMPLETE');
  const next=clone(vote);next.revealed=true;return next;
}

/** Player/shared projection: meanings are public; chosen cards stay hidden until reveal. */
export function projectContextualIntentionVote(vote){
  validateVote(vote);
  const publicVote={
    schema:vote.schema,
    contextRef:vote.contextRef,
    mapping:clone(vote.mapping),
    playerOrder:[...vote.playerOrder],
    submittedPlayerIds:[...vote.submittedPlayerIds],
    revealed:vote.revealed
  };
  if(vote.revealed)publicVote.selections=vote.playerOrder.map(playerId=>({playerId,...clone(vote.secretSelections[playerId])}));
  return publicVote;
}

export function serializeContextualIntentionVote(vote){validateVote(vote);return JSON.stringify(vote);}
export function deserializeContextualIntentionVote(json){const vote=JSON.parse(json);validateVote(vote);return vote;}

function validateVote(vote){
  if(vote?.schema!==GENESIS_CONTEXTUAL_VOTE_SCHEMA||vote.mapping?.schema!==GENESIS_CONTEXTUAL_INTENTIONS_SCHEMA)throw new Error('GEN_CONTEXTUAL_VOTE_INVALID');
  if(!Array.isArray(vote.playerOrder)||!Array.isArray(vote.submittedPlayerIds)||!vote.secretSelections)throw new Error('GEN_CONTEXTUAL_VOTE_INVALID');
}
