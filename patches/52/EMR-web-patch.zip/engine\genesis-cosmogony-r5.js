import {axialDistance,makeBoardPreset,nearestCells} from './genesis-board-r5.js';
import {generateMatterParcels,totalMatterMass} from './genesis-material-r5.js';
import {stellarPacingGateR528} from './genesis-stellar-pacing-r528.js';

export const GENESIS_COSMOGONY_R5_SCHEMA='EMR_GENESIS_COSMOGONY_R5_v1';
export const GENESIS_R520_COLLISION_DECISION='D-GEN-R5.20-CAUSAL-GUIONISTA01';
export const GENESIS_R522_STELLAR_DECISION='D-GEN-R5.22-STELLAR-GENEALOGY-ENVIRONMENT01';

const clone=x=>structuredClone(x);
const byId=(s,id)=>s.matter.parcels.find(p=>p.id===id);
const centerOf=s=>s.board.center||{q:0,r:0};
const FAMILY_ORDER=['M_RED_DWARF','K_ORANGE','G_YELLOW','F_A_WHITE_YELLOW','B_O_BLUE_MASSIVE'];

export function createCosmogonyR5({seed='EMR',boardPreset='B76',matterCount=10}={}){
 const board=makeBoardPreset(boardPreset),matter=generateMatterParcels({seed,board,count:matterCount}),totalMass=totalMatterMass(matter);
 return{schema:GENESIS_COSMOGONY_R5_SCHEMA,seed:String(seed),board,matter,epoch:0,phase:'COLLAPSE',totalInitialMass:totalMass,star:{state:'NONE',mass:0,members:[],family:null,ignitionEpoch:null,formationProfile:null},planets:[],satellites:[],history:[],interventions:[],closed:false};
}

export function applyCosmogonyIntervention(state,{actorId,producerEntityId=null,nature,kind,targetId,otherId=null,principle=null}={}){
 if(state.closed)throw new Error('GEN_COSMOGONY_CLOSED');
 const s=clone(state),p=byId(s,targetId);if(!p)throw new Error('GEN_COSMOGONY_TARGET_UNKNOWN');
 if(kind==='CONCENTRATE'){
  if(nature!=='PHYSICS')throw new Error('GEN_COSMOGONY_ACTION_NATURE');
  p.hidden.angularMomentum=Math.max(1,p.hidden.angularMomentum-2);moveOneTowardCenter(s,p);record(s,actorId,producerEntityId,nature,kind,targetId,{angularMomentumDelta:-2});
 }else if(kind==='PRESERVE_DISK'){
  if(!['PHYSICS','WILL'].includes(nature))throw new Error('GEN_COSMOGONY_ACTION_NATURE');
  if(!p.preservedBy.includes(actorId))p.preservedBy.push(actorId);
  p.hidden.angularMomentum=Math.min(6,p.hidden.angularMomentum+2);
  p.diskBias=(p.diskBias||0)+1;
  record(s,actorId,producerEntityId,nature,kind,targetId,{preserved:true,angularMomentumDelta:+2,diskBias:+1});
 }else if(kind==='IMPRINT'){
  if(nature!=='MYSTIC')throw new Error('GEN_COSMOGONY_ACTION_NATURE');
  p.imprints.push({source:actorId,sourceEntityId:producerEntityId||null,principle:principle||'PERSISTENCE_TRACE'});record(s,actorId,producerEntityId,nature,kind,targetId,{principle:principle||'PERSISTENCE_TRACE'});
 }else if(kind==='LINK'){
  if(nature!=='MYSTIC')throw new Error('GEN_COSMOGONY_ACTION_NATURE');
  const other=byId(s,otherId);if(!other)throw new Error('GEN_COSMOGONY_OTHER_UNKNOWN');
  p.links.push({otherId,source:actorId,sourceEntityId:producerEntityId||null});other.links.push({otherId:targetId,source:actorId,sourceEntityId:producerEntityId||null});record(s,actorId,producerEntityId,nature,kind,targetId,{otherId});
 }else if(kind==='CLAIM'||kind==='PROTECT'){
  if(nature!=='WILL')throw new Error('GEN_COSMOGONY_ACTION_NATURE');
  if(!p.preservedBy.includes(actorId))p.preservedBy.push(actorId);
  if(kind==='PROTECT'){
   p.protectionUntilEpoch=Math.max(p.protectionUntilEpoch||0,s.epoch+1);
   p.hidden.angularMomentum=Math.min(6,p.hidden.angularMomentum+1);
  }
  record(s,actorId,producerEntityId,nature,kind,targetId,{relation:kind,protectionUntilEpoch:p.protectionUntilEpoch||null});
 }else throw new Error('GEN_COSMOGONY_ACTION_UNKNOWN');
 s.interventions.push({epoch:s.epoch,actorId,producerEntityId,nature,kind,targetId,otherId,principle});return s;
}

function record(s,actorId,producerEntityId,nature,kind,targetId,delta){s.history.push({type:'INTERVENTION',epoch:s.epoch,actorId,producerEntityId,nature,kind,targetId,delta});}

export function advanceCosmicEpoch(state){
 if(state.closed)throw new Error('GEN_COSMOGONY_CLOSED');
 const s=clone(state);s.epoch++;
 if(s.phase==='COLLAPSE')evolveCollapse(s);
 else if(s.phase==='DISK')evolveDisk(s);
 if(s.phase==='PLANETS')formPlanets(s);
 return s;
}

function evolveCollapse(s){
 const center=centerOf(s);
 coalesceMatterCollisionsR520(s);
 const free=s.matter.parcels.filter(p=>p.state==='FREE');
 for(const p of free){
  const d=axialDistance(p,center),protectedNow=(p.protectionUntilEpoch||0)>=s.epoch;
  const preservationResistance=Math.min(2,p.diskBias||0)+(protectedNow?3:0);
  const captureBias=p.hidden.density+p.hidden.mass-p.hidden.angularMomentum-preservationResistance;
  if(d<=1&&captureBias>=2&&!protectedNow){captureIntoStar(s,p);continue;}
  if((p.hidden.angularMomentum+(p.diskBias||0))>=5&&d<=3){p.state='DISK';s.history.push({type:'DISK_RETAIN',epoch:s.epoch,targetId:p.id,reason:(p.diskBias||0)>0?'PRESERVATION_AND_ANGULAR_MOMENTUM':'ANGULAR_MOMENTUM'});continue;}
  moveOneTowardCenter(s,p);
 }
 coalesceMatterCollisionsR520(s);
 for(const p of s.matter.parcels.filter(p=>p.state==='FREE')){
  const protectedNow=(p.protectionUntilEpoch||0)>=s.epoch;
  const afterBias=p.hidden.density+p.hidden.mass-p.hidden.angularMomentum-Math.min(2,p.diskBias||0);
  if(axialDistance(p,center)<=1&&afterBias>=1&&!protectedNow)captureIntoStar(s,p);
 }
 const threshold=ignitionThreshold(s.totalInitialMass);
 const pacing=stellarPacingGateR528({epoch:s.epoch,phase:s.phase,starMass:s.star.mass,threshold});
 if(pacing.holdIgnition){
  s.history.push({type:'STELLAR_IGNITION_HELD_FOR_AGENCY',decisionId:pacing.decisionId,epoch:s.epoch,starMass:s.star.mass,threshold,minNaturalIgnitionEpoch:pacing.minNaturalIgnitionEpoch,reason:'MINIMUM_CAUSAL_ROUNDS_NOT_COMPLETED'});
  return;
 }
 if(pacing.naturalIgnitionAllowed){ignite(s,threshold,false);return;}
 if(pacing.referenceConvergenceDue){
  compressToIgnition(s,threshold);
  if(s.star.mass>=threshold)ignite(s,threshold,true);
 }
}

export function coalesceMatterCollisionsR520(s){
 const active=s.matter?.parcels?.filter(p=>p.state==='FREE')||[],byCell=new Map();
 for(const p of active){if(!byCell.has(p.cell))byCell.set(p.cell,[]);byCell.get(p.cell).push(p);}
 for(const [cell,group] of [...byCell.entries()].sort((a,b)=>String(a[0]).localeCompare(String(b[0])))){
  if(group.length<2)continue;
  const ordered=[...group].sort((a,b)=>String(a.id).localeCompare(String(b.id))),retained=ordered[0],absorbed=ordered.slice(1),sources=[...new Set(ordered.flatMap(p=>Array.isArray(p.members)&&p.members.length?p.members:[p.id]))].sort();
  const totalMass=ordered.reduce((n,p)=>n+Number(p.hidden?.mass||0),0),weighted=key=>bandValue(weightedMean(ordered,key,totalMass));
  retained.hidden={...retained.hidden,mass:totalMass,lightGas:weighted('lightGas'),refractories:weighted('refractories'),volatiles:weighted('volatiles'),thermal:weighted('thermal'),angularMomentum:weighted('angularMomentum'),density:weighted('density')};
  retained.members=sources;
  retained.public={label:'Concentración de materia acrecida',traits:publicTraitsFromHidden(retained.hidden)};
  retained.preservedBy=[...new Set(ordered.flatMap(p=>p.preservedBy||[]))];
  retained.imprints=ordered.flatMap(p=>p.imprints||[]).map(clone);
  retained.links=dedupeLinks(ordered.flatMap(p=>p.links||[]));
  retained.diskBias=Math.max(...ordered.map(p=>Number(p.diskBias||0)),0);
  retained.protectionUntilEpoch=Math.max(...ordered.map(p=>Number(p.protectionUntilEpoch||0)),0);
  for(const p of absorbed){p.state='MERGED';p.mergedInto=retained.id;p.members=Array.isArray(p.members)&&p.members.length?p.members:[p.id];}
  s.history.push({type:'MATTER_COLLISION_COALESCENCE',decisionId:GENESIS_R520_COLLISION_DECISION,epoch:s.epoch,atCell:cell,retainedId:retained.id,absorbedIds:absorbed.map(p=>p.id),sourceIds:sources,totalMass,mode:'ACCRETION_NOT_NUCLEAR_FUSION'});
 }
 return s;
}

function weightedMean(group,key,totalMass){
 if(totalMass<=0)return 1;
 return group.reduce((n,p)=>n+Number(p.hidden?.[key]||1)*Math.max(1,Number(p.hidden?.mass||1)),0)/group.reduce((n,p)=>n+Math.max(1,Number(p.hidden?.mass||1)),0);
}
function bandValue(n){return Math.max(1,Math.min(6,Math.round(Number(n)||1)));}
function publicTraitsFromHidden(v){
 const t=[];
 if(v.mass>=8)t.push('MUY_MASIVA');else if(v.mass<=2)t.push('LIGERA');
 if(v.volatiles>=5)t.push('RICA_EN_VOLATILES');
 if(v.refractories>=5)t.push('RICA_EN_REFRACTARIOS');
 if(v.thermal>=5)t.push('CALIENTE');else if(v.thermal<=2)t.push('FRIA');
 if(v.angularMomentum>=5)t.push('ALTO_MOMENTO');
 if(v.density>=5)t.push('DENSA');
 return t.slice(0,3);
}
function dedupeLinks(links){const seen=new Set(),out=[];for(const l of links){const key=`${l.otherId||''}|${l.source||''}|${l.sourceEntityId||''}`;if(seen.has(key))continue;seen.add(key);out.push(clone(l));}return out;}

function compressToIgnition(s,threshold){
 const activeProtection=p=>(p.protectionUntilEpoch||0)>=s.epoch;
 const free=s.matter.parcels.filter(p=>p.state==='FREE'&&!activeProtection(p)).sort((a,b)=>effectiveCaptureScore(b)-effectiveCaptureScore(a)||a.id.localeCompare(b.id));
 const orbital=s.matter.parcels.filter(p=>p.state==='DISK'&&!activeProtection(p)).sort((a,b)=>effectiveCaptureScore(b)-effectiveCaptureScore(a)||a.id.localeCompare(b.id));
 const candidates=[...free,...orbital];
 let consumed=0;
 for(const p of candidates){
  if(s.star.mass>=threshold)break;
  const remainingNonStar=s.matter.parcels.filter(x=>['FREE','DISK'].includes(x.state)&&x.id!==p.id).length;
  if(remainingNonStar<1)continue;
  if(p.state==='DISK')s.history.push({type:'INNER_DISK_INFALL',epoch:s.epoch,targetId:p.id,reason:'COSMIC_COMPRESSION'});
  captureIntoStar(s,p);consumed++;
 }
 if(consumed)s.history.push({type:'COSMIC_COMPRESSION',epoch:s.epoch,absorbedParcels:consumed,targetMass:threshold,starMass:s.star.mass});
}

function effectiveCaptureScore(p){return p.hidden.mass+p.hidden.density-p.hidden.angularMomentum-Math.min(2,p.diskBias||0);}

function ignite(s,threshold,assistedByReferenceConvergence){
 const formationProfile=buildStellarFormationProfileR522(s,{assistedByReferenceConvergence});
 s.star.state='IGNITED';s.star.ignitionEpoch=s.epoch;s.star.family=formationProfile.finalFamily;s.star.formationProfile=formationProfile;s.phase='DISK';
 for(const p of s.matter.parcels)if(p.state==='FREE')p.state='DISK';
 s.history.push({type:'STELLAR_FORMATION_PROFILE',decisionId:GENESIS_R522_STELLAR_DECISION,epoch:s.epoch,profile:clone(formationProfile)});
 s.history.push({type:'STAR_IGNITION',epoch:s.epoch,mass:s.star.mass,family:s.star.family,threshold,formationProfile:clone(formationProfile),...(assistedByReferenceConvergence?{assistedByReferenceConvergence:true}:{})});
}

export function buildStellarFormationProfileR522(s,{assistedByReferenceConvergence=false}={}){
 const starParcels=s.matter?.parcels?.filter(p=>p.state==='STAR')||[];
 const capturedMass=Number(s.star?.mass||starParcels.reduce((n,p)=>n+Number(p.hidden?.mass||0),0));
 const capturedMassFraction=Number((capturedMass/Math.max(1,Number(s.totalInitialMass||capturedMass||1))).toFixed(4));
 const sourceIds=[...new Set((s.star?.members||[]).length?s.star.members:starParcels.flatMap(p=>Array.isArray(p.members)&&p.members.length?p.members:[p.id]))].sort();
 const physical={lightGas:stellarWeightedBand(starParcels,'lightGas'),refractories:stellarWeightedBand(starParcels,'refractories'),volatiles:stellarWeightedBand(starParcels,'volatiles'),thermal:stellarWeightedBand(starParcels,'thermal'),angularMomentum:stellarWeightedBand(starParcels,'angularMomentum'),density:stellarWeightedBand(starParcels,'density')};
 const baseFamily=stellarFamily(capturedMassFraction),reasons=[];
 let score=0;
 if(physical.thermal>=5&&physical.density>=4){score++;reasons.push('HOT_DENSE_CORE');}
 if(physical.lightGas>=5&&physical.density>=4){score++;reasons.push('LIGHT_GAS_DENSE_CORE');}
 if(physical.density>=5){score++;reasons.push('VERY_DENSE_CORE');}
 if(physical.thermal<=2&&physical.density<=3){score--;reasons.push('COOL_DIFFUSE_CORE');}
 if(physical.angularMomentum>=5){score--;reasons.push('HIGH_ROTATIONAL_RETENTION');}
 if(physical.lightGas<=2&&physical.thermal<=3){score--;reasons.push('LOW_LIGHT_GAS_COOL_CORE');}
 const familyModifier=score>=2?1:score<=-2?-1:0;
 const finalFamily=shiftFamily(baseFamily,familyModifier);
 const sourceSet=new Set(sourceIds);
 const relevantInterventions=(s.interventions||[]).filter(i=>sourceSet.has(i.targetId)||sourceSet.has(i.otherId));
 const interventionKinds=[...new Set(relevantInterventions.map(i=>i.kind).filter(Boolean))].sort();
 const collisionCount=(s.history||[]).filter(e=>e.type==='MATTER_COLLISION_COALESCENCE'&&(e.sourceIds||[]).some(id=>sourceSet.has(id))).length;
 const accretionCount=(s.history||[]).filter(e=>e.type==='STAR_ACCRETION'&&(e.sourceIds||[]).some(id=>sourceSet.has(id))).length;
 return{schema:'EMR_STELLAR_FORMATION_PROFILE_R522_v1',decisionId:GENESIS_R522_STELLAR_DECISION,capturedMass,capturedMassFraction,sourceCount:sourceIds.length,sourceIds,physical,baseFamily,familyModifier,finalFamily,score,reasons,history:{ignitionEpoch:Number(s.epoch||0),collisionCount,accretionCount,assistedByReferenceConvergence:Boolean(assistedByReferenceConvergence),interventionCount:relevantInterventions.length,interventionKinds}};
}

function stellarWeightedBand(parcels,key){
 if(!parcels.length)return 3;
 const denom=parcels.reduce((n,p)=>n+Math.max(1,Number(p.hidden?.mass||1)),0);
 const raw=parcels.reduce((n,p)=>n+Number(p.hidden?.[key]||3)*Math.max(1,Number(p.hidden?.mass||1)),0)/Math.max(1,denom);
 return bandValue(raw);
}
function shiftFamily(baseFamily,modifier){const i=Math.max(0,FAMILY_ORDER.indexOf(baseFamily));return FAMILY_ORDER[Math.max(0,Math.min(FAMILY_ORDER.length-1,i+modifier))];}

function evolveDisk(s){
 s.history.push({type:'DISK_SETTLE',epoch:s.epoch,remaining:s.matter.parcels.filter(p=>p.state==='DISK').map(p=>p.id)});
 s.phase='PLANETS';
}

function captureIntoStar(s,p){
 p.state='STAR';s.star.mass+=p.hidden.mass;s.star.members.push(...(Array.isArray(p.members)&&p.members.length?p.members:[p.id]));s.star.members=[...new Set(s.star.members)].sort();s.history.push({type:'STAR_ACCRETION',epoch:s.epoch,targetId:p.id,sourceIds:Array.isArray(p.members)&&p.members.length?[...p.members]:[p.id],mass:p.hidden.mass});
}

function moveOneTowardCenter(s,p){
 const center=centerOf(s),current=axialDistance(p,center),next=nearestCells(s.board,p,6).filter(c=>c.code!==p.cell).sort((a,b)=>axialDistance(a,center)-axialDistance(b,center)||a.code.localeCompare(b.code)).find(c=>axialDistance(c,center)<current);
 if(next){const from=p.cell;p.cell=next.code;p.q=next.q;p.r=next.r;s.history.push({type:'COSMIC_MOVE',epoch:s.epoch,targetId:p.id,from,to:next.code});}
}

export function ignitionThreshold(totalMass){return Math.max(7,Math.round(totalMass*0.38));}

export function stellarFamily(starFraction){
 if(starFraction<0.46)return'M_RED_DWARF';
 if(starFraction<0.56)return'K_ORANGE';
 if(starFraction<0.66)return'G_YELLOW';
 if(starFraction<0.76)return'F_A_WHITE_YELLOW';
 return'B_O_BLUE_MASSIVE';
}

export function stellarIrradiationBiasR522(family){return({M_RED_DWARF:-2,K_ORANGE:-1,G_YELLOW:0,F_A_WHITE_YELLOW:1,B_O_BLUE_MASSIVE:2})[family]??0;}
export function planetEnvironmentClassR522(type,effectiveThermal){const band=effectiveThermal<=2?'COLD':effectiveThermal>=5?'HOT':'TEMPERATE';return`${band}_${type}`;}

function formPlanets(s){
 const disk=s.matter.parcels.filter(p=>p.state==='DISK');
 if(!disk.length){s.planets=[];s.closed=true;s.phase='CLOSED_NO_PLANET';return;}
 const center=centerOf(s),sorted=[...disk].sort((a,b)=>axialDistance(a,center)-axialDistance(b,center)||a.hidden.angularMomentum-b.hidden.angularMomentum||a.id.localeCompare(b.id));
 const groups=[];for(const p of sorted){const radial=axialDistance(p,center),last=groups.at(-1);if(!last||Math.abs(radial-last.meanRadius)>1||last.members.length>=4)groups.push({members:[p],meanRadius:radial});else{last.members.push(p);last.meanRadius=last.members.reduce((sum,x)=>sum+axialDistance(x,center),0)/last.members.length;}}
 s.planets=groups.filter(g=>g.members.reduce((z,p)=>z+p.hidden.mass,0)>=3).map((g,i)=>planetFromGroupR522(g,i+1,s));
 if(!s.planets.length){const best=[...disk].sort((a,b)=>b.hidden.mass-a.hidden.mass)[0];s.planets=[planetFromGroupR522({members:[best],meanRadius:axialDistance(best,center)},1,s)];}
 for(const p of disk)p.state='PLANETARY';
 s.closed=true;s.phase='CLOSED';s.history.push({type:'PLANET_FORMATION',decisionId:GENESIS_R522_STELLAR_DECISION,epoch:s.epoch,stellarFamily:s.star.family,planetIds:s.planets.map(p=>p.id)});
}

export function planetFromGroupR522(g,index,s){
 const members=g.members,mass=members.reduce((z,p)=>z+p.hidden.mass,0),refractories=avg(members,'refractories'),volatiles=avg(members,'volatiles'),sourceThermal=avg(members,'thermal'),sourceIds=[...new Set(members.flatMap(p=>Array.isArray(p.members)&&p.members.length?p.members:[p.id]))].sort(),mysticImprints=members.flatMap(p=>(p.imprints||[]).map(x=>({...x,sourceMatter:p.id}))),volitionRelations=members.flatMap(p=>(p.preservedBy||[]).map(source=>({source,type:'PROTECTED_OR_CLAIMED',sourceMatter:p.id})));
 const type=mass>=14&&volatiles>=4?'GAS_GIANT':mass>=10&&volatiles>=4?'ICE_GIANT':refractories>=4&&volatiles>=4?'VOLATILE_RICH_TERRESTRIAL':refractories>=4?'ROCKY_TERRESTRIAL':'MINOR_WORLD';
 const stellarFamilyValue=s.star?.family||null,irradiationBias=stellarIrradiationBiasR522(stellarFamilyValue),effectiveThermal=Math.max(1,Math.min(6,sourceThermal+irradiationBias));
 const environmentClass=planetEnvironmentClassR522(type,effectiveThermal);
 return{id:`PLANET-${String(index).padStart(2,'0')}`,members:sourceIds,massBand:band6(mass/Math.max(1,members.length)),sizeBand:mass>=14?'VERY_LARGE':mass>=9?'LARGE':mass>=5?'MEDIUM':'SMALL',orbitBand:g.meanRadius<=2?'INNER':g.meanRadius<=4?'MIDDLE':'OUTER',composition:{refractories,volatiles},thermalBand:band6(effectiveThermal),sourceThermalBand:band6(sourceThermal),type,environmentClass,stellarFamily:stellarFamilyValue,stellarEnvironment:{decisionId:GENESIS_R522_STELLAR_DECISION,irradiationBias,sourceThermal,effectiveThermal,rule:'STELLAR_FAMILY_CONDITIONS_PLANETARY_THERMAL_ENVIRONMENT'},mysticImprints,volitionRelations,causalSources:sourceIds};
}

const avg=(members,key)=>Math.round(members.reduce((z,p)=>z+p.hidden[key],0)/members.length);
const band6=n=>n<=2?'LOW':n<=4?'MEDIUM':'HIGH';

export function cosmogonySummary(s){return{epoch:s.epoch,phase:s.phase,star:{...s.star},planetCount:s.planets.length,planets:clone(s.planets),matterStates:Object.fromEntries(['FREE','STAR','DISK','PLANETARY','MERGED'].map(k=>[k,s.matter.parcels.filter(p=>p.state===k).length])),physicalMoves:s.history.filter(x=>x.type==='COSMIC_MOVE').length,collisions:s.history.filter(x=>x.type==='MATTER_COLLISION_COALESCENCE').length};}
