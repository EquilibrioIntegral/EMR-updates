// BOOT-05 · CIERRE SAVE STATE 0
// Authority: EMR_BOOT05_CIERRE_SAVE_STATE0_v0.1

export const KNOWLEDGE = Object.freeze({
  OBJECTIVE: 'HECHO_OBJETIVO',
  PUBLIC: 'CONOCIMIENTO_PUBLICO',
  RUMOR: 'RUMOR_LEYENDA',
  SECRET: 'SECRETO'
});

const VALID_KNOWLEDGE = new Set(Object.values(KNOWLEDGE));

function assertBootInputs(boots) {
  for (let i = 0; i <= 4; i += 1) {
    const key = `BOOT-0${i}`;
    if (!boots?.[key]) throw new Error(`BOOT05_GAP_MISSING_${key}`);
  }
}

function mergeRefs(items = []) {
  const seen = new Set();
  return items.filter(item => {
    const authority = item.authority ?? item.owner ?? 'WORLD';
    const id = item.id ?? item.ref ?? JSON.stringify(item);
    const key = `${authority}:${id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function classifyFacts(facts = []) {
  return facts.map(fact => {
    if (!VALID_KNOWLEDGE.has(fact.knowledge)) {
      throw new Error(`BOOT05_INVALID_KNOWLEDGE:${fact.id ?? 'UNKNOWN'}`);
    }
    return { ...fact };
  });
}

function publicView(facts) {
  return facts
    .filter(f => f.knowledge === KNOWLEDGE.PUBLIC || f.knowledge === KNOWLEDGE.RUMOR)
    .map(f => ({
      id: f.id,
      text: f.publicText ?? f.text,
      knowledge: f.knowledge,
      // Rumours expose the social claim, never objective truth metadata.
      ...(f.knowledge === KNOWLEDGE.RUMOR ? { truth: undefined } : {})
    }));
}

export function compileBoot05({ boots, canonicalGenes = [], requiredGenes = [] }) {
  assertBootInputs(boots);

  const configEntries = mergeRefs(Object.values(boots).flatMap(b => b.config ?? []));
  const byGene = new Map(configEntries.map(entry => [entry.gene, entry]));
  const gaps = [];

  for (const gene of requiredGenes) {
    const entry = byGene.get(gene);
    if (!entry || (entry.value == null && entry.absence !== true)) gaps.push(`MISSING_REQUIRED_GENE:${gene}`);
  }

  // Canonical genes may be present or explicitly non-applicable; never invent values.
  for (const gene of canonicalGenes) {
    const entry = byGene.get(gene);
    if (!entry) gaps.push(`UNDECLARED_GENE:${gene}`);
  }

  const contradictions = Object.values(boots).flatMap(b => b.contradictions ?? []).filter(c => !c.resolvedByPrecedence);
  if (contradictions.length) gaps.push(...contradictions.map(c => `UNRESOLVED_CONTRADICTION:${c.id ?? 'UNKNOWN'}`));

  const facts = classifyFacts(mergeRefs(Object.values(boots).flatMap(b => b.save0 ?? [])));
  const ownerRefs = mergeRefs(Object.values(boots).flatMap(b => b.ownerRefs ?? []));

  const config = Object.freeze(configEntries.map(entry => ({ ...entry })));
  const signature = Object.freeze(config.map(entry => ({ gene: entry.gene, ref: entry.id ?? entry.ref, value: entry.signature ?? entry.value })));
  const atlasChronicle = Object.freeze(publicView(facts));

  return {
    phase: gaps.length ? 'BOOT05_GAP' : 'BOOT05_CLOSED',
    config,
    signature,
    save0: Object.freeze(facts),
    atlasChronicle,
    ownerRefs: Object.freeze(ownerRefs),
    gaps: Object.freeze(gaps),
    invariants: Object.freeze([
      'SIGNATURE_DERIVES_CONFIG','NO_NEW_WORLD_CONTENT','ONE_KNOWLEDGE_CLASS','NO_SECRET_IN_PUBLIC_VIEW',
      'NO_NONPUBLIC_OBJECTIVE_IN_PUBLIC_VIEW','RUMOR_DOES_NOT_REVEAL_TRUTH','NO_PARALLEL_OWNER_STATE',
      'MISSING_REQUIRED_PRODUCER_IS_GAP','UNRESOLVED_CONTRADICTION_BLOCKS_CLOSE','RUNTIME_DOES_NOT_REREAD_BOOT',
      'GUIONISTA_NOT_RUNNING'
    ])
  };
}

export function advanceBoot05ToBoot06(state) {
  if (state?.phase !== 'BOOT05_CLOSED' || state.gaps?.length) throw new Error('BOOT05_NOT_CLOSED');
  return {
    phase: 'BOOT06_PROTAGONISTAS',
    world: {
      config: state.config,
      signature: state.signature,
      save0: state.save0,
      atlasChronicle: state.atlasChronicle,
      ownerRefs: state.ownerRefs
    },
    rules: { mayRetrocontradictSave0: false, guionistaEnabled: false, runtimeEnabled: false }
  };
}
