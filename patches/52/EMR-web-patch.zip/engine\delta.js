import { findById, getByPath, setByPath } from './state.js';

function ensureAuthority(delta) {
  if (!delta.AUTHORITY_ID) throw new Error(`DELTA_AUTHORITY_MISSING:${delta.DELTA_ID ?? 'UNKNOWN'}`);
  if (!delta.CAUSE_REF) throw new Error(`DELTA_CAUSE_MISSING:${delta.DELTA_ID ?? 'UNKNOWN'}`);
}

export function applyDelta(state, delta) {
  ensureAuthority(delta);
  const op=delta.OPERATION;
  if (op === 'SET') {
    const target=findById(state,delta.TARGET_REF);
    if (!target) throw new Error(`TARGET_NOT_FOUND:${delta.TARGET_REF}`);
    if (!delta.FIELD) throw new Error('SET_FIELD_MISSING');
    target.value[delta.FIELD]=delta.AFTER;
  } else if (op === 'SET_PATH') {
    setByPath(state,delta.PATH,delta.AFTER);
  } else if (op === 'MOVE') {
    const target=findById(state,delta.TARGET_REF);
    if (!target) throw new Error(`TARGET_NOT_FOUND:${delta.TARGET_REF}`);
    target.value.LOCATION_REF=delta.AFTER;
  } else if (op === 'CREATE') {
    const coll=state[delta.COLLECTION];
    if (!coll) throw new Error(`COLLECTION_UNKNOWN:${delta.COLLECTION}`);
    if (coll[delta.AFTER.ID]) throw new Error(`CREATE_DUPLICATE:${delta.AFTER.ID}`);
    coll[delta.AFTER.ID]=delta.AFTER.OBJECT;
  } else if (op === 'LINK') {
    state.relations[delta.AFTER.RELATION_ID]=delta.AFTER;
  } else if (op === 'CLOSE' || op === 'INVALIDATE' || op === 'TRANSFORM' || op === 'REVEAL' || op === 'HIDE') {
    const target=findById(state,delta.TARGET_REF);
    if (!target) throw new Error(`TARGET_NOT_FOUND:${delta.TARGET_REF}`);
    if (op==='CLOSE') target.value.STATUS='CLOSED';
    if (op==='INVALIDATE') target.value.STATUS='INVALIDATED';
    if (op==='TRANSFORM') target.value.STATUS=delta.AFTER ?? 'TRANSFORMED';
    if (op==='REVEAL') { target.value.VISIBILITY='REVEALED'; if ('STATUS' in target.value && delta.AFTER) target.value.STATUS=delta.AFTER; }
    if (op==='HIDE') target.value.VISIBILITY='HIDDEN';
  } else if (op === 'ADVANCE_TIME') {
    state.meta.gameTime += Number(delta.AFTER ?? 1);
  } else {
    throw new Error(`UNSUPPORTED_DELTA:${op}`);
  }
  return state;
}

export function applyDeltas(state, deltas=[]) {
  for (const d of deltas) applyDelta(state,d);
  return state;
}
