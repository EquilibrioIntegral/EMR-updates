const setup=document.querySelector('#setup');
const host=document.querySelector('#preshow-step');
const root=document.querySelector('#pre-genesis-background-root');

// DEV031.5+: pre-Genesis deliberately shares the live six-image HOME carousel.
// Keep the former single-image layer inert so cached/legacy markup cannot cover it.
if(root){
  root.hidden=true;
  root.classList.remove('is-active');
}

let playerCount=1;
function adaptSoloCopy(){
  if(!host||playerCount!==1)return;

  const nameScreen=host.querySelector('.preshow-question');
  const nameInput=nameScreen?.querySelector('#preshow-name');
  if(nameScreen&&nameInput){
    const paragraphs=[...nameScreen.querySelectorAll('p')];
    const equipment=paragraphs.find(p=>p.textContent.includes('meeple')&&p.textContent.includes('Intenciones'));
    if(equipment)equipment.innerHTML='Este jugador usará el meeple <strong>rojo</strong>.';
  }

  const ready=host.querySelector('.preshow-ready');
  if(!ready)return;
  const paragraphs=[...ready.querySelectorAll('p')];
  const startCopy=paragraphs.find(p=>p.textContent.includes('Cuando empecéis'));
  if(startCopy)startCopy.textContent='Cuando empieces, el mundo comenzará a tomar forma y recordará lo que ocurra.';
  const readiness=ready.querySelector('h2');
  if(readiness&&readiness.textContent.includes('Estáis'))readiness.textContent='¿Estás listo?';

  if(!ready.querySelector('[data-solo-meeple-setup]')){
    const start=ready.querySelector('#new-game');
    const box=document.createElement('section');
    box.className='intention-setup physical intent-red';
    box.dataset.soloMeepleSetup='1';
    box.innerHTML='<p class="preshow-progress">Preparación 1 de 1</p><h2>Prepara tu meeple</h2><p>Toma el <strong>meeple rojo</strong> y déjalo a tu alcance para comenzar la partida.</p>';
    if(start)ready.insertBefore(box,start);else ready.appendChild(box);
  }
}

setup?.addEventListener('click',event=>{
  const button=event.target.closest?.('[data-player-count]');
  if(button)playerCount=Number(button.dataset.playerCount)||1;
});

if(host)new MutationObserver(adaptSoloCopy).observe(host,{childList:true,subtree:true});
adaptSoloCopy();
