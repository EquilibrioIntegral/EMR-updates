import {isCapabilityUnlockedR53} from './genesis-signature-r53.js';
import {GENESIS_R511_CAPABILITY_CATALOG,GENESIS_R511_DECISION_ID,GENESIS_R511_NO_INTERVENE,validateGenesisR511Catalog} from '../data/genesis-capability-catalog-r511.js';

const clone=x=>structuredClone(x);

export function capabilityByIdR511(id){
 validateGenesisR511Catalog();
 const c=GENESIS_R511_CAPABILITY_CATALOG.find(x=>x.id===id);
 if(!c)throw new Error('GEN_R511_CAPABILITY_UNKNOWN');
 return clone(c);
}

export function capabilityCatalogForNatureR511(nature){
 validateGenesisR511Catalog();
 return GENESIS_R511_CAPABILITY_CATALOG.filter(x=>x.nature===nature).map(clone);
}

export function unlockedCapabilitiesR511({nature,intensity}={}){
 return capabilityCatalogForNatureR511(nature).filter(c=>isCapabilityUnlockedR53(intensity,c.requiredLevel));
}

export function projectAgencyCapabilitiesR511(agency){
 if(!agency?.nature)throw new Error('GEN_R511_AGENCY_REQUIRED');
 const unlocked=unlockedCapabilitiesR511({nature:agency.nature,intensity:agency.universeIntensity});
 return{
  decisionId:GENESIS_R511_DECISION_ID,
  nature:agency.nature,
  intensity:agency.universeIntensity,
  unlockedLevels:[...(agency.unlockedLevels||[])],
  capabilities:unlocked,
  noIntervene:clone(GENESIS_R511_NO_INTERVENE),
  playerFacingRule:'GUIÓN_CONTEXTUAL_NOT_POWER_MENU',
  humanFunBalanceValidation:'PENDING'
 };
}

// This function validates only gates that belong to the catalog contract itself.
// Domain, objective legality, relations, material state and exact spatial topology remain
// separate engine gates and must be supplied by the caller rather than guessed here.
export function catalogEligibilityR511({nature,intensity,capabilityId,context={}}={}){
 const c=capabilityByIdR511(capabilityId);
 if(c.nature!==nature)return{legal:false,reason:'NATURE_MISMATCH',capability:c};
 if(!isCapabilityUnlockedR53(intensity,c.requiredLevel))return{legal:false,reason:'REQUIRED_LEVEL',capability:c};
 if(context.remote===true&&!c.remoteEligible)return{legal:false,reason:'REMOTE_NOT_DECLARED',capability:c};
 if(context.remote===true&&c.remoteEligible&&context.remotePathAuthorized!==true)return{legal:false,reason:'REMOTE_PATH_REQUIRED',capability:c};
 return{legal:true,reason:'CATALOG_GATES_PASS',capability:c,remainingGates:['DOMAIN','TARGET','STATE','RELATION','LIMITS','SPATIAL_TOPOLOGY','CONTEXTUAL_RELEVANCE']};
}

export function noInterveneR511(){return clone(GENESIS_R511_NO_INTERVENE);}
