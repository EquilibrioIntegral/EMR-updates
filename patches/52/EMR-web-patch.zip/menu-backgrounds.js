export const MENU_BACKGROUNDS=Object.freeze([
  Object.freeze({id:'mountain',src:'./assets/menu-backgrounds/menu-bg-mountain.webp',position:'50% 44%',from:'translate(-0.7%, 0.8%) scale(1.032)',to:'translate(0.7%, -0.7%) scale(1.010)'}),
  Object.freeze({id:'ruins',src:'./assets/menu-backgrounds/menu-bg-ruins.webp',position:'50% 47%',from:'translate(0.6%, 0.2%) scale(1.012)',to:'translate(-0.7%, -0.5%) scale(1.034)'}),
  Object.freeze({id:'settlement',src:'./assets/menu-backgrounds/menu-bg-settlement.webp',position:'50% 45%',from:'translate(0.4%, 0.7%) scale(1.030)',to:'translate(-0.6%, -0.5%) scale(1.010)'}),
  Object.freeze({id:'sea',src:'./assets/menu-backgrounds/menu-bg-sea.webp',position:'42% 48%',from:'translate(0.9%, 0.1%) scale(1.010)',to:'translate(-0.9%, -0.4%) scale(1.032)'}),
  Object.freeze({id:'hunt',src:'./assets/menu-backgrounds/menu-bg-hunt.webp',position:'46% 49%',from:'translate(-0.5%, 0.7%) scale(1.031)',to:'translate(0.5%, -0.5%) scale(1.011)'}),
  Object.freeze({id:'castle',src:'./assets/menu-backgrounds/menu-bg-castle.webp',position:'50% 43%',from:'translate(-0.5%, 0.3%) scale(1.010)',to:'translate(0.6%, -0.6%) scale(1.033)'})
]);

const CYCLE_MS=10500;
const FADE_MS=1600;

export class MenuBackgroundController{
  constructor({root,layerA,layerB,home,setup,backgrounds=MENU_BACKGROUNDS}={}){
    this.root=root; this.layers=[layerA,layerB]; this.home=home; this.setup=setup; this.backgrounds=backgrounds;
    this.index=0; this.activeLayer=0; this.running=false; this.initialized=false;
    this.nextTimer=0; this.fadeTimer=0; this.preloads=new Map();
  }
  preload(index){
    const item=this.backgrounds[index%this.backgrounds.length];
    if(!item) return Promise.resolve();
    if(this.preloads.has(item.src)) return this.preloads.get(item.src);
    const promise=new Promise(resolve=>{const image=new Image();image.onload=resolve;image.onerror=resolve;image.src=item.src;});
    this.preloads.set(item.src,promise); return promise;
  }
  preloadRest(){
    let i=1;
    const step=()=>{if(i>=this.backgrounds.length)return;this.preload((this.index+i)%this.backgrounds.length).finally(()=>{i++;setTimeout(step,70);});};
    step();
  }
  apply(layer,item,visible=false){
    if(!layer||!item)return;
    layer.style.backgroundImage=`url("${item.src}")`;
    layer.style.setProperty('--bg-position',item.position||'50% 50%');
    layer.style.setProperty('--kb-from',item.from);
    layer.style.setProperty('--kb-to',item.to);
    layer.dataset.scene=item.id;
    layer.classList.remove('is-animating');
    void layer.offsetWidth;
    layer.classList.add('is-animating');
    layer.classList.toggle('is-visible',visible);
  }
  schedule(delay=CYCLE_MS){
    clearTimeout(this.nextTimer);
    if(this.running)this.nextTimer=setTimeout(()=>this.next(),delay);
  }
  start(){
    if(this.running||!this.root||!this.layers[0]||!this.layers[1]||!this.backgrounds.length)return;
    this.running=true; this.root.hidden=false;
    if(!this.initialized){
      this.layers.forEach(layer=>layer.classList.remove('is-visible','is-animating'));
      this.activeLayer=0; this.apply(this.layers[0],this.backgrounds[this.index],true);
      this.initialized=true;
    }
    this.preload((this.index+1)%this.backgrounds.length).finally(()=>this.preloadRest());
    this.schedule(CYCLE_MS);
  }
  stop(){
    if(!this.running&&!this.root)return;
    this.running=false; clearTimeout(this.nextTimer); clearTimeout(this.fadeTimer);
    this.nextTimer=0; this.fadeTimer=0;
    if(this.root)this.root.hidden=true;
    this.layers.forEach(layer=>layer?.classList.remove('is-animating'));
    this.initialized=false;
  }
  async next(){
    if(!this.running)return;
    const nextIndex=(this.index+1)%this.backgrounds.length;
    await this.preload(nextIndex);
    if(!this.running)return;
    const incomingIndex=this.activeLayer===0?1:0;
    const outgoing=this.layers[this.activeLayer],incoming=this.layers[incomingIndex];
    this.apply(incoming,this.backgrounds[nextIndex],false);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(!this.running)return;
      incoming.classList.add('is-visible'); outgoing.classList.remove('is-visible');
    }));
    clearTimeout(this.fadeTimer);
    this.fadeTimer=setTimeout(()=>{
      if(!this.running)return;
      outgoing.classList.remove('is-animating');
      this.activeLayer=incomingIndex; this.index=nextIndex;
      this.preload((this.index+1)%this.backgrounds.length);
      this.schedule(Math.max(1000,CYCLE_MS-FADE_MS));
    },FADE_MS);
  }
}

const home=document.querySelector('#home');
const setup=document.querySelector('#setup');
const controller=new MenuBackgroundController({
  root:document.querySelector('#menu-background-root'),
  layerA:document.querySelector('#menu-bg-layer-a'),
  layerB:document.querySelector('#menu-bg-layer-b'),
  home,
  setup
});
const isPreGenesisShellActive=()=>Boolean((home&&!home.hidden)||(setup&&!setup.hidden));
const sync=()=>{if(document.visibilityState==='hidden'||!isPreGenesisShellActive())controller.stop();else controller.start();};
if(home)new MutationObserver(sync).observe(home,{attributes:true,attributeFilter:['hidden']});
if(setup)new MutationObserver(sync).observe(setup,{attributes:true,attributeFilter:['hidden']});
document.addEventListener('visibilitychange',sync);
sync();
export {controller as menuBackgroundController};
