// M-PRIMORDIAL · declarative causal corpus for CI-03/Preshow.
// Data, not player-facing UI copy.
export const M_PRIMORDIAL = Object.freeze({
 id:'M-PRIMORDIAL', class:'GPF', version:'0.1',
 domains:['SILENCIO','ALIENTO','VOLUNTAD'], maxIntentions:4,
 resolution:{die:6,resistance:5,outcomes:{failure:[1,4],cost:[5,6],clean:[7,99]}},
 transforms:[
  {id:'T-DENSE-CORE',label:'Concentrar el núcleo',domain:'SILENCIO',minForce:2,roles:['ATTRACT','PRESSURE'],relations:['CONVERGES','CONTAINS'],requiresTags:[],resultTag:'NUCLEO_DENSO',consumer:'BOOT01_FORMACION_MUNDO',physicalOperation:'MOVE_TOWARD'},
  {id:'T-DISTRIBUTE',label:'Extender la materia',domain:'SILENCIO',minForce:1,roles:['DISPERSE','MOTION'],relations:['SEPARATES'],requiresTags:[],resultTag:'MATERIA_DISTRIBUIDA',consumer:'BOOT01_FORMACION_MUNDO',physicalOperation:'MOVE_AWAY'},
  {id:'T-COOL',label:'Enfriar la materia',domain:'SILENCIO',minForce:1,roles:['COOL','RADIATE'],relations:['TRANSFORMS'],requiresTags:[],resultTag:'MATERIA_ENFRIADA',consumer:'BOOT01_FORMACION_MUNDO',physicalOperation:'MARK_STATE'},
  {id:'T-STABLE-ORBIT',label:'Estabilizar órbitas',domain:'SILENCIO',minForce:3,roles:['ATTRACT','ROTATE'],relations:['ORBITS'],requiresTags:[],resultTag:'ORBITAS_ESTABLES',consumer:'BOOT01_FORMACION_MUNDO',physicalOperation:'MOVE_ORBIT'},
  {id:'T-PRIMORDIAL-LINK',label:'Tejer un vínculo primordial',domain:'ALIENTO',minForce:1,roles:['LINK','VEIL'],relations:['BINDS','CROSSES'],requiresTags:[],resultTag:'VINCULO_PRIMORDIAL',consumer:'GUIONISTA_OR_LATER_BOOT',physicalOperation:'LINK_TOKENS'},
  {id:'T-CONSCIOUS-IMPRINT',label:'Imprimir una voluntad',domain:'VOLUNTAD',minForce:1,roles:['WILL','COMMAND'],relations:['TRANSFORMS'],requiresTags:[],resultTag:'HUELLA_CONSCIENTE',consumer:'GUIONISTA_OR_LATER_BOOT',physicalOperation:'MARK_AGENCY'},
  {id:'T-FRACTURE',label:'Fracturar la materia',domain:'SILENCIO',minForce:1,roles:['FRACTURE','PRESSURE'],relations:['SEPARATES'],requiresTags:[],resultTag:'MATERIA_FRACTURADA',consumer:'BOOT01_FORMACION_MUNDO',physicalOperation:'SEPARATE_TOKENS'}
 ]
});
