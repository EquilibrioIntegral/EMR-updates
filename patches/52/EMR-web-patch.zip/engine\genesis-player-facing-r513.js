// Player-facing projection for the DEV031.13+ human Genesis loop.
// Internal IDs/properties remain in state; this module translates them into
// readable, causal choices without leaking implementation vocabulary.
import {visibleGenesisCellR515} from './genesis-board-display-r515.js';
import {causalNarrativeForOptionR520} from './genesis-player-facing-r520.js';

export const GENESIS_PLAYER_FACING_R513='EMR_GENESIS_PLAYER_FACING_R513_v1';

export const PLAYER_COLORS_R513=[
  {name:'rojo',css:'#ff6b6b'},
  {name:'azul',css:'#69a7ff'},
  {name:'dorado',css:'#e4b95f'},
  {name:'verde',css:'#66d49e'}
];

export function visibleGenesisCellR513(code,board=null){
  if(board?.id==='A61')return visibleGenesisCellR515(board,code);
  const s=String(code??'');
  const m=s.match(/^H0*(\d+)$/i);
  return m?String(Number(m[1])):s;
}

export function controllerNameR513(player={}){
  return String(player.controllerName||player.humanName||player.name||'Jugador');
}

export function primordialActorNameR513(player={}){
  if(player.controller==='APP')return String(player.primordialNarrativeRef||player.publicName||player.name||autonomousNatureName(player.nature));
  return String(player.primordialNarrativeRef||player.publicName||player.name||controllerNameR513(player));
}

export function playerColorR513(players=[],player={}){
  const i=Math.max(0,players.findIndex(p=>p.id===player.id));
  return PLAYER_COLORS_R513[i]||PLAYER_COLORS_R513[2];
}

export function genesisObjectiveR513(){
  return {
    title:'Objetivo común · Encender una estrella',
    text:'La materia del sistema ya está en movimiento. Debéis permitir, favorecer o alterar su evolución hasta que nazca una estrella estable. La materia que no quede atrapada en ella podrá formar después el disco, los planetas y otros cuerpos. Cómo nazca esa estrella cambiará lo que pueda existir después.'
  };
}

export function projectAgencyActionR513(live,option={}){
  const board=live?.runtime?.cosmogony?.board;
  const parcel=findParcel(live,option.targetId);
  const cell=visibleGenesisCellR513(parcel?.cell||option?.spatial?.targetCell||'',board);
  const situation=parcel?matterSituation(parcel,live):genericSituation(option,cell);
  const k=String(option.kind||option.capabilityId||'WAIT');
  const causal=causalNarrativeForOptionR520(live,option);
  const base={kind:k,cell,title:'Intervenir',situation,consequence:'La intervención quedará registrada como causa y podrá tener consecuencias posteriores.',tableInstruction:cell?`Si la acción cambia la posición de la materia, la app te indicará cómo reflejarlo en la casilla ${cell}.`:'La app te indicará cualquier cambio que deba materializarse en la mesa.'};
  const finish=row=>({...row,situation:mergeText(row.situation,causal.whatHappensNext),consequence:mergeText(row.consequence,causal.ifChosen),forecastDecisionId:causal.forecastDecisionId,forecastMode:causal.forecastMode});

  if(option.primitive)return finish({...base,title:humanize(option.label,board),situation:humanize(option.hint||'',board),consequence:humanize(option.publicText||'',board)});
  if(k==='WAIT')return finish({...base,title:'No intervenir',situation:parcel?`${situation} Puedes dejar que el proceso siga su curso sin añadir una causa nueva.`:'Puedes no intervenir. El universo seguirá evolucionando por gravedad, colisiones, intercambio de energía y por las causas que ya existan.',consequence:'No intervenir no detiene el universo: el tiempo cósmico avanza y la materia continúa evolucionando.',tableInstruction:'No muevas nada por esta decisión salvo que la evolución posterior de la app lo indique.'});
  if(k.includes('PROTECT'))return finish({...base,title:cell?`Preservar la materia de la casilla ${cell}`:'Preservar esta posibilidad',consequence:'Intentas mantener esta materia disponible frente al siguiente cambio. No la vuelves invulnerable; si otras causas la superan, el mundo recordará el intento.'});
  if(k==='PRESERVE_DISK')return finish({...base,title:cell?`Conservar materia para el futuro disco desde la casilla ${cell}`:'Conservar materia para el futuro disco',consequence:physicalConsequence(parcel,'REDISTRIBUTE')});
  if(k.includes('CLAIM'))return finish({...base,title:cell?`Vincular tu voluntad a la materia de la casilla ${cell}`:'Vincular tu voluntad a esta materia',consequence:'Dejas una relación causal entre tu entidad y esa materia. No equivale a poseerla para siempre: crea una historia que el Guionista podrá recordar.'});
  if(k.includes('REJECT'))return finish({...base,title:'Rechazar esta influencia',consequence:'Intentas impedir o limitar una relación que afecta a tu ámbito. Si existe una causa opuesta suficiente, el resultado se resolverá en vez de convertirse en un veto automático.'});
  if(k.includes('DESIGNATE')||k.includes('PURPOSE'))return finish({...base,title:cell?`Imprimir un propósito en la materia de la casilla ${cell}`:'Imprimir un propósito',consequence:'La materia queda asociada a un propósito consciente que puede sobrevivir a transformaciones futuras. El propósito no garantiza el resultado.'});
  if(k.includes('REVEAL'))return finish({...base,title:'Manifestar una verdad de tu existencia',consequence:'Haces descubrible una verdad que ya existe. Esta opción solo debe aparecer cuando exista alguien o algo capaz de recibir esa revelación.'});
  if(k.includes('HIDE'))return finish({...base,title:'Permanecer oculto',consequence:'Limitas que tu presencia sea descubierta sin borrar tu existencia objetiva. Puede retrasar alianzas, cultos o reacciones futuras.'});
  if(k==='LINK'||k.includes('BIND'))return finish({...base,title:cell?`Crear un vínculo invisible desde la casilla ${cell}`:'Crear un vínculo invisible',consequence:'Creas un vínculo místico impersonal. Si la materia cambia o se separa, ese vínculo podrá reaparecer como causa futura según sus límites.'});
  if(k.includes('IMPRINT')||k.includes('PERSIST'))return finish({...base,title:cell?`Hacer persistir una huella en la casilla ${cell}`:'Hacer persistir una huella',consequence:'Intentas que una propiedad invisible sobreviva aunque la materia se fusione, se fragmente o cambie de estado.'});
  if(k.includes('RESON'))return finish({...base,title:'Establecer una resonancia',consequence:'Dos referentes podrán compartir una consecuencia futura si la condición que los une llega a activarse.'});
  if(k.includes('CONDITIONAL'))return finish({...base,title:'Dejar una transformación condicionada',consequence:'La transformación solo ocurrirá si el mundo cumple más adelante la condición real que la activa.'});
  if(k.includes('CONCENTR'))return finish({...base,title:cell?`Favorecer la caída de materia desde la casilla ${cell}`:'Concentrar materia',consequence:physicalConsequence(parcel,'CONCENTRATE')});
  if(k.includes('REDISTR')||k.includes('DISPERS'))return finish({...base,title:cell?`Reservar o redistribuir materia desde la casilla ${cell}`:'Redistribuir materia',consequence:physicalConsequence(parcel,'REDISTRIBUTE')});
  if(k.includes('TRANSFER')||k.includes('ENERGY'))return finish({...base,title:cell?`Modificar el intercambio de energía en la casilla ${cell}`:'Transferir o disipar energía',consequence:'Puedes cambiar si esta materia se calienta, se enfría o conserva impulso. Eso puede acercarla a la ignición, la condensación o una trayectoria distinta, según el estado real del sistema.'});
  if(k.includes('STABIL')||k.includes('CAPTURE'))return finish({...base,title:'Estabilizar una relación entre cuerpos',consequence:'Intentas convertir una aproximación o captura provisional en una relación duradera. Solo será legal si las trayectorias y masas lo permiten.'});
  if(k.includes('NUCLEAR')||k.includes('IGNIT'))return finish({...base,title:'Favorecer la ignición del núcleo',consequence:'La app solo ofrece esta opción cuando masa, presión, composición y temperatura ya permiten un cambio nuclear. Si se consolida, puede ser el paso decisivo para que nazca la estrella.'});
  if(k.includes('SYSTEMIC'))return finish({...base,title:'Aplicar tu influencia a escala del sistema',consequence:'Extiendes una capacidad ya disponible sobre varios referentes conectados. No crea una ley nueva ni permite ignorar sus condiciones.'});
  if(k.includes('DECREE'))return finish({...base,title:'Establecer una regularidad acotada',consequence:'Solo afecta al ámbito que tu autoridad permite. No sustituye la evolución física ordinaria del sistema ni convierte a la deidad en dueña automática de lo que nazca.'});
  if(k.includes('EMANATE'))return finish({...base,title:'Emanar una nueva voluntad',consequence:'Creas una entidad consciente distinta con genealogía propia. Nacer de ti no implica obediencia automática.'});

  return finish({...base,title:humanize(option.label||k,board),consequence:option.hint?humanize(option.hint,board):base.consequence});
}

export function projectSharedOptionR513(option={},board=null){
  return {
    slot:option.slot,
    title:humanize(option.title||`Opción ${option.slot||''}`,board),
    attempt:humanize(option.attempt||option.description||'',board),
    consequence:humanize(option.consequence||option.risk||'El mundo resolverá esta dirección junto con las demás causas activas.',board)
  };
}

function findParcel(live,id){return live?.runtime?.cosmogony?.matter?.parcels?.find(p=>p.id===id)||null;}
function matterSituation(parcel,live){
  const h=parcel.hidden||{},parts=[];
  if(Number(h.lightGas||0)>=4)parts.push('rica en gases ligeros');
  if(Number(h.refractories||0)>=5)parts.push('con abundante material rocoso y metálico');
  if(Number(h.volatiles||0)>=5)parts.push('con muchos compuestos volátiles');
  if(Number(h.mass||0)>=5)parts.push('especialmente masiva');
  if(Number(h.thermal||0)>=5)parts.push('muy caliente');
  if(Number(h.angularMomentum||0)>=5)parts.push('con un movimiento que favorece que permanezca en el disco');
  const desc=parts.length?parts.slice(0,3).join(', '):'sin una propiedad dominante evidente todavía';
  const cell=visibleGenesisCellR513(parcel.cell,live?.runtime?.cosmogony?.board);
  return `En la casilla ${cell} hay materia primordial ${desc}.`;
}
function physicalConsequence(parcel,mode){
  const h=parcel?.hidden||{};
  if(mode==='CONCENTRATE'){
    if(Number(h.mass||0)>=5)return 'Acercarla al centro puede aumentar de forma importante la masa del núcleo y adelantar su camino hacia la ignición, pero deja menos material para futuros planetas.';
    if(Number(h.angularMomentum||0)>=5)return 'Forzar su caída puede acelerar el crecimiento del núcleo, pero sacrificarías parte de una reserva que naturalmente tendería a permanecer en el disco.';
    return 'Favoreces el colapso y el crecimiento de la concentración central. A cambio, esa materia deja de estar tan disponible para formar cuerpos separados.';
  }
  if(Number(h.refractories||0)+Number(h.volatiles||0)>=9)return 'Separarla del colapso central conserva una reserva especialmente prometedora para el disco y los futuros mundos, pero puede retrasar el crecimiento de la estrella.';
  return 'Redistribuirla puede impedir que todo termine en el mismo cuerpo y conservar materia para el disco, aunque retrasa o debilita el colapso central.';
}
function genericSituation(option,cell){return cell?`Tu influencia alcanza la casilla ${cell}.`:'El Guionista ha detectado una intervención legal en el estado actual del sistema.';}
function autonomousNatureName(n){return n==='PHYSICS'?'Fuerza física autónoma':n==='MYSTIC'?'Fuerza mística autónoma':'Voluntad autónoma';}
function humanize(v,board=null){return String(v??'').replace(/MAT-\d+/gi,'esta materia').replace(/H0*(\d+)/gi,(_,n)=>visibleGenesisCellR513(`H${String(n).padStart(3,'0')}`,board)).replace(/_/g,' ').replace(/\s+/g,' ').trim();}
function mergeText(a,b){const x=String(a||'').trim(),y=String(b||'').trim();if(!y||x.includes(y))return x;return`${x} ${y}`.trim();}
