export const GENESIS_R57_VOLITION_RELATIONS='EMR_GENESIS_R57_VOLITION_RELATIONS_v1';
export const VOLITION_RELATION_BASELINE_R57='COEXISTENT_UNRELATED';
export const VOLITION_RELATION_TYPES_R57=Object.freeze([
 'PACTED_WITH','COOPERATES_WITH','OPPOSES','RIVALRY_WITH','CREATED','CREATED_BY','EMANATED','EMANATED_FROM','BOUND_TO','LIMITS','LIMITED_BY','PROMISED_TO'
]);
export const VOLITION_VISIBILITY_R57=Object.freeze(['PUBLIC','PRIVATE','HIDDEN']);
const clone=x=>structuredClone(x);
const pairKey=(a,b)=>[String(a),String(b)].sort().join('::');

export function createVolitionRelationGraphR57({binding=null,volitionEntities=null}={}){
 const source=volitionEntities||(binding?.volitionEntities||[]);
 const nodes=source.map(v=>({entityId:v.entityId,controllerPlayerId:v.controllerPlayerId||null})).sort((a,b)=>a.entityId.localeCompare(b.entityId));
 const baselines=[];
 for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++)baselines.push({pairId:pairKey(nodes[i].entityId,nodes[j].entityId),entityIds:[nodes[i].entityId,nodes[j].entityId],state:VOLITION_RELATION_BASELINE_R57,origin:'D-GEN-R5.7-VOLITION-RELATIONS01'});
 return{schema:GENESIS_R57_VOLITION_RELATIONS,decisionId:'D-GEN-R5.7-VOLITION-RELATIONS01',defaultRelation:VOLITION_RELATION_BASELINE_R57,nodes,baselines,edges:[],sequence:0};
}

export function establishVolitionRelationR57(graph,{fromEntityId,toEntityId,type,symmetry='DIRECTED',producerIds=[],scope='RELATIONAL',conditions=[],limits=[],createdAt=0,provenance,visibility='PUBLIC',knownToPlayerIds=[],futureConsumers=[]}={}){
 validateGraph(graph);
 if(!fromEntityId||!toEntityId||fromEntityId===toEntityId)throw new Error('GEN_R57_RELATION_PAIR_INVALID');
 if(!graph.nodes.some(n=>n.entityId===fromEntityId)||!graph.nodes.some(n=>n.entityId===toEntityId))throw new Error('GEN_R57_VOLITION_UNKNOWN');
 if(!VOLITION_RELATION_TYPES_R57.includes(type))throw new Error('GEN_R57_RELATION_TYPE_INVALID');
 if(!['DIRECTED','SYMMETRIC'].includes(symmetry))throw new Error('GEN_R57_RELATION_SYMMETRY_INVALID');
 if(!Array.isArray(producerIds)||!producerIds.length)throw new Error('GEN_R57_CAUSAL_PRODUCER_REQUIRED');
 if(!provenance)throw new Error('GEN_R57_PROVENANCE_REQUIRED');
 if(!VOLITION_VISIBILITY_R57.includes(visibility))throw new Error('GEN_R57_VISIBILITY_INVALID');
 const next=clone(graph),relationId=`VR57-${String(next.sequence+1).padStart(3,'0')}-${type}`;
 next.sequence++;
 next.edges.push({relationId,fromEntityId,toEntityId,type,symmetry,producerIds:[...new Set(producerIds.map(String))],scope,conditions:clone(conditions),limits:clone(limits),createdAt,provenance,visibility,knownToPlayerIds:[...new Set(knownToPlayerIds.map(String))],futureConsumers:[...new Set(futureConsumers.map(String))],state:'ACTIVE'});
 return next;
}

export function createDerivedVolitionGenealogyR57(graph,{producerEntityId,derivedEntityId,mode='CREATED',producerIds=[],createdAt=0,provenance,visibility='HIDDEN',knownToPlayerIds=[],futureConsumers=[]}={}){
 const type=mode==='EMANATED'?'EMANATED':'CREATED';
 let next=establishVolitionRelationR57(graph,{fromEntityId:producerEntityId,toEntityId:derivedEntityId,type,symmetry:'DIRECTED',producerIds:producerIds.length?producerIds:[producerEntityId],scope:'GENEALOGICAL',createdAt,provenance,visibility,knownToPlayerIds,futureConsumers});
 next=establishVolitionRelationR57(next,{fromEntityId:derivedEntityId,toEntityId:producerEntityId,type:type==='CREATED'?'CREATED_BY':'EMANATED_FROM',symmetry:'DIRECTED',producerIds:producerIds.length?producerIds:[producerEntityId],scope:'GENEALOGICAL',createdAt,provenance,visibility,knownToPlayerIds,futureConsumers});
 return next;
}

export function relationsBetweenVolitionsR57(graph,a,b){
 validateGraph(graph);const key=pairKey(a,b),baseline=graph.baselines.find(x=>x.pairId===key)||null;
 const edges=graph.edges.filter(e=>pairKey(e.fromEntityId,e.toEntityId)===key&&e.state==='ACTIVE').map(clone);
 return{pairId:key,relationState:edges.length?'RELATED':baseline?.state||VOLITION_RELATION_BASELINE_R57,baseline:clone(baseline),edges};
}

export function relationsForVolitionR57(graph,entityId){
 validateGraph(graph);if(!graph.nodes.some(n=>n.entityId===entityId))throw new Error('GEN_R57_VOLITION_UNKNOWN');
 return graph.edges.filter(e=>(e.fromEntityId===entityId||e.toEntityId===entityId)&&e.state==='ACTIVE').map(clone);
}

export function projectVolitionRelationsForPlayersR57(graph,{playerIds=[]}={}){
 validateGraph(graph);const known=new Set(playerIds.map(String));
 const visible=graph.edges.filter(e=>e.visibility==='PUBLIC'||e.knownToPlayerIds.some(id=>known.has(String(id))));
 return{schema:graph.schema,decisionId:graph.decisionId,defaultRelation:graph.defaultRelation,nodes:clone(graph.nodes),baselines:clone(graph.baselines),edges:clone(visible)};
}

export function projectVolitionRelationsLegacyR57(graph){validateGraph(graph);return clone(graph);}
export function serializeVolitionRelationGraphR57(graph){validateGraph(graph);return JSON.stringify(graph);}
export function deserializeVolitionRelationGraphR57(json){const g=JSON.parse(json);validateGraph(g);return g;}
function validateGraph(g){if(g?.schema!==GENESIS_R57_VOLITION_RELATIONS||!Array.isArray(g.nodes)||!Array.isArray(g.baselines)||!Array.isArray(g.edges))throw new Error('GEN_R57_GRAPH_INVALID');}
