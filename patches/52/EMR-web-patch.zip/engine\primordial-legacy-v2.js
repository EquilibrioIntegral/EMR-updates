const clone=x=>structuredClone(x);
const uniq=a=>[...new Set(a.filter(Boolean))];

export const PRIMORDIAL_LEGACY_SCHEMA_V2='EMR_PRIMORDIAL_LEGACY_v2';

function chainFrom(state){
 return (state.deltas||[]).map(d=>({id:d.id,transformId:d.transformId,resultTag:d.resultTag,producer:d.producer,consumer:d.consumer,outcome:d.outcome,domain:d.domain??d.causalDomain??null}));
}
function activeResidues(state){return (state.residues||[]).filter(r=>r.status==='ACTIVE').map(clone);}
function causalFingerprint(chain){return chain.map(x=>`${x.transformId}:${x.resultTag}:${x.outcome}`).join('|');}
function derivePhysics(state,chain){
 const tags=uniq(chain.flatMap(x=>[x.transformId,x.resultTag]));
 const entities=Object.values(state.entities||{});
 const bodies=entities.filter(e=>e.kind==='BODY').map(e=>({id:e.id,name:e.name??null,x:e.x,y:e.y,tags:[...(e.tags||[])]}));
 return {schema:'EMR_PRIMORDIAL_PHYSICS_TRACE_v1',formation:{distribution:tags.includes('SISTEMA_DISTRIBUIDO')?'DISTRIBUTED':tags.includes('NUCLEO_DOMINANTE')?'CONCENTRATED':'UNRESOLVED',cohesion:tags.includes('COHESION_PRIMORDIAL')?'COHESIVE':tags.includes('FRACTURA_PRIMORDIAL')?'FRACTURED':'UNRESOLVED',orbitality:tags.includes('ORBITAS_ESTABLES')?'STABLE_ORBITAL':'UNRESOLVED'},bodies,sourceTags:tags};
}
function deriveMystic(state,chain){
 const tags=uniq(chain.flatMap(x=>[x.transformId,x.resultTag]));
 return {schema:'EMR_PRIMORDIAL_MYSTIC_TRACE_v1',domains:uniq(chain.map(x=>x.domain)),imprints:tags.filter(x=>x==='VINCULO_IMPERSONAL'||x==='HUELLA_CONSCIENTE'),prohibitions:(state.signature?.VOLUNTAD??0)===0?['CONSCIOUS_CAUSALITY_FORBIDDEN']:[],sourceTags:tags};
}

export function compilePrimordialLegacyV2(state,{focusBodyId=null,seedKind='PHYSICS'}={}){
 const chain=chainFrom(state); const body=focusBodyId?state.entities?.[focusBodyId]:null;
 if(focusBodyId&&body?.kind!=='BODY') throw new Error('PRIMORDIAL_FOCUS_BODY_INVALID');
 const common={identity:{id:`LEGADO-PRIMORDIAL-${state.seed}`,seed:state.seed,seedKind},provenance:{producer:'CI03-S03',consumer:'BOOT01_FORMACION_MUNDO',signature:clone(state.signature||{}),causalFingerprint:causalFingerprint(chain)},namedReferents:Object.values(state.entities||{}).filter(e=>e.name).map(e=>({id:e.id,name:e.name,kind:e.kind})),facts:clone(state.facts||[]),causalChain:chain,residues:activeResidues(state),threads:clone(state.threads||[]),promises:clone(state.promises||[]),scars:activeResidues(state).map(r=>({id:r.id,type:r.type??r.resultTag??'PRIMORDIAL_RESIDUE',source:r.source??r.transformId??null})),focusBody:body?{id:body.id,name:body.name??null,x:body.x,y:body.y,tags:[...(body.tags||[])]}:null};
 const extensions={};
 if(seedKind==='PHYSICS')extensions.physics=derivePhysics(state,chain);
 if(seedKind==='MYSTIC')extensions.mystic=deriveMystic(state,chain);
 return {schemaVersion:PRIMORDIAL_LEGACY_SCHEMA_V2,id:common.identity.id,producer:common.provenance.producer,consumer:common.provenance.consumer,fingerprint:common.provenance.causalFingerprint,common,extensions};
}

export function validatePrimordialLegacyV2(legacy){
 if(legacy?.schemaVersion!==PRIMORDIAL_LEGACY_SCHEMA_V2)throw new Error('PRIMORDIAL_LEGACY_V2_SCHEMA_INVALID');
 if(legacy.consumer!=='BOOT01_FORMACION_MUNDO')throw new Error('PRIMORDIAL_LEGACY_V2_CONSUMER_INVALID');
 if(!legacy.common?.provenance?.causalFingerprint)throw new Error('PRIMORDIAL_LEGACY_V2_PROVENANCE_REQUIRED');
 if(!legacy.extensions?.physics&&!legacy.extensions?.mystic)throw new Error('PRIMORDIAL_LEGACY_V2_EXTENSION_REQUIRED');
 return true;
}

export function projectPrimordialLegacyV2ToBoot01(legacy){
 validatePrimordialLegacyV2(legacy);
 const p=legacy.extensions.physics; const m=legacy.extensions.mystic;
 return {legacyId:legacy.id,causalFingerprint:legacy.common.provenance.causalFingerprint,seedKind:legacy.common.identity.seedKind,formation:p?clone(p.formation):null,mystic:m?{domains:[...m.domains],imprints:[...m.imprints],prohibitions:[...m.prohibitions]}:null,publicFacts:clone(legacy.common.facts.filter(f=>f.KNOWLEDGE==='PUBLIC'||f.knowledge==='PUBLIC'))};
}
