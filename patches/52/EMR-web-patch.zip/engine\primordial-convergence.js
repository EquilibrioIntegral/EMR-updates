// GEN-CONVERGENCE-01 — finite causal progression for inter-BOOT Genesis.
// Internal engine only: no player-facing UX copy.

const clone = x => JSON.parse(JSON.stringify(x));

export const GENESIS_CONVERGENCE_SCHEMA = 'EMR_GENESIS_CONVERGENCE_v1';
export const DEFAULT_GENESIS_CONVERGENCE = Object.freeze({ targetMinRounds:4, targetMaxRounds:7, safetyCeiling:8 });

export function createGenesisConvergence({seed='EMR-GENESIS', config={}}={}) {
  const cfg={...DEFAULT_GENESIS_CONVERGENCE,...config};
  if(!Number.isInteger(cfg.targetMinRounds)||!Number.isInteger(cfg.targetMaxRounds)||!Number.isInteger(cfg.safetyCeiling)||cfg.targetMinRounds<1||cfg.targetMaxRounds<cfg.targetMinRounds||cfg.safetyCeiling<cfg.targetMaxRounds) throw new Error('GENESIS_CONVERGENCE_CONFIG_INVALID');
  return {schema:GENESIS_CONVERGENCE_SCHEMA,seed,round:0,pressure:0,possibilityBudget:cfg.safetyCeiling,progress:{transformations:0,stableRelations:0,residues:0,transition:0},thresholds:{transition:4},config:cfg,status:'OPEN',history:[]};
}

export function applyGenesisOutcome(state,{decisionId,outcome,delta={}}={}) {
  if(state?.schema!==GENESIS_CONVERGENCE_SCHEMA) throw new Error('GENESIS_CONVERGENCE_STATE_INVALID');
  if(state.status!=='OPEN') throw new Error('GENESIS_CONVERGENCE_CLOSED');
  if(!decisionId||!['SUCCESS','COST','FAILURE'].includes(outcome)) throw new Error('GENESIS_OUTCOME_INVALID');
  const d={transformations:delta.transformations??0,stableRelations:delta.stableRelations??0,residues:delta.residues??0,transition:delta.transition??0};
  if(Object.values(d).some(v=>!Number.isInteger(v)||v<0)) throw new Error('GENESIS_DELTA_INVALID');
  // No empty turns: every valid decision must irreversibly change the possibility space.
  if(Object.values(d).every(v=>v===0)) {
    if(outcome==='FAILURE') d.residues=1;
    else d.transition=1;
  }
  const s=clone(state); s.round+=1; s.possibilityBudget=Math.max(0,s.possibilityBudget-1);
  for(const k of Object.keys(s.progress)) s.progress[k]+=d[k];
  s.pressure=Math.max(s.pressure,Math.min(s.config.safetyCeiling,s.round+s.progress.residues));
  s.history.push({round:s.round,decisionId,outcome,delta:clone(d),pressure:s.pressure,possibilityBudget:s.possibilityBudget});
  return evaluateGenesisConvergence(s);
}

export function evaluateGenesisConvergence(state) {
  const s=clone(state); const thresholdReached=s.progress.transition>=s.thresholds.transition;
  if(thresholdReached && s.round>=s.config.targetMinRounds) s.status='READY_TO_CLOSE';
  else if(s.round>=s.config.safetyCeiling) s.status='ASSISTED_CONVERGENCE_REQUIRED';
  return s;
}

export function assistGenesisConvergence(state,{causalSourceIds=[]}={}) {
  if(state?.status!=='ASSISTED_CONVERGENCE_REQUIRED') throw new Error('GENESIS_ASSIST_NOT_REQUIRED');
  if(!Array.isArray(causalSourceIds)||causalSourceIds.length===0) throw new Error('GENESIS_ASSIST_CAUSAL_PROVENANCE_REQUIRED');
  const s=clone(state); const missing=Math.max(0,s.thresholds.transition-s.progress.transition);
  s.progress.transition+=missing; s.status='READY_TO_CLOSE';
  s.history.push({round:s.round,type:'ASSISTED_CONVERGENCE',causalSourceIds:[...causalSourceIds],delta:{transition:missing}});
  return s;
}

export function closeGenesisConvergence(state) {
  if(state?.status!=='READY_TO_CLOSE') throw new Error('GENESIS_NOT_READY_TO_CLOSE');
  const s=clone(state); s.status='CLOSED';
  return {state:s,digest:{rounds:s.round,pressure:s.pressure,progress:clone(s.progress),possibilityBudget:s.possibilityBudget,history:clone(s.history)}};
}
