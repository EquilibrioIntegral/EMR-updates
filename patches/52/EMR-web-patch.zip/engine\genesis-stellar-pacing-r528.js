// R5.28 / P13 — Stellar pacing policy.
// Separates the physical possibility of accumulating enough mass from the
// player-experience gate that decides when ignition may actually occur.
// The goal is to guarantee several full causal rounds before a star can exist,
// while preserving a deterministic reference convergence so Genesis still ends.

export const GENESIS_STELLAR_PACING_R528_SCHEMA='EMR_GENESIS_STELLAR_PACING_R528_v1';
export const GENESIS_STELLAR_PACING_R528_DECISION='D-GEN-R5.28-STELLAR-PACING01';

// Candidate A1 calibration for the 10-minute Genesis prototype.
// Not final balance canon until human timing/CVI evidence exists.
export const GENESIS_MIN_NATURAL_IGNITION_EPOCH_R528=3;
export const GENESIS_REFERENCE_CONVERGENCE_EPOCH_R528=7;

export function stellarPacingGateR528({epoch=0,phase='COLLAPSE',starMass=0,threshold=0}={}){
 const e=Math.max(0,Number(epoch)||0),mass=Math.max(0,Number(starMass)||0),limit=Math.max(0,Number(threshold)||0);
 const thresholdReached=limit>0&&mass>=limit;
 const collapseActive=phase==='COLLAPSE';
 const minimumAgencyWindowComplete=e>=GENESIS_MIN_NATURAL_IGNITION_EPOCH_R528;
 const referenceConvergenceDue=collapseActive&&e>=GENESIS_REFERENCE_CONVERGENCE_EPOCH_R528;
 return{
  schema:GENESIS_STELLAR_PACING_R528_SCHEMA,
  decisionId:GENESIS_STELLAR_PACING_R528_DECISION,
  epoch:e,
  phase,
  starMass:mass,
  threshold:limit,
  thresholdReached,
  minimumAgencyWindowComplete,
  naturalIgnitionAllowed:collapseActive&&thresholdReached&&minimumAgencyWindowComplete,
  holdIgnition:collapseActive&&thresholdReached&&!minimumAgencyWindowComplete,
  referenceConvergenceDue,
  minNaturalIgnitionEpoch:GENESIS_MIN_NATURAL_IGNITION_EPOCH_R528,
  referenceConvergenceEpoch:GENESIS_REFERENCE_CONVERGENCE_EPOCH_R528,
  calibrationStatus:'CANDIDATE_HUMAN_TEST'
 };
}

export function stellarPacingSummaryR528(cosmogony){
 const threshold=Math.max(7,Math.round(Number(cosmogony?.totalInitialMass||0)*0.38));
 return stellarPacingGateR528({epoch:cosmogony?.epoch,phase:cosmogony?.phase,starMass:cosmogony?.star?.mass,threshold});
}
