import { applyDeltas } from './delta.js';
import { buildVisibleBindings, realizeTyped } from './realizer.js';

const ACCESS=['OPEN','PARTIAL','CLOSED'];
const CONDITION=['OK','DAMAGED','BROKEN','DESTROYED'];
const OPPOSITE={ACCESS_DOWN:'ACCESS_UP',ACCESS_UP:'ACCESS_DOWN',SAFETY_DOWN:'SAFETY_UP',SAFETY_UP:'SAFETY_DOWN',RELATION_DOWN:'RELATION_UP',RELATION_UP:'RELATION_DOWN',RESOURCE_DOWN:'RESOURCE_UP',RESOURCE_UP:'RESOURCE_DOWN'};

function pipe(v){ return String(v ?? '').split('|').map(x=>x.trim()).filter(Boolean); }
function arr(v){ return Array.isArray(v)?v:[]; }
function clamp(n,a,b){ return Math.max(a,Math.min(b,n)); }
function asNum(v,d=0){ const n=Number(v); return Number.isFinite(n)?n:d; }
function recordType(collection,obj){
  if (collection==='relations') return 'RELATION';
  if (collection==='facts') return 'FACT';
  return obj?.ENTITY_TYPE ?? 'ENTITY';
}
function publicLabel(obj,id='referente') {
  return obj?.ATTRIBUTES?.name ?? obj?.PUBLIC_LABEL ?? obj?.PUBLIC_HINT ?? obj?.QUESTION_OR_TENSION ?? obj?.PROMISED_CHANGE_OR_PAYOFF ?? 'un referente ya conocido';
}
function isPublic(obj){ return ['PUBLIC','REVEALED'].includes(obj?.VISIBILITY ?? 'PUBLIC'); }
function hasAny(haystack,needles){ const h=new Set(arr(haystack)); return needles.some(x=>h.has(x)); }
function hasAffordance(obj,required){ return !required.length || hasAny(obj?.AFFORDANCES,required); }
function getAllTargets(state){
  const out=[];
  for (const c of ['entities','facts','relations']) for (const [id,obj] of Object.entries(state[c] ?? {})) out.push({collection:c,id,obj,type:recordType(c,obj)});
  return out;
}
function typeMatch(type,allowed){ return allowed.includes(type) || (allowed.includes('ENTITY') && !['RELATION','FACT'].includes(type)); }
function locOf(state,rec){
  if (!rec) return null;
  if (rec.type==='RELATION') {
    const a=state.entities?.[rec.obj.SOURCE_REF], b=state.entities?.[rec.obj.TARGET_REF];
    return a?.LOCATION_REF ?? b?.LOCATION_REF ?? null;
  }
  return rec.obj.LOCATION_REF ?? (rec.type==='LOCATION'?rec.id:null);
}
function distance(state,a,b){
  if (!a || !b) return 0;
  if (a===b) return 0;
  const graph=state.generative?.connections ?? {};
  const q=[[a,0]], seen=new Set([a]);
  while(q.length){ const [cur,d]=q.shift(); for(const n of graph[cur] ?? []) { if(n===b) return d+1; if(!seen.has(n) && d<4){seen.add(n);q.push([n,d+1]);} } }
  return Infinity;
}
function scopeLegal(state,source,target,primitive){
  const scopes=pipe(primitive.SCOPE_ALLOWED);
  if (scopes.includes('GLOBAL_PROCESS')) return true;
  const d=distance(state,locOf(state,source),locOf(state,target));
  if (d===0 && scopes.includes('LOCAL')) return true;
  if (d===1 && scopes.includes('ADJACENT')) return true;
  if (Number.isFinite(d) && d<=4 && scopes.includes('NETWORK')) return true;
  return false;
}
function nextNeighbor(state,location,seedIndex=0){
  const ns=state.generative?.connections?.[location] ?? [];
  if (!ns.length) return null;
  return ns[Math.abs(seedIndex)%ns.length];
}
function idxStep(list,current,delta){ const i=Math.max(0,list.indexOf(current)); return list[clamp(i+delta,0,list.length-1)]; }
function isKnowledgePrimitive(p){ return ['PRIM-REVEAL','PRIM-DISCOVER-EVIDENCE'].includes(p.PRIMITIVE_ID); }
function memoryAnchorPublic(state,event){
  for (const id of [event?.targetRef,event?.producerRef]) {
    const obj=state.entities?.[id] ?? state.relations?.[id] ?? state.facts?.[id];
    if (obj && isPublic(obj)) return publicLabel(obj,id);
  }
  return 'un hecho anterior';
}
function relevantWorldMemory(state,app,g){
  if (!isPublic(app.target.obj)) return null;
  const used=new Set(g.recalledWorldEvents ?? []), now=asNum(state.meta?.gameTime,0);
  const anchors=new Set([app.source.id,app.target.id]);
  const candidates=(state.eventLog ?? []).filter(e=>
    e.type==='WORLD_EVENT_RECORDED' && e.worldEventId && !used.has(e.worldEventId) &&
    asNum(e.gameTime,0)<=now-2 && e.primitiveId!==app.primitive.PRIMITIVE_ID &&
    (anchors.has(e.producerRef) || anchors.has(e.targetRef))
  );
  if (!candidates.length) return null;
  return candidates.map(event=>{
    let relevance=0;
    if (event.producerRef===app.source.id) relevance+=22;
    if (event.targetRef===app.target.id) relevance+=28;
    if (event.targetRef===app.source.id || event.producerRef===app.target.id) relevance+=12;
    if (event.changeSignature && OPPOSITE[event.changeSignature]===app.primitive.CHANGE_SIGNATURE) relevance+=14;
    else if (event.changeSignature && event.changeSignature!==app.primitive.CHANGE_SIGNATURE) relevance+=6;
    relevance+=Math.max(0,8-Math.min(8,now-asNum(event.gameTime,0)));
    return {event,relevance};
  }).sort((a,b)=>b.relevance-a.relevance || asNum(a.event.gameTime,0)-asNum(b.event.gameTime,0))[0];
}

function primitiveLegal(state,p,source,target){
  const t=target.obj, s=source.obj;
  if (source.id===target.id && ['PRIM-THREATEN','PRIM-PURSUE','PRIM-PROTECT','PRIM-PROVIDE-RESOURCE','PRIM-DISPLACE-ACTOR'].includes(p.PRIMITIVE_ID)) return false;
  switch(p.PRIMITIVE_ID){
    case 'PRIM-BLOCK-ACCESS': return ['OPEN','PARTIAL'].includes(t.ACCESS_STATE ?? 'OPEN');
    case 'PRIM-FLOOD-ACCESS': return (t.ACCESS_STATE ?? 'OPEN')!=='CLOSED' && asNum(t.FLOOD_LEVEL,0)<3;
    case 'PRIM-ISOLATE': return t.ISOLATION_STATE!=='ISOLATED';
    case 'PRIM-CLEAR-ACCESS': return ['CLOSED','PARTIAL'].includes(t.ACCESS_STATE);
    case 'PRIM-RESTORE-CONNECTION': return target.type==='RELATION' && t.RELATION_TYPE==='CONNECTED_TO' && ['BROKEN','DISABLED'].includes(t.STATUS);
    case 'PRIM-DAMAGE': return (t.CONDITION_STATE ?? 'OK')!=='DESTROYED';
    case 'PRIM-THREATEN': return asNum(t.THREAT_LEVEL,0)<3;
    case 'PRIM-PURSUE': return t.PURSUIT_STATE!=='ACTIVE' && target.id!==source.id;
    case 'PRIM-PROTECT': return (asNum(t.THREAT_LEVEL,0)>0 || asNum(t.HAZARD_LEVEL,0)>0) && asNum(t.PROTECTION_LEVEL,0)<3;
    case 'PRIM-STABILIZE-HAZARD': return asNum(t.HAZARD_LEVEL,0)>0;
    case 'PRIM-REVEAL':
    case 'PRIM-DISCOVER-EVIDENCE': return !isPublic(t) && t.REVEAL_AUTHORIZED===true;
    case 'PRIM-TAKE-CONTROL': return t.CONTROLLED_BY!==source.id;
    case 'PRIM-CONTEST-CONTROL': return Boolean(t.CONTROLLED_BY) && t.CONTROL_STATE!=='CONTESTED';
    case 'PRIM-STRAIN-RELATION': return target.type==='RELATION' && t.STATUS==='ACTIVE' && asNum(t.VALUE,0)>-2;
    case 'PRIM-BREAK-TRUST': return target.type==='RELATION' && t.STATUS==='ACTIVE' && t.TRUST_STATE!=='BROKEN' && asNum(t.VALUE,0)>-2;
    case 'PRIM-REPAIR-RELATION': return target.type==='RELATION' && t.STATUS==='ACTIVE' && asNum(t.VALUE,0)<2;
    case 'PRIM-SUPPORT-RELATION': return target.type==='RELATION' && t.STATUS==='ACTIVE' && asNum(t.VALUE,0)<2;
    case 'PRIM-DENY-RESOURCE': return asNum(t.RESOURCE_LEVEL,0)>0;
    case 'PRIM-SABOTAGE-RESOURCE': return asNum(t.OPERATIONAL_LEVEL,1)>0;
    case 'PRIM-PROVIDE-RESOURCE': return asNum(s.RESOURCE_STOCK,0)>0 && asNum(t.RESOURCE_LEVEL,0)<asNum(t.MAX_RESOURCE_LEVEL,3);
    case 'PRIM-RECOVER-RESOURCE': return asNum(t.RESOURCE_LEVEL,0)<asNum(t.MAX_RESOURCE_LEVEL,3) || asNum(t.OPERATIONAL_LEVEL,0)<asNum(t.MAX_OPERATIONAL_LEVEL,2);
    case 'PRIM-RELOCATE-SELF': return source.id===target.id && Boolean(nextNeighbor(state,s.LOCATION_REF,0));
    case 'PRIM-DISPLACE-ACTOR': return source.id!==target.id && target.id!=='PC-001' && Boolean(nextNeighbor(state,t.LOCATION_REF,1));
    default:return true;
  }
}

function makeDeltas(state,p,app,sceneId){
  const t=app.target.obj, s=app.source.obj, id=app.target.id, sid=app.source.id, auth='M-HYB-GEN04';
  const mk=(n,extra)=>({DELTA_ID:`${sceneId}-D${n}`,CAUSE_REF:sceneId,AUTHORITY_ID:auth,...extra});
  switch(p.PRIMITIVE_ID){
    case 'PRIM-BLOCK-ACCESS': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'ACCESS_STATE',AFTER:idxStep(ACCESS,t.ACCESS_STATE ?? 'OPEN',1)})];
    case 'PRIM-FLOOD-ACCESS': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'FLOOD_LEVEL',AFTER:clamp(asNum(t.FLOOD_LEVEL,0)+1,0,3)}),mk(2,{OPERATION:'SET',TARGET_REF:id,FIELD:'ACCESS_STATE',AFTER:idxStep(ACCESS,t.ACCESS_STATE ?? 'OPEN',1)})];
    case 'PRIM-ISOLATE': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'ISOLATION_STATE',AFTER:'ISOLATED'})];
    case 'PRIM-CLEAR-ACCESS': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'ACCESS_STATE',AFTER:idxStep(ACCESS,t.ACCESS_STATE ?? 'PARTIAL',-1)})];
    case 'PRIM-RESTORE-CONNECTION': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'STATUS',AFTER:'ACTIVE'})];
    case 'PRIM-DAMAGE': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'CONDITION_STATE',AFTER:idxStep(CONDITION,t.CONDITION_STATE ?? 'OK',1)})];
    case 'PRIM-THREATEN': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'THREAT_LEVEL',AFTER:clamp(asNum(t.THREAT_LEVEL,0)+1,0,3)})];
    case 'PRIM-PURSUE': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'PURSUIT_STATE',AFTER:'ACTIVE'}),mk(2,{OPERATION:'SET',TARGET_REF:id,FIELD:'PURSUER_REF',AFTER:sid})];
    case 'PRIM-PROTECT': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'PROTECTION_LEVEL',AFTER:clamp(asNum(t.PROTECTION_LEVEL,0)+1,0,3)})];
    case 'PRIM-STABILIZE-HAZARD': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'HAZARD_LEVEL',AFTER:clamp(asNum(t.HAZARD_LEVEL,0)-1,0,3)})];
    case 'PRIM-REVEAL':
    case 'PRIM-DISCOVER-EVIDENCE': return [mk(1,{OPERATION:'REVEAL',TARGET_REF:id,AFTER:'REVEALED'})];
    case 'PRIM-TAKE-CONTROL': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'CONTROLLED_BY',AFTER:sid}),mk(2,{OPERATION:'SET',TARGET_REF:id,FIELD:'CONTROL_STATE',AFTER:'CONTROLLED'})];
    case 'PRIM-CONTEST-CONTROL': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'CONTROL_STATE',AFTER:'CONTESTED'}),mk(2,{OPERATION:'SET',TARGET_REF:id,FIELD:'CHALLENGER_REF',AFTER:sid})];
    case 'PRIM-STRAIN-RELATION': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'VALUE',AFTER:clamp(asNum(t.VALUE,0)-1,-2,2)})];
    case 'PRIM-BREAK-TRUST': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'TRUST_STATE',AFTER:'BROKEN'}),mk(2,{OPERATION:'SET',TARGET_REF:id,FIELD:'VALUE',AFTER:clamp(asNum(t.VALUE,0)-1,-2,2)})];
    case 'PRIM-REPAIR-RELATION':
    case 'PRIM-SUPPORT-RELATION': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'VALUE',AFTER:clamp(asNum(t.VALUE,0)+1,-2,2)})];
    case 'PRIM-DENY-RESOURCE': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'RESOURCE_LEVEL',AFTER:clamp(asNum(t.RESOURCE_LEVEL,0)-1,0,asNum(t.MAX_RESOURCE_LEVEL,3))})];
    case 'PRIM-SABOTAGE-RESOURCE': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'OPERATIONAL_LEVEL',AFTER:clamp(asNum(t.OPERATIONAL_LEVEL,1)-1,0,asNum(t.MAX_OPERATIONAL_LEVEL,2))})];
    case 'PRIM-PROVIDE-RESOURCE': return [mk(1,{OPERATION:'SET',TARGET_REF:id,FIELD:'RESOURCE_LEVEL',AFTER:clamp(asNum(t.RESOURCE_LEVEL,0)+1,0,asNum(t.MAX_RESOURCE_LEVEL,3))}),mk(2,{OPERATION:'SET',TARGET_REF:sid,FIELD:'RESOURCE_STOCK',AFTER:Math.max(0,asNum(s.RESOURCE_STOCK,0)-1)})];
    case 'PRIM-RECOVER-RESOURCE': {
      const ds=[]; let n=1;
      if (asNum(t.RESOURCE_LEVEL,0)<asNum(t.MAX_RESOURCE_LEVEL,3)) ds.push(mk(n++,{OPERATION:'SET',TARGET_REF:id,FIELD:'RESOURCE_LEVEL',AFTER:clamp(asNum(t.RESOURCE_LEVEL,0)+1,0,asNum(t.MAX_RESOURCE_LEVEL,3))}));
      if (asNum(t.OPERATIONAL_LEVEL,0)<asNum(t.MAX_OPERATIONAL_LEVEL,2)) ds.push(mk(n++,{OPERATION:'SET',TARGET_REF:id,FIELD:'OPERATIONAL_LEVEL',AFTER:clamp(asNum(t.OPERATIONAL_LEVEL,0)+1,0,asNum(t.MAX_OPERATIONAL_LEVEL,2))}));
      return ds;
    }
    case 'PRIM-RELOCATE-SELF': return [mk(1,{OPERATION:'MOVE',TARGET_REF:sid,AFTER:app.destination})];
    case 'PRIM-DISPLACE-ACTOR': return [mk(1,{OPERATION:'MOVE',TARGET_REF:id,AFTER:app.destination})];
    default:return [];
  }
}

export class GenerativeDirector {
  constructor({gen04,realizerV3}) { this.gen04=gen04; this.realizer=realizerV3; }

  ensureState(state) {
    state.generative ??={sceneSeq:0,primitiveUse:{},axisUse:{},recentKeys:[],recentAxes:[],recalledWorldEvents:[],current:null,connections:{},stats:{callbacks:0,threadClosures:0,worldMemoryCallbacks:0,zero:0}};
    state.generative.primitiveUse ??={}; state.generative.axisUse ??={}; state.generative.recentKeys ??=[]; state.generative.recentAxes ??=[]; state.generative.recalledWorldEvents ??=[]; state.generative.stats ??={callbacks:0,threadClosures:0,worldMemoryCallbacks:0,zero:0};
    state.generative.stats.worldMemoryCallbacks ??=0;
    return state.generative;
  }

  installFixture(state,fixture) {
    const g=this.ensureState(state); g.connections=structuredClone(fixture.connections ?? {}); g.fixtureAuthority=fixture.authority;
    for (const [id,patch] of Object.entries(fixture.entities ?? {})) state.entities[id]={...(state.entities[id] ?? {}),...structuredClone(patch)};
    for (const [id,patch] of Object.entries(fixture.relations ?? {})) state.relations[id]={...(state.relations[id] ?? {}),...structuredClone(patch)};
    for (const [id,obj] of Object.entries(fixture.facts ?? {})) { delete state.entities[id]; state.facts[id]=structuredClone(obj); }
    return state;
  }

  applications(state) {
    const producers=Object.entries(state.entities ?? {}).map(([id,obj])=>({collection:'entities',id,obj,type:obj.ENTITY_TYPE ?? 'ENTITY'})).filter(r=>['ACTOR','NPC','FACTION','PHENOMENON'].includes(r.type) && isPublic(r.obj) && r.id!=='PC-001');
    const targets=getAllTargets(state);
    const out=[];
    for (const p of this.gen04.primitives) {
      const pt=pipe(p.PRODUCER_TYPES), pc=pipe(p.PRODUCER_CAPABILITIES), tt=pipe(p.TARGET_TYPES), ta=pipe(p.TARGET_AFFORDANCES);
      for (const source of producers) {
        if (!pt.includes(source.type) || !hasAny(source.obj.CAPABILITIES,pc)) continue;
        const targetPool=p.PRIMITIVE_ID==='PRIM-RELOCATE-SELF' ? [source] : targets;
        for (const target of targetPool) {
          if (!typeMatch(target.type,tt) || !hasAffordance(target.obj,ta)) continue;
          if (!scopeLegal(state,source,target,p)) continue;
          if (!isKnowledgePrimitive(p) && !isPublic(target.obj)) continue;
          if (!primitiveLegal(state,p,source,target)) continue;
          const destination=p.PRIMITIVE_ID==='PRIM-RELOCATE-SELF' ? nextNeighbor(state,source.obj.LOCATION_REF,this.ensureState(state).sceneSeq) : p.PRIMITIVE_ID==='PRIM-DISPLACE-ACTOR' ? nextNeighbor(state,target.obj.LOCATION_REF,this.ensureState(state).sceneSeq+1) : null;
          out.push({primitive:p,source,target,destination});
        }
      }
    }
    return out;
  }

  score(state,app) {
    const g=this.ensureState(state), p=app.primitive;
    let score=10;
    const mature=Object.values(state.promises ?? {}).filter(x=>x.STATUS==='MATURE');
    const promise=mature.find(x=>(!x.SOURCE_REF || x.SOURCE_REF===app.source.id) && (!x.TARGET_REF || x.TARGET_REF===app.target.id));
    if (promise) {
      score+=90;
      if (promise.ORIGIN_PRIMITIVE===p.PRIMITIVE_ID) score-=90;
      else score+=20;
      if (promise.VALUE_AXIS && promise.VALUE_AXIS!==p.VALUE_AXIS) score+=12;
    }
    const threads=Object.values(state.threads ?? {}).filter(x=>x.STATUS==='OPEN');
    const thread=threads.find(x=>x.TARGET_REF===app.target.id && (!x.VALUE_AXIS || x.VALUE_AXIS===p.VALUE_AXIS));
    if (thread) {
      score+=32+12*asNum(thread.PRESSURE_STATE,1);
      if (thread.PRIMITIVE_ID===p.PRIMITIVE_ID) score-=18;
    }
    const memoryMatch=relevantWorldMemory(state,app,g), memory=memoryMatch?.event ?? null;
    if (memoryMatch) score+=36+memoryMatch.relevance;
    const use=asNum(g.primitiveUse[p.PRIMITIVE_ID],0); if (use===0) score+=24; else score-=Math.min(48,use*6);
    const axisUse=asNum(g.axisUse[p.VALUE_AXIS],0); score-=Math.min(24,axisUse*2);
    const recent=g.recentKeys, recentAxes=g.recentAxes;
    if (recent.at(-1)===p.RECENCY_KEY) score-=70;
    else if (recent.slice(-3).includes(p.RECENCY_KEY)) score-=36;
    else if (recent.slice(-6).includes(p.RECENCY_KEY)) score-=16;
    if (recentAxes.at(-1)===p.VALUE_AXIS) score-=22;
    else if (recentAxes.slice(-3).includes(p.VALUE_AXIS)) score-=10;
    if (p.CHANGE_SIGNATURE.endsWith('_UP')) score+=3;
    return {score,promise,thread,memory};
  }

  select(engine) {
    const state=engine.state,g=this.ensureState(state), apps=this.applications(state);
    if (!apps.length){ g.stats.zero++; engine.log('N-GEN ZERO',{reason:'NO_LEGAL_PRIMITIVE'}); return null; }
    const scored=apps.map(app=>({...app,...this.score(state,app)}));
    const max=Math.max(...scored.map(x=>x.score)); const top=scored.filter(x=>x.score>=max-4);
    const selected=top.length===1?top[0]:engine.rng.pickWeighted(top,x=>Math.max(1,x.score-(max-5)));
    engine.log('SELECT',{mode:'GEN04',selectedRef:selected.primitive.PRIMITIVE_ID,sourceRef:selected.source.id,targetRef:selected.target.id,legalCount:apps.length,topCount:top.length,score:selected.score,context:selected.promise?'PROMISE':selected.thread?'THREAD':selected.memory?'WORLD_MEMORY':'NOVELTY',contextWorldEventId:selected.memory?.worldEventId??null});
    return selected;
  }

  makeSituation(engine) {
    const state=engine.state,g=this.ensureState(state); if (g.current) throw new Error('GENERATED_SCENE_UNRESOLVED');
    const app=this.select(engine); if(!app) return {returnCode:'ZERO',situation:null};
    g.sceneSeq++; const sceneId=`GEN-SCENE-${String(g.sceneSeq).padStart(4,'0')}`; const p=app.primitive;
    const sourceLabel=publicLabel(app.source.obj,app.source.id);
    const destinationLabel=app.destination ? publicLabel(state.entities?.[app.destination] ?? {},'otro lugar conocido') : null;
    const targetLabel=p.PRIMITIVE_ID==='PRIM-RELOCATE-SELF' && destinationLabel ? destinationLabel : publicLabel(app.target.obj,app.target.id);
    const loc=publicLabel(state.entities?.[locOf(state,app.target)] ?? state.entities?.[locOf(state,app.source)] ?? {},'el lugar');
    const memoryLabel=app.memory ? memoryAnchorPublic(state,app.memory) : '';
    let domain=app.promise?'LIVE_DECK':app.thread||app.memory?'HISTORY':app.source.type==='PHENOMENON'?'WORLD_RUI':'NPC';
    const contextText=app.promise?.PROMISED_CHANGE_OR_PAYOFF ?? app.thread?.QUESTION_OR_TENSION ?? (app.memory?`Lo ocurrido anteriormente alrededor de ${memoryLabel} sigue teniendo consecuencias.`:'');
    const causeText=app.promise?.PUBLIC_TRIGGER ?? app.thread?.PUBLIC_CAUSE ?? (app.memory?`una consecuencia de lo ocurrido antes alrededor de ${memoryLabel}`:app.source.obj.MOTIVE ?? 'una causa ya presente');
    let bindings={
      SOURCE_REF:sourceLabel,ACTOR_REF:sourceLabel,MOTIVE_REF:app.source.obj.MOTIVE ?? 'una necesidad ya presente',ACTION_OBJECT_REF:targetLabel,
      LOCATION_PHRASE:p.PRIMITIVE_ID==='PRIM-RELOCATE-SELF' && app.destination ? `desde ${loc}` : p.PRIMITIVE_ID==='PRIM-DISPLACE-ACTOR' && app.destination ? `desde ${loc} hacia ${destinationLabel}` : targetLabel===loc ? 'en ese lugar' : `en ${loc}`,
      THREAD_REF:contextText || 'Una tensión anterior',CAUSE_REF:causeText,PROMISE_REF:contextText || 'Una consecuencia pendiente',TRIGGER_REF:app.promise?.PUBLIC_TRIGGER ?? 'su condición llega a cumplirse',
      EVENT_REF:app.memory?`Lo ocurrido antes alrededor de ${memoryLabel}`:'Un cambio pendiente',PLAYER_REF:'el protagonista',PLAYER_ACTION:'actúa',REACTOR_REF:sourceLabel
    };
    bindings=buildVisibleBindings({primitive:p,realizer:this.realizer,sceneKey:sceneId,bindings});
    const rendered=realizeTyped({domain,bindings,realizer:this.realizer});
    const situation={sceneId,title:'Situación',text:rendered.text,physical:[],choices:[{id:'ALLOW',label:'Dejas que el cambio siga su curso.'},{id:'INTERVENE',label:'Intervienes para alterar lo que está ocurriendo.'}]};
    g.current={sceneId,primitiveId:p.PRIMITIVE_ID,sourceId:app.source.id,targetId:app.target.id,destination:app.destination,contextPromiseId:app.promise?.PROMISE_ID ?? null,contextThreadId:app.thread?.THREAD_ID ?? null,contextWorldEventId:app.memory?.worldEventId ?? null,visibleText:rendered.text,provenance:rendered.provenance};
    engine.log('N-04/N-05 REALIZE_EMIT',{sceneId,primitiveId:p.PRIMITIVE_ID,domain,contextWorldEventId:app.memory?.worldEventId??null,provenance:rendered.provenance.map(x=>x.recordId)});
    return {returnCode:'RETURN_OK',situation};
  }

  _findAppFromCurrent(state,current) {
    const p=this.gen04.primitives.find(x=>x.PRIMITIVE_ID===current.primitiveId); if(!p) throw new Error('GENERATED_PRIMITIVE_NOT_FOUND');
    const source={collection:'entities',id:current.sourceId,obj:state.entities[current.sourceId],type:state.entities[current.sourceId]?.ENTITY_TYPE};
    let collection='entities', obj=state.entities[current.targetId];
    if (!obj && state.facts[current.targetId]) { collection='facts'; obj=state.facts[current.targetId]; }
    if (!obj && state.relations[current.targetId]) { collection='relations'; obj=state.relations[current.targetId]; }
    if (!obj) throw new Error('GENERATED_TARGET_NOT_FOUND');
    return {primitive:p,source,target:{collection,id:current.targetId,obj,type:recordType(collection,obj)},destination:current.destination};
  }

  _memoryDelta(state,current,choice,app) {
    const id=`MEM-${current.sceneId}`; const source=publicLabel(app.source.obj), target=publicLabel(app.target.obj);
    const summary=choice==='ALLOW'?`Permitiste que ${source} actuara sobre ${target}.`:`Interviniste contra la acción de ${source} sobre ${target}.`;
    return {DELTA_ID:`${current.sceneId}-MEM`,CAUSE_REF:current.sceneId,AUTHORITY_ID:'M-HYB-GEN04',OPERATION:'CREATE',COLLECTION:'facts',TARGET_REF:id,AFTER:{ID:id,OBJECT:{FACT_ID:id,ENTITY_TYPE:'FACT',AUTHORITY_ID:'M-HYB-GEN04',STATUS:'ACTIVE',VISIBILITY:'SYSTEM',KNOWLEDGE_SCOPE:'SYSTEM_ONLY',SUMMARY:summary,SOURCE_REF:app.source.id,TARGET_REF:app.target.id,CHOICE:choice,TURN:state.meta.turn}}};
  }

  _touchThread(state,current,choice,app) {
    const matching=Object.values(state.threads ?? {}).find(t=>t.STATUS==='OPEN' && t.TARGET_REF===app.target.id && (!t.VALUE_AXIS || t.VALUE_AXIS===app.primitive.VALUE_AXIS));
    if (matching) {
      if (choice==='INTERVENE') { matching.PRESSURE_STATE=asNum(matching.PRESSURE_STATE,1)-1; if (matching.PRESSURE_STATE<=0){matching.STATUS='CLOSED';this.ensureState(state).stats.threadClosures++;} }
      else matching.PRESSURE_STATE=clamp(asNum(matching.PRESSURE_STATE,1)+1,1,3);
      matching.LAST_TOUCHED=state.meta.turn; return;
    }
    if (choice==='ALLOW' && ['ACCESS_DOWN','SAFETY_DOWN','CONTROL_SHIFT','RELATION_DOWN','RESOURCE_DOWN'].includes(app.primitive.CHANGE_SIGNATURE)) {
      const open=Object.values(state.threads ?? {}).filter(t=>t.STATUS==='OPEN');
      if (open.length>=3) { const victim=[...open].sort((a,b)=>asNum(a.PRESSURE_STATE,1)-asNum(b.PRESSURE_STATE,1)||asNum(a.LAST_TOUCHED,0)-asNum(b.LAST_TOUCHED,0))[0]; victim.STATUS='CLOSED'; this.ensureState(state).stats.threadClosures++; }
      const id=`THR-GEN-${String(this.ensureState(state).sceneSeq).padStart(4,'0')}`;
      state.threads[id]={THREAD_ID:id,ORIGIN_REF:current.sceneId,QUESTION_OR_TENSION:`¿Qué consecuencias tendrá el cambio sobre ${publicLabel(app.target.obj)}?`,PUBLIC_CAUSE:`${publicLabel(app.source.obj)} dejó esa tensión abierta`,STATUS:'OPEN',PRESSURE_STATE:1,ACTORS_REFS:[app.source.id],WORLD_REFS:[app.target.id],PRIMITIVE_ID:app.primitive.PRIMITIVE_ID,VALUE_AXIS:app.primitive.VALUE_AXIS,TARGET_REF:app.target.id,SOURCE_REF:app.source.id,LAST_TOUCHED:state.meta.turn,VISIBILITY:'SYSTEM',AUTHORITY_ID:'M-HYB-GEN04'};
    }
  }

  _createPromise(state,current,choice,app) {
    if (choice!=='INTERVENE' || current.contextPromiseId) return;
    const id=`PROM-GEN-${String(this.ensureState(state).sceneSeq).padStart(4,'0')}`;
    const due=state.meta.gameTime+2+(this.ensureState(state).sceneSeq%3);
    const sourceLabel=publicLabel(app.source.obj), targetLabel=publicLabel(app.target.obj);
    const payoff=app.source.type==='PHENOMENON' ? `La presión acumulada de ${sourceLabel} sobre ${targetLabel}` : `La reacción pendiente de ${sourceLabel} a tu intervención sobre ${targetLabel}`;
    state.promises[id]={PROMISE_ID:id,ORIGIN_REF:current.sceneId,PROMISED_CHANGE_OR_PAYOFF:payoff,PUBLIC_TRIGGER:'la situación vuelve a poner esa tensión en juego',MATURITY_TIME:due,STATUS:'PENDING',PREFERRED_PRIMITIVE:null,ORIGIN_PRIMITIVE:app.primitive.PRIMITIVE_ID,VALUE_AXIS:app.primitive.VALUE_AXIS,SOURCE_REF:app.source.id,TARGET_REF:app.target.id,CHANGE_SIGNATURE:app.primitive.CHANGE_SIGNATURE,VISIBILITY:'SYSTEM',KNOWLEDGE_SCOPE:'SYSTEM_ONLY',AUTHORITY_ID:'M-HYB-GEN04'};
  }

  resolve(engine,sceneId,choiceId) {
    const state=engine.state,g=this.ensureState(state),current=g.current;
    if (!current || current.sceneId!==sceneId) throw new Error(`GENERATED_SCENE_NOT_CURRENT:${sceneId}`);
    if (!['ALLOW','INTERVENE'].includes(choiceId)) throw new Error(`GENERATED_CHOICE_UNKNOWN:${choiceId}`);
    const app=this._findAppFromCurrent(state,current); const p=app.primitive;
    engine.log('PLAYER_RESOLUTION',{sceneId,choiceId,mode:'GEN04',contextWorldEventId:current.contextWorldEventId??null});
    const deltas=[];
    if (choiceId==='ALLOW') deltas.push(...makeDeltas(state,p,app,sceneId));
    deltas.push(this._memoryDelta(state,current,choiceId,app));
    applyDeltas(state,deltas);
    this._touchThread(state,current,choiceId,app); this._createPromise(state,current,choiceId,app);
    if (current.contextPromiseId && state.promises[current.contextPromiseId]?.STATUS==='MATURE') { state.promises[current.contextPromiseId].STATUS='RESOLVED'; g.stats.callbacks++; }
    if (current.contextThreadId && state.threads[current.contextThreadId]?.STATUS==='OPEN' && choiceId==='INTERVENE') { state.threads[current.contextThreadId].PRESSURE_STATE=Math.max(0,asNum(state.threads[current.contextThreadId].PRESSURE_STATE,1)-1); if(state.threads[current.contextThreadId].PRESSURE_STATE===0){state.threads[current.contextThreadId].STATUS='CLOSED';g.stats.threadClosures++;} }
    if (current.contextWorldEventId) { g.recalledWorldEvents.push(current.contextWorldEventId); g.recalledWorldEvents=g.recalledWorldEvents.slice(-64); g.stats.worldMemoryCallbacks++; }
    g.primitiveUse[p.PRIMITIVE_ID]=asNum(g.primitiveUse[p.PRIMITIVE_ID],0)+1; g.axisUse[p.VALUE_AXIS]=asNum(g.axisUse[p.VALUE_AXIS],0)+1; g.recentKeys.push(p.RECENCY_KEY); g.recentKeys=g.recentKeys.slice(-8); g.recentAxes.push(p.VALUE_AXIS); g.recentAxes=g.recentAxes.slice(-8);
    state.history.push({sceneId,choiceId,primitiveId:p.PRIMITIVE_ID,sourceRef:app.source.id,targetRef:app.target.id,contextWorldEventId:current.contextWorldEventId??null,gameTime:state.meta.gameTime});
    state.meta.turn+=1; g.current=null;
    engine.advanceTime(1); engine.updateLifecycle();
    engine.log('K-06 APPLY_DELTA',{sceneId,mode:'GEN04',deltaCount:deltas.length,primitiveId:p.PRIMITIVE_ID,contextWorldEventId:current.contextWorldEventId??null});
    engine.log('K-07 RETURN_CONTROL',{returnCode:'RETURN_OK',mode:'GEN04'});
    return state;
  }
}