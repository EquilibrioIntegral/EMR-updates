import { getByPath } from './state.js';

function cmp(actual, op, expected) {
  switch(op) {
    case 'eq': return actual === expected;
    case 'neq': return actual !== expected;
    case 'gt': return Number(actual) > Number(expected);
    case 'gte': return Number(actual) >= Number(expected);
    case 'lt': return Number(actual) < Number(expected);
    case 'lte': return Number(actual) <= Number(expected);
    case 'in': return Array.isArray(expected) && expected.includes(actual);
    case 'contains': return Array.isArray(actual) ? actual.includes(expected) : String(actual ?? '').includes(String(expected));
    default: throw new Error(`UNKNOWN_COMPARATOR:${op}`);
  }
}

export function evalCondition(state, cond) {
  if (!cond) return {ok:true, reason:'NONE'};
  if (cond.all) {
    const results=cond.all.map(c=>evalCondition(state,c));
    const failed=results.find(x=>!x.ok);
    return failed ? {ok:false, reason:`ALL:${failed.reason}`} : {ok:true, reason:'ALL_OK'};
  }
  if (cond.any) {
    const results=cond.any.map(c=>evalCondition(state,c));
    return results.some(x=>x.ok) ? {ok:true, reason:'ANY_OK'} : {ok:false, reason:`ANY:${results.map(x=>x.reason).join('|')}`};
  }
  if (cond.not) {
    const r=evalCondition(state,cond.not);
    return {ok:!r.ok, reason:`NOT:${r.reason}`};
  }
  if (cond.path) {
    const actual=getByPath(state,cond.path);
    const ok=cmp(actual,cond.op ?? 'eq',cond.value);
    return {ok, reason:`${cond.path}:${actual}:${cond.op ?? 'eq'}:${cond.value}`};
  }
  if (cond.collection) {
    const coll=Object.values(state[cond.collection] ?? {});
    const matched=coll.filter(obj => Object.entries(cond.where ?? {}).every(([field,rule]) => {
      if (rule && typeof rule === 'object' && 'op' in rule) return cmp(obj[field],rule.op,rule.value);
      return obj[field] === rule;
    }));
    const n=matched.length;
    const min=cond.min ?? 1, max=cond.max ?? Infinity;
    return {ok:n>=min && n<=max, reason:`${cond.collection}:matches=${n}`};
  }
  throw new Error(`UNKNOWN_CONDITION:${JSON.stringify(cond)}`);
}
