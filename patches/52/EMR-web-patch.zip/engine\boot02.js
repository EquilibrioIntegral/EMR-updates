import {compileBoot02MetaphysicalConstraintsR512} from './boot-metaphysics-r512.js';

const FUNCTIONS=['ARRAIGO','EXPANSION','ADAPTACION','MIGRACION'];
const SEMANTICS={
  ARRAIGO:'favorece comunidades persistentes y lugares habitados estables compatibles',
  EXPANSION:'favorece presencia de pueblos y comunidades en varios contextos territoriales compatibles',
  ADAPTACION:'favorece diversidad de formas de vida y poblamiento compatibles con nichos distintos',
  MIGRACION:'favorece comunidades moviles, desplazamientos y relaciones mediante rutas o corredores compatibles'
};
const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
function d6(v){ v=Number(v); if(!Number.isInteger(v)||v<1||v>6) throw new Error('BOOT02_D6_INVALID'); return v; }
export function compileBoot02Pressures(intentions,die){
  if(!Array.isArray(intentions)||intentions.length<1||intentions.length>4) throw new Error('BOOT02_PLAYER_COUNT_INVALID');
  const vals=intentions.map(norm);
  if(vals.some(v=>!FUNCTIONS.includes(v))) throw new Error('BOOT02_INTENTION_INVALID');
  const variant=d6(die);
  const pressures=Object.fromEntries(FUNCTIONS.map(k=>[k,0]));
  vals.forEach(v=>pressures[v]++);
  const levels=[...new Set(Object.values(pressures).filter(v=>v>0))].sort((a,b)=>b-a);
  const precedence=levels.map(weight=>({weight,functions:FUNCTIONS.filter(k=>pressures[k]===weight)}));
  const biases=Object.fromEntries(FUNCTIONS.map(k=>[k,{weight:pressures[k],provided:pressures[k]>0,semantic:SEMANTICS[k]}]));
  const causalTraces=FUNCTIONS.filter(k=>pressures[k]>0).map(k=>({id:`BOOT02-${k}`,function:k,weight:pressures[k],classification:'UNCLASSIFIED_UNTIL_MATERIALIZED'}));
  return {schemaVersion:'WG-STATE-BOOT02-0.1',pressures,variant,biases,precedence,causalTraces,authorityOrder:['HARD','BOOT02_BIAS','CONSUMER_PREFERENCE','CONSUMER_TIEBREAK']};
}
export function commitBoot02(state,intentions,die){
  if(!state?.session?.boot?.boot01?.territory) throw new Error('BOOT02_TERRITORY_REQUIRED');
  const out=compileBoot02Pressures(intentions,die);
  const genesisSource=state.session?.genesisLegacy||state.session?.genesis||state.genesisLegacy||state.genesis||null;
  if(genesisSource){
    // Hidden world truth constrains future simulation; it is not player knowledge.
    out.metaphysicalConstraints=compileBoot02MetaphysicalConstraintsR512(genesisSource);
    out.metaphysicalConstraintsVisibility='ENGINE_ONLY';
    out.metaphysicalConstraintDecisionId='D-GEN-R5.12-BOOT-KNOWLEDGE01';
  }
  const boot=state.session.boot;
  boot.boot02=out;
  boot.phase='BOOT02_COMPILED';
  state.eventLog??=[];
  state.eventLog.push({type:'BOOT02_PRESSURES_COMPILED',gameTime:state.meta?.gameTime??0,pressures:{...out.pressures},variant:out.variant,causalTraceIds:out.causalTraces.map(x=>x.id),metaphysicalConstraintsConsumed:!!out.metaphysicalConstraints});
  return out;
}
export function advanceBoot02ToBoot03(state){
  if(!state?.session?.boot?.boot02) throw new Error('BOOT02_NOT_COMPILED');
  state.session.boot.phase='BOOT03_READY';
  return state.session.boot.phase;
}
