import {applySharedDecisionResolutionR58 as applySharedDecisionResolutionR516} from './genesis-live-r516-layer.js';
import {confirmLiveMaterializationR5 as confirmLiveMaterializationLegacyR5} from './genesis-live-r510-legacy.js';

export const GENESIS_MATERIALIZATION_R530='EMR_GENESIS_MATERIALIZATION_R530_v1';
const clone=x=>structuredClone(x);

export function primeMaterializationFlowR530(live){
  const n=clone(live);
  if(n.phase!=='MATERIALIZE')return n;
  if(n.materializationFlow?.schema===GENESIS_MATERIALIZATION_R530)return n;
  const queue=clone(n.lastMaterialization||[]);
  n.materializationFlow={
    schema:GENESIS_MATERIALIZATION_R530,
    round:Number(n.round||0),
    cursor:0,
    total:queue.length,
    queue,
    confirmed:[],
    status:queue.length?'IN_PROGRESS':'EMPTY_PENDING_CONFIRMATION',
    afterMaterializationPhase:n.afterMaterializationPhase||null
  };
  n.lastMaterialization=queue.length?[clone(queue[0])]:[];
  n.history??=[];
  n.history.push({type:'GEN_R530_MATERIALIZATION_QUEUE_OPENED',round:n.round??0,total:queue.length,afterMaterializationPhase:n.afterMaterializationPhase||null});
  return n;
}

export function currentMaterializationStepR530(live){
  const flow=live?.materializationFlow;
  if(live?.phase!=='MATERIALIZE'||flow?.schema!==GENESIS_MATERIALIZATION_R530)return null;
  if(flow.cursor>=flow.total)return null;
  return clone(flow.queue[flow.cursor]);
}

export function confirmMaterializationStepR530(live){
  let n=primeMaterializationFlowR530(live);
  if(n.phase!=='MATERIALIZE')throw new Error('GEN_R530_MATERIALIZATION_PHASE');
  const flow=n.materializationFlow;
  if(flow.total===0){flow.status='COMPLETE';return{state:n,complete:true,confirmed:null};}
  const current=flow.queue[flow.cursor];
  if(!current)throw new Error('GEN_R530_MATERIALIZATION_CURSOR_INVALID');
  flow.confirmed.push(clone(current));
  n.history??=[];
  n.history.push({type:'GEN_R530_MATERIALIZATION_STEP_CONFIRMED',round:n.round??0,index:flow.cursor,total:flow.total,change:clone(current)});
  flow.cursor+=1;
  if(flow.cursor<flow.total){
    flow.status='IN_PROGRESS';
    n.lastMaterialization=[clone(flow.queue[flow.cursor])];
    return{state:n,complete:false,confirmed:clone(current)};
  }
  flow.status='COMPLETE';
  n.lastMaterialization=clone(flow.queue);
  return{state:n,complete:true,confirmed:clone(current)};
}

export function applySharedDecisionResolutionR530(live){
  const result=applySharedDecisionResolutionR516(live);
  if(result?.needsTests||!result?.state)return result;
  if(result.state.phase!=='MATERIALIZE')return result;
  // A new resolved interval owns a new queue. Keep an existing cursor only
  // when resuming that interval, never when carrying a completed prior round.
  const next=clone(result.state);
  delete next.materializationFlow;
  return{...result,state:primeMaterializationFlowR530(next)};
}

export function confirmLiveMaterializationR530(live){
  const step=confirmMaterializationStepR530(live);
  if(!step.complete)return step.state;
  const fullQueue=clone(step.state.materializationFlow?.queue||[]);
  const completed=confirmLiveMaterializationLegacyR5(step.state);
  completed.materializationFlow={...clone(step.state.materializationFlow),status:'COMPLETE',cursor:fullQueue.length,total:fullQueue.length,queue:fullQueue,confirmed:clone(step.state.materializationFlow?.confirmed||[])};
  completed.lastMaterialization=fullQueue;
  completed.history??=[];
  completed.history.push({type:'GEN_R530_MATERIALIZATION_QUEUE_COMPLETED',round:completed.round??0,total:fullQueue.length,nextPhase:completed.phase});
  return completed;
}
