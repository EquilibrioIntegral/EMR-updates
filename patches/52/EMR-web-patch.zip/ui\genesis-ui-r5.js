// R5.24/R5.26 player-facing Genesis UI facade.
// The table-first renderer remains the visual authority. P11 enriches the already
// legal R5.8 shared frame once, immediately before declarations/voting, so the
// situation and the <=4+N options respond to actual causal context and memory.
import {renderGenesisR5Ui as renderGenesisR524} from './genesis-ui-r524.js';
import {enrichGenesisSharedDecisionR526} from '../engine/genesis-shared-guionista-r526.js';

export function renderGenesisR5Ui(args){
  const live=args?.state?.session?.genesisR5;
  if(live?.phase==='PHYSICAL_INTENTION_CHOICE'&&live?.contextual&&!live.contextual.guionistaR526){
    args.state.session.genesisR5=enrichGenesisSharedDecisionR526(live);
  }
  return renderGenesisR524(args);
}

export {pickContextualActions} from './genesis-ui-r524-compat.js';
