import {primordialEntityNarrativeRefR512} from './genesis-entity-config-r512.js';

export const GENESIS_AI_IDENTITY_R524='EMR_GENESIS_AI_IDENTITY_R524_v2';
const MYSTIC_NAMES=['Ecos','Umbral','Velo','Resonancia','Trama','Latencia','Nexo','Marea'];
const WILL_NAMES=['Aster','Nahar','Elyon','Orun','Sira','Vael','Nemea','Ilyr'];
const PHYSICS_NAMES=['Impulso','Inercia','Atracción','Entropía','Equilibrio','Curvatura','Flujo','Presión'];
const hash=s=>{let h=2166136261>>>0;for(const ch of String(s)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0;}return h>>>0;};
const pick=(xs,key)=>xs[hash(key)%xs.length];
const bool=(key,threshold=50)=>hash(key)%100<threshold;

export function ensureAutonomousPrimordialIdentitiesR524(live){
 const n=structuredClone(live),seed=n.seed||n.runtime?.seed||'EMR';
 n.playerFacingFlow??={};
 n.playerFacingFlow.aiIdentityRevealQueue??=[];
 n.playerFacingFlow.aiIdentitySeen??=[];
 n.entityConfiguration??={schema:'EMR_GENESIS_ENTITY_CONFIG_R512_v1',confirmed:false,profiles:{},history:[]};
 n.entityConfiguration.profiles??={};
 const seen=new Set(n.playerFacingFlow.aiIdentitySeen||[]);
 for(const p of n.players||[]){
  if(p.controller!=='APP')continue;
  if(p.primordialNarrativeRef)continue;
  const key=`${seed}:${p.id}:${p.nature}`;
  if(p.nature==='PHYSICS'){
   const designation=pick(PHYSICS_NAMES,key);
   const profile={kind:'PHYSICS',entityClass:'PHYSICAL_PRINCIPLE',entityId:`PHY-${p.id}`,controller:'APP',controllerPlayerId:p.id,primordialDesignation:designation,personhood:'IMPERSONAL_FORCE',identityOrigin:'GENESIS_AUTONOMOUS',identitySeedKey:key};
   n.entityConfiguration.profiles[profile.entityId]=profile;
   p.primordialEntityId=profile.entityId;
   p.publicName=`La fuerza física ${designation}`;
   p.primordialNarrativeRef=p.publicName;
   p.name=p.publicName;
   propagateAgencyIdentity(n,p,profile,p.publicName);
   enqueueReveal(n,p,seen);
   continue;
  }
  if(p.nature==='MYSTIC'){
   const entityId=p.primordialEntityId||n.runtime?.binding?.agencies?.find(a=>a.playerId===p.id)?.mysticForceId;
   const named=bool(key+':NAMED',72),designation=named?pick(MYSTIC_NAMES,key):null;
   const profile={kind:'MYSTIC',entityClass:'MYSTIC_FORCE',entityId,controller:'APP',controllerPlayerId:p.id,substrateId:'MYSTIC_SUBSTRATE',primordialDesignation:designation,personhood:'IMPERSONAL_FORCE',metaphysicalRulesStatus:'UNDETERMINED_BY_GENESIS_ACTIONS',identityOrigin:'GENESIS_AUTONOMOUS',identitySeedKey:key};
   if(entityId)n.entityConfiguration.profiles[entityId]=profile;
   p.primordialEntityId=entityId;p.primordialNarrativeRef=primordialEntityNarrativeRefR512(profile);p.publicName=p.primordialNarrativeRef;p.name=p.primordialNarrativeRef;
   const force=n.runtime?.ontology?.mysticForces?.find(x=>x.entityId===entityId);if(force){force.primordialIdentity=structuredClone(profile);force.name=p.primordialNarrativeRef;force.publicName=p.primordialNarrativeRef;}
   propagateAgencyIdentity(n,p,profile,p.primordialNarrativeRef);
   enqueueReveal(n,p,seen);
   continue;
  }
  if(p.nature==='WILL'){
   const entityId=p.primordialEntityId||n.runtime?.binding?.agencies?.find(a=>a.playerId===p.id)?.volitionEntityId;
   const hasName=bool(key+':NAMED',82),trueName=hasName?pick(WILL_NAMES,key):null,mode=hash(key+':FORM')%4;
   const manifestation=mode===0?'NON_ANTHROPOMORPHIC':'ANTHROPOMORPHIC';
   const grammaticalGender=manifestation==='ANTHROPOMORPHIC'?['MASCULINE','FEMININE','UNSPECIFIED'][hash(key+':GENDER')%3]:'UNSPECIFIED';
   const profile={kind:'WILL',entityClass:'VOLITION_ENTITY',entityId,controller:'APP',controllerPlayerId:p.id,trueName,manifestation,grammaticalGender,ethicalCodeStatus:'UNDETERMINED_BY_GENESIS_ACTIONS',identityOrigin:'GENESIS_AUTONOMOUS',identitySeedKey:key};
   if(entityId)n.entityConfiguration.profiles[entityId]=profile;
   p.primordialEntityId=entityId;p.primordialNarrativeRef=primordialEntityNarrativeRefR512(profile);p.publicName=p.primordialNarrativeRef;p.name=p.primordialNarrativeRef;
   const entity=n.runtime?.ontology?.volitionEntities?.find(x=>x.entityId===entityId);if(entity){entity.primordialIdentity=structuredClone(profile);entity.name=p.primordialNarrativeRef;entity.publicName=p.primordialNarrativeRef;}
   propagateAgencyIdentity(n,p,profile,p.primordialNarrativeRef);
   enqueueReveal(n,p,seen);
  }
 }
 n.entityConfiguration.history??=[];
 if(!n.entityConfiguration.history.some(x=>x.type==='GEN_R524_APP_IDENTITIES_ASSIGNED'))n.entityConfiguration.history.push({type:'GEN_R524_APP_IDENTITIES_ASSIGNED',schema:GENESIS_AI_IDENTITY_R524});
 return n;
}

export function autonomousIdentitySummaryR524(live,playerId){
 const p=(live.players||[]).find(x=>x.id===playerId);
 if(!p)return null;
 const profile=Object.values(live.entityConfiguration?.profiles||{}).find(x=>x.controllerPlayerId===playerId)||null;
 const subject=p.primordialNarrativeRef||p.publicName||p.name||'La entidad primordial';
 if(p.nature==='PHYSICS')return{subject,title:subject,text:`${subject} no piensa ni desea. Es una regularidad física primordial: actuará mediante materia, energía, movimiento, estabilidad y transformación del sistema.`};
 if(p.nature==='MYSTIC')return{subject,title:subject,text:profile?.primordialDesignation?`${subject} ha surgido como una fuerza mística impersonal con identidad propia. No es una deidad ni una persona: obedecerá reglas invisibles que podrán dejar huella en el mundo.`:'Ha surgido una fuerza mística impersonal sin nombre primordial. No es una deidad ni una persona: podrá ser interpretada y nombrada mucho más tarde por quienes lleguen a percibir sus efectos.'};
 if(p.nature==='WILL'){
  const form=profile?.manifestation==='ANTHROPOMORPHIC'?'puede manifestarse con forma antropomorfa':'no está ligada a una forma humana';
  const naming=profile?.trueName?`Su nombre primordial es ${profile.trueName}.`:'No ha fijado un nombre primordial.';
  return{subject,title:subject,text:`${subject} es una Voluntad consciente: puede querer, elegir e intervenir. ${form.charAt(0).toUpperCase()+form.slice(1)}. ${naming}`};
 }
 return{subject,title:subject,text:`${subject} forma parte de la realidad primordial de este universo.`};
}

export function markAutonomousIdentitySeenR524(live,playerId){
 const n=structuredClone(live);n.playerFacingFlow??={};n.playerFacingFlow.aiIdentitySeen??=[];
 if(!n.playerFacingFlow.aiIdentitySeen.includes(playerId))n.playerFacingFlow.aiIdentitySeen.push(playerId);
 n.playerFacingFlow.aiIdentityRevealQueue=(n.playerFacingFlow.aiIdentityRevealQueue||[]).filter(id=>id!==playerId);
 return n;
}

function enqueueReveal(n,p,seen){
 if(!seen.has(p.id)&&!n.playerFacingFlow.aiIdentityRevealQueue.includes(p.id))n.playerFacingFlow.aiIdentityRevealQueue.push(p.id);
}
function propagateAgencyIdentity(n,p,profile,narrativeRef){
 const agency=n.runtime?.binding?.agencies?.find(a=>a.playerId===p.id);
 if(!agency)return;
 agency.primordialEntityId=profile.entityId;
 agency.primordialIdentity=structuredClone(profile);
 agency.primordialNarrativeRef=narrativeRef;
 agency.name=narrativeRef;
 agency.publicName=narrativeRef;
}
