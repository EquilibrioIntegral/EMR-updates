import {axialDistance} from './genesis-board-r5.js';

export const GENESIS_MATTER_R5_SCHEMA='EMR_GENESIS_MATTER_R5_v1';

const hashSeed=seed=>{let h=2166136261;for(const ch of String(seed))h=Math.imul(h^ch.charCodeAt(0),16777619);return h>>>0;};
export const seededRng=seed=>{let x=hashSeed(seed)||1;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return(x>>>0)/4294967296;};};
const d6=r=>1+Math.floor(r()*6);

function weightedPick(items,weightFn,r){
 const weights=items.map(x=>Math.max(0,Number(weightFn(x))||0)),total=weights.reduce((a,b)=>a+b,0);
 if(total<=0)return items[Math.floor(r()*items.length)];
 let t=r()*total;for(let i=0;i<items.length;i++){t-=weights[i];if(t<=0)return items[i];}return items.at(-1);
}

export function generateMatterParcels({seed='EMR',board,count=10}={}){
 if(!board?.cells?.length)throw new Error('GEN_MATTER_BOARD_REQUIRED');
 if(!Number.isInteger(count)||count<4||count>24||count>board.cells.length)throw new Error('GEN_MATTER_COUNT_INVALID');
 const r=seededRng(`${seed}:matter`),center=board.center||{q:0,r:0},available=[...board.cells],parcels=[];
 for(let i=0;i<count;i++){
  // R5.24 human-play pacing: new systems begin as a broad cloud, not already
  // parked on the future stellar centre. On A61 this strongly favours rings 3-4,
  // allows ring 2, and excludes centre/ring 1 from initial spawn. Every seed is
  // still reproducible and the engine continues to use the same internal H-codes.
  const chosen=weightedPick(available,c=>{
   const d=axialDistance(c,center);
   if(d<=1)return 0;
   if(d===2)return 0.9;
   if(d===3)return 2.4;
   if(d>=4)return 3.2;
   return 1;
  },r);
  available.splice(available.indexOf(chosen),1);
  const mass=d6(r),lightGas=Math.max(2,d6(r)),refractories=d6(r),volatiles=d6(r),thermal=d6(r),angularMomentum=d6(r),density=d6(r);
  parcels.push({
   id:`MAT-${String(i+1).padStart(2,'0')}`,
   cell:chosen.code,q:chosen.q,r:chosen.r,
   public:{label:`Materia primordial ${i+1}`,traits:publicTraits({mass,refractories,volatiles,thermal,angularMomentum,density})},
   hidden:{mass,lightGas,refractories,volatiles,thermal,angularMomentum,density},
   state:'FREE',preservedBy:[],imprints:[],links:[],members:[`MAT-${String(i+1).padStart(2,'0')}`]
  });
 }
 return{schema:GENESIS_MATTER_R5_SCHEMA,seed:String(seed),count,parcels};
}

function publicTraits(v){
 const t=[];
 if(v.mass>=5)t.push('MUY_MASIVA');else if(v.mass<=2)t.push('LIGERA');
 if(v.volatiles>=5)t.push('RICA_EN_VOLATILES');
 if(v.refractories>=5)t.push('RICA_EN_REFRACTARIOS');
 if(v.thermal>=5)t.push('CALIENTE');else if(v.thermal<=2)t.push('FRIA');
 if(v.angularMomentum>=5)t.push('ALTO_MOMENTO');
 if(v.density>=5)t.push('DENSA');
 return t.slice(0,3);
}

export function totalMatterMass(matter){return matter.parcels.reduce((s,p)=>s+p.hidden.mass,0);}

export function revealMatterHint(parcel,question='GENERAL'){
 if(!parcel?.hidden)throw new Error('GEN_MATTER_INVALID');
 const h=parcel.hidden;
 const map={
  STAR_FEED:h.mass>=5?'ALIMENTARLA AUMENTARIA MUCHO LA MASA ESTELAR':h.mass>=3?'APORTARIA MASA APRECIABLE A LA PROTOESTRELLA':'APORTARIA POCA MASA ESTELAR',
  PLANET:h.refractories+h.volatiles>=9?'MATERIAL MUY VALIOSO PARA FUTUROS MUNDOS':h.refractories+h.volatiles>=6?'PUEDE CONTRIBUIR BIEN AL DISCO PLANETARIO':'SU VALOR PLANETARIO ES LIMITADO',
  GENERAL:parcel.public.traits.length?parcel.public.traits.join(' · '):'SIN RASGO DOMINANTE VISIBLE'
 };
 return map[question]||map.GENERAL;
}
