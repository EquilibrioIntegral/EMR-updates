import {livePlanetOptionsR5 as legacyLivePlanetOptionsR5,chooseLivePlanetR5 as legacyChooseLivePlanetR5,closeLiveGenesisR5 as legacyCloseLiveGenesisR5} from './genesis-live-r510-legacy.js';
import {genesisProgressionR517,genesisObjectiveR517,GENESIS_R517_DECISION} from './genesis-progression-r517.js';

export {genesisProgressionR517,genesisObjectiveR517};

const TYPE_LABELS={GAS_GIANT:'gigante gaseoso',ICE_GIANT:'gigante helado',VOLATILE_RICH_TERRESTRIAL:'mundo rocoso rico en volátiles',ROCKY_TERRESTRIAL:'mundo rocoso',MINOR_WORLD:'mundo menor'};
const ORBIT_LABELS={INNER:'órbita interior',MIDDLE:'órbita intermedia',OUTER:'órbita exterior'};
const SIZE_LABELS={SMALL:'pequeño',MEDIUM:'mediano',LARGE:'grande',VERY_LARGE:'muy grande'};

export function livePlanetOptionsR5(live){
  const planets=legacyLivePlanetOptionsR5(live);
  return planets.map((planet,index)=>{
    const publicIndex=index+1,publicType=TYPE_LABELS[planet.type]||'mundo planetario',publicOrbit=ORBIT_LABELS[planet.orbitBand]||'órbita aún no descrita',publicSize=SIZE_LABELS[planet.sizeBand]||'tamaño aún no descrito';
    return{
      // `id`, `type` and `orbitBand` are retained only as compatibility aliases for
      // the existing UI shape; from R5.18 their values are player-safe, never engine ids/enums.
      id:publicIndex,
      type:publicType,
      orbitBand:publicOrbit,
      sizeBand:publicSize,
      eligible:true,
      publicIndex,
      publicName:`Mundo ${publicIndex}`,
      publicType,
      publicOrbit,
      publicSize
    };
  });
}

function resolvePlanetSelection(live,selector){
  const planets=legacyLivePlanetOptionsR5(live);
  let index=-1;
  const numeric=Number(selector);
  if(Number.isInteger(numeric)&&numeric>=1)index=numeric-1;
  if(index<0&&typeof selector==='string'){
    const m=/^WORLD-(\d+)$/.exec(selector);if(m)index=Number(m[1])-1;
  }
  // Compatibility only for internal callers/saves from the pre-R5.18 player facade.
  if((index<0||index>=planets.length)&&typeof selector==='string')index=planets.findIndex(p=>p.id===selector);
  if(index<0||index>=planets.length)throw new Error('GEN_R517_WORLD_NOT_ELIGIBLE');
  return{planet:planets[index],publicIndex:index+1,publicName:`Mundo ${index+1}`};
}

function publicSelectionNarrative(publicName){
  return `${publicName} será el mundo que continúe la historia. Su materia, su órbita y su genealogía causal viajarán en el Legado hacia los siguientes BOOT. La app conservará las causas y propiedades ocultas sin convertirlas en spoilers.`;
}

export function chooseLivePlanetR5(live,planetSelector){
  if(live?.phase!=='SELECT_PLANET')throw new Error('GEN_R517_PLANET_PHASE');
  const chosen=resolvePlanetSelection(live,planetSelector),planetId=chosen.planet.id;
  const next=legacyChooseLivePlanetR5(live,planetId),publicText=publicSelectionNarrative(chosen.publicName);
  next.currentNarrative=publicText;
  next.narrativeLog??=[];
  for(let i=next.narrativeLog.length-1;i>=0;i--){
    if(next.narrativeLog[i]?.kind==='PLANET_SELECTED'){
      next.narrativeLog[i]={...next.narrativeLog[i],publicText};
      break;
    }
  }
  next.history??=[];
  next.history.push({type:'GEN_R517_WORLD_SELECTED',decisionId:GENESIS_R517_DECISION,selectedPlanetId:planetId,publicIndex:chosen.publicIndex});
  return next;
}

export function closeLiveGenesisR5(live){
  if(live?.phase!=='READY_TO_CLOSE')throw new Error('GEN_R517_CLOSE_PHASE');
  const progression=genesisProgressionR517(live),planets=Array.isArray(live?.runtime?.cosmogony?.planets)?live.runtime.cosmogony.planets:[];
  if(!progression.starIgnited)throw new Error('GEN_R517_STAR_REQUIRED');
  if(!planets.length)throw new Error('GEN_R517_WORLD_REQUIRED');
  const selectedPlanetId=live?.runtime?.selectedPlanetId||live?.selectedPlanetId||null;
  if(!selectedPlanetId||!planets.some(p=>p.id===selectedPlanetId))throw new Error('GEN_R517_SELECTED_WORLD_INVALID');
  const next=legacyCloseLiveGenesisR5(live);
  next.history??=[];
  next.history.push({type:'GEN_R517_HANDOFF_GUARD_PASSED',decisionId:GENESIS_R517_DECISION,selectedPlanetId});
  return next;
}