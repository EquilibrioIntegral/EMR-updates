export const GENESIS_SHARED_GUIONISTA_R526='EMR_GENESIS_SHARED_GUIONISTA_R526_v1';

/**
 * P11: enrich the already legal R5.8 shared-decision frame with a causal situation,
 * deterministic option prioritisation and a player-facing explanation. It does not
 * invent new effects: every retained option already came from the established engine.
 */
export function enrichGenesisSharedDecisionR526(live){
  if(!live?.contextual) return live;
  const n=structuredClone(live);
  const contextual=n.contextual;
  const candidates=[...(contextual.options||[])];
  const context=sharedContextR526(n,candidates);
  const scored=candidates.map((o,index)=>({o,index,score:scoreOption(o,context)}));
  scored.sort((a,b)=>b.score-a.score||a.index-b.index||String(a.o.id).localeCompare(String(b.o.id)));

  const selected=[];
  const usedAxes=new Set();
  for(const row of scored){
    if(selected.length>=4) break;
    const axis=optionAxis(row.o);
    if(usedAxes.has(axis)&&scored.some(x=>!usedAxes.has(optionAxis(x.o)))) continue;
    selected.push(row.o);
    usedAxes.add(axis);
  }
  for(const row of scored){
    if(selected.length>=Math.min(4,scored.length)) break;
    if(!selected.some(x=>x.id===row.o.id)) selected.push(row.o);
  }

  contextual.options=selected.map((o,i)=>({...o,slot:i+1}));
  contextual.narrative={
    ...(contextual.narrative||{}),
    schema:GENESIS_SHARED_GUIONISTA_R526,
    situationKind:context.kind,
    publicText:publicSituationText(context,n),
    decisionPrompt:'Cada entidad puede apoyar una posibilidad distinta o no intervenir. Las declaraciones públicas orientan, pero la resolución usará el perfil completo de decisiones reales.',
    causalBasis:context.publicBasis
  };
  contextual.guionistaR526={
    schema:GENESIS_SHARED_GUIONISTA_R526,
    round:Number(n.round||1),
    situationKind:context.kind,
    candidateCount:candidates.length,
    selectedOptionIds:contextual.options.map(o=>o.id),
    selectedAxes:contextual.options.map(optionAxis),
    publicBasis:context.publicBasis,
    privateReasoningExcluded:true
  };
  n.history??=[];
  n.history.push({
    type:'GEN_R526_SHARED_SITUATION_COMPILED',
    round:Number(n.round||1),
    situationKind:context.kind,
    candidateCount:candidates.length,
    selectedOptionIds:contextual.options.map(o=>o.id),
    selectedAxes:contextual.options.map(optionAxis)
  });
  return n;
}

export function sharedContextR526(live,options=[]){
  const c=live?.runtime?.cosmogony||{};
  const parcels=c?.matter?.parcels||[];
  const free=parcels.filter(p=>p.state==='FREE');
  const disk=parcels.filter(p=>p.state==='DISK');
  const centerish=free.filter(p=>axialDistance(p.cell,c.board)<=1).length;
  const starMass=Number(c?.star?.capturedMass||c?.star?.mass||0);
  const starIgnited=Boolean(c?.star?.ignited||c?.star?.status==='IGNITED');
  const divergenceSeeds=(live?.intentMemoryR525?.relationshipSeeds||[]).filter(x=>x.status!=='RESOLVED');
  const invisibleCount=options.filter(o=>String(o.effect||'').includes('INVISIBLE')||String(o.id||'').includes('POST_MORTEM')||String(o.id||'').includes('REBIRTH')||String(o.id||'').includes('MORAL')||String(o.id||'').includes('JUDG')).length;
  const relationCount=options.filter(o=>/RELATION|PACT|COOPER|OPPOSE/i.test(`${o.effect||''} ${o.id||''} ${o.title||''}`)).length;
  const preserveCount=options.filter(o=>/PRESERVE|DISK|WORLD/i.test(`${o.effect||''} ${o.id||''} ${o.title||''}`)).length;
  const collapseCount=options.filter(o=>/CONCENTRATE|STAR|COLLAPSE|FEED/i.test(`${o.effect||''} ${o.id||''} ${o.title||''}`)).length;

  let kind='CAUSAL_CROSSROADS';
  if(divergenceSeeds.length&&relationCount) kind='RELATIONAL_TENSION';
  else if(!starIgnited&&(centerish>0||starMass>0)&&(preserveCount||collapseCount)) kind='STELLAR_BALANCE';
  else if(invisibleCount>=2) kind='INVISIBLE_FOUNDATION';
  else if(disk.length&&preserveCount) kind='DISK_FUTURE';

  const publicBasis=[];
  if(centerish) publicBasis.push(`${centerish} concentración${centerish===1?' está':'es están'} ya cerca del centro`);
  if(disk.length) publicBasis.push(`${disk.length} concentración${disk.length===1?' conserva':'es conservan'} trayectoria de disco`);
  if(starMass&&!starIgnited) publicBasis.push('el centro ya ha comenzado a acumular masa sin haber nacido todavía una estrella');
  if(divergenceSeeds.length) publicBasis.push('existen divergencias observables entre declaraciones y decisiones anteriores');
  if(invisibleCount) publicBasis.push('hay posibilidades de reglas invisibles todavía no fijadas');
  if(!publicBasis.length) publicBasis.push('las intervenciones de esta ronda han abierto consecuencias incompatibles entre sí');
  return{kind,centerish,starMass,starIgnited,diskCount:disk.length,divergenceCount:divergenceSeeds.length,invisibleCount,relationCount,preserveCount,collapseCount,publicBasis};
}

function scoreOption(o,c){
  const axis=optionAxis(o);let s=0;
  if(c.kind==='RELATIONAL_TENSION'&&axis==='RELATION') s+=40;
  if(c.kind==='STELLAR_BALANCE'&&['COLLAPSE','PRESERVE'].includes(axis)) s+=35;
  if(c.kind==='INVISIBLE_FOUNDATION'&&axis==='INVISIBLE') s+=35;
  if(c.kind==='DISK_FUTURE'&&axis==='PRESERVE') s+=35;
  if(o.requiredNature) s+=5;
  if(o.resolution?.conflictKey) s+=4;
  if(o.resolution?.cooperationKey) s+=3;
  if(Array.isArray(o.causalConsumers)&&o.causalConsumers.length) s+=Math.min(4,o.causalConsumers.length);
  return s;
}

function optionAxis(o){
  const k=`${o.effect||''} ${o.id||''} ${o.title||''}`.toUpperCase();
  if(/RELATION|PACT|COOPER|OPPOSE/.test(k)) return'RELATION';
  if(/POST_MORTEM|REBIRTH|MORAL|JUDG|INVISIBLE|MYSTIC|BIND|RESON|CYCLE/.test(k)) return'INVISIBLE';
  if(/PRESERVE|DISK|WORLD/.test(k)) return'PRESERVE';
  if(/CONCENTRATE|STAR|COLLAPSE|FEED/.test(k)) return'COLLAPSE';
  if(/ENERGY|STABIL|CAPTURE|NUCLEAR|SYSTEMIC|PHYS/.test(k)) return'PHYSICAL';
  return'OTHER';
}

function publicSituationText(c,live){
  const actors=(live?.players||[]).length;
  const lead=c.kind==='RELATIONAL_TENSION'
    ?'La creación recuerda una diferencia entre lo que alguna entidad anunció y lo que finalmente hizo. Esa diferencia ya forma parte de la historia, aunque sus motivos sigan ocultos.'
    :c.kind==='STELLAR_BALANCE'
      ?'La materia se acerca a una bifurcación real: favorecer el colapso central puede acelerar el nacimiento estelar, mientras preservar material fuera del centro puede cambiar los mundos que lleguen después.'
      :c.kind==='INVISIBLE_FOUNDATION'
        ?'La materia todavía no contiene seres conscientes, pero las causas invisibles que se establezcan ahora podrían sobrevivir a la formación de mundos y condicionar realidades futuras.'
        :c.kind==='DISK_FUTURE'
          ?'Parte de la materia ha evitado el centro y conserva la posibilidad de formar un disco. Decidir qué se preserva puede importar mucho después de que nazca la estrella.'
          :'Las intervenciones de esta ronda han creado varias consecuencias posibles que no pueden realizarse todas del mismo modo.';
  return `${lead} ${actors===1?'La entidad presente':'Las entidades presentes'} deben decidir qué causa añadir ahora al mundo.`;
}

function axialDistance(code,board){
  if(!code||!board?.cells) return 99;
  const cell=board.cells.find(x=>x.code===code||x.id===code||x.internalCode===code);
  if(!cell) return 99;
  const q=Number(cell.q||0),r=Number(cell.r||0);return Math.max(Math.abs(q),Math.abs(r),Math.abs(q+r));
}
