import {R53_NATURES} from './genesis-signature-r53.js';
import {axialDistance} from './genesis-board-r5.js';

export const GENESIS_AUTONOMOUS_AGENCIES_R59_SCHEMA='EMR_GENESIS_AUTONOMOUS_AGENCIES_R59_v1';
export const GENESIS_PERIPHERAL_SPAWN_R59_SCHEMA='EMR_GENESIS_PERIPHERAL_SPAWN_R59_v1';

const AI_NAMES=Object.freeze({PHYSICS:'Fuerza física',MYSTIC:'Fuerza mística',WILL:'Voluntad primordial'});

export function expandSoloAutonomousParticipantsR59({entryResult,humanPlayers=[]}={}){
 if(!entryResult?.signature||!Array.isArray(entryResult.natures))throw new Error('GEN_R59_ENTRY_REQUIRED');
 if(!Array.isArray(humanPlayers)||humanPlayers.length!==entryResult.natures.length)throw new Error('GEN_R59_HUMAN_PLAYERS_MISMATCH');
 const humans=humanPlayers.map((p,i)=>({...p,id:p.id||`P${i+1}`,name:p.name||`Jugador ${i+1}`,nature:entryResult.natures[i],controller:'HUMAN',simulated:false,source:'PRIMORDIAL_CHOICE'}));
 if(humans.length!==1)return humans;
 const simulatedNatures=[...(entryResult.soloEmergence?.simulatedNatures||[])];
 const totals=Object.fromEntries(R53_NATURES.map(n=>[n,simulatedNatures.filter(x=>x===n).length]));
 const seen={PHYSICS:0,MYSTIC:0,WILL:0};
 const autonomous=simulatedNatures.map((nature,i)=>{
  seen[nature]++;
  const suffix=totals[nature]>1?` ${seen[nature]}`:'';
  return{id:`APP-${i+2}`,name:`${AI_NAMES[nature]}${suffix}`,nature,controller:'APP',simulated:true,source:'SOLO_SIMULATED_SEAT',secondaryIntensity:Number(entryResult.signature[nature]||0),secondaryOrder:i+1};
 });
 return[...humans,...autonomous];
}

export function autonomousParticipantsR59(participants=[]){return participants.filter(p=>p.controller==='APP'||p.simulated===true);}
export function humanParticipantsR59(participants=[]){return participants.filter(p=>!(p.controller==='APP'||p.simulated===true));}

export function peripheralSpawnSlotsR59(board){
 if(!board?.cells?.length)throw new Error('GEN_R59_BOARD_REQUIRED');
 const qs=board.cells.map(c=>c.q),rs=board.cells.map(c=>c.r);
 const qMin=Math.min(...qs),qMax=Math.max(...qs),rMin=Math.min(...rs),rMax=Math.max(...rs);
 const qInset=qMax-qMin>=5?1:0,rInset=rMax-rMin>=5?1:0;
 const targets=[{slot:'NW',q:qMin+qInset,r:rMin+rInset},{slot:'NE',q:qMax-qInset,r:rMin+rInset},{slot:'SE',q:qMax-qInset,r:rMax-rInset},{slot:'SW',q:qMin+qInset,r:rMax-rInset}];
 const used=new Set();
 return targets.map(t=>{const cell=[...board.cells].filter(c=>!used.has(c.code)).sort((a,b)=>axialDistance(a,t)-axialDistance(b,t)||a.code.localeCompare(b.code))[0];if(!cell)throw new Error('GEN_R59_SPAWN_SLOT_UNAVAILABLE');used.add(cell.code);return{slot:t.slot,cell:cell.code,q:cell.q,r:cell.r};});
}

export function assignPeripheralSpawnsR59(board,participants=[],seed='EMR'){
 if(!Array.isArray(participants)||participants.length<1||participants.length>4)throw new Error('GEN_R59_PARTICIPANT_COUNT_INVALID');
 const slots=shuffle(peripheralSpawnSlotsR59(board),`${seed}:GENESIS:R59:SPAWN`);
 return{schema:GENESIS_PERIPHERAL_SPAWN_R59_SCHEMA,randomButReproducible:true,centerAvoidance:true,noCollision:true,assignments:participants.map((p,i)=>({participantId:p.id,controller:p.controller||'HUMAN',nature:p.nature,...slots[i]}))};
}

export function chooseAutonomousAgencyOptionR59(live,options=[]){
 const p=live?.players?.[live.actorIndex];if(!p||p.controller!=='APP')throw new Error('GEN_R59_AUTONOMOUS_ACTOR_REQUIRED');if(!Array.isArray(options)||!options.length)throw new Error('GEN_R59_AUTONOMOUS_OPTIONS_REQUIRED');
 const active=options.filter(o=>o.kind!=='WAIT'),candidates=active.length?active:options;
 const value=o=>{const parcel=live?.runtime?.cosmogony?.matter?.parcels?.find(x=>x.id===o.targetId),h=parcel?.hidden||{};const mass=Number(h.mass||0),world=Number(h.refractories||0)+Number(h.volatiles||0);if(p.nature==='PHYSICS')return(o.kind==='CONCENTRATE'?mass*2:Number(h.angularMomentum||0)+world)-(Number(o.movementDistance)||0);if(p.nature==='MYSTIC')return(o.primitive?20:0)+(o.kind==='IMPRINT'?world:mass)+Number(o.capabilityLevel||0);return(o.primitive?20:0)+(/PROTECT|PURPOSE|CLAIM/.test(o.kind)?world:mass)+Number(o.capabilityLevel||0);};
 const best=Math.max(...candidates.map(value)),pool=candidates.filter(o=>value(o)===best);return pool[stableIndex(`${live.seed||live.runtime?.seed||'EMR'}:${live.round}:${p.id}:ACTION`,pool.length)];
}

export function commitAutonomousIntentionsR59(live,contextual){
 const options=contextual?.options||[],commits={};
 for(const p of autonomousParticipantsR59(live?.players||[])){const matching=options.filter(o=>!o.requiredNature||o.requiredNature===p.nature).map(o=>String(o.slot));const pool=matching.length?matching:['N'];commits[p.id]=pool[stableIndex(`${live.seed||live.runtime?.seed||'EMR'}:${live.round}:${p.id}:INTENTION`,pool.length)];}
 return commits;
}

function stableIndex(seed,count){if(count<1)return 0;let h=2166136261>>>0;for(const ch of String(seed)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0;}return h%count;}
function shuffle(items,seed){const out=items.map(x=>({...x}));let state=stableIndex(seed,0x7fffffff)||1;const next=()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return(state>>>0)/4294967296;};for(let i=out.length-1;i>0;i--){const j=Math.floor(next()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
