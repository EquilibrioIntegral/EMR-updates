// GEN-NARR-SIG-01 / R5.16 — player-facing cosmogony derived from the primordial signature.
// R5.16 clarification: PHYSICS=0 never means that gravity/material evolution are absent.
// The signature describes primordial causal weight/layers; baseline physical evolution is always active.

const NATURES=['PHYSICS','MYSTIC','WILL'];
const LABEL={PHYSICS:'Física',MYSTIC:'Mística',WILL:'Voluntad'};

const value=(signature,nature)=>Number(signature?.[nature]||0);
const maxValue=signature=>Math.max(...NATURES.map(n=>value(signature,n)));
const positiveNatures=signature=>NATURES.filter(n=>value(signature,n)>0);

function stableIndex(seed,count){
 if(count<1)return 0;
 let h=2166136261>>>0;
 for(const ch of String(seed)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0;}
 return h%count;
}

function variationKey(result,signature){
 const soloSeed=result?.soloEmergence?.seed||'';
 const mode=result?.mode||'';
 return `${soloSeed}|${mode}|${NATURES.map(n=>value(signature,n)).join('/')}`;
}

export function signatureNarrativeHierarchy(result={}){
 const signature=result.signature||result||{};
 const top=maxValue(signature);
 const topNatures=top>0?NATURES.filter(n=>value(signature,n)===top):[];
 const soloPrimary=result?.soloEmergence?.primaryNature||result?.soloPrimaryNature||null;
 let originNature=null;
 if(soloPrimary&&NATURES.includes(soloPrimary)&&value(signature,soloPrimary)===top&&top>0)originNature=soloPrimary;
 else if(topNatures.length===1)originNature=topNatures[0];
 const ordered=[...positiveNatures(signature)].sort((a,b)=>value(signature,b)-value(signature,a)||NATURES.indexOf(a)-NATURES.indexOf(b));
 return{signature:{PHYSICS:value(signature,'PHYSICS'),MYSTIC:value(signature,'MYSTIC'),WILL:value(signature,'WILL')},originNature,topNatures,ordered,tiedOrigin:topNatures.length>1,topValue:top};
}

function originOpening(nature,power,variant,namedOriginRef=null){
 if(nature==='WILL'){
  const subject=namedOriginRef||'una Voluntad primordial todavía sin nombre';
  const openings=[
   `La singularidad cedió y la primera causa extraordinaria que dejó una huella consciente fue ${subject}. Mientras espacio, tiempo, materia y energía comenzaban a seguir regularidades físicas propias, esa voluntad ya podía querer, elegir e intervenir.`,
   `Cuando el equilibrio primordial se quebró, ${subject} estuvo entre las primeras causas capaces de orientar la creación. A su alrededor, el universo material comenzó a expandirse y evolucionar por gravedad, energía y movimiento sin necesitar una orden nueva para cada cambio.`,
   `El primer despertar del universo quedó marcado por ${subject}. La materia no quedó inmóvil a la espera de su permiso: las regularidades físicas siguieron actuando, pero desde entonces existía también una voluntad capaz de alterar, proteger u orientar parte de lo que naciera.`
  ];
  return openings[variant%openings.length]+' '+willAuthoritySentence(power);
 }
 if(nature==='MYSTIC'){
  const subject=namedOriginRef||'un sustrato místico impersonal';
  const openings=[
   `La singularidad cedió y una de las primeras capas extraordinarias de la realidad fue ${subject}. No pensaba ni deseaba. Mientras la materia comenzaba a evolucionar físicamente, aquella causalidad invisible ya podía modificar qué relaciones y huellas serían posibles.`,
   `Cuando el universo se abrió por primera vez, ${subject} atravesaba ya la creación. No sustituyó a la gravedad ni a las regularidades materiales: añadió una capa causal distinta, ciega y sin voluntad.`,
   `Del primer instante nació una realidad material en evolución y, sobre ella, ${subject}. La materia podía colapsar, calentarse y formar estructuras por sí misma, pero no todo lo real quedaba agotado por lo físico.`
  ];
  return openings[variant%openings.length]+' '+mysticAuthoritySentence(power);
 }
 const openings=[
  'La singularidad cedió y con ella se afirmaron las primeras regularidades de la realidad. Espacio, tiempo, materia y energía comenzaron a relacionarse sin necesitar ninguna voluntad que decidiera cada cambio.',
  'El primer principio dominante de esta firma fue físico. Al romperse el equilibrio primordial, materia y energía empezaron a organizarse por gravedad, movimiento e intercambio de energía antes de que ninguna causa extraordinaria pudiera desviarlas.',
  'Cuando comenzó la expansión, el orden material ocupó el primer plano. Fuerzas, distancias, energía y materia establecieron el armazón inicial sobre el que después podrían aparecer otras causalidades.'
 ];
 return openings[variant%openings.length]+' '+physicsAuthoritySentence(power);
}

function willAuthoritySentence(power){
 if(power>=6)return 'Su capacidad de intervención era extraordinaria, aunque no anulaba la evolución física basal ni convertía todo el cosmos en una extensión automática de su deseo.';
 if(power>=5)return 'Su poder era inmenso, pero seguía actuando sobre un universo que también poseía procesos propios.';
 if(power>=3)return 'Su poder era real e importante, pero no absoluto: podía cambiar la creación sin sustituir cada proceso físico por una decisión consciente.';
 return 'Su poder era limitado. Podía dejar huella, pero no controlar por sí sola todo lo que la materia llegara a hacer.';
}
function mysticAuthoritySentence(power){
 if(power>=6)return 'Esa capa mística condicionaba profundamente qué podía llegar a existir, sin por ello reemplazar la física del universo.';
 if(power>=5)return 'Su presencia era inmensa y podía alterar de forma sostenida la creación, aunque la materia seguía teniendo dinámica propia.';
 if(power>=3)return 'Su presencia era importante y podía modificar el curso de la realidad, sin gobernar cada aspecto material.';
 return 'Era una raíz verdadera pero limitada, capaz de dejar consecuencias sin dominar por completo cuanto llegara después.';
}
function physicsAuthoritySentence(power){
 if(power>=6)return 'El peso físico primordial de la firma era enorme: los procesos materiales tenderían a imponerse con gran estabilidad frente a otras intervenciones.';
 if(power>=5)return 'El componente físico primordial tenía un peso muy alto y favorecía una evolución material difícil de desviar.';
 if(power>=3)return 'El componente físico primordial era firme e importante, aunque otras causalidades reales podían modificar resultados concretos.';
 return 'El peso físico primordial de la firma era limitado, pero la evolución física basal seguía existiendo igualmente.';
}

function strengthWord(power){
 if(power>=6)return 'enorme';
 if(power>=5)return 'muy fuerte';
 if(power>=4)return 'fuerte';
 if(power>=3)return 'importante';
 if(power>=2)return 'apreciable';
 return 'tenue';
}

function secondaryParagraph(origin,nature,power){
 const strength=strengthWord(power);
 if(origin==='WILL'&&nature==='PHYSICS')return `Además de la voluntad dominante, la firma otorgó al componente físico primordial un peso ${strength}. La gravedad, la acreción y el intercambio de energía seguían siendo causas reales y podían resistir o amortiguar intervenciones conscientes.`;
 if(origin==='WILL'&&nature==='MYSTIC')return `También existía una capa mística ${strength}, real pero sin voluntad propia. No era otra deidad: añadía posibilidades causales que la voluntad dominante no controlaba automáticamente.`;
 if(origin==='MYSTIC'&&nature==='PHYSICS')return `El componente físico primordial de la firma tenía una presencia ${strength}. La materia seguía pudiendo colapsar, calentarse, orbitar y formar cuerpos aunque el sustrato místico fuera la causa extraordinaria dominante.`;
 if(origin==='MYSTIC'&&nature==='WILL')return `También despertó una voluntad de presencia ${strength}. No era el sustrato místico entero y tendría que intervenir dentro de una realidad que no obedecía automáticamente a sus deseos.`;
 if(origin==='PHYSICS'&&nature==='MYSTIC')return `Sobre aquel fundamento apareció una corriente mística ${strength}. No sustituyó el orden material, pero introdujo fenómenos reales que la física por sí sola no agotaba.`;
 if(origin==='PHYSICS'&&nature==='WILL')return `También apareció una voluntad de presencia ${strength}: una conciencia sobrenatural capaz de querer e intervenir. No había creado cada ley que la rodeaba y tendría que actuar dentro de un cosmos con dinámica propia.`;
 return '';
}

function tiedOpening(hierarchy){
 const names=hierarchy.topNatures.map(n=>LABEL[n]);
 const joined=names.length===2?`${names[0]} y ${names[1]}`:`${names.slice(0,-1).join(', ')} y ${names.at(-1)}`;
 return `La singularidad cedió, pero ningún principio extraordinario despertó solo. ${joined} aparecieron con la misma autoridad primordial. Aun así, la materia comenzó a evolucionar físicamente desde el principio: la igualdad de la firma describe causalidades, no una ausencia de gravedad o de dinámica material.`;
}

export function primordialEmergenceNarrative(result={}){
 const hierarchy=signatureNarrativeHierarchy(result),s=hierarchy.signature,parts=[];
 if(hierarchy.topValue<=0){
  parts.push('La singularidad cedió sin que ninguna causalidad extraordinaria dominara la firma. Aun así, espacio, tiempo, materia y energía comenzaron a evolucionar físicamente y a formar estructuras.');
 }else if(hierarchy.tiedOrigin&&!hierarchy.originNature){
  parts.push(tiedOpening(hierarchy));
  for(const nature of hierarchy.topNatures){
   if(nature==='PHYSICS')parts.push(physicsAuthoritySentence(s.PHYSICS));
   if(nature==='MYSTIC')parts.push(mysticAuthoritySentence(s.MYSTIC));
   if(nature==='WILL')parts.push(willAuthoritySentence(s.WILL));
  }
 }else{
  const origin=hierarchy.originNature||hierarchy.ordered[0];
  const variant=stableIndex(variationKey(result,s),3);
  parts.push(originOpening(origin,value(s,origin),variant,result.namedOriginRef||null));
  for(const nature of hierarchy.ordered)if(nature!==origin)parts.push(secondaryParagraph(origin,nature,value(s,nature)));
 }
 parts.push('Durante millones y millones de años, las consecuencias de aquel origen se extendieron por la oscuridad. Nacieron estrellas, murieron otras, se formaron nubes de polvo y regiones enteras del cosmos adquirieron lentamente una estructura propia.');
 parts.push('Muchísimo tiempo después, la historia deja atrás la inmensidad del cosmos y se concentra en un lugar concreto: el nacimiento de un sistema solar joven. La gravedad ya está reuniendo materia; el núcleo todavía no es una estrella y el futuro disco aún no ha decidido qué mundos podrá formar.');
 return parts.filter(Boolean);
}

function absoluteDescription(nature,power,isOrigin){
 if(power===0){
  if(nature==='PHYSICS')return 'La firma no añade peso físico primordial extraordinario; aun así, la evolución física basal sigue activa: gravedad, calentamiento, acreción, ignición, disco y dinámica orbital.';
  if(nature==='MYSTIC')return 'No existe una causalidad mística primordial activa en esta firma.';
  return 'No existe una voluntad sobrenatural primordial activa en esta firma.';
 }
 const role=isOrigin?'Es el principio dominante de esta firma.':'Es una causalidad secundaria respecto al principio dominante.';
 if(nature==='PHYSICS')return `${role} Su intensidad física primordial es ${power}/6 y su peso material es ${strengthWord(power)}.`;
 if(nature==='MYSTIC')return `${role} Su intensidad mística es ${power}/6 y su presencia sobrenatural impersonal es ${strengthWord(power)}.`;
 return `${role} Su intensidad volitiva es ${power}/6: existe una voluntad o deidad real capaz de querer e intervenir, con una capacidad ${strengthWord(power)}.`;
}

export function universeSignatureExplanation(signature={},context={}){
 const result=context?.signature?context:{...context,signature};
 const h=signatureNarrativeHierarchy(result),s=h.signature;
 const mapping=`La firma se lee Física / Mística / Voluntad: ${s.PHYSICS} / ${s.MYSTIC} / ${s.WILL}. Física 0 no desactiva la evolución material basal.`;
 let hierarchy;
 if(h.topValue<=0)hierarchy='Ninguna causalidad extraordinaria queda establecida como dominante.';
 else if(h.tiedOrigin&&!h.originNature)hierarchy=`No hay un único principio dominante: ${h.topNatures.map(n=>LABEL[n]).join(' y ')} comparten el valor máximo.`;
 else hierarchy=`El principio dominante de la firma es ${LABEL[h.originNature||h.ordered[0]]}. El valor absoluto indica cuánto peso causal añade, no si la materia puede o no tener gravedad.`;
 const origin=h.originNature||(!h.tiedOrigin?h.ordered[0]:null);
 const clauses=NATURES.map(n=>absoluteDescription(n,value(s,n),n===origin));
 return `${mapping} ${hierarchy} ${clauses.join(' ')}`;
}
