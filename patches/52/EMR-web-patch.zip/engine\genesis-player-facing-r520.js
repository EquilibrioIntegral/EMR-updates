import {visibleGenesisCellR515} from './genesis-board-display-r515.js';
import {forecastAgencyOptionR520,causalDeltaR520,GENESIS_R520_DECISION} from './genesis-causal-forecast-r520.js';

export const GENESIS_PLAYER_FACING_R520='EMR_GENESIS_PLAYER_FACING_R520_v1';

export function causalNarrativeForOptionR520(live,option={}){
  const forecast=forecastAgencyOptionR520(live,option);
  return{
    forecastDecisionId:GENESIS_R520_DECISION,
    whatHappensNext:forecastTextR520(live,forecast.baseline,{targetId:option.targetId}),
    ifChosen:choiceForecastTextR520(live,option,forecast),
    forecastMode:forecast.mode,
    forecastHonesty:'PROJECTION_NEXT_INTERVAL_BEFORE_LATER_CAUSES'
  };
}

export function genesisCausalSituationR520(live){
  const option={id:'WAIT',kind:'WAIT'};
  const forecast=forecastAgencyOptionR520(live,option);
  return{
    title:'Lo que está a punto de ocurrir',
    text:forecastTextR520(live,forecast.baseline,{}),
    note:'Es una proyección del siguiente intervalo a partir del estado actual. Una intervención o una causa autónoma posterior puede cambiarla.'
  };
}

function visible(code,board){
  if(board?.id==='A61')return visibleGenesisCellR515(board,code);
  const s=String(code??''),m=s.match(/^H0*(\d+)$/i);return m?String(Number(m[1])):s;
}

export function forecastTextR520(live,forecast,{targetId=null}={}){
  if(!forecast)return'El Guionista no dispone todavía de una proyección física fiable para este intervalo.';
  if(forecast.terminal)return'La fase física de Génesis ya ha terminado; el siguiente paso depende del mundo que continúe la historia.';
  const events=forecast.events||[];
  const targetEvents=targetId?events.filter(e=>eventTouches(e,targetId)):[];
  const chosen=targetEvents[0]||events.find(e=>e.type==='MATTER_COLLISION_COALESCENCE')||events.find(e=>e.type==='STAR_IGNITION')||events.find(e=>e.type==='STAR_ACCRETION')||events.find(e=>e.type==='DISK_RETAIN')||events.find(e=>e.type==='PLANET_FORMATION')||events.find(e=>e.type==='COSMIC_MOVE')||events[0];
  if(!chosen)return'En el siguiente intervalo la materia seguirá evolucionando, pero el motor no proyecta un cambio singular dominante.';
  return eventNarrative(live,forecast,chosen);
}

export function choiceForecastTextR520(live,option,forecast){
  if(option.kind==='WAIT')return`${forecastTextR520(live,forecast.baseline,{})} No añades una causa consciente nueva.`;
  if(forecast.mode==='NON_MATERIAL_CAUSE')return'Esta decisión actúa sobre la capa invisible. No sustituye la física: la evolución material proyectada continúa en paralelo salvo que otra causa material la altere.';
  if(!forecast.branch)return'El motor reconoce la acción como legal, pero no puede prometer un resultado material concreto del siguiente intervalo; la consecuencia se resolverá con el resto de causas activas.';
  const delta=causalDeltaR520(forecast),targetId=option.targetId;
  const baseTarget=parcelIn(forecast.baseline.next,targetId),branchTarget=parcelIn(forecast.branch.next,targetId);
  const board=live?.runtime?.cosmogony?.board;
  if(baseTarget&&branchTarget&&baseTarget.state!==branchTarget.state)return`Si ninguna otra causa la contradice, esta intervención cambia el destino inmediato de esa materia: sin intervenir quedaría ${stateText(baseTarget.state)}, mientras que con tu acción quedaría ${stateText(branchTarget.state)}.`;
  if(baseTarget&&branchTarget&&baseTarget.cell!==branchTarget.cell)return`Si ninguna otra causa la contradice, esta intervención cambia su trayectoria inmediata: la proyección pasa de la casilla ${visible(baseTarget.cell,board)} a la casilla ${visible(branchTarget.cell,board)}.`;
  if(delta?.starFamilyChanged&&delta.branchStarFamily)return`Esta intervención es suficiente para cambiar la clase de estrella proyectada: el sistema pasaría de ${stellarLabel(delta.baselineStarFamily)} a ${stellarLabel(delta.branchStarFamily)}. Eso cambiará el entorno térmico que heredarán los mundos y la materia disponible para formarlos.`;
  if(delta?.starMassDelta>0)return'La proyección del siguiente intervalo incorpora más masa al núcleo que si no intervinieras. Acerca la ignición o refuerza la estrella, a cambio de dejar menos materia independiente para el disco.';
  if(delta?.starMassDelta<0)return'La proyección conserva más materia fuera de la estrella que el curso natural inmediato. Eso protege posibilidades para el disco y los mundos, aunque retrasa o reduce el crecimiento estelar.';
  const baseCollision=countEvents(forecast.baseline,'MATTER_COLLISION_COALESCENCE'),branchCollision=countEvents(forecast.branch,'MATTER_COLLISION_COALESCENCE');
  if(baseCollision!==branchCollision)return branchCollision>baseCollision?'La intervención hace que en el siguiente intervalo aparezca un encuentro y acreción entre concentraciones de materia que no ocurriría del mismo modo sin ella.':'La intervención evita o desplaza un encuentro entre concentraciones que el curso natural produciría en el siguiente intervalo.';
  const baseText=forecastTextR520(live,forecast.baseline,{targetId}),branchText=forecastTextR520(live,forecast.branch,{targetId});
  return branchText!==baseText?`Si ninguna otra causa la contradice: ${lowerFirst(branchText)}`:'La intervención deja una causa real en el sistema, pero el siguiente cambio físico visible coincide con el curso proyectado; sus diferencias pueden reaparecer en intervalos posteriores.';
}

function eventNarrative(live,forecast,event){
  const board=live?.runtime?.cosmogony?.board,before=live?.runtime?.cosmogony;
  if(event.type==='MATTER_COLLISION_COALESCENCE'){
    const sources=(event.sourceIds||[]).map(id=>parcelIn(before,id)).filter(Boolean),cells=[...new Set(sources.map(p=>visible(p.cell,board)))],destination=visible(event.atCell,board),composition=combinedComposition(sources);
    return `En el siguiente intervalo ${sources.length||2} concentraciones${cells.length?` procedentes de las casillas ${cells.join(' y ')}`:''} convergerán en la casilla ${destination} y pasarán a comportarse como una concentración mayor${composition?`, ${composition}`:''}. No es una fusión nuclear automática: es acreción por encuentro de materia.`;
  }
  if(event.type==='STAR_ACCRETION'){
    const p=parcelIn(before,event.targetId),cell=p?visible(p.cell,board):null;
    return`En el siguiente intervalo ${cell?`la materia de la casilla ${cell}`:'una concentración de materia'} será incorporada al núcleo central y aumentará su masa hacia la ignición.`;
  }
  if(event.type==='DISK_RETAIN'){
    const p=parcelIn(before,event.targetId),cell=p?visible(p.cell,board):null;
    return`En el siguiente intervalo ${cell?`la materia de la casilla ${cell}`:'parte de la materia'} conservará suficiente movimiento para evitar la caída inmediata y quedará disponible para el disco.`;
  }
  if(event.type==='COSMIC_MOVE'){
    const p=parcelIn(before,event.targetId),from=event.from?visible(event.from,board):(p?visible(p.cell,board):null),to=visible(event.to,board);
    return`En el siguiente intervalo ${from?`la materia de la casilla ${from}`:'una concentración'} caerá hacia la casilla ${to}, acercándose a la región central por la evolución física autónoma.`;
  }
  if(event.type==='STAR_IGNITION'){
    const profile=event.formationProfile||forecast?.next?.star?.formationProfile;
    const cause=profile?.familyModifier===1?'La combinación de su masa con un núcleo especialmente caliente, denso o rico en gases ligeros la empuja hacia una familia más energética que la indicada solo por masa.':profile?.familyModifier===-1?'Su historia física de formación la desplaza hacia una familia menos energética que la indicada solo por masa.':'La masa capturada y las condiciones físicas del núcleo mantienen la familia esperada.';
    return`En el siguiente intervalo el núcleo alcanzará la ignición y nacerá ${stellarLabel(event.family)}. ${cause} La materia que no haya sido capturada quedará disponible para el disco y los futuros mundos, que heredarán el entorno térmico de esta estrella.`;
  }
  if(event.type==='COSMIC_COMPRESSION')return`La compresión del sistema alcanzará un umbral decisivo y absorberá ${event.absorbedParcels} concentraciones hacia el núcleo, acercando o produciendo la ignición sin consumir deliberadamente toda la materia planetaria.`;
  if(event.type==='DISK_SETTLE')return'En el siguiente intervalo la materia remanente se reorganizará como disco alrededor de la estrella y empezará a fijar las condiciones de los futuros cuerpos.';
  if(event.type==='PLANET_FORMATION')return`En el siguiente intervalo el disco consolidará ${event.planetIds?.length||forecast.after?.planetCount||1} mundo${(event.planetIds?.length||forecast.after?.planetCount||1)===1?'':'s'} con genealogías distintas. Su masa y composición proceden del disco, y su entorno térmico queda condicionado también por la estrella que acaba de formarse.`;
  return'El siguiente intervalo contiene un cambio físico real que el motor resolverá y conservará en la genealogía del sistema.';
}

function eventTouches(event,id){return event.targetId===id||event.retainedId===id||(event.absorbedIds||[]).includes(id)||(event.sourceIds||[]).includes(id);}
function parcelIn(c,id){return id?c?.matter?.parcels?.find(p=>p.id===id)||null:null;}
function countEvents(forecast,type){return(forecast?.events||[]).filter(e=>e.type===type).length;}
function stateText(s){return({FREE:'libre y en colapso',DISK:'reservada en el disco',STAR:'incorporada a la estrella',PLANETARY:'integrada en un cuerpo planetario',MERGED:'integrada en otra concentración'})[s]||'en otro estado físico';}
function stellarLabel(family){return({M_RED_DWARF:'una estrella roja pequeña y longeva',K_ORANGE:'una estrella anaranjada estable',G_YELLOW:'una estrella amarilla de masa intermedia',F_A_WHITE_YELLOW:'una estrella blanca-amarillenta caliente',B_O_BLUE_MASSIVE:'una estrella azul muy masiva y energética'})[family]||'una estrella estable';}
function lowerFirst(s){return s?s.charAt(0).toLowerCase()+s.slice(1):s;}
function combinedComposition(parcels){
  if(!parcels.length)return'';
  const avg=k=>parcels.reduce((n,p)=>n+Number(p.hidden?.[k]||0),0)/parcels.length,parts=[];
  if(avg('lightGas')>=4)parts.push('rica en gases ligeros');
  if(avg('refractories')>=4.5)parts.push('con abundante material rocoso y metálico');
  if(avg('volatiles')>=4.5)parts.push('rica en volátiles');
  return parts.slice(0,2).join(' y ');
}
