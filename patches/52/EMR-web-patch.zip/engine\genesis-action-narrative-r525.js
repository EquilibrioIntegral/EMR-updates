import {visibleGenesisCellR513,primordialActorNameR513} from './genesis-player-facing-r513.js';

export const GENESIS_ACTION_NARRATIVE_R525='EMR_GENESIS_ACTION_NARRATIVE_R525_v1';

export function narrateGenesisAgencyActionR525({live,player,option,card}={}){
  const actor=primordialActorNameR513(player||{})||'La entidad primordial';
  const kind=String(option?.kind||option?.capabilityId||'WAIT').toUpperCase();
  const cell=targetCell(live,option,card);
  const place=cell?` en la casilla ${cell}`:'';

  if(!option||kind==='WAIT')return `${actor} permanece al margen. No añade una causa nueva: deja que la materia y las influencias ya activas sigan su curso, y el mundo conserva también esa renuncia a intervenir.`;

  if(/CONCENTR/.test(kind))return `${actor} favorece el colapso${place}. La materia pierde parte de su resistencia a la caída y queda más expuesta a alimentar la concentración central; lo que gane la futura estrella puede faltar después en el disco.`;
  if(/REDISTR|DISPERS|PRESERVE_DISK/.test(kind))return `${actor} desvía parte del colapso${place}. Esa materia conserva más opciones de permanecer fuera del centro del sistema y alimentar el futuro disco, a costa de retrasar o debilitar la concentración estelar.`;
  if(/TRANSFER|ENERGY/.test(kind))return `${actor} altera el intercambio de energía${place}. Cambian las condiciones térmicas y dinámicas de esa materia, modificando cuánto favorece la compresión, la condensación o una trayectoria distinta.`;
  if(/STABIL|CAPTURE/.test(kind))return `${actor} intenta estabilizar una relación entre cuerpos${place}. Si las masas y trayectorias lo permiten, una aproximación pasajera podrá convertirse en una captura duradera.`;
  if(/NUCLEAR|IGNIT/.test(kind))return `${actor} empuja al sistema hacia un cambio nuclear${place}. La intervención solo puede prosperar porque la materia ya se acerca a las condiciones de presión y temperatura necesarias; no crea una estrella de la nada.`;
  if(/SYSTEMIC/.test(kind))return `${actor} extiende una influencia física ya existente a escala del sistema. No introduce una ley nueva: hace actuar de forma coordinada una capacidad que ya estaba presente en varios lugares conectados.`;

  if(/BIND|LINK/.test(kind))return `${actor} establece un vínculo invisible${place}. La materia puede cambiar de forma o separarse, pero desde este instante existe una relación que podrá reaparecer como causa si sus condiciones sobreviven.`;
  if(/IMPRINT|PERSIST/.test(kind))return `${actor} deja una huella invisible${place}. La marca no obliga al futuro, pero queda preparada para persistir a través de transformaciones materiales que antes la habrían borrado.`;
  if(/RESON/.test(kind))return `${actor} hace resonar dos referentes del mundo. Desde ahora una alteración futura podrá propagarse entre ellos si llega a cumplirse la condición que mantiene esa correspondencia.`;
  if(/CONDITIONAL/.test(kind))return `${actor} deja preparada una transformación que todavía no ocurre. El mundo recordará la condición; solo cuando llegue a cumplirse, la causa latente podrá hacerse efectiva.`;
  if(/CYCLE|ENTANGLE/.test(kind))return `${actor} entrelaza procesos que hasta ahora podían evolucionar por separado. La creación conserva esa dependencia y podrá devolverla más adelante como ciclo, repetición o consecuencia compartida.`;
  if(/BRIDGE|CONSCIOUSNESS|MATTER/.test(kind))return `${actor} abre una posibilidad de correspondencia entre lo invisible y la materia${place}. No nace aún una mente, pero queda establecida una vía por la que futuros seres conscientes podrían relacionarse con esa regla.`;

  if(/PROTECT/.test(kind))return `${actor} intenta preservar una posibilidad${place}. No la vuelve invulnerable: simplemente añade una causa a favor de su continuidad, que deberá competir con todo lo que tienda a destruirla o transformarla.`;
  if(/CLAIM/.test(kind))return `${actor} vincula su voluntad a esta parte de la creación${place}. No obtiene una propiedad absoluta, pero desde ahora existe una relación histórica que otras voluntades podrán reconocer, disputar o recordar.`;
  if(/REJECT/.test(kind))return `${actor} se opone a una influencia que alcanza su ámbito. El rechazo introduce resistencia, no un veto automático: el resultado dependerá de las demás causas activas.`;
  if(/DESIGNATE|PURPOSE/.test(kind))return `${actor} imprime un propósito${place}. La materia no queda obligada a cumplirlo, pero ese propósito entra en la historia causal y podrá sobrevivir a transformaciones posteriores.`;
  if(/REVEAL/.test(kind))return `${actor} hace manifiesta una verdad de su propia existencia. No crea esa verdad ahora: reduce la distancia entre lo que existe y lo que otros podrán llegar a conocer.`;
  if(/HIDE/.test(kind))return `${actor} retira su presencia de aquello que podría percibirla. Sigue existiendo y actuando, pero limita las huellas por las que otras entidades podrían descubrirla.`;
  if(/PACT|RELATE|OPPOSE/.test(kind))return `${actor} redefine su relación con otra voluntad. La afinidad o el conflicto dejan de ser una posibilidad abstracta y pasan a formar parte de la memoria causal del mundo.`;
  if(/AUTOLIMIT|CONTINUITY/.test(kind))return `${actor} se impone un límite a sí mismo. Renuncia a parte de su capacidad inmediata para conservar una forma de continuidad que podrá condicionar decisiones futuras.`;
  if(/DECREE/.test(kind))return `${actor} establece una regularidad acotada dentro de su autoridad. No sustituye las leyes físicas ni domina todo el sistema: añade una regla concreta allí donde su alcance lo permite.`;
  if(/EMANATE/.test(kind))return `${actor} hace surgir una nueva voluntad distinta de sí. Nacer de esa causa crea genealogía, no obediencia: la nueva entidad tendrá desde su origen capacidad de relación y conflicto propios.`;

  const title=clean(card?.title||option?.label||'interviene');
  const consequence=clean(card?.consequence||option?.publicText||option?.hint||'');
  return consequence?`${actor} ${lowerFirst(title)}. ${capitalize(consequence)}`:`${actor} interviene en la creación. La acción queda registrada como una causa real y podrá modificar consecuencias posteriores.`;
}

function targetCell(live,option,card){
  const board=live?.runtime?.cosmogony?.board;
  const parcel=live?.runtime?.cosmogony?.matter?.parcels?.find(p=>p.id===option?.targetId);
  const code=parcel?.cell||option?.spatial?.targetCell;
  if(code)return visibleGenesisCellR513(code,board);
  const source=`${card?.title||''} ${card?.situation||''}`;
  const match=source.match(/casilla\s+(\d+)/i);
  return match?match[1]:'';
}
function clean(v){return String(v??'').replace(/\b(?:MAT-\d+|H\d+)\b/gi,'').replace(/_/g,' ').replace(/\s+/g,' ').trim();}
function capitalize(s){return s?s[0].toUpperCase()+s.slice(1):s;}
function lowerFirst(s){return s?s[0].toLowerCase()+s.slice(1):s;}
