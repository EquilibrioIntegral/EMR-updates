import { PRIMORDIAL_CAUSAL_CORPUS } from '../data/primordial-causal-corpus.js';

const clone=x=>JSON.parse(JSON.stringify(x));
const forceOf=(state,source)=>state.signature?.[source]??0;

export function compilePrimordialCandidates(state,{limit=4}={}){
  const legal=PRIMORDIAL_CAUSAL_CORPUS.filter(rule=>{
    const force=forceOf(state,rule.source);
    if(force<rule.minForce) return false;
    if(rule.requires?.entityKind && !Object.values(state.entities||{}).some(e=>e.kind===rule.requires.entityKind&&e.domain===rule.source)) return false;
    return true;
  }).map(rule=>({id:rule.id,title:rule.intent.title,attempt:rule.intent.attempt,source:rule.source,force:forceOf(state,rule.source),physicalOp:rule.physicalOp,transform:rule.transform}));
  // Preserve causal diversity before filling remaining slots by stable corpus order.
  const selected=[]; const seen=new Set();
  for(const c of legal){if(!seen.has(c.source)&&selected.length<limit){selected.push(c);seen.add(c.source);}}
  for(const c of legal){if(selected.length>=limit)break;if(!selected.some(x=>x.id===c.id))selected.push(c);}
  return {actions:selected,noIntervene:{id:'CI03-NO-INTERVENIR',title:'NO INTERVENIR',source:'AUTONOMA'}};
}

export function validateFreePrimordialAction(state,{source,actorEntityId=null,verb,target=null}={}){
  if(!['SILENCIO','ALIENTO','VOLUNTAD'].includes(source)) return {legal:false,reason:'CAUSAL_SOURCE_UNKNOWN'};
  const force=forceOf(state,source); if(force===0)return {legal:false,reason:'CAUSAL_SOURCE_GATE_ZERO'};
  const actor=actorEntityId?state.entities?.[actorEntityId]:null;
  if(actorEntityId&&!actor)return {legal:false,reason:'ACTOR_UNKNOWN'};
  if(actor&&actor.domain!==source)return {legal:false,reason:'ACTOR_SOURCE_MISMATCH'};
  if(source==='VOLUNTAD'&&(!actor||actor.kind!=='AGENCY'))return {legal:false,reason:'CONSCIOUS_AGENCY_REQUIRED'};
  if(source!=='VOLUNTAD'&&['DECIDE','QUIERE','ORDENA','PROMETE'].includes(String(verb||'').toUpperCase()))return {legal:false,reason:'DIEGETIC_CONSCIOUSNESS_NOT_AUTHORIZED'};
  return {legal:true,translated:{type:'FREE_PRIMORDIAL_ACTION',source,force,actorEntityId,verb:String(verb||'ACT').toUpperCase(),target:clone(target)}};
}

export function resolvePrimordialCausalAction(state,{actionId,d6,producer='CI03-S01',decisionSource='CONTEXTUAL_INTENTION'}={}){
  const rule=PRIMORDIAL_CAUSAL_CORPUS.find(x=>x.id===actionId); if(!rule)throw new Error('PRIMORDIAL_CAUSAL_ACTION_UNKNOWN');
  const force=forceOf(state,rule.source); if(force<rule.minForce)throw new Error('PRIMORDIAL_CAUSAL_ACTION_ILLEGAL');
  if(!Number.isInteger(d6)||d6<1||d6>6)throw new Error('PRIMORDIAL_D6_INVALID');
  const total=d6+force; const outcome=total>=7?'CLEAN_SUCCESS':total>=5?'SUCCESS_WITH_COST':'FAILURE_WITH_CONSEQUENCE';
  const residueId=outcome==='CLEAN_SUCCESS'?rule.residues.clean:outcome==='SUCCESS_WITH_COST'?rule.residues.cost:rule.residues.fail;
  const next=clone(state); next.turn=(next.turn||0)+1;
  const residue={id:residueId,stage:'S01_OUT',source:rule.source,producer,producerRule:rule.id,outcome,transform:rule.transform,consumers:[...rule.consumers],status:'ACTIVE'};
  next.residues??=[]; next.residues.push(residue); next.history??=[]; next.history.push({turn:next.turn,type:'PRIMORDIAL_CAUSAL_RESOLUTION',decisionSource,actionId:rule.id,source:rule.source,force,d6,total,outcome,residueId});
  next.eventLog??=[]; next.eventLog.push({id:`EV-${next.eventLog.length+1}`,turn:next.turn,type:'PRIMORDIAL_CAUSAL_RESOLUTION',payload:{producer,actionId:rule.id,source:rule.source,force,d6,total,outcome,residueId,consumers:[...rule.consumers]}});
  return {state:next,result:{actionId:rule.id,force,d6,total,outcome,residue,physicalOp:rule.physicalOp}};
}

export function deriveNextPrimordialFocus(state){
  const active=(state.residues||[]).filter(r=>r.status==='ACTIVE');
  if(!active.length)return {status:'GAP',reason:'NO_PERSISTENT_CAUSAL_OUTPUT'};
  const latest=active[active.length-1];
  return {status:'READY',stage:'S02',producerResidue:clone(latest),semanticQuery:{stage:'S01_OUT',source:latest.source,transform:latest.transform},mustConsumeProducer:latest.id};
}
