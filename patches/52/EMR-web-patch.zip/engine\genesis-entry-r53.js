import {deriveSignatureR53,signatureRollPlan,R53_NATURES} from './genesis-signature-r53.js';

export const GENESIS_ENTRY_R53_SCHEMA='EMR_GENESIS_ENTRY_R53_v1';
export const PRIMORDIAL_CARD_TO_NATURE=Object.freeze({1:'PHYSICS',2:'MYSTIC',3:'WILL'});
const NATURE_TO_CARD=Object.freeze({PHYSICS:1,MYSTIC:2,WILL:3});
const clone=x=>structuredClone(x);

export function natureFromPrimordialCard(card){const nature=PRIMORDIAL_CARD_TO_NATURE[Number(card)];if(!nature)throw new Error('GEN_R53_PRIMORDIAL_CARD_INVALID');return nature;}

export function createGenesisEntryR53({playerIds=[],playerNames=[]}={}){
 const count=Math.max(playerIds.length,playerNames.length);if(count<1||count>4)throw new Error('GEN_R53_ENTRY_PLAYER_COUNT_INVALID');
 const players=Array.from({length:count},(_,i)=>({playerId:playerIds[i]||`P${i+1}`,playerName:playerNames[i]||`Jugador ${i+1}`}));
 if(new Set(players.map(p=>p.playerId)).size!==players.length)throw new Error('GEN_R53_ENTRY_PLAYER_DUPLICATE');
 return{schema:GENESIS_ENTRY_R53_SCHEMA,players,phase:'PHYSICAL_CHOICE',choices:null,natures:null,rollPlan:null,rolls:{},resolved:null};
}

export function recordRevealedPrimordialCards(entry,cards=[],options={}){
 validate(entry);if(entry.phase!=='PHYSICAL_CHOICE')throw new Error('GEN_R53_ENTRY_PHASE');if(cards.length!==entry.players.length)throw new Error('GEN_R53_ENTRY_CHOICES_INCOMPLETE');
 const natures=cards.map(natureFromPrimordialCard),next=clone(entry);next.choices=cards.map(Number);next.natures=natures;
 if(natures.length===1)return resolveSoloPrimordialEmergenceR53(next,{seed:options.seed||'EMR'});
 const plan=signatureRollPlan(natures);next.rollPlan=plan;if(plan.rolls.length===0){next.resolved=deriveSignatureR53(natures,{});next.phase='RESOLVED';return next;}next.phase='SIGNATURE_DICE';return next;
}

export function resolveSoloPrimordialEmergenceR53(entry,{seed='EMR'}={}){
 validate(entry);if(entry.players.length!==1)throw new Error('GEN_R53_SOLO_REQUIRED');
 const primary=entry.natures?.[0]||natureFromPrimordialCard(entry.choices?.[0]);
 const token=`${seed}:GENESIS:SOLO-EMERGENCE:${primary}`;
 const effectiveCount=1+stableIndex(`${token}:COUNT`,4);
 const candidates=enumerateNatureTuples(effectiveCount-1).filter(tuple=>{
  const counts=choiceCounts([primary,...tuple]);
  return R53_NATURES.every(n=>counts[primary]>=counts[n]);
 });
 const simulatedNatures=effectiveCount===1?[]:candidates[stableIndex(`${token}:SEATS`,candidates.length)];
 const voteNatures=[primary,...simulatedNatures];
 const internalRolls={};
 let resolved;
 if(effectiveCount===1){
  resolved={schema:'EMR_GENESIS_SIGNATURE_R53_v1',signature:Object.fromEntries(R53_NATURES.map(n=>[n,n===primary?6:0])),counts:choiceCounts(voteNatures),mode:'SOLO_SINGLE_CAUSE',rolls:{}};
 }else{
  const plan=signatureRollPlan(voteNatures);
  if(plan.mode==='TIED_SUPPORT'){
   const represented=R53_NATURES.filter(n=>plan.counts[n]>0),others=shuffle(represented.filter(n=>n!==primary),`${token}:TIE-ORDER`);
   const values=shuffle([1,2,3,4,5,6],`${token}:TIE-DICE`).slice(0,represented.length).sort((a,b)=>b-a);
   internalRolls[primary]=values[0];others.forEach((nature,i)=>internalRolls[nature]=values[i+1]);
  }else{
   for(const spec of plan.rolls)internalRolls[spec.nature]=1+stableIndex(`${token}:ROLL:${spec.nature}`,6);
  }
  resolved=deriveSignatureR53(voteNatures,internalRolls);
  resolved.mode=`SOLO_${effectiveCount}_ACTORS_${plan.mode}`;
 }
 const next=clone(entry);next.rollPlan=null;next.rolls={...internalRolls};next.resolved={...resolved,soloPrimaryNature:primary,soloEffectiveCount:effectiveCount};
 next.soloSimulation={schema:'EMR_GENESIS_SOLO_EMERGENCE_v2',hidden:true,seed:String(seed),effectiveCount,primaryNature:primary,simulatedNatures:[...simulatedNatures],voteNatures:[...voteNatures],internalRolls:{...internalRolls},primaryAlwaysDominant:true,primarySupportNeverLower:true,primaryWinsSupportTie:true,simulatedMayCopyPrimary:true,simulatedMayOutvotePrimary:false,maxEffectiveCount:4};
 next.phase='RESOLVED';return next;
}

export function migrateLegacySoloSignatureEntryR53(entry,{seed='EMR'}={}){validate(entry);if(entry.players.length!==1||entry.phase!=='SIGNATURE_DICE')return entry;if(!entry.natures?.length&&!entry.choices?.length)return entry;return resolveSoloPrimordialEmergenceR53(entry,{seed});}

export function signatureDiceInstructionsR53(entry){validate(entry);if(entry.phase!=='SIGNATURE_DICE')return[];return entry.rollPlan.rolls.map(r=>({nature:r.nature,card:NATURE_TO_CARD[r.nature],kind:r.kind,min:r.min,max:r.max,rerollEqual:r.rerollEqual,text:r.kind==='DIRECT_D6'?`Tira 1d6 para ${label(r.nature)}. El resultado será su intensidad.`:`Tira 1d6 para ${label(r.nature)}. La app lo traducirá a intensidad 1–${r.max}.`}));}

export function resolveGenesisEntryDiceR53(entry,rolls={}){
 validate(entry);if(entry.phase!=='SIGNATURE_DICE')throw new Error('GEN_R53_ENTRY_DICE_PHASE');if(entry.players.length===1)throw new Error('GEN_R53_SOLO_DICE_NOT_PLAYER_FACING');
 const next=clone(entry);next.rolls={};for(const spec of next.rollPlan.rolls){const die=Number(rolls[spec.nature]);if(!Number.isInteger(die)||die<1||die>6)throw new Error('GEN_R53_ENTRY_DICE_INCOMPLETE');next.rolls[spec.nature]=die;}
 try{next.resolved=deriveSignatureR53(next.natures,next.rolls);}catch(e){if(e.message==='GEN_R53_TIE_REROLL_REQUIRED')throw new Error('GEN_R53_ENTRY_REROLL_EQUAL_DICE');throw e;}next.phase='RESOLVED';return next;
}

export function genesisEntryPublicResultR53(entry){
 validate(entry);if(entry.phase!=='RESOLVED'||!entry.resolved)throw new Error('GEN_R53_ENTRY_NOT_RESOLVED');
 const out={schema:'EMR_GENESIS_ENTRY_RESULT_R53_v1',choices:[...entry.choices],natures:[...entry.natures],signature:{...entry.resolved.signature},counts:{...entry.resolved.counts},mode:entry.resolved.mode,rolls:{...(entry.resolved.rolls||entry.rolls||{})}};
 if(entry.players.length===1&&entry.soloSimulation){
  out.soloEmergence={...clone(entry.soloSimulation),internal:true};
  out.rolls.__signatureOverride={signature:{...entry.resolved.signature},counts:{...entry.resolved.counts},mode:entry.resolved.mode,rolls:{...entry.rolls}};
 }
 return out;
}

function choiceCounts(choices){return Object.fromEntries(R53_NATURES.map(n=>[n,choices.filter(x=>x===n).length]));}
function enumerateNatureTuples(length){if(length<=0)return[[]];const tails=enumerateNatureTuples(length-1);return R53_NATURES.flatMap(n=>tails.map(t=>[n,...t]));}
function label(n){return n==='PHYSICS'?'Física':n==='MYSTIC'?'Mística':'Voluntad';}
function validate(e){if(e?.schema!==GENESIS_ENTRY_R53_SCHEMA||!Array.isArray(e.players))throw new Error('GEN_R53_ENTRY_INVALID');}
function stableIndex(seed,count){if(count<1)return 0;let h=2166136261>>>0;for(const ch of String(seed)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0;}return h%count;}
function shuffle(items,seed){const out=[...items];let state=stableIndex(seed,0x7fffffff)||1;const next=()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return(state>>>0)/4294967296;};for(let i=out.length-1;i>0;i--){const j=Math.floor(next()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
