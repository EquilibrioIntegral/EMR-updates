import {M_PRIMORDIAL} from '../data/primordial-module.js';
import {transferMatter,combineMatter} from './primordial-matter.js';
const clone=x=>JSON.parse(JSON.stringify(x));
const DOMAINS=['SILENCIO','ALIENTO','VOLUNTAD'];
const force=(state,domain)=>Number(state?.signature?.[domain]??0);
const entity=(state,id)=>state?.entities?.[id]??null;
const cell=e=>e?{x:e.x,y:e.y}:null;
const dist=(a,b)=>a&&b?Math.abs(a.x-b.x)+Math.abs(a.y-b.y):Infinity;

export function queryPrimordialCandidates(state,{actorEntityId=null,targetEntityId=null}={}){
 const actor=entity(state,actorEntityId), target=entity(state,targetEntityId);
 return M_PRIMORDIAL.transforms.map(t=>{
  const reasons=[]; const f=force(state,t.domain);
  if(f<t.minForce) reasons.push('FORCE_GATE');
  if(t.domain==='VOLUNTAD' && f===0) reasons.push('CONSCIOUS_CAUSALITY_FORBIDDEN');
  if(actor && actor.domain!==t.domain) reasons.push('ACTOR_DOMAIN_MISMATCH');
  if(actor&&target&&dist(cell(actor),cell(target))>2) reasons.push('SPATIAL_PRECONDITION');
  return {...clone(t),force:f,legal:reasons.length===0,rejectionReasons:reasons,actorEntityId,targetEntityId};
 });
}

export function selectPrimordialIntentions(candidates,{limit=4}={}){
 const legal=candidates.filter(x=>x.legal); if(!legal.length) return [];
 const selected=[]; const domains=new Set();
 for(const c of legal){if(!domains.has(c.domain)&&selected.length<limit){selected.push(c);domains.add(c.domain);}}
 for(const c of legal){if(selected.length>=limit)break;if(!selected.some(x=>x.id===c.id))selected.push(c);}
 return selected.map((x,i)=>({...x,intentionId:`PRI-CTX-${i+1}`}));
}

export function translatePrimordialFreeAction(state,{declaration,actorEntityId,targetEntityId=null,desiredTransform,causalDomain}={}){
 const text=String(declaration??'').trim(); if(!text) throw new Error('PRIMORDIAL_FREE_ACTION_REQUIRED');
 if(!DOMAINS.includes(causalDomain)) throw new Error('PRIMORDIAL_CAUSAL_DOMAIN_REQUIRED');
 const actor=entity(state,actorEntityId); if(!actor) throw new Error('PRIMORDIAL_ENTITY_UNKNOWN');
 if(actor.domain!==causalDomain) return {legal:false,reasons:['ACTOR_DOMAIN_MISMATCH'],declaration:text};
 if(force(state,causalDomain)<=0) return {legal:false,reasons:['FORCE_GATE'],declaration:text};
 const candidates=queryPrimordialCandidates(state,{actorEntityId,targetEntityId});
 const candidate=candidates.find(x=>x.id===desiredTransform);
 if(!candidate) return {legal:false,reasons:['TRANSFORM_UNKNOWN'],declaration:text};
 if(!candidate.legal) return {legal:false,reasons:candidate.rejectionReasons,declaration:text};
 return {legal:true,kind:'PRIMORDIAL_FREE_ACTION',declaration:text,actorEntityId,targetEntityId,causalDomain,transformId:candidate.id,force:candidate.force,physicalOperation:candidate.physicalOperation,sourceIds:[M_PRIMORDIAL.id,actorEntityId,...(targetEntityId?[targetEntityId]:[])]};
}

export function resolvePrimordialAction(state,{action,roll}){
 if(!action?.legal) throw new Error('PRIMORDIAL_LEGAL_ACTION_REQUIRED');
 if(!Number.isInteger(roll)||roll<1||roll>6) throw new Error('PRIMORDIAL_D6_REQUIRED');
 const total=roll+action.force; const outcome=total>=7?'CLEAN_SUCCESS':total>=5?'SUCCESS_WITH_COST':'FAILURE_WITH_CONSEQUENCE';
 const transform=M_PRIMORDIAL.transforms.find(x=>x.id===action.transformId); if(!transform) throw new Error('PRIMORDIAL_TRANSFORM_UNKNOWN');
 const delta={id:`DELTA-${action.transformId}-${state.turn+1}`,type:'PRIMORDIAL_TRANSFORM',transformId:transform.id,resultTag:transform.resultTag,producer:action.transformId,consumer:transform.consumer,actorEntityId:action.actorEntityId,targetEntityId:action.targetEntityId??null,outcome,roll,force:action.force,total};
 const residue=outcome==='CLEAN_SUCCESS'?null:{id:`RES-${delta.id}`,producer:delta.id,consumer:transform.consumer,status:'ACTIVE',kind:outcome==='SUCCESS_WITH_COST'?'COST':'CONSEQUENCE'};
 const trace={module:M_PRIMORDIAL.id,action:clone(action),roll,force:action.force,total,outcome,deltaId:delta.id,residueId:residue?.id??null};
 return {outcome,delta,residue,trace};
}

export function applyPrimordialResolution(state,resolution){
 const s=clone(state); s.turn+=1; s.deltas??=[]; s.residues??=[]; s.eventLog??=[]; s.history??=[];
 s.deltas.push(clone(resolution.delta)); if(resolution.residue)s.residues.push(clone(resolution.residue));
 const target=resolution.delta.targetEntityId&&s.entities[resolution.delta.targetEntityId]; if(target&&!target.tags.includes(resolution.delta.resultTag))target.tags.push(resolution.delta.resultTag);
 s.history.push({turn:s.turn,type:'PRIMORDIAL_RESOLUTION',deltaId:resolution.delta.id,outcome:resolution.outcome,sourceIds:resolution.trace.action.sourceIds});
 s.eventLog.push({id:`EV-${s.eventLog.length+1}`,turn:s.turn,type:'PRIMORDIAL_DELTA_APPLIED',payload:{deltaId:resolution.delta.id,producer:resolution.delta.producer,consumer:resolution.delta.consumer,outcome:resolution.outcome},trace:clone(resolution.trace)});
 return s;
}

// GEN-R4.3: bridge a resolved tabletop Physics decision into conserved hidden matter.
// The player chooses WHAT matter and WHERE it acts; the app performs bookkeeping.
export function applyPrimordialMatterAction(state,{resolution,reservoirIds=[],amount=null,toLocation=null,playerCauseId=null}={}){
 if(!resolution?.delta)throw new Error('PRIMORDIAL_MATTER_RESOLUTION_REQUIRED');
 if(resolution.outcome==='FAILURE_WITH_CONSEQUENCE')return clone(state);
 const transform=M_PRIMORDIAL.transforms.find(x=>x.id===resolution.delta.transformId);
 if(!transform||transform.domain!=='SILENCIO')throw new Error('PRIMORDIAL_MATTER_PHYSICS_REQUIRED');
 const s=clone(state);s.matter??={schema:'EMR_PRIMORDIAL_MATTER_FIELD_v1',reservoirs:{},eventLog:[]};s.matter.reservoirs??={};s.matter.eventLog??=[];
 const inputs=reservoirIds.map(id=>s.matter.reservoirs[id]).filter(Boolean);if(inputs.length!==reservoirIds.length||!inputs.length)throw new Error('PRIMORDIAL_MATTER_RESERVOIR_UNKNOWN');
 const actionId=resolution.delta.id;const cause=playerCauseId??resolution.delta.actorEntityId??null;
 if(transform.physicalOperation==='MOVE_TOWARD'||transform.physicalOperation==='MOVE_AWAY'){
  if(reservoirIds.length!==1)throw new Error('PRIMORDIAL_MATTER_SINGLE_SOURCE_REQUIRED');
  const source=inputs[0];const movedAmount=amount??Object.values(source.composition||{}).reduce((a,b)=>a+b,0);
  const moved=transferMatter({reservoir:source,amount:movedAmount,toLocation,actionId,playerCauseId:cause,producerId:transform.id});
  s.matter.reservoirs[source.id]=moved.remainder;s.matter.reservoirs[moved.packet.id]=moved.packet;s.matter.eventLog.push(moved.event);
  return s;
 }
 if(transform.physicalOperation==='SEPARATE_TOKENS'){
  if(reservoirIds.length!==1)throw new Error('PRIMORDIAL_MATTER_SINGLE_SOURCE_REQUIRED');
  const source=inputs[0];const movedAmount=amount??Object.values(source.composition||{}).reduce((a,b)=>a+b,0)/2;
  const moved=transferMatter({reservoir:source,amount:movedAmount,toLocation,actionId,playerCauseId:cause,producerId:transform.id});
  s.matter.reservoirs[source.id]=moved.remainder;s.matter.reservoirs[moved.packet.id]=moved.packet;s.matter.eventLog.push({...moved.event,type:'MATTER_FRACTURE'});
  return s;
 }
 if(transform.physicalOperation==='MARK_STATE'){
  for(const r of inputs){r.physicalState={...(r.physicalState||{}),thermal:'COOLED',lastCauseId:actionId};r.provenance=[...(r.provenance||[]),{type:'MATTER_COOL',actionId,producerId:transform.id,playerCauseId:cause,location:clone(r.location)}];}
  s.matter.eventLog.push({type:'MATTER_COOL',actionId,producerId:transform.id,playerCauseId:cause,reservoirIds:[...reservoirIds]});return s;
 }
 if(transform.physicalOperation==='MOVE_ORBIT'){
  for(const r of inputs){r.physicalState={...(r.physicalState||{}),orbitalRelation:'STABILIZED',lastCauseId:actionId};r.provenance=[...(r.provenance||[]),{type:'MATTER_ORBIT_STABILIZE',actionId,producerId:transform.id,playerCauseId:cause,location:clone(r.location)}];}
  s.matter.eventLog.push({type:'MATTER_ORBIT_STABILIZE',actionId,producerId:transform.id,playerCauseId:cause,reservoirIds:[...reservoirIds]});return s;
 }
 throw new Error('PRIMORDIAL_MATTER_OPERATION_UNSUPPORTED');
}

export function combinePrimordialMatterAtLocation(state,{reservoirIds,id,location,actionId,playerCauseId=null}={}){
 const s=clone(state);s.matter??={schema:'EMR_PRIMORDIAL_MATTER_FIELD_v1',reservoirs:{},eventLog:[]};
 const inputs=reservoirIds.map(x=>s.matter.reservoirs[x]).filter(Boolean);if(inputs.length!==reservoirIds.length||!inputs.length)throw new Error('PRIMORDIAL_MATTER_RESERVOIR_UNKNOWN');
 const combined=combineMatter({id,location,reservoirs:inputs,actionId,playerCauseId});for(const r of inputs)r.status='CONSUMED';s.matter.reservoirs[id]=combined;s.matter.eventLog.push({type:'MATTER_COMBINE',actionId,playerCauseId,inputReservoirIds:[...reservoirIds],outputReservoirId:id,location:clone(location)});return s;
}

export function projectPrimordialPlayerView(value,{scope='PUBLIC'}={}){
 const walk=v=>{
  if(Array.isArray(v)) return v.map(walk).filter(x=>x!==undefined);
  if(v&&typeof v==='object'){
   const visibility=v.visibility??'PUBLIC'; const gate=v.knowledgeGate??'OPEN'; const scopes=v.knowledgeScope??['PUBLIC'];
   if(visibility==='SECRET'||gate!=='OPEN'||(Array.isArray(scopes)&&!scopes.includes(scope)&&!scopes.includes('PUBLIC'))) return undefined;
   return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,walk(x)]).filter(([,x])=>x!==undefined));
  }
  return v;
 };
 return walk(clone(value));
}

export function serializePrimordialState(state){return JSON.stringify(state);}
export function deserializePrimordialState(json){const s=JSON.parse(json);if(s?.schema!=='EMR_PRIMORDIAL_GRID_v1')throw new Error('PRIMORDIAL_SAVE_SCHEMA_INVALID');return s;}
