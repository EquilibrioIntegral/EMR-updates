import {createPrimordialGrid,addPrimordialEntity,movePrimordialEntity,resolveCollectiveIntentions,getPrimordialSituation} from './primordial-grid.js';
import {translatePrimordialFreeAction} from './primordial-causal.js';
import {beginPrimordialLoop,compilePrimordialScene,resolvePrimordialScene,evaluatePrimordialProgression,compilePrimordialLegacy,savePrimordialLoop,loadPrimordialLoop} from './primordial-loop.js';
import {selectPrimordialPlanet} from './primordial-planet.js';
import {beginBoot01,commitBoot01Intentions,compileBoot01World} from './boot01-hybrid.js';
const clone=x=>JSON.parse(JSON.stringify(x));

export function createGenesisE2EFixture({seed='GENESIS-E2E',signature={SILENCIO:3,ALIENTO:1,VOLUNTAD:0},players=[{id:'P1'},{id:'P2'}]}={}){
 let s=createPrimordialGrid({signature,seed,players});
 s=addPrimordialEntity(s,{id:'GRAV',name:'Atracción',kind:'FORCE',domain:'SILENCIO',power:3,x:1,y:1});
 s=addPrimordialEntity(s,{id:'MAT',name:'Materia',kind:'BODY',domain:'SILENCIO',power:1,x:2,y:1,tags:['MATTER']});
 s=addPrimordialEntity(s,{id:'BREATH',name:'Impulso',kind:'FORCE',domain:'ALIENTO',power:1,x:3,y:2});
 return beginPrimordialLoop(s).state;
}

export function applyGenesisPhysicalMove(state,{entityId,to,actorId=null}={}){
 const s=movePrimordialEntity(state,{entityId,to,actorId,source:'GENESIS_PHYSICAL_MOVE'});
 return {state:s,situation:getPrimordialSituation(s)};
}

export function resolveGenesisCollectiveChoice(state,{votes,options,tieBreaker=null}={}){
 const result=resolveCollectiveIntentions(state,{votes,options,tieBreaker});
 return {state:clone(state),result};
}

export function applyGenesisCausalChoice(state,{declaration,actorEntityId,targetEntityId='MAT',desiredTransform,causalDomain,roll}={}){
 const action=translatePrimordialFreeAction(state,{declaration,actorEntityId,targetEntityId,desiredTransform,causalDomain});
 if(!action.legal) throw new Error(`GENESIS_CAUSAL_ACTION_ILLEGAL:${(action.reasons||[]).join(',')}`);
 const resolved=resolvePrimordialScene(state,{action,roll});
 return {...resolved,next:compilePrimordialScene(resolved.state,{actorEntityId,targetEntityId})};
}

export function chooseGenesisPlanet(state,{planetId}={}){return selectPrimordialPlanet(state,{planetId});}

export function checkpointGenesis(state,{build='HH4-GENESIS-E2E'}={}){
 const json=savePrimordialLoop(state,{build});
 return {json,state:loadPrimordialLoop(json)};
}

export function closeGenesisIntoBoot01(state,{bootIntention=1,dice=[4,3,5,4,5,4,5]}={}){
 const progress=evaluatePrimordialProgression(state);
 if(!progress.canClose) throw new Error(`GENESIS_NOT_READY_FOR_LEGACY:${progress.reasons.join(',')}`);
 const closed=compilePrimordialLegacy(state);
 const bootState={meta:{gameTime:closed.state.turn},session:{players:clone(state.players||[]),boot:{phase:'BOOT01_READY',legadoPrimordial:clone(closed.legacy),selectedPlanetId:closed.state.selectedPlanetId}},eventLog:clone(closed.state.eventLog||[])};
 beginBoot01(bootState);
 commitBoot01Intentions(bootState,[bootIntention]);
 const territory=compileBoot01World(bootState,{dice});
 return {genesisState:closed.state,legacy:closed.legacy,bootState,territory};
}
