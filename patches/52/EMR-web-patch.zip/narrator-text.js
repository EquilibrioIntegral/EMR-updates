export function prepareNarrationText(input=''){
  let text=String(input)
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ')
    .replace(/<br\s*\/?>/gi,'\n')
    .replace(/<\/p\s*>/gi,'\n\n')
    .replace(/<[^>]+>/g,' ')
    .replace(/&nbsp;/gi,' ')
    .replace(/&amp;/gi,'&')
    .replace(/&quot;/gi,'"')
    .replace(/&#39;|&apos;/gi,"'")
    .replace(/\b(?:ART|QA|DEV|BUILD|SHA|STATE|ID)[-_]?[A-Z0-9._-]+\b/g,' ')
    .replace(/[🔊🔇⏸▶■◀◆□●○]/g,' ')
    .replace(/\r\n?/g,'\n')
    .replace(/[ \t]+/g,' ')
    .replace(/\s+([,.;:!?…])/g,'$1')
    .replace(/ *\n */g,'\n')
    .replace(/\n{3,}/g,'\n\n')
    .trim();
  return text;
}

function splitLongSentence(sentence,maxChars){
  if(sentence.length<=maxChars)return [sentence];
  const clauses=sentence.match(/[^,;:—]+[,;:—]?|.+$/g)||[sentence];
  const out=[];let current='';
  for(const raw of clauses){
    const clause=raw.trim();if(!clause)continue;
    const joined=current?`${current} ${clause}`:clause;
    if(current&&joined.length>maxChars){out.push(current);current=clause;}else current=joined;
  }
  if(current)out.push(current);
  return out;
}

// RC46+: one linguistic sentence per synthesis unit. Long sentences are only
// split on natural clause boundaries so playback can pipeline without robotic cuts.
export function chunkNarrationText(input,maxChars=180){
  const text=prepareNarrationText(input);
  if(!text)return [];
  const chunks=[];
  for(const paragraph of text.split(/\n{2,}/).filter(Boolean)){
    const sentences=paragraph.match(/[^.!?…]+[.!?…]+(?:[”’"']+)?|[^.!?…]+$/g)||[paragraph];
    for(const raw of sentences){
      const sentence=raw.trim();if(!sentence)continue;
      chunks.push(...splitLongSentence(sentence,maxChars));
    }
  }
  return chunks;
}
