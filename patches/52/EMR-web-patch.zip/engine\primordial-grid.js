// BOOT-00 / CI-03 primordial physical-grid minigame.
// The app remembers the board; the table materializes it.

const KINDS = new Set(['FORCE','AGENCY','MATTER','BODY','PHENOMENON']);
const DOMAINS = new Set(['SILENCIO','ALIENTO','VOLUNTAD']);

const clone = (x) => JSON.parse(JSON.stringify(x));
const key = (x,y) => `${x},${y}`;
const inGrid = (s,x,y) => Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<s.board.width&&y<s.board.height;

export function createPrimordialGrid({width=6,height=6,signature,seed='EMR-BOOT00',players=[]}={}) {
  if (!signature || ['SILENCIO','ALIENTO','VOLUNTAD'].some(k => !Number.isInteger(signature[k]) || signature[k] < 0)) throw new Error('PRIMORDIAL_SIGNATURE_REQUIRED');
  if (width<4 || height<4) throw new Error('PRIMORDIAL_GRID_TOO_SMALL');
  return {
    schema:'EMR_PRIMORDIAL_GRID_v1', seed, phase:'PRIMORDIAL_PLAY', turn:0,
    signature:clone(signature), board:{width,height,cells:{}}, entities:{}, players:clone(players),
    history:[], facts:[], residues:[], threads:[], promises:[], consumables:[], eventLog:[]
  };
}

export function addPrimordialEntity(state, entity) {
  const s=clone(state);
  if (!entity?.id || s.entities[entity.id]) throw new Error('PRIMORDIAL_ENTITY_ID_INVALID');
  if (!KINDS.has(entity.kind) || !DOMAINS.has(entity.domain)) throw new Error('PRIMORDIAL_ENTITY_TYPE_INVALID');
  if (!inGrid(s,entity.x,entity.y)) throw new Error('PRIMORDIAL_POSITION_INVALID');
  s.entities[entity.id]={id:entity.id,name:entity.name||null,kind:entity.kind,domain:entity.domain,power:entity.power??1,x:entity.x,y:entity.y,controller:entity.controller??null,tags:[...(entity.tags||[])],memory:[]};
  syncCells(s); log(s,'ENTITY_ENTERED',{entityId:entity.id,to:{x:entity.x,y:entity.y}}); return s;
}

export function namePrimordialEntity(state,{entityId,name}) {
  const s=clone(state), e=s.entities[entityId]; if(!e) throw new Error('PRIMORDIAL_ENTITY_UNKNOWN');
  if(typeof name!=='string'||!name.trim()) throw new Error('PRIMORDIAL_NAME_REQUIRED');
  e.name=name.trim(); log(s,'ENTITY_NAMED',{entityId,name:e.name}); return s;
}

export function movePrimordialEntity(state,{entityId,to,actorId=null,source='FREE_ACTION'}) {
  const s=clone(state), e=s.entities[entityId]; if(!e) throw new Error('PRIMORDIAL_ENTITY_UNKNOWN');
  if(!inGrid(s,to?.x,to?.y)) throw new Error('PRIMORDIAL_POSITION_INVALID');
  const distance=Math.abs(e.x-to.x)+Math.abs(e.y-to.y); if(distance!==1) throw new Error('PRIMORDIAL_MOVE_NOT_ADJACENT');
  const from={x:e.x,y:e.y}; e.x=to.x;e.y=to.y;s.turn+=1;
  e.memory.push({turn:s.turn,type:'MOVE',from,to:clone(to),actorId,source});
  syncCells(s); log(s,'ENTITY_MOVED',{entityId,from,to:clone(to),actorId,source});
  return resolveCellEncounters(s,to.x,to.y);
}

export function resolveCollectiveIntentions(state,{votes,options,tieBreaker=null}) {
  if(!Array.isArray(options)||options.length<2) throw new Error('PRIMORDIAL_INTENTION_OPTIONS_REQUIRED');
  const legal=new Set(options.map(o=>o.id)); const counts={};
  for(const v of votes||[]){if(!legal.has(v.optionId)) throw new Error('PRIMORDIAL_INTENTION_ILLEGAL'); counts[v.optionId]=(counts[v.optionId]||0)+1;}
  const max=Math.max(0,...Object.values(counts)); const tied=options.filter(o=>(counts[o.id]||0)===max).map(o=>o.id);
  let winner=tied[0]??null;
  if(tied.length>1){ if(!tieBreaker || !tied.includes(tieBreaker)) return {status:'TIE',tied,counts}; winner=tieBreaker; }
  return {status:'RESOLVED',winner,counts,tied:tied.length>1?tied:[]};
}

export function applyPrimordialDecision(state,{decisionId,actorIds=[],action,causalSourceIds=[]}) {
  if(!decisionId || !action?.type || !causalSourceIds.length) throw new Error('PRIMORDIAL_CAUSAL_PROVENANCE_REQUIRED');
  let s=clone(state);
  if(action.type==='MOVE') s=movePrimordialEntity(s,{entityId:action.entityId,to:action.to,actorId:actorIds.join('+')||null,source:decisionId});
  else if(action.type==='NAME') s=namePrimordialEntity(s,{entityId:action.entityId,name:action.name});
  else if(action.type==='WAIT'){s.turn+=1;log(s,'PRIMORDIAL_WAIT',{decisionId,actorIds});}
  else throw new Error('PRIMORDIAL_ACTION_UNSUPPORTED');
  s.history.push({turn:s.turn,decisionId,actorIds:[...actorIds],action:clone(action),causalSourceIds:[...causalSourceIds]});
  return s;
}

export function getPrimordialSituation(state) {
  const s=state, occupied=Object.values(s.board.cells).filter(ids=>ids.length>1);
  const tensions=occupied.map(ids=>({cell:cellOf(s.entities[ids[0]]),entities:ids,domains:[...new Set(ids.map(id=>s.entities[id].domain))]}));
  const namedAgencies=Object.values(s.entities).filter(e=>e.kind==='AGENCY'&&e.name).map(e=>({id:e.id,name:e.name,domain:e.domain,cell:cellOf(e)}));
  return {turn:s.turn,signature:clone(s.signature),tensions,namedAgencies,recentHistory:clone(s.history.slice(-5)),publicFacts:clone(s.facts.filter(f=>f.visibility!=='SECRET'))};
}

export function closePrimordialGrid(state,{focusBodyId}) {
  const s=clone(state), body=s.entities[focusBodyId]; if(!body||body.kind!=='BODY') throw new Error('PRIMORDIAL_FOCUS_BODY_REQUIRED');
  const legacy={id:`LEGADO-PRIMORDIAL-${s.seed}`,producer:'BOOT00_PRIMORDIAL_GRID',signature:clone(s.signature),focusBody:{id:body.id,name:body.name,cell:cellOf(body),tags:[...body.tags]},facts:clone(s.facts),residues:clone(s.residues),threads:clone(s.threads),promises:clone(s.promises),historyDigest:clone(s.history),consumer:'BOOT01_FORMACION_MUNDO'};
  s.phase='PRIMORDIAL_CLOSED'; s.consumables.push(legacy); log(s,'PRIMORDIAL_LEGACY_CREATED',{legacyId:legacy.id,consumer:legacy.consumer}); return {state:s,legacy};
}

function resolveCellEncounters(s,x,y){
  const ids=Object.values(s.entities).filter(e=>e.x===x&&e.y===y).map(e=>e.id); if(ids.length<2)return s;
  const entities=ids.map(id=>s.entities[id]); const domains=[...new Set(entities.map(e=>e.domain))];
  const fact={id:`PF-${s.eventLog.length+1}`,turn:s.turn,type:domains.length>1?'PRIMORDIAL_CONFLICT':'PRIMORDIAL_CONVERGENCE',cell:{x,y},participants:ids,domains,visibility:'PUBLIC',producerEvent:`EV-${s.eventLog.length+1}`};
  s.facts.push(fact);
  if(domains.length>1)s.residues.push({id:`RES-${s.residues.length+1}`,producer:fact.id,cell:{x,y},domains,consumer:'GUIONISTA_OR_LATER_BOOT',status:'ACTIVE'});
  log(s,fact.type,{factId:fact.id,participants:ids,cell:{x,y},domains}); return s;
}
function syncCells(s){s.board.cells={};for(const e of Object.values(s.entities)){const k=key(e.x,e.y);(s.board.cells[k]??=[]).push(e.id);}}
function log(s,type,payload){s.eventLog.push({id:`EV-${s.eventLog.length+1}`,turn:s.turn,type,payload:clone(payload)});}
function cellOf(e){return {x:e.x,y:e.y};}
