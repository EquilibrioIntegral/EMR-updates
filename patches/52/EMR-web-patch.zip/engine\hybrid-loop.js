import { availableTiles, materializeTile, returnTileToLibrary, reconstructLocation, makePlacementInstruction } from './map.js';

export function configurePlayers(engine, players=[]) {
  if (!Array.isArray(players) || players.length < 1 || players.length > 4) throw new Error('PLAYER_COUNT_INVALID');
  const normalized=players.map((p,i)=>({id:`J${i+1}`,name:String(p?.name ?? p ?? `Jugador ${i+1}`).trim() || `Jugador ${i+1}`}));
  engine.state.session ??= {players:[],physicalResults:[],pendingPhysicalResolution:null};
  engine.state.session.players=normalized;
  engine.log('HYB_SESSION_PLAYERS',{playerCount:normalized.length,playerRefs:normalized.map(x=>x.id)});
  return normalized;
}

export function getNarrativeLocationBinding(engine, locationId) {
  const entity=engine.state.entities?.[locationId];
  if (!entity || entity.ENTITY_TYPE!=='LOCATION') throw new Error(`HYB_LOCATION_UNKNOWN:${locationId}`);
  const binding=entity.SPATIAL_BINDING;
  if (!binding?.scale) return {ok:false,reason:'LOCATION_SPATIAL_BINDING_MISSING',locationId};
  return {ok:true,locationId,locationName:entity.ATTRIBUTES?.name ?? locationId,...binding};
}

export function materializePhysicalLocation(engine,catalog,{locationId,scale='U',families=[],rotation=null,orientationCount=4,anchor=null}={}) {
  const candidates=availableTiles(catalog,engine.state.mapState,{scale,families});
  if (!candidates.length) {
    engine.log('HYB_PHYSICAL_ZERO',{kind:'TILE',locationId,scale,families});
    return {ok:false,reason:'NO_PHYSICAL_TILE_AVAILABLE'};
  }
  const ordered=[...candidates].sort((a,b)=>a.id.localeCompare(b.id));
  const tile=ordered.length===1 ? ordered[0] : ordered[Math.floor(engine.rng.next()*ordered.length)];
  const resolvedRotation=rotation == null ? Math.floor(engine.rng.next()*orientationCount) : rotation;
  const instruction=makePlacementInstruction(tile,{locationId,rotation:resolvedRotation,orientationCount,anchor});
  const placement=materializeTile(engine.state.mapState,tile,{locationId,rotation:instruction.rotation,orientationCount:instruction.orientationCount,anchor,visibleFacts:{}});
  engine.log('HYB_PHYSICAL_MATERIALIZE',{kind:'TILE',tileId:tile.id,locationId,placementId:placement.placementId,rotation:placement.rotation,orientationCount});
  return {ok:true,instruction,placement};
}

// Canonical bridge: narrative LOCATION identity is the authority; R/U/I is its physical representation.
export function materializeNarrativeLocation(engine,catalog,locationId,{rotation=null}={}) {
  const binding=getNarrativeLocationBinding(engine,locationId);
  if (!binding.ok) { engine.log('HYB_LOCATION_BINDING_ZERO',{locationId,reason:binding.reason}); return binding; }
  const out=materializePhysicalLocation(engine,catalog,{
    locationId,
    scale:binding.scale,
    families:binding.families ?? [],
    rotation,
    orientationCount:binding.orientationCount ?? 4,
    anchor:binding.anchor ?? null
  });
  if (out.ok) {
    out.instruction.locationName=binding.locationName;
    out.instruction.playerText=`Busca ${out.instruction.tileId} en la Biblioteca y materializa ${binding.locationName}.`;
    engine.log('HYB_LOCATION_BOUND',{locationId,locationName:binding.locationName,tileId:out.instruction.tileId,scale:binding.scale});
  }
  return out;
}

export function returnPhysicalPlacement(engine,placementId) {
  const placement=returnTileToLibrary(engine.state.mapState,placementId);
  engine.log('HYB_PHYSICAL_RETURN',{kind:'TILE',tileId:placement.tileId,locationId:placement.locationId,placementId});
  return placement;
}

export function reconstructPhysicalLocation(engine,catalog,locationId) {
  const result=reconstructLocation(engine.state.mapState,catalog,locationId);
  engine.log('HYB_PHYSICAL_RECONSTRUCT',{locationId,ok:result.ok,reason:result.reason ?? null,tileId:result.instruction?.tileId ?? null});
  return result;
}

export function recordTableResult(engine,{kind,code,sceneId=null,componentRefs=[]}={}) {
  if (!kind || !code) throw new Error('TABLE_RESULT_INVALID');
  engine.state.session ??= {players:[],physicalResults:[],pendingPhysicalResolution:null};
  const record={id:`PHY-${String(engine.state.session.physicalResults.length+1).padStart(4,'0')}`,kind:String(kind),code:String(code),sceneId,componentRefs:[...componentRefs],gameTime:engine.state.meta.gameTime,turn:engine.state.meta.turn};
  engine.state.session.physicalResults.push(record);
  engine.log('HYB_TABLE_RESULT',{resultId:record.id,kind:record.kind,code:record.code,sceneId,componentRefs:record.componentRefs});
  return record;
}

export function requestPhysicalResolution(engine, contracts, contractId, context={}) {
  const contract=(contracts?.contracts ?? []).find(x=>x.id===contractId);
  if (!contract) throw new Error(`PHYSICAL_CONTRACT_UNKNOWN:${contractId}`);
  if (engine.state.session?.pendingPhysicalResolution) throw new Error('PHYSICAL_RESOLUTION_ALREADY_PENDING');
  const request={
    requestId:`PR-${String((engine.state.session?.physicalResults?.length ?? 0)+1).padStart(4,'0')}`,
    contractId,
    kind:contract.kind,
    prompt:contract.prompt,
    allowedResults:contract.results.map(x=>({code:x.code,label:x.label})),
    componentRefs:[...(context.componentRefs ?? contract.componentRefs ?? [])],
    sceneId:context.sceneId ?? null
  };
  engine.state.session ??= {players:[],physicalResults:[],pendingPhysicalResolution:null};
  engine.state.session.pendingPhysicalResolution=request;
  engine.log('HYB_PHYSICAL_RESOLUTION_REQUEST',{requestId:request.requestId,contractId,kind:request.kind,sceneId:request.sceneId,componentRefs:request.componentRefs});
  return structuredClone(request);
}

export function submitPhysicalResolution(engine, contracts, resultCode) {
  const pending=engine.state.session?.pendingPhysicalResolution;
  if (!pending) throw new Error('PHYSICAL_RESOLUTION_NOT_PENDING');
  const contract=(contracts?.contracts ?? []).find(x=>x.id===pending.contractId);
  if (!contract) throw new Error(`PHYSICAL_CONTRACT_UNKNOWN:${pending.contractId}`);
  const result=contract.results.find(x=>x.code===resultCode);
  if (!result) throw new Error(`PHYSICAL_RESULT_INVALID:${resultCode}`);
  const record=recordTableResult(engine,{kind:pending.kind,code:result.code,sceneId:pending.sceneId,componentRefs:pending.componentRefs});
  engine.state.session.pendingPhysicalResolution=null;
  engine.log('HYB_PHYSICAL_RESOLUTION_ACCEPTED',{requestId:pending.requestId,resultId:record.id,contractId:pending.contractId,resultCode:result.code});
  return {record,result};
}
