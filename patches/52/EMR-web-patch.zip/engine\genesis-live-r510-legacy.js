import {applyInvisibleWorldOptionR512} from './genesis-invisible-world-r512.js';
import {createGenesisRuntimeR5,runtimeAgencyR5,applyRuntimeAgencyActionR5,recordVolitionDecreeR5,lawOriginGateR5,establishLawOriginR5,establishVolitionRelationR5,advanceRuntimeEpochR5,selectRuntimePlanetR5,closeGenesisRuntimeR5} from './genesis-runtime-r5.js';
import {assignIntentionDecks,intentionSetupInstruction} from './intention-decks.js';
import {revealMatterHint} from './genesis-material-r5.js';
import {GENESIS_R5_REFERENCE_CONFIG} from '../data/genesis-r5-reference.js';
import {planSharedSecretDecision,finalizeSharedSecretDecision} from './shared-secret-decision.js';
import {composeGenesisSharedDecisionR58} from './genesis-guionista.js';
import {expandSoloAutonomousParticipantsR59,humanParticipantsR59,assignPeripheralSpawnsR59,chooseAutonomousAgencyOptionR59,commitAutonomousIntentionsR59} from './genesis-autonomous-agencies-r59.js';
import {GENESIS_SPATIAL_R510_DECISION,GENESIS_AGENCY_MOVEMENT_R510,reachableAgencyCellsR510,validateAgencyRepositionR510,classifyAgencyPresenceR510} from './genesis-spatial-policy-r510.js';

export const GENESIS_LIVE_R5_SCHEMA='EMR_GENESIS_LIVE_R5_v1';
export const GENESIS_SHARED_R58_SCHEMA='EMR_GENESIS_SHARED_RESOLUTION_R58_v1';
const clone=x=>structuredClone(x);

export function createGenesisLiveR5({entryResult,seed='EMR',players=[],config=GENESIS_R5_REFERENCE_CONFIG}={}){
 if(!entryResult?.signature||!Array.isArray(entryResult.natures))throw new Error('GEN_LIVE_R5_ENTRY_REQUIRED');
 if(players.length!==entryResult.natures.length)throw new Error('GEN_LIVE_R5_PLAYER_COUNT_MISMATCH');
 const participants=expandSoloAutonomousParticipantsR59({entryResult,humanPlayers:players});
 const playerIds=participants.map((p,i)=>p.id||`P${i+1}`),names=participants.map((p,i)=>p.name||`Jugador ${i+1}`),agencyNatures=participants.map(p=>p.nature);
 const runtime=createGenesisRuntimeR5({choices:entryResult.natures,signatureRolls:entryResult.rolls||{},seed,boardPreset:config.boardPreset,matterCount:config.matterCount,playerIds,agencyNatures});
 if(JSON.stringify(runtime.signatureRecord.signature)!==JSON.stringify(entryResult.signature))throw new Error('GEN_LIVE_R5_SIGNATURE_DRIFT');
 const decks=assignIntentionDecks(names);
 const livePlayers=participants.map((p,i)=>({id:playerIds[i],name:names[i],nature:p.nature,controller:p.controller||'HUMAN',simulated:p.simulated===true,source:p.source||'PRIMORDIAL_CHOICE',secondaryIntensity:p.secondaryIntensity??null,deck:decks[i],position:null,lastRepositionRound:0}));
 const spawnPlan=assignPeripheralSpawnsR59(runtime.cosmogony.board,livePlayers,seed);
 for(const p of livePlayers){const s=spawnPlan.assignments.find(x=>x.participantId===p.id);p.spawn=s?clone(s):null;p.position=s?.cell||null;}
 const opening='Antes de que exista un mundo, ya existen causas. La mesa representará aquello que puede tocarse; la app conservará lo que todavía no debe verse. Vuestras decisiones —y, en solitario, las de las fuerzas autónomas que hayan despertado— convertirán posibilidad en historia.';
 const gaps=clone(runtime.ontologyAnalysis.gaps||[]).filter(g=>g.id!=='GAP-GEN-R59-MOVEMENT-RANGE');
 return{schema:GENESIS_LIVE_R5_SCHEMA,version:'R5.10-dev031',seed:String(seed),referenceConfig:clone(config),runtime,players:livePlayers,spawnPlan,spatialPolicy:{decisionId:GENESIS_SPATIAL_R510_DECISION,movementLimit:GENESIS_AGENCY_MOVEMENT_R510,movementScalesWithIntensity:false,remoteRequiresConcreteCapability:true},phase:'SETUP',round:1,actorIndex:0,pendingAgencyActions:[],contextual:null,revealedSelections:null,jointPlan:null,jointTestResults:{},lastJointResolution:null,lastMaterialization:[],afterMaterializationPhase:null,currentNarrative:opening,narrativeLog:[{round:0,kind:'OPENING',publicText:opening}],history:[{type:'GEN_LIVE_R5_CREATED',seed:String(seed),signature:clone(entryResult.signature),participants:livePlayers.map(p=>({id:p.id,nature:p.nature,controller:p.controller,spawn:p.spawn?.cell||null,position:p.position})),boardPreset:config.boardPreset,matterCount:config.matterCount,spatialDecisionId:GENESIS_SPATIAL_R510_DECISION}],openDesignGaps:gaps};
}

export function setupProjectionR5(live){
 validate(live);const c=live.runtime.cosmogony;
 const humanSetup=humanParticipantsR59(live.players).map(p=>intentionSetupInstruction(p.deck));
 const meeples=live.players.map(p=>`Coloca el peón ${p.deck.colorName} de ${p.name} (${natureLabel(p.nature)}${p.controller==='APP'?' · control app':''}) en ${p.position||p.spawn?.cell||'su slot periférico asignado'}.`);
 return{narrative:live.currentNarrative||null,board:{preset:c.board.id||live.referenceConfig.boardPreset,cellCount:c.board.cells.length,canonicalFinal:false},matter:c.matter.parcels.map(p=>({id:p.id,cell:p.cell,label:p.public.label,traits:[...p.public.traits]})),players:live.players.map(p=>({id:p.id,name:p.name,nature:p.nature,controller:p.controller,color:p.deck.colorName,intentionDeck:p.controller==='HUMAN'?p.deck.code:null,spawn:p.spawn?.cell||null,position:p.position||p.spawn?.cell||null})),instructions:[...humanSetup,...meeples,...c.matter.parcels.map(p=>`Coloca ${p.id} en ${p.cell}.`)],movement:{limit:GENESIS_AGENCY_MOVEMENT_R510,sameForHumanAndApp:true,scalesWithIntensity:false},warning:'A60/10 continúa como geometría/BOM candidata. Regla espacial canónica R5.10: cada agencia puede reposicionarse hasta 2 celdas antes de actuar; la intensidad no aumenta su velocidad y el alcance remoto requiere una capacidad concreta.'};
}

export function confirmLiveSetupR5(live){
 validate(live);if(live.phase!=='SETUP')throw new Error('GEN_LIVE_R5_PHASE');const n=clone(live),mode=n.runtime.ontologyAnalysis.lawMode;
 narrate(n,'SETUP_READY','La materia primordial y las agencias ya ocupan la mesa. Antes de cada acción, cada peón puede reposicionarse hasta dos celdas. Las fuerzas autónomas, si existen, deciden en la app y se materializan con la misma regla espacial que las humanas.');
 if(mode==='LAW_ORIGIN_GATE'){n.phase='LAW_ORIGIN_GATE';n.history.push({type:'GEN_LIVE_R5_LAW_ORIGIN_GATE_OPENED',decisionId:'D-GEN-R5.4-LAW-ORIGIN-GATE01'});return n;}
 if(mode==='VOLITION_DECREED'){n.phase='ONTOLOGY_GATE';return n;}
 n.phase='AGENCY_ACTIONS';return n;
}

export function liveLawOriginGateR5(live){validate(live);if(live.phase!=='LAW_ORIGIN_GATE')return null;return lawOriginGateR5(live.runtime);}

export function establishLiveLawOriginR5(live,{mode,playerId=null}={}){
 validate(live);if(live.phase!=='LAW_ORIGIN_GATE')throw new Error('GEN_LIVE_R5_LAW_ORIGIN_PHASE');const n=clone(live);n.runtime=establishLawOriginR5(n.runtime,{mode,playerId});n.phase='AGENCY_ACTIONS';n.history.push({type:'GEN_LIVE_R5_LAW_ORIGIN_ESTABLISHED',mode,playerId,producerIds:[...(n.runtime.lawOriginResolution?.producerIds||[])]});narrate(n,'LAW_ORIGIN',mode==='MYSTIC_DERIVED'?'El orden material nace del sustrato místico. La decisión queda en la verdad del mundo y podrá ser interpretada de formas distintas mucho después.':mode==='VOLITION_DECREED'?'Una Voluntad impone las primeras regularidades de la materia. No crea todavía religión ni moral: crea una causa objetiva que el mundo recordará.':'Mística y Voluntad coproducen las regularidades materiales bajo límites concretos. Esa cooperación no concede dominio universal sobre la Mística.');return n;
}

export function liveOntologyGateR5(live){
 validate(live);if(live.phase!=='ONTOLOGY_GATE')return null;
 const candidates=live.players.map(p=>runtimeAgencyR5(live.runtime,p.id)).filter(a=>a.nature==='WILL'&&a.volitionActions.some(x=>x.id==='DECREE_LAW'));
 return{reason:'MATERIAL_REGULARITIES_REQUIRE_PRODUCER',candidates:candidates.map(a=>({playerId:a.playerId,agencyId:a.id,volitionEntityId:a.volitionEntityId,action:'DECREE_LAW'}))};
}

export function decreeMaterialRegularitiesLiveR5(live,playerId){
 validate(live);if(live.phase!=='ONTOLOGY_GATE')throw new Error('GEN_LIVE_R5_ONTOLOGY_PHASE');const gate=liveOntologyGateR5(live);if(!gate?.candidates.some(x=>x.playerId===playerId))throw new Error('GEN_LIVE_R5_DECREE_PLAYER_ILLEGAL');const n=clone(live);n.runtime=recordVolitionDecreeR5(n.runtime,{playerId,decreeId:'STABLE_MATERIAL_REGULARITIES'});n.phase='AGENCY_ACTIONS';n.history.push({type:'GEN_LIVE_R5_MATERIAL_LAWS_ESTABLISHED',playerId});narrate(n,'LAW_DECREE','Por primera vez la materia puede seguir regularidades estables. La Voluntad que las produjo queda registrada como causa, no como dueña automática de todo lo que nazca después.');return n;
}

export function currentLiveAgencyR5(live){validate(live);if(live.phase!=='AGENCY_ACTIONS')return null;const p=live.players[live.actorIndex];return p?runtimeAgencyR5(live.runtime,p.id):null;}
export function agencyNeedsRepositionR510(live){validate(live);if(live.phase!=='AGENCY_ACTIONS')return false;const p=live.players[live.actorIndex];return !!p&&Number(p.lastRepositionRound||0)!==Number(live.round);}
export function liveAgencyMovementR510(live){
 validate(live);if(live.phase!=='AGENCY_ACTIONS')throw new Error('GEN_LIVE_R510_MOVEMENT_PHASE');const p=live.players[live.actorIndex],board=live.runtime.cosmogony.board,from=p.position||p.spawn?.cell;if(!from)throw new Error('GEN_LIVE_R510_POSITION_REQUIRED');
 return{decisionId:GENESIS_SPATIAL_R510_DECISION,playerId:p.id,controller:p.controller,from,movementLimit:GENESIS_AGENCY_MOVEMENT_R510,destinations:reachableAgencyCellsR510(board,from)};
}
export function repositionLiveAgencyR510(live,to){
 validate(live);if(live.phase!=='AGENCY_ACTIONS')throw new Error('GEN_LIVE_R510_MOVEMENT_PHASE');const n=clone(live),p=n.players[n.actorIndex],board=n.runtime.cosmogony.board,from=p.position||p.spawn?.cell,move=validateAgencyRepositionR510({board,from,to});p.position=to;p.lastRepositionRound=n.round;n.history.push({type:'GEN_LIVE_R510_AGENCY_REPOSITION',round:n.round,playerId:p.id,controller:p.controller,nature:p.nature,from,to,distance:move.distance,movementLimit:GENESIS_AGENCY_MOVEMENT_R510,decisionId:GENESIS_SPATIAL_R510_DECISION});return n;
}

export function liveAgencyOptionsR5(live){
 const agency=currentLiveAgencyR5(live);if(!agency)return[];const p=live.players[live.actorIndex],position=p.position||p.spawn?.cell;if(!position)return[];return agencyOptionsAtPositionR510(live,agency,position);
}

export function simulatedAgencyDecisionR59(live){
 validate(live);if(live.phase!=='AGENCY_ACTIONS')return null;const p=live.players[live.actorIndex];if(!p||p.controller!=='APP')return null;
 if(!agencyNeedsRepositionR510(live)){const option=chooseAutonomousAgencyOptionR59(live,liveAgencyOptionsR5(live));return{playerId:p.id,playerName:p.name,nature:p.nature,option:clone(option),controller:'APP',movement:{from:p.position,to:p.position,distance:0,limit:GENESIS_AGENCY_MOVEMENT_R510},spatialDecisionId:GENESIS_SPATIAL_R510_DECISION};}
 const plans=simulatedAgencyPlansR510(live),chosen=chooseAutonomousAgencyOptionR59(live,plans);return{playerId:p.id,playerName:p.name,nature:p.nature,option:clone(chosen),controller:'APP',movement:{from:p.position||p.spawn?.cell,to:chosen.moveTo,distance:chosen.movementDistance,limit:GENESIS_AGENCY_MOVEMENT_R510},spatialDecisionId:GENESIS_SPATIAL_R510_DECISION};
}

export function applyLiveAgencyOptionR5(live,optionId){
 validate(live);if(live.phase!=='AGENCY_ACTIONS')throw new Error('GEN_LIVE_R5_ACTION_PHASE');
 const planned=simulatedAgencyPlansR510(live).find(x=>x.id===optionId);if(planned){const moved=repositionLiveAgencyR510(live,planned.moveTo);return applyLiveAgencyOptionR5(moved,planned.originalOptionId);}
 let working=live;
 if(agencyNeedsRepositionR510(working))working=autoRepositionForRequestedOptionR510(working,optionId);
 const options=liveAgencyOptionsR5(working),o=options.find(x=>x.id===optionId);if(!o)throw new Error('GEN_LIVE_R5_ACTION_ILLEGAL');const n=clone(working),player=n.players[n.actorIndex],agency=runtimeAgencyR5(n.runtime,player.id);
 n.pendingAgencyActions??=[];
 if(o.kind!=='WAIT')n.pendingAgencyActions.push({seq:n.pendingAgencyActions.length,round:n.round,playerId:player.id,controller:player.controller,agencyId:agency.id,nature:agency.nature,intensity:agency.universeIntensity,optionId:o.id,kind:o.kind,targetId:o.targetId,otherId:o.otherId||null,principle:o.principle||null,agencyPosition:player.position,spatial:clone(o.spatial||null),spatialDecisionId:GENESIS_SPATIAL_R510_DECISION});
 n.history.push({type:'GEN_LIVE_R5_AGENCY_CHOICE',round:n.round,playerId:player.id,controller:player.controller,optionId:o.id,agencyPosition:player.position,spatial:clone(o.spatial||null),spatialDecisionId:GENESIS_SPATIAL_R510_DECISION});
 narrate(n,'AGENCY_CHOICE',o.kind==='WAIT'?`${player.name} decide no intervenir. La omisión no borra la causalidad ya existente: el universo seguirá avanzando.`:`${player.controller==='APP'?'La app hace actuar a':'El jugador hace actuar a'} ${agency.nature==='PHYSICS'?'una fuerza física':agency.nature==='MYSTIC'?'un principio místico':'una Voluntad'} (${player.name}): ${o.label}. La posición del peón delimita lo que esta autoridad puede alcanzar; la app conserva magnitudes, procedencia y consecuencias ocultas.`);
 n.actorIndex++;
 if(n.actorIndex>=n.players.length){n.actorIndex=0;applyPendingAgencyBatchR53(n);n.contextual=compileLiveContextualIntentionsR5(n);n.phase='PHYSICAL_INTENTION_CHOICE';narrate(n,'JOINT_INTENTION_FRAME',n.contextual.narrative.publicText);}
 return n;
}

export function compileLiveContextualIntentionsR5(live){
 validate(live);const frame=composeGenesisSharedDecisionR58(live),opts=frame.options.slice(0,4).map((o,i)=>{
  const option={...clone(o),slot:i+1};
  if(['PRESERVE_BEST','PROTECT_BEST'].includes(option.effect)&&option.resolution)option.resolution.effectKey='PRESERVE_FOR_WORLD';
  return option;
 });
 const contextual={schema:'EMR_GENESIS_CONTEXTUAL_INTENTIONS_R5_v4',guionistaSchema:frame.schema,decisionId:frame.decisionId,actionZone:frame.actionZone,round:live.round,narrative:clone(frame.narrative),truthContract:clone(frame.truthContract),consumerContract:clone(frame.consumerContract),options:opts,noIntervene:{slot:'N',...clone(frame.noIntervene)},players:live.players.map(p=>({playerId:p.id,controller:p.controller,deckCode:p.controller==='HUMAN'?p.deck.code:null,cards:p.controller==='HUMAN'?opts.map(o=>({slot:o.slot,cardCode:`${p.deck.code}-${o.slot}`,actionId:o.id})).concat([{slot:'N',cardCode:`${p.deck.code}-N`,actionId:'JOINT-NO-INTERVENE'}]):[]}))};
 contextual.simulatedCommitments=commitAutonomousIntentionsR59(live,contextual);
 return contextual;
}

/** Human cards stay hidden physically; app-controlled intentions are committed internally before reveal. */
export function recordRevealedLiveIntentionsR5(live,selections=[]){
 validate(live);if(live.phase!=='PHYSICAL_INTENTION_CHOICE')throw new Error('GEN_LIVE_R5_INTENTION_PHASE');
 const humans=humanParticipantsR59(live.players),fullInput=selections.length===live.players.length,humanInput=selections.length===humans.length;if(!fullInput&&!humanInput)throw new Error('GEN_LIVE_R5_INTENTIONS_INCOMPLETE');
 const legal=new Set([...live.contextual.options.map(o=>String(o.slot)),'N']);let normalized=[];
 if(fullInput)normalized=selections.map((x,i)=>({playerId:live.players[i].id,slot:String(x).toUpperCase()==='N'?'N':String(Number(x))}));
 else{
  let hi=0;normalized=live.players.map(p=>{const x=p.controller==='APP'?live.contextual.simulatedCommitments?.[p.id]:selections[hi++];return{playerId:p.id,slot:String(x).toUpperCase()==='N'?'N':String(Number(x))};});
 }
 if(normalized.some(x=>!legal.has(x.slot)))throw new Error('GEN_LIVE_R5_INTENTION_ILLEGAL');const n=clone(live);n.revealedSelections=normalized;n.jointPlan=buildSharedPlanR58(n);n.jointTestResults={};n.phase='JOINT_RESOLUTION';n.history.push({type:'GEN_LIVE_R59_INTENTIONS_REVEALED',round:n.round,simulatedPlayerIds:n.players.filter(p=>p.controller==='APP').map(p=>p.id)});narrate(n,'INTENTIONS_REVEALED','Las cartas humanas se revelan y, en ese mismo momento, la app revela las Intenciones que ya había comprometido para sus agencias autónomas. No se cuentan votos ni se busca una mayoría: el perfil completo se convierte en causa.');return n;
}

export function previewSharedDecisionR58(live){
 validate(live);if(live.phase!=='JOINT_RESOLUTION')throw new Error('GEN_LIVE_R5_JOINT_PHASE');const plan=live.jointPlan||buildSharedPlanR58(live),auto=authorityAutoResultsR58(live,plan),testResults={...clone(live.jointTestResults||{}),...auto},finalized=finalizeSharedSecretDecision({plan,testResults});
 return{schema:GENESIS_SHARED_R58_SCHEMA,decisionId:plan.decisionId,plan:clone(plan),testResults,requiredTests:finalized.tests.filter(x=>!x.resolved).map(x=>clone(x.test)),resolvedTests:finalized.tests.filter(x=>x.resolved).map(x=>({test:clone(x.test),result:clone(x.result)})),finalized,majorityWinner:null,ready:finalized.ready};
}

export function recordSharedConflictTestR58(live,testId,rollsByOption={}){
 const preview=previewSharedDecisionR58(live),test=preview.requiredTests.find(t=>t.id===testId);if(!test)throw new Error('GEN_LIVE_R58_TEST_UNKNOWN');if(!['CONFLICT','COVERT_COMPETITION'].includes(test.kind))throw new Error('GEN_LIVE_R58_TEST_KIND_UNSUPPORTED');
 const contenders=[...new Map((test.contenders||[]).map(c=>[c.optionId,c])).values()].filter(c=>c.optionId);if(contenders.length<2)throw new Error('GEN_LIVE_R58_TEST_CONTENDERS_INVALID');
 const rolls={};for(const c of contenders){const d=Number(rollsByOption[c.optionId]);if(!Number.isInteger(d)||d<1||d>6)throw new Error('GEN_LIVE_R58_TEST_D6_REQUIRED');rolls[c.optionId]=d;}
 const max=Math.max(...Object.values(rolls)),leaders=Object.entries(rolls).filter(([,d])=>d===max).map(([id])=>id).sort();if(leaders.length!==1)throw new Error(`GEN_LIVE_R58_TEST_TIE_REROLL:${leaders.join(',')}`);
 const n=clone(live);n.jointTestResults??={};n.jointTestResults[test.id]={kind:test.kind,mode:'PHYSICAL_D6_BY_DISTINCT_INTENTION',winningOptionId:leaders[0],rolls,supportCountsIgnored:true};n.history.push({type:'GEN_LIVE_R58_CAUSAL_TEST',round:n.round,testId:test.id,kind:test.kind,result:clone(n.jointTestResults[test.id])});narrate(n,'CAUSAL_TEST_RESOLVED','La incertidumbre causal se resuelve sobre la mesa. Cada intención enfrentada recibió una oportunidad, independientemente de cuántos actores la apoyaban.');return n;
}

export function applySharedDecisionResolutionR58(live){
 validate(live);if(live.phase!=='JOINT_RESOLUTION')throw new Error('GEN_LIVE_R5_JOINT_PHASE');const preview=previewSharedDecisionR58(live);if(!preview.ready)return{state:live,result:preview,needsTests:true,needsDie:true};
 const n=clone(live),before=clone(n.runtime.cosmogony),blocked=new Set(),winningByTest={};
 for(const x of preview.resolvedTests){const win=x.result?.winningOptionId;if(!win)continue;winningByTest[x.test.id]=win;for(const c of x.test.contenders||[])if(c.optionId&&c.optionId!==win)blocked.add(c.optionId);}
 const supporters={};for(const i of preview.plan.activeIntentions){supporters[i.option.id]??=[];supporters[i.option.id].push(i.playerId);}
 const distinct=[...new Map(preview.plan.activeIntentions.map(i=>[i.option.id,i.option])).values()];
 const applicable=distinct.filter(o=>!blocked.has(o.id)&&o.effect!=='NONE').sort((a,b)=>jointEffectOrder(a)-jointEffectOrder(b)||String(a.id).localeCompare(String(b.id)));
 for(const option of applicable)n.runtime=applyJointEffect(n.runtime,option);
 const resolution={schema:GENESIS_SHARED_R58_SCHEMA,decisionId:preview.plan.decisionId,round:n.round,profile:clone(preview.plan.selections),allIntentionsPreserved:true,majorityWinner:null,noIntervenePlayers:clone(preview.plan.noIntervenePlayers),interactionGraph:clone(preview.plan.interactionGraph),supportersByOption:Object.fromEntries(Object.entries(supporters).map(([k,v])=>[k,[...v].sort()])),tests:clone(preview.resolvedTests),winningByTest,appliedOptionIds:applicable.map(o=>o.id),blockedOptionIds:[...blocked].sort()};
 n.runtime.cosmogony.history.push({type:'SHARED_SECRET_DECISION_R58',decisionId:resolution.decisionId,round:n.round,profile:clone(resolution.profile),appliedOptionIds:[...resolution.appliedOptionIds],blockedOptionIds:[...resolution.blockedOptionIds],majorityWinner:null,tests:clone(resolution.tests)});
 n.runtime.eventLog.push({type:'GEN_R58_SHARED_SECRET_DECISION_RESOLVED',decisionId:resolution.decisionId,round:n.round,profile:clone(resolution.profile),appliedOptionIds:[...resolution.appliedOptionIds],blockedOptionIds:[...resolution.blockedOptionIds],majorityWinner:null});
 n.lastJointResolution=resolution;n.runtime=advanceRuntimeEpochR5(n.runtime);n.lastMaterialization=materializationDelta(before,n.runtime.cosmogony);n.history.push({type:'GEN_LIVE_R58_SHARED_SECRET_RESOLUTION',round:n.round,resolution:clone(resolution),canonicalDecisionId:'D-GEN-R5.8-SECRET-SHARED-DECISION01'});n.revealedSelections=null;n.contextual=null;n.jointPlan=null;n.jointTestResults={};n.afterMaterializationPhase=n.runtime.phase==='SELECT_PLANET'?'SELECT_PLANET':'AGENCY_ACTIONS';if(n.afterMaterializationPhase==='AGENCY_ACTIONS'){n.round++;n.actorIndex=0;}n.phase='MATERIALIZE';narrate(n,'CAUSAL_RESOLUTION',resolutionNarrativeR58(resolution,distinct));return{state:n,result:resolution,needsTests:false,needsDie:false};
}

export function previewJointResolutionR5(live){return previewSharedDecisionR58(live);}
export function applyExperimentalJointResolutionR5(live){return applySharedDecisionResolutionR58(live);}

export function confirmLiveMaterializationR5(live){
 validate(live);if(live.phase!=='MATERIALIZE'||!live.afterMaterializationPhase)throw new Error('GEN_LIVE_R5_MATERIALIZATION_PHASE');const n=clone(live);n.history.push({type:'GEN_LIVE_R5_TABLE_MATERIALIZED',round:n.round,changes:clone(n.lastMaterialization)});narrate(n,'TABLE_MATERIALIZED',n.lastMaterialization.length?'La mesa ya refleja el cambio. Lo visible queda delante de vosotros; las causas, huellas y posibilidades que todavía no deban conocerse permanecen en la memoria privada del mundo.':'Nada necesita moverse esta vez. Aun así, la historia causal puede haber cambiado y la app la conserva.');n.phase=n.afterMaterializationPhase;n.afterMaterializationPhase=null;return n;
}

export function livePlanetOptionsR5(live){validate(live);if(live.phase!=='SELECT_PLANET')return[];return live.runtime.cosmogony.planets.map(p=>clone(p));}
export function chooseLivePlanetR5(live,planetId){validate(live);if(live.phase!=='SELECT_PLANET')throw new Error('GEN_LIVE_R5_PLANET_PHASE');const n=clone(live);n.runtime=selectRuntimePlanetR5(n.runtime,planetId);n.phase='READY_TO_CLOSE';narrate(n,'PLANET_SELECTED',`${planetId} será el mundo que continúe. Su materia, su historia de formación y las causas visibles e invisibles que lo alcanzan viajarán en el Legado hacia los BOOT que puedan consumirlas.`);return n;}
export function closeLiveGenesisR5(live){validate(live);if(live.phase!=='READY_TO_CLOSE')throw new Error('GEN_LIVE_R5_CLOSE_PHASE');const n=clone(live);n.runtime=closeGenesisRuntimeR5(n.runtime);n.phase='CLOSED';n.history.push({type:'GEN_LIVE_R5_CLOSED',selectedPlanetId:n.runtime.selectedPlanetId});narrate(n,'GENESIS_CLOSED','Génesis termina, pero nada de lo que deba importar desaparece. El mundo entra en su siguiente edad con una verdad objetiva, una memoria causal, secretos todavía no revelados y promesas disponibles para los BOOT futuros.');return n;}

export function serializeGenesisLiveR5(live){validate(live);return JSON.stringify(live);}
export function deserializeGenesisLiveR5(json){const live=JSON.parse(json);validate(live);live.pendingAgencyActions??=[];live.narrativeLog??=[];live.currentNarrative??=null;live.jointPlan??=null;live.jointTestResults??={};live.spawnPlan??=null;live.spatialPolicy??={decisionId:GENESIS_SPATIAL_R510_DECISION,movementLimit:GENESIS_AGENCY_MOVEMENT_R510,movementScalesWithIntensity:false,remoteRequiresConcreteCapability:true};live.version=live.version||'R5.10-dev031';live.openDesignGaps=(live.openDesignGaps||[]).filter(g=>g.id!=='GAP-GEN-R59-MOVEMENT-RANGE');for(const p of live.players){p.controller??='HUMAN';p.simulated??=false;p.position??=p.spawn?.cell||null;p.lastRepositionRound??=0;}return live;}

function buildSharedPlanR58(live){
 if(!live.contextual||!live.revealedSelections)throw new Error('GEN_LIVE_R58_PROFILE_REQUIRED');
 return planSharedSecretDecision({decision:{id:live.contextual.decisionId||`GENESIS-SHARED-R${live.round}`,actionZone:live.contextual.actionZone||`GENESIS:R${live.round}`,participants:live.players.map(p=>({playerId:p.id})),options:live.contextual.options},selections:live.revealedSelections});
}

function authorityAutoResultsR58(live,plan){
 const out={},signature=live.runtime.signatureRecord.signature||{};
 for(const test of plan.testsRequired||[]){
  if(test.kind!=='CONFLICT')continue;
  const options=[...new Map((test.contenders||[]).filter(c=>c.optionId).map(c=>[c.optionId,c])).values()];if(options.length<2)continue;
  const scored=options.map(c=>({optionId:c.optionId,nature:c.requiredNature||null,authority:c.requiredNature?Number(signature[c.requiredNature]||0):0}));
  const max=Math.max(...scored.map(x=>x.authority)),leaders=scored.filter(x=>x.authority===max);if(leaders.length===1&&max>0)out[test.id]={kind:'CONFLICT',mode:'R5.3_CAUSAL_AUTHORITY',winningOptionId:leaders[0].optionId,authorityByOption:Object.fromEntries(scored.map(x=>[x.optionId,{nature:x.nature,authority:x.authority}])),supportCountsIgnored:true};
 }
 return out;
}

function rawAgencyOptionsR510(live,agency){
 const parcels=live.runtime.cosmogony.matter.parcels.filter(p=>['FREE','DISK'].includes(p.state)),out=[];
 if(agency.nature==='PHYSICS'){
  for(const p of parcels)out.push({id:`CONCENTRATE:${p.id}`,kind:'CONCENTRATE',targetId:p.id,label:`Concentrar ${p.id}`,hint:revealMatterHint(p,'STAR_FEED')});
  for(const p of parcels)out.push({id:`PRESERVE_DISK:${p.id}`,kind:'PRESERVE_DISK',targetId:p.id,label:`Preservar ${p.id} para el disco`,hint:revealMatterHint(p,'PLANET')});
 }
 if(agency.nature==='MYSTIC'){
  for(const p of parcels)out.push({id:`IMPRINT:${p.id}`,kind:'IMPRINT',targetId:p.id,principle:agency.actionTier>=2?'PERSISTENCE_TRACE':'LINKED_POTENTIAL',label:`Imprimir una huella en ${p.id}`,hint:p.public.traits.join(' · ')||'Sin rasgo dominante visible'});
  for(let i=0;i<Math.min(3,parcels.length);i++)for(let j=i+1;j<Math.min(4,parcels.length);j++)out.push({id:`LINK:${parcels[i].id}:${parcels[j].id}`,kind:'LINK',targetId:parcels[i].id,otherId:parcels[j].id,label:`Vincular ${parcels[i].id} y ${parcels[j].id}`});
 }
 if(agency.nature==='WILL'){
  for(const p of parcels)out.push({id:`PROTECT:${p.id}`,kind:'PROTECT',targetId:p.id,label:`Proteger ${p.id}`,hint:revealMatterHint(p,'PLANET')});
  for(const p of parcels)out.push({id:`CLAIM:${p.id}`,kind:'CLAIM',targetId:p.id,label:`Reclamar ${p.id}`,hint:p.public.traits.join(' · ')||'Sin rasgo dominante visible'});
 }
 out.push({id:'WAIT',kind:'WAIT',targetId:null,label:'No intervenir con esta agencia'});return out;
}

function agencyOptionsAtPositionR510(live,agency,position){
 const board=live.runtime.cosmogony.board,parcels=live.runtime.cosmogony.matter.parcels,raw=rawAgencyOptionsR510(live,agency),out=[];
 for(const option of raw){
  if(option.kind==='WAIT'){out.push({...option,spatial:{decisionId:GENESIS_SPATIAL_R510_DECISION,from:position,presence:'NONE'}});continue;}
  const ids=[option.targetId,option.otherId].filter(Boolean),targets=[];let legal=true;
  for(const id of ids){const parcel=parcels.find(p=>p.id===id);if(!parcel){legal=false;break;}const status=classifyAgencyPresenceR510({board,from:position,target:parcel.cell,intensity:agency.universeIntensity,option});targets.push({id,cell:parcel.cell,...status});if(status.presence==='OUT_OF_REACH')legal=false;}
  if(legal)out.push({...option,spatial:{decisionId:GENESIS_SPATIAL_R510_DECISION,from:position,targets,presence:targets[0]?.presence||'NONE',effectiveReach:Math.max(...targets.map(t=>t.effectiveReach),1)}});
 }
 return out;
}

function simulatedAgencyPlansR510(live){
 if(live?.phase!=='AGENCY_ACTIONS')return[];const p=live.players[live.actorIndex];if(!p||p.controller!=='APP'||!agencyNeedsRepositionR510(live))return[];const agency=runtimeAgencyR5(live.runtime,p.id),movement=liveAgencyMovementR510(live),plans=[];
 for(const dest of movement.destinations){for(const option of agencyOptionsAtPositionR510(live,agency,dest.code).filter(o=>o.kind!=='WAIT'))plans.push({...option,id:`R510-PLAN:${dest.code}:${option.id}`,originalOptionId:option.id,moveTo:dest.code,movementDistance:dest.distance,label:`${dest.distance?`Mover a ${dest.code} y `:'Sin mover: '}${option.label}`});}
 if(plans.length)return plans;
 return[{id:`R510-PLAN:${movement.from}:WAIT`,originalOptionId:'WAIT',moveTo:movement.from,movementDistance:0,kind:'WAIT',targetId:null,label:'No intervenir con esta agencia'}];
}

function autoRepositionForRequestedOptionR510(live,optionId){
 const p=live.players[live.actorIndex],agency=runtimeAgencyR5(live.runtime,p.id),movement=liveAgencyMovementR510(live),candidates=[];
 for(const dest of movement.destinations){const option=agencyOptionsAtPositionR510(live,agency,dest.code).find(o=>o.id===optionId);if(option)candidates.push({dest,option});}
 if(!candidates.length)throw new Error('GEN_LIVE_R510_ACTION_UNREACHABLE_AFTER_MOVE');const chosen=candidates.sort((a,b)=>a.dest.distance-b.dest.distance||a.dest.code.localeCompare(b.dest.code))[0];return repositionLiveAgencyR510(live,chosen.dest.code);
}

function applyPendingAgencyBatchR53(live){
 const actions=[...(live.pendingAgencyActions||[])];if(!actions.length){live.pendingAgencyActions=[];return;}
 const signature=live.runtime.signatureRecord.signature,defeated=new Set(),precedence=new Map();
 for(let i=0;i<actions.length;i++)for(let j=i+1;j<actions.length;j++){
  const a=actions[i],b=actions[j];if(!crossNatureIncompatibleR53(a,b))continue;
  const ai=Number(signature[a.nature]||0),bi=Number(signature[b.nature]||0);if(ai===bi)throw new Error('GEN_LIVE_R53_CAUSAL_TIE_INVALID');
  const winner=ai>bi?a:b,loser=ai>bi?b:a;defeated.add(loser.seq);const key=`${winner.targetId}:${winner.nature}>${loser.nature}`;
  if(!precedence.has(key))precedence.set(key,{type:'GEN_R53_CAUSAL_PRECEDENCE',round:live.round,targetId:winner.targetId,winnerNature:winner.nature,loserNature:loser.nature,winnerIntensity:Number(signature[winner.nature]||0),loserIntensity:Number(signature[loser.nature]||0),winnerPlayerIds:new Set(),defeatedPlayerIds:new Set(),defeatedOptionIds:new Set()});
  const p=precedence.get(key);p.winnerPlayerIds.add(winner.playerId);p.defeatedPlayerIds.add(loser.playerId);p.defeatedOptionIds.add(loser.optionId);
 }
 const kindOrder={CONCENTRATE:1,PRESERVE_DISK:2,PROTECT:3,CLAIM:4,IMPRINT:5,LINK:6};
 const applied=actions.filter(a=>!defeated.has(a.seq)).sort((a,b)=>String(a.targetId||'').localeCompare(String(b.targetId||''))||(kindOrder[a.kind]??99)-(kindOrder[b.kind]??99)||String(a.nature).localeCompare(String(b.nature))||String(a.playerId).localeCompare(String(b.playerId)));
 let runtime=live.runtime;for(const a of applied)runtime=applyRuntimeAgencyActionR5(runtime,{playerId:a.playerId,kind:a.kind,targetId:a.targetId,otherId:a.otherId,principle:a.principle});
 for(const raw of precedence.values()){
  const event={...raw,winnerPlayerIds:[...raw.winnerPlayerIds].sort(),defeatedPlayerIds:[...raw.defeatedPlayerIds].sort(),defeatedOptionIds:[...raw.defeatedOptionIds].sort()};runtime.eventLog.push(clone(event));runtime.cosmogony.history.push({type:'CAUSAL_OPPOSITION_RESIDUE',round:live.round,targetId:event.targetId,winnerNature:event.winnerNature,loserNature:event.loserNature,winnerIntensity:event.winnerIntensity,loserIntensity:event.loserIntensity,defeatedPlayerIds:[...event.defeatedPlayerIds]});live.history.push(clone(event));
 }
 live.runtime=runtime;live.pendingAgencyActions=[];
}

function crossNatureIncompatibleR53(a,b){
 if(a.targetId!==b.targetId||a.nature===b.nature)return false;
 const pair=new Set([a.nature,b.nature]);if(!(pair.has('PHYSICS')&&pair.has('WILL')))return false;
 return (a.kind==='CONCENTRATE'&&b.kind==='PROTECT')||(a.kind==='PROTECT'&&b.kind==='CONCENTRATE');
}

function applyJointEffect(runtime,option){
 if(option.effect==='INVISIBLE_WORLD'&&option.invisibleSpec)return applyInvisibleWorldOptionR512(runtime,option.invisibleSpec);
 if(option.effect==='VOLITION_RELATION'&&option.relationSpec)return establishVolitionRelationR5(runtime,option.relationSpec);
 const parcels=runtime.cosmogony.matter.parcels.filter(p=>['FREE','DISK'].includes(p.state));if(!parcels.length)return runtime;const planetValue=p=>p.hidden.refractories+p.hidden.volatiles+p.hidden.mass/3;const frozenId=String(option.resolution?.targetKey||'').startsWith('MAT:')?String(option.resolution.targetKey).slice(4):null;let target=frozenId?parcels.find(p=>p.id===frozenId)||null:null,nature=option.requiredNature,kind=null,principle=null;
 if(option.effect==='CONCENTRATE_BEST'){target??=[...parcels].filter(p=>p.state==='FREE').sort((a,b)=>b.hidden.mass-a.hidden.mass||a.id.localeCompare(b.id))[0];kind='CONCENTRATE';}
 if(option.effect==='PRESERVE_BEST'){target??=[...parcels].sort((a,b)=>planetValue(b)-planetValue(a)||a.id.localeCompare(b.id))[0];kind=nature==='WILL'?'PROTECT':'PRESERVE_DISK';}
 if(option.effect==='IMPRINT_BEST'){target??=[...parcels].sort((a,b)=>planetValue(b)-planetValue(a)||a.id.localeCompare(b.id))[0];kind='IMPRINT';principle='PERSISTENCE_TRACE';}
 if(option.effect==='PROTECT_BEST'){target??=[...parcels].sort((a,b)=>planetValue(b)-planetValue(a)||a.id.localeCompare(b.id))[0];kind='PROTECT';}
 if(!target||!kind)return runtime;const contributor=runtime.binding.agencies.find(a=>a.nature===nature);if(!contributor)throw new Error('GEN_LIVE_R5_JOINT_NO_CAUSAL_CONTRIBUTOR');return applyRuntimeAgencyActionR5(runtime,{playerId:contributor.playerId,kind,targetId:target.id,principle});
}

function jointEffectOrder(option){if(option.effect==='VOLITION_RELATION')return 0;if(option.effect==='IMPRINT_BEST')return 1;if(['PRESERVE_BEST','PROTECT_BEST'].includes(option.effect))return 2;if(option.effect==='CONCENTRATE_BEST')return 3;return 9;}
function resolutionNarrativeR58(resolution,options){
 if(!resolution.profile.some(x=>!x.noIntervene))return'Nadie añade una intervención compartida. Eso no borra lo ocurrido antes: el universo continúa y la omisión queda registrada como parte de la historia.';
 const labels=resolution.appliedOptionIds.map(id=>options.find(o=>o.id===id)?.title||id);const blocked=resolution.blockedOptionIds.length?` ${resolution.blockedOptionIds.length} intención${resolution.blockedOptionIds.length===1?'':'es'} incompatible${resolution.blockedOptionIds.length===1?'':'s'} no logra${resolution.blockedOptionIds.length===1?'':'n'} imponerse en su conflicto, pero queda${resolution.blockedOptionIds.length===1?'':'n'} registrada${resolution.blockedOptionIds.length===1?'':'s'} como causa intentada.`:'';
 return labels.length?`Las decisiones compatibles producen sus consecuencias: ${labels.join('; ')}.${blocked} La app conserva el perfil completo, no una votación ganadora.`:`Las elecciones producen tensión pero ninguna nueva intervención material aplicable.${blocked} El perfil completo queda en la memoria causal.`;
}

function materializationDelta(before,after){
 const out=[];for(const p of after.matter.parcels){const b=before.matter.parcels.find(x=>x.id===p.id);if(!b)continue;if(b.cell!==p.cell)out.push({type:'MOVE',id:p.id,from:b.cell,to:p.cell});if(b.state!==p.state)out.push({type:'STATE',id:p.id,from:b.state,to:p.state});}
 if(before.star.state!==after.star.state&&after.star.state==='IGNITED')out.push({type:'STAR_IGNITED',family:after.star.family,members:[...after.star.members]});
 for(const p of after.planets)if(!before.planets.some(x=>x.id===p.id))out.push({type:'PLANET_FORMED',id:p.id,typeId:p.type,members:[...p.members]});return out;
}
function natureLabel(n){return n==='PHYSICS'?'Física':n==='MYSTIC'?'Mística':'Voluntad';}
function narrate(live,kind,publicText){live.currentNarrative=publicText;live.narrativeLog??=[];live.narrativeLog.push({round:live.round,kind,publicText});}
function validate(l){if(l?.schema!==GENESIS_LIVE_R5_SCHEMA||!l.runtime||!Array.isArray(l.players))throw new Error('GEN_LIVE_R5_INVALID');}
