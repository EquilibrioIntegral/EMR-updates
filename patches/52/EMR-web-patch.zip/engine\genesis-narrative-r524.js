import {visibleGenesisCellR513,primordialActorNameR513} from './genesis-player-facing-r513.js';
import {narrateGenesisAgencyActionR525} from './genesis-action-narrative-r525.js';
import {publicAndHiddenIntentionsR525} from './genesis-intention-memory-r525.js';
import {composeCosmicNarrativeR529} from './genesis-cosmic-narrator-r529.js';

export const GENESIS_NARRATIVE_R524='EMR_GENESIS_NARRATIVE_R524_v1';

export function genesisRoundNarrativeR524(live){
 return composeCosmicNarrativeR529(live);
}

export function actionNarrativeR524(args={}){
 return narrateGenesisAgencyActionR525(args);
}

export function meepleRepresentationTextR524(live,player){
 const actor=primordialActorNameR513(player),board=live?.runtime?.cosmogony?.board,cell=visibleGenesisCellR513(player?.position||player?.spawn?.cell||'',board);
 const color=player?.deck?.colorName||'asignado';
 return `${actor} está representado en la mesa por el meeple ${color}, situado en la casilla ${cell}.`;
}

export function publicAndHiddenIntentionsR524(live){
 return publicAndHiddenIntentionsR525(live);
}
