export const GENESIS_R510_PHYSICAL_QA_FIXTURE_SCHEMA='EMR_GENESIS_R510_PHYSICAL_QA_FIXTURE_v1';

export const GENESIS_R510_PHYSICAL_QA_FIXTURE=Object.freeze({
 schema:GENESIS_R510_PHYSICAL_QA_FIXTURE_SCHEMA,
 id:'R510-PHYSICAL-QA-001',
 status:'READY_FOR_HUMAN_EXECUTION_NOT_PASS',
 purpose:'Medir el bucle híbrido real mover → actuar → Intenciones → materializar sin confundir simulación con validación humana.',
 seed:'R510-PHYSICAL-QA-001',
 entry:{
  mode:'SOLO_R59_CANONICAL',
  primaryNature:'WILL',
  secondaryDice:Object.freeze({PHYSICS:2,MYSTIC:1}),
  expectedSignature:Object.freeze({PHYSICS:2,MYSTIC:1,WILL:6}),
  expectedControllers:Object.freeze(['HUMAN','APP','APP'])
 },
 table:{
  boardPreset:'A60',
  matterCount:10,
  humanIntentionDecks:1,
  physicalAgencyMeeples:3,
  d6:'AVAILABLE_WHEN_REAL_UNCERTAINTY_EXISTS'
 },
 spatial:{movementLimit:2,movementScalesWithIntensity:false,remoteRequiresConcreteCapability:true},
 targets:{
  totalSecondsMax:600,
  screenShareMax:0.35,
  screenClearlyMinority:true,
  desyncIncidentsMax:0,
  ruleInventionsAllowed:0
 },
 measurements:Object.freeze([
  'setupSeconds','movementDecisionSeconds','physicalMovementSeconds','appInteractionSeconds','tableActionSeconds','materializationSeconds',
  'screenSeconds','tableSeconds','totalSeconds','screenActions','manualInputs','movementErrors','desyncIncidents','ruleQuestions',
  'causalChangeRecognized','worldMemoryRecognized','feltBoardGameSupportedByApp','desireToContinue'
 ]),
 passPolicy:'NO_AUTOMATIC_PASS. Technical fixture readiness may PASS; physical/UX/HH4 PASS requires an observed human execution and recorded measurements.'
});

export function evaluateGenesisR510HumanRun(measurement={}){
 const f=GENESIS_R510_PHYSICAL_QA_FIXTURE,t=Number(measurement.totalSeconds),s=Number(measurement.screenSeconds),table=Number(measurement.tableSeconds);
 const hasTiming=Number.isFinite(t)&&t>0&&Number.isFinite(s)&&s>=0&&Number.isFinite(table)&&table>=0;
 const screenShare=hasTiming?s/t:null;
 const checks={
  humanRunRecorded:measurement.humanRun===true,
  timingRecorded:hasTiming,
  underTenMinutes:hasTiming&&t<=f.targets.totalSecondsMax,
  screenMinority:hasTiming&&screenShare<=f.targets.screenShareMax&&table>s,
  noDesync:Number(measurement.desyncIncidents)===0,
  noInventedRules:Number(measurement.ruleInventions||0)===0,
  causalChangeRecognized:measurement.causalChangeRecognized===true,
  boardGameSupportedByApp:measurement.feltBoardGameSupportedByApp===true
 };
 const pass=Object.values(checks).every(Boolean);
 return{fixtureId:f.id,pass,screenShare,checks,status:pass?'HUMAN_PHYSICAL_QA_PASS':'NOT_PASS_OR_INCOMPLETE'};
}
