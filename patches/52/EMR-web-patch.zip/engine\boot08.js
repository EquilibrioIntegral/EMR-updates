// BOOT-08 · Guionista live handoff · A1
// Authority: EMR_BOOT08_LIVE_HANDOFF_A1_v0.1.
// P0→P8: validate authority/visibility, build sourced graph, select only legal
// causal pressure, compile a reproducible HISTORY_SEED, then and only then open runtime.

const legal = f => !!f?.id && f.valid !== false && f.contradiction !== true;
const visibleToBoot08 = f => legal(f) && f.secret !== true && f.missionLike !== true;
const stable = xs => [...xs].sort((a,b)=>String(a.id).localeCompare(String(b.id)));

const pcOriginFacts = pcs => pcs.map(pc => ({
  id:`${pc.id}-ORIGIN`, referentId:pc.originRef, type:'ORIGIN', origin:pc.id,
  valid:true, public:true, secret:false, missionLike:false, contradiction:false,
  causalTags:['PC_ORIGIN',pc.originRef].filter(Boolean), specificity:3
}));

export function buildBoot08Graph({worldPayload,protagonists,startLink,extraWorldFacts=[]}) {
  if (!worldPayload || !Array.isArray(worldPayload.save0Refs)) throw new Error('BOOT08_WORLD_FACTS_REQUIRED');
  if (!Array.isArray(protagonists) || !protagonists.length) throw new Error('BOOT08_PC_STATE_REQUIRED');
  if (!startLink?.startLinkId && !startLink?.id) throw new Error('BOOT08_START_LINK_REQUIRED');
  const worldFacts = stable([...worldPayload.save0Refs, ...extraWorldFacts].filter(visibleToBoot08));
  const facts = [...worldFacts, ...pcOriginFacts(protagonists)].filter(legal);
  return Object.freeze({facts,worldFacts,worldPayload,startLink,protagonists});
}

function grammarFor(f) {
  if (f.grammar && /^G[1-4](?:_|$)/.test(f.grammar)) return f.grammar;
  const tags = new Set(f.causalTags ?? []);
  if (tags.has('AMENAZA')) return 'G1_AMENAZA';
  if (tags.has('FRACTURA')) return 'G2_FRACTURA';
  if (tags.has('ENIGMA')) return 'G3_ENIGMA';
  if (tags.has('PRESION') || tags.has('OBSTRUCCION_AMBIENTAL') || f.dynamic === true) return 'G4_PRESION';
  return null;
}

export function inspectBoot08Threads(graph) {
  const link = graph.startLink;
  const anchor = link.anchorId;
  const candidates = stable(graph.worldFacts.filter(f => {
    const anchored = !anchor || f.referentId === anchor || (f.referents ?? []).includes(anchor);
    return anchored && grammarFor(f) && Array.isArray(f.sourceIds) && f.sourceIds.length > 0;
  }));
  if (!candidates.length) return Object.freeze({status:'NO_THREAD',reason:'NO_SOURCED_LEGAL_G1_G4_CANDIDATE',request:'MEC21_WINDOW_REQUEST'});
  const event = candidates[0];
  return Object.freeze({
    status:'THREAD', id:`THREAD-BOOT08-${event.id}`, grammar:grammarFor(event), anchorId:anchor ?? event.referentId ?? null,
    sourceIds:[event.id,...event.sourceIds,link.startLinkId ?? link.id].filter(Boolean), event
  });
}

export function compileHistorySeed(thread, protagonists) {
  if (thread?.status !== 'THREAD') throw new Error('BOOT08_THREAD_REQUIRED');
  const event = thread.event;
  const initialSituation = event.publicText ?? event.description ?? event.label;
  if (!initialSituation) throw new Error('BOOT08_PUBLIC_REALIZATION_REQUIRED');
  return Object.freeze({
    id:`HISTORY-SEED-${event.id}`, threadId:thread.id, grammar:thread.grammar, anchorId:thread.anchorId,
    initialSituation,
    centralDramaticQuestion:event.dramaticQuestion ?? null,
    commonObjective:null,
    sourceIds:[...thread.sourceIds],
    interests:[],
    firstCommitmentSpec:event.firstCommitmentSpec ?? null,
    missionPrefixed:false,
    protagonistIds:protagonists.map(p=>p.id)
  });
}

export function runBoot08(input) {
  const graph = buildBoot08Graph(input);
  const thread = inspectBoot08Threads(graph);
  if (thread.status === 'NO_THREAD') return Object.freeze({phase:'BOOT08_NO_THREAD',graph,thread,request:'MEC21_WINDOW_REQUEST',runtimeEnabled:false});
  const historySeed = compileHistorySeed(thread,input.protagonists);
  return Object.freeze({phase:'BOOT08_CLOSED',graph,thread,historySeed,runtimeEnabled:true,nextPhase:'RUNTIME',runtimeGate:'BOOT08'});
}

export function bridgeNoThreadWithMec21(input,event) {
  const first = runBoot08(input);
  if (first.phase !== 'BOOT08_NO_THREAD') return first;
  if (!event || event.origin !== 'WORLD' || event.public !== true || !event.sourceIds?.length) throw new Error('BOOT08_MEC21_EVENT_NOT_SOURCED');
  return runBoot08({...input,extraWorldFacts:[...(input.extraWorldFacts ?? []),event]});
}
