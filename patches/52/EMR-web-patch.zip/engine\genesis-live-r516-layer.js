import * as r512 from './genesis-live-r512-layer.js';
import {confirmLiveSetupR5 as legacyConfirmLiveSetupR5,agencyNeedsRepositionR510,liveAgencyMovementR510,repositionLiveAgencyR510,applySharedDecisionResolutionR58 as legacyApplySharedDecisionResolutionR58} from './genesis-live-r510-legacy.js';
import {chooseAutonomousAgencyOptionR59} from './genesis-autonomous-agencies-r59.js';

export const GENESIS_R516_PHYSICAL_BASELINE_DECISION='D-GEN-R5.16-PHYSICAL-BASELINE01';
export const GENESIS_R516_COSMIC_CLOCK_SCHEMA='EMR_GENESIS_COSMIC_CLOCK_R516_v1';
const clone=x=>structuredClone(x);

function normalizedFacts(facts=[]){
  const kept=facts.filter(f=>!['LAW_SOURCE_REQUIRED','LAW_SOURCE_FIXED','LAW_ORIGIN_GATE_REQUIRED'].includes(f?.type));
  if(!kept.some(f=>f?.type==='BASELINE_PHYSICAL_EVOLUTION'))kept.push({type:'BASELINE_PHYSICAL_EVOLUTION',decisionId:GENESIS_R516_PHYSICAL_BASELINE_DECISION,mode:'ALWAYS_ACTIVE',scope:'GRAVITY_THERMAL_ACCRETION_IGNITION_DISK_ORBITS'});
  return kept;
}

function ensureCosmicClockR516(live){
  live.cosmicClock??={schema:GENESIS_R516_COSMIC_CLOCK_SCHEMA,tick:0,roundStartTick:0,history:[]};
  live.cosmicClock.schema=GENESIS_R516_COSMIC_CLOCK_SCHEMA;
  live.cosmicClock.tick=Number(live.cosmicClock.tick||0);
  live.cosmicClock.roundStartTick=Number(live.cosmicClock.roundStartTick||0);
  live.cosmicClock.history??=[];
  return live.cosmicClock;
}

function advanceClockR516(live,{amount=1,kind,actorId=null,optionId=null,round=null,cosmogonyEpoch=null}={}){
  const clock=ensureCosmicClockR516(live),delta=Math.max(1,Number(amount)||1);
  clock.tick+=delta;
  clock.history.push({tick:clock.tick,delta,kind,actorId,optionId,round:round??live.round??0,cosmogonyEpoch:cosmogonyEpoch??live.runtime?.cosmogony?.epoch??0});
  live.history??=[];
  live.history.push({type:'GEN_R516_COSMIC_CLOCK_ADVANCED',tick:clock.tick,delta,kind,actorId,optionId,round:round??live.round??0,cosmogonyEpoch:cosmogonyEpoch??live.runtime?.cosmogony?.epoch??0});
  return live;
}

export function normalizePhysicalBaselineR516(live){
  const n=clone(live);
  const runtime=n.runtime;
  if(!runtime)return n;
  runtime.ontologyAnalysis??={};
  runtime.ontologyAnalysis.lawMode='AUTONOMOUS_PHYSICS_PRESENT';
  runtime.ontologyAnalysis.facts=normalizedFacts(runtime.ontologyAnalysis.facts||[]);
  runtime.ontology??={};
  runtime.ontology.lawAuthority={
    ...(runtime.ontology.lawAuthority||{}),
    physicalAutonomy:'BASELINE_ALWAYS_ACTIVE',
    originOfPhysicalRegularities:'BASELINE_PHYSICAL_EVOLUTION',
    originMode:'PHYSICAL_BASELINE',
    producerIds:[...new Set(['BASELINE_PHYSICS',...(runtime.ontology.lawAuthority?.producerIds||[])])],
    decisionId:GENESIS_R516_PHYSICAL_BASELINE_DECISION,
    exceptionsAndSelfLimits:clone(runtime.ontology.lawAuthority?.exceptionsAndSelfLimits||[])
  };
  n.playerFacingFlow??={schema:'EMR_GENESIS_PLAYER_FLOW_R516_v1',originSeen:false};
  ensureCosmicClockR516(n);
  n.history??=[];
  if(!n.history.some(x=>x?.type==='GEN_R516_PHYSICAL_BASELINE_ACTIVE'))n.history.push({type:'GEN_R516_PHYSICAL_BASELINE_ACTIVE',decisionId:GENESIS_R516_PHYSICAL_BASELINE_DECISION,round:n.round??0});
  return n;
}

export function createGenesisLiveR5(args={}){
  return normalizePhysicalBaselineR516(r512.createGenesisLiveR5(args));
}

export function deserializeGenesisLiveR5(json){
  return normalizePhysicalBaselineR516(r512.deserializeGenesisLiveR5(json));
}

export function confirmLiveSetupR5(live){
  const normalized=normalizePhysicalBaselineR516(live);
  let next=legacyConfirmLiveSetupR5(normalized);
  if(['LAW_ORIGIN_GATE','ONTOLOGY_GATE'].includes(next.phase))next.phase='AGENCY_ACTIONS';
  next=normalizePhysicalBaselineR516(next);
  const clock=ensureCosmicClockR516(next);clock.roundStartTick=clock.tick;
  next.currentNarrative='La materia ya evoluciona bajo gravedad, intercambio de energía y acreción. Las agencias primordiales pueden intervenir, pero no son necesarias para que el sistema físico siga avanzando.';
  next.narrativeLog??=[];
  next.narrativeLog.push({round:next.round??1,kind:'PHYSICAL_BASELINE_READY',publicText:next.currentNarrative});
  next.history??=[];
  next.history.push({type:'GEN_R516_SETUP_READY_PHYSICS_BASELINE',decisionId:GENESIS_R516_PHYSICAL_BASELINE_DECISION,round:next.round??1});
  return next;
}

export function resumePhysicalBaselineR516(live){
  const n=normalizePhysicalBaselineR516(live);
  if(['LAW_ORIGIN_GATE','ONTOLOGY_GATE'].includes(n.phase)){
    n.phase='AGENCY_ACTIONS';
    n.history??=[];
    n.history.push({type:'GEN_R516_LEGACY_LAW_GATE_BYPASSED',decisionId:GENESIS_R516_PHYSICAL_BASELINE_DECISION,round:n.round??1});
  }
  return n;
}

function optionFingerprint(options=[]){
  return [...new Set(options.map(o=>[o.kind||'',o.targetId||'',o.otherId||'',o.capabilityId||'',o.spatial?.targetCell||''].join('|')))].sort().join('||');
}

export function meaningfulAgencyMovementR516(live){
  if(live?.phase!=='AGENCY_ACTIONS'||!agencyNeedsRepositionR510(live))return null;
  const movement=liveAgencyMovementR510(live);
  const baseline=optionFingerprint(r512.liveAgencyOptionsR5(live));
  const destinations=[];
  for(const d of movement.destinations||[]){
    if(Number(d.distance||0)<=0)continue;
    try{
      const moved=repositionLiveAgencyR510(live,d.code);
      const changed=optionFingerprint(r512.liveAgencyOptionsR5(moved));
      if(changed!==baseline)destinations.push(d);
    }catch{}
  }
  return destinations.length?{...movement,destinations}:null;
}

export function simulatedAgencyDecisionR59(live){
  const decision=r512.simulatedAgencyDecisionR59(live);
  if(!decision||Number(decision.movement?.distance||0)<=0)return decision;
  const meaningful=meaningfulAgencyMovementR516(live),allowed=new Set((meaningful?.destinations||[]).map(d=>d.code));
  if(allowed.has(decision.movement.to))return decision;
  const p=live?.players?.[live.actorIndex];if(!p)return decision;
  const currentOptions=r512.liveAgencyOptionsR5(live),option=chooseAutonomousAgencyOptionR59(live,currentOptions);
  return{playerId:p.id,playerName:p.name,nature:p.nature,option:clone(option),controller:'APP',movement:{from:p.position||p.spawn?.cell,to:p.position||p.spawn?.cell,distance:0,limit:decision.movement?.limit??0},spatialDecisionId:decision.spatialDecisionId,reason:'R516_NO_MOVEMENT_WITHOUT_CAUSAL_OPTION_CHANGE'};
}

export function applyLiveAgencyOptionR5(live,optionId){
  const actor=live?.players?.[live.actorIndex];
  const beforeRound=live?.round??0;
  const next=r512.applyLiveAgencyOptionR5(live,optionId);
  advanceClockR516(next,{amount:1,kind:optionId==='WAIT'?'FREE_ACTION_NO_INTERVENE':'FREE_ACTION_RESOLVED',actorId:actor?.id||null,optionId,round:beforeRound});
  if(next.phase==='PHYSICAL_INTENTION_CHOICE'){
    next.history??=[];
    next.history.push({type:'GEN_R516_FREE_ACTIONS_COMPLETE',round:beforeRound,cosmicTick:next.cosmicClock.tick,nextLayer:'JOINT_INTENTION'});
    next.narrativeLog??=[];
    next.narrativeLog.push({round:beforeRound,kind:'COSMIC_TIME_ADVANCED',publicText:'El tiempo cósmico avanza con las intervenciones y omisiones de las agencias. El Guionista reevalúa ahora el sistema completo antes de la decisión conjunta.'});
  }
  return next;
}

export function applySharedDecisionResolutionR58(live){
  const beforeEpoch=Number(live?.runtime?.cosmogony?.epoch||0),round=live?.round??0;
  const result=legacyApplySharedDecisionResolutionR58(live);
  if(result?.needsTests||!result?.state)return result;
  let next=normalizePhysicalBaselineR516(result.state);
  advanceClockR516(next,{amount:1,kind:'JOINT_INTENTION_RESOLVED',round,cosmogonyEpoch:beforeEpoch});
  const afterEpoch=Number(next.runtime?.cosmogony?.epoch||beforeEpoch);
  if(afterEpoch>beforeEpoch)advanceClockR516(next,{amount:Math.max(1,afterEpoch-beforeEpoch),kind:'AUTONOMOUS_UNIVERSE_EVOLUTION',round,cosmogonyEpoch:afterEpoch});
  if(next.phase==='MATERIALIZE'&&next.afterMaterializationPhase==='AGENCY_ACTIONS')ensureCosmicClockR516(next).roundStartTick=next.cosmicClock.tick;
  return{...result,state:next};
}

export const liveAgencyOptionsR5=r512.liveAgencyOptionsR5;
export const capabilityDebugProjectionR511=r512.capabilityDebugProjectionR511;
export const invisibleWorldProjectionR512=r512.invisibleWorldProjectionR512;
