// HYB-MIG-01 · Digital substitute for the administrative M1-M4 path
// M1 context -> M2 candidate recovery -> M3 legal filtering -> M4 0/1/N resolution.
// Physical materialization remains outside this module (M5).

function arr(v){ return Array.isArray(v) ? v : (v == null ? [] : [v]); }
function val(obj,path){ return String(path).split('.').reduce((a,k)=>a == null ? undefined : a[k],obj); }
function same(a,b){ return Array.isArray(a) ? a.includes(b) : a === b; }

export function normalizeSelectionContext(input={}) {
  const context={};
  for (const [k,v] of Object.entries(input)) if (v !== undefined && v !== null && v !== '') context[k]=v;
  return Object.freeze(context);
}

export function recoverCandidates(records=[], {statusPath='status', availableValues=['AVAILABLE','LIBRARY','ACTIVE']}={}) {
  const allowed=new Set(availableValues);
  return arr(records).filter(r => {
    const status=val(r,statusPath);
    return status == null || allowed.has(status);
  });
}

export function filterCandidates(candidates=[], rules=[], context={}) {
  const accepted=[], rejected=[];
  for (const candidate of candidates) {
    const reasons=[];
    for (const rule of rules) {
      const actual=val(candidate,rule.field);
      const expected=rule.contextKey ? context[rule.contextKey] : rule.value;
      let ok=true;
      switch(rule.op ?? 'EQ') {
        case 'EQ': ok=same(actual,expected); break;
        case 'IN': ok=arr(expected).includes(actual); break;
        case 'HAS_ANY': ok=arr(actual).some(x=>arr(expected).includes(x)); break;
        case 'HAS_ALL': ok=arr(expected).every(x=>arr(actual).includes(x)); break;
        case 'NEQ': ok=!same(actual,expected); break;
        default: throw new Error(`SELECTOR_RULE_UNKNOWN:${rule.op}`);
      }
      if (!ok) reasons.push(rule.id ?? `${rule.field}:${rule.op ?? 'EQ'}`);
    }
    (reasons.length ? rejected : accepted).push(reasons.length ? {candidate,reasons} : candidate);
  }
  return {accepted,rejected};
}

export function resolveZeroOneMany(candidates=[], {rng=null, weightPath='weight'}={}) {
  if (!candidates.length) return {returnCode:'RETURN_ZERO',selected:null,count:0};
  if (candidates.length===1) return {returnCode:'RETURN_ONE',selected:candidates[0],count:1};
  const selected=rng?.pickWeighted ? rng.pickWeighted(candidates,x=>Number(val(x,weightPath) ?? 1)) : candidates[0];
  return {returnCode:'RETURN_MANY',selected,count:candidates.length};
}

export function runReferenceSelector({records=[],context={},rules=[],rng=null,options={}}={}) {
  const normalized=normalizeSelectionContext(context);
  const recovered=recoverCandidates(records,options);
  const filtered=filterCandidates(recovered,rules,normalized);
  const resolved=resolveZeroOneMany(filtered.accepted,{rng,weightPath:options.weightPath});
  return {
    ...resolved,
    trace:{
      stage:'M1-M4',
      context:normalized,
      recoveredCount:recovered.length,
      legalCount:filtered.accepted.length,
      rejected:filtered.rejected.map(x=>({id:x.candidate.id ?? x.candidate.ID ?? null,reasons:x.reasons})),
      selectedId:resolved.selected?.id ?? resolved.selected?.ID ?? null
    }
  };
}
