import {advanceCosmicEpoch,cosmogonySummary} from './genesis-cosmogony-r5.js';
import {applyContextualCapabilityActionR511} from './genesis-capability-live-r511.js';

export const GENESIS_R520_FORECAST_SCHEMA='EMR_GENESIS_CAUSAL_FORECAST_R520_v1';
export const GENESIS_R520_DECISION='D-GEN-R5.20-CAUSAL-GUIONISTA01';

const clone=x=>structuredClone(x);

export function forecastNextCosmicEpochR520(cosmogony){
  if(!cosmogony)throw new Error('GEN_R520_COSMOGONY_REQUIRED');
  if(cosmogony.closed)return{
    schema:GENESIS_R520_FORECAST_SCHEMA,
    decisionId:GENESIS_R520_DECISION,
    fromEpoch:Number(cosmogony.epoch||0),
    toEpoch:Number(cosmogony.epoch||0),
    fromPhase:cosmogony.phase,
    toPhase:cosmogony.phase,
    events:[],
    before:cosmogonySummary(cosmogony),
    after:cosmogonySummary(cosmogony),
    next:clone(cosmogony),
    terminal:true
  };
  const before=clone(cosmogony),historyStart=before.history?.length||0;
  const next=advanceCosmicEpoch(before);
  return{
    schema:GENESIS_R520_FORECAST_SCHEMA,
    decisionId:GENESIS_R520_DECISION,
    fromEpoch:Number(cosmogony.epoch||0),
    toEpoch:Number(next.epoch||0),
    fromPhase:cosmogony.phase,
    toPhase:next.phase,
    events:clone((next.history||[]).slice(historyStart)),
    before:cosmogonySummary(cosmogony),
    after:cosmogonySummary(next),
    next,
    terminal:false
  };
}

export function forecastAgencyOptionR520(live,option,{playerId=null}={}){
  if(!live?.runtime?.cosmogony)throw new Error('GEN_R520_LIVE_REQUIRED');
  const actorId=playerId||live.players?.[live.actorIndex]?.id||null;
  let baseline;try{baseline=forecastNextCosmicEpochR520(live.runtime.cosmogony);}catch(error){return{schema:GENESIS_R520_FORECAST_SCHEMA,actorId,mode:'FORECAST_UNAVAILABLE',baseline:null,branch:null,simulatedIntervention:false,errorCode:String(error?.message||error)};}
  if(!option||option.kind==='WAIT')return{schema:GENESIS_R520_FORECAST_SCHEMA,decisionId:GENESIS_R520_DECISION,actorId,optionId:option?.id||'WAIT',mode:'NO_INTERVENTION',baseline,branch:baseline,simulatedIntervention:false};

  // Invisible-world options are real causal actions but they do not alter the material
  // forecast directly in the same interval. They therefore inherit the baseline
  // material forecast instead of inventing a physical effect that the engine did not compute.
  if(!option.capabilityId||option.primitive)return{schema:GENESIS_R520_FORECAST_SCHEMA,decisionId:GENESIS_R520_DECISION,actorId,optionId:option.id,mode:'NON_MATERIAL_CAUSE',baseline,branch:baseline,simulatedIntervention:false};

  try{
    const runtime=applyContextualCapabilityActionR511(clone(live.runtime),{...clone(option),playerId:actorId});
    const branch=forecastNextCosmicEpochR520(runtime.cosmogony);
    return{schema:GENESIS_R520_FORECAST_SCHEMA,decisionId:GENESIS_R520_DECISION,actorId,optionId:option.id,mode:'SIMULATED_MATERIAL_BRANCH',baseline,branch,simulatedIntervention:true};
  }catch(error){
    return{schema:GENESIS_R520_FORECAST_SCHEMA,decisionId:GENESIS_R520_DECISION,actorId,optionId:option.id,mode:'FORECAST_UNAVAILABLE',baseline,branch:null,simulatedIntervention:false,errorCode:String(error?.message||error)};
  }
}

export function causalDeltaR520(forecast){
  const base=forecast?.baseline?.after,branch=forecast?.branch?.after;
  if(!base||!branch)return null;
  const baseStar=Number(base.star?.mass||0),branchStar=Number(branch.star?.mass||0);
  const basePlanets=Number(base.planetCount||0),branchPlanets=Number(branch.planetCount||0);
  return{
    starMassDelta:branchStar-baseStar,
    starFamilyChanged:(base.star?.family||null)!==(branch.star?.family||null),
    baselineStarFamily:base.star?.family||null,
    branchStarFamily:branch.star?.family||null,
    planetCountDelta:branchPlanets-basePlanets,
    phaseChanged:base.phase!==branch.phase,
    baselinePhase:base.phase,
    branchPhase:branch.phase,
    baselineEvents:forecast.baseline.events.map(e=>e.type),
    branchEvents:forecast.branch.events.map(e=>e.type)
  };
}
