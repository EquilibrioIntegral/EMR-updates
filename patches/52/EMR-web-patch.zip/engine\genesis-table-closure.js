// GEN-R5.1 — Integration boundary between the live Genesis table and playable formation.
// Closure is caused by the world that players formed, never by a round counter.
import {derivePlayableSolarSystem,selectPlayablePlanet,compilePlayableSystemHandoff} from './genesis-playable-formation.js';

export const GENESIS_CLOSURE_VERSION='EMR_GENESIS_TABLE_CLOSURE_v1';

export function getTableClosureStatus(state){
 const formation=derivePlayableSolarSystem(state);
 return {
  schema:GENESIS_CLOSURE_VERSION,
  stage:formation.stage,
  ready:formation.ready,
  reasons:[...formation.reasons],
  star:formation.star,
  planetCandidates:formation.planetCandidates,
  selectedPlanet:formation.selectedPlanet,
  canContinuePlaying:!formation.ready,
  requiresPlanetSelection:formation.stage==='SELECT_PLANET'
 };
}

export function chooseTablePlanet(state,planetId,name=null){
 const result=selectPlayablePlanet(state,planetId,name);
 state.closedReason=result.ready?'PLAYABLE_SYSTEM_READY':null;
 if(result.ready){
  state.agencies.closed=true;
  state.phase='CLOSED';
 }
 return getTableClosureStatus(state);
}

export function closeTableIntoBoot01(state,baseHandoff={}){
 const status=getTableClosureStatus(state);
 if(!status.ready)throw new Error(`GENESIS_CLOSURE_NOT_READY:${status.reasons.join(',')}`);
 const playableSystem=compilePlayableSystemHandoff(state);
 return {
  ...baseHandoff,
  schema:'EMR_GENESIS_TO_BOOT01_v3',
  playableSystem,
  selectedPlanet:playableSystem.selectedPlanet,
  formationCause:'PLAYER_AND_UNIVERSE_CAUSAL_HISTORY',
  closureReason:'PLAYABLE_SYSTEM_READY'
 };
}
