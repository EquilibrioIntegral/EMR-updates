import {createGenesisLiveR5} from './genesis-live-r5.js';

const clone=x=>structuredClone(x);

export function installGenesisLiveFromEntryR53(state,entryResult,{config}={}){
 if(!state?.session?.players?.length)throw new Error('GEN_R53_LIVE_PLAYERS_REQUIRED');
 if(entryResult?.schema!=='EMR_GENESIS_ENTRY_RESULT_R53_v1')throw new Error('GEN_R53_LIVE_ENTRY_RESULT_REQUIRED');
 const live=createGenesisLiveR5({entryResult,seed:state.meta?.seed||'EMR',players:state.session.players,...(config?{config}:{})});
 live.entryProvenance={schema:'EMR_GENESIS_ENTRY_PROVENANCE_R53_v1',signature:clone(entryResult.signature),counts:clone(entryResult.counts),mode:entryResult.mode,soloEmergence:entryResult.soloEmergence?clone(entryResult.soloEmergence):null};
 state.session.genesisR5=live;
 state.session.boot??={};
 state.session.boot.ci03Result=clone(entryResult);
 state.session.boot.phase='GENESIS_ACTIVE';
 state.eventLog??=[];
 state.eventLog.push({type:'CI03_R53_TO_GENESIS_LIVE',gameTime:state.meta?.gameTime??0,signature:clone(entryResult.signature),choices:[...entryResult.choices],mode:entryResult.mode});
 return live;
}
