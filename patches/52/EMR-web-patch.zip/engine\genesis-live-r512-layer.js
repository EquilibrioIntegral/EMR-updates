import {chooseAutonomousAgencyOptionR59} from './genesis-autonomous-agencies-r59.js';
import * as r511 from './genesis-live-r511-layer.js';
import {runtimeAgencyR5} from './genesis-runtime-r5.js';
import {composeGenesisSharedDecisionR512,narrativeAgencyRefR512} from './genesis-guionista-r512.js';
import {GENESIS_INVISIBLE_WORLD_DECISION,invisibleWorldOptionsR512,applyInvisibleWorldOptionR512,invisibleWorldProjectionR512} from './genesis-invisible-world-r512.js';

const clone=x=>structuredClone(x);

export function createGenesisLiveR5(args={}){
 const live=r511.createGenesisLiveR5(args);
 live.invisibleWorldPolicy={decisionId:GENESIS_INVISIBLE_WORLD_DECISION,mode:'CAUSAL_CONTEXTUAL',worldTruthSeparateFromCulture:true,playerFacingWorldEditor:false,humanValidation:'PENDING'};
 live.history.push({type:'GEN_R512_INVISIBLE_WORLD_POLICY_ACTIVE',decisionId:GENESIS_INVISIBLE_WORLD_DECISION,mode:'CAUSAL_CONTEXTUAL',humanValidation:'PENDING'});
 return live;
}

export function deserializeGenesisLiveR5(json){
 const live=r511.deserializeGenesisLiveR5(json);
 live.invisibleWorldPolicy??={decisionId:GENESIS_INVISIBLE_WORLD_DECISION,mode:'CAUSAL_CONTEXTUAL',worldTruthSeparateFromCulture:true,playerFacingWorldEditor:false,humanValidation:'PENDING'};
 return live;
}

export function liveAgencyOptionsR5(live){
 const base=r511.liveAgencyOptionsR5(live);
 if(live?.phase!=='AGENCY_ACTIONS')return base;
 const player=live.players?.[live.actorIndex];if(!player)return base;
 const agency=runtimeAgencyR5(live.runtime,player.id);
 const invisible=invisibleWorldOptionsR512(live,agency);
 if(!invisible.length)return base;
 const merged=new Map();for(const o of [...invisible,...base])merged.set(o.id,o);
 return[...merged.values()];
}

export function simulatedAgencyDecisionR59(live){
 if(live?.phase==='AGENCY_ACTIONS'){
  const p=live.players?.[live.actorIndex];
  if(p?.controller==='APP'){
   const agency=runtimeAgencyR5(live.runtime,p.id),invisible=invisibleWorldOptionsR512(live,agency);
   if(invisible.length){const option=clone(chooseAutonomousAgencyOptionR59(live,invisible));return{playerId:p.id,playerName:p.name,nature:p.nature,option,controller:'APP',movement:{from:p.position||p.spawn?.cell,to:p.position||p.spawn?.cell,distance:0,limit:0,nonSpatial:true},spatialDecisionId:'D-GEN-R5.12-INVISIBLE-WORLD01'};}
  }
 }
 return r511.simulatedAgencyDecisionR59(live);
}

export const capabilityDebugProjectionR511=r511.capabilityDebugProjectionR511;
export {invisibleWorldProjectionR512};

export function applyLiveAgencyOptionR5(live,optionId){
 const actingPlayer=live?.players?.[live.actorIndex]?clone(live.players[live.actorIndex]):null;
 if(!actingPlayer)throw new Error('GEN_LIVE_R5_ACTION_PHASE');
 const agency=runtimeAgencyR5(live.runtime,actingPlayer.id);
 const invisible=invisibleWorldOptionsR512(live,agency).find(o=>o.id===optionId);
 const next=invisible?applyInvisibleLiveOptionR512(live,actingPlayer,agency,invisible):r511.applyLiveAgencyOptionR5(live,optionId);
 if(!invisible)personalizeLatestAgencyNarrativeR512(next,actingPlayer.id);
 projectIdentityAwareSharedFrameR512(next);
 return next;
}

function applyInvisibleLiveOptionR512(live,player,agency,option){
 const seed=clone(live),producerEntityId=agency.volitionEntityId||agency.mysticForceId||null;
 seed.runtime=applyInvisibleWorldOptionR512(seed.runtime,{option,playerId:player.id,producerEntityId,round:seed.round});
 seed.history??=[];seed.history.push({type:'GEN_LIVE_R512_INVISIBLE_WORLD_CHOICE',round:seed.round,playerId:player.id,controller:player.controller,agencyId:agency.id,producerEntityId,optionId:option.id,primitive:option.primitive,mode:option.mode||null,decisionId:GENESIS_INVISIBLE_WORLD_DECISION});
 seed.narrativeLog??=[];seed.narrativeLog.push({round:seed.round,kind:'INVISIBLE_WORLD_ESTABLISHED',publicText:option.publicText});seed.currentNarrative=option.publicText;
 // Reuse the proven R5.11 actor-advance/batch machinery without adding a second
 // competing turn engine. WAIT is only an internal carrier and is removed below.
 const next=r511.applyLiveAgencyOptionR5(seed,'WAIT');
 const h=[...(next.history||[])];for(let i=h.length-1;i>=0;i--){const e=h[i];if(e.type==='GEN_LIVE_R5_AGENCY_CHOICE'&&e.playerId===player.id&&e.round===live.round&&e.optionId==='WAIT'){h.splice(i,1);break;}}next.history=h;
 const nl=[...(next.narrativeLog||[])];for(let i=nl.length-1;i>=0;i--){const e=nl[i];if(e.kind==='AGENCY_CHOICE'&&e.round===live.round&&/decide no intervenir/i.test(e.publicText||'')){nl.splice(i,1);break;}}next.narrativeLog=nl;
 if(next.phase==='AGENCY_ACTIONS')next.currentNarrative=option.publicText;
 return next;
}

function projectIdentityAwareSharedFrameR512(next){
 if(next?.phase!=='PHYSICAL_INTENTION_CHOICE'||!next.contextual)return;
 const frame=composeGenesisSharedDecisionR512(next);
 next.contextual.narrative=clone(frame.narrative);
 next.contextual.narrativeActors=clone(frame.narrativeActors||[]);
 next.contextual.narrativeIdentitySchema=frame.narrativeIdentitySchema||null;
 const relation=next.contextual.options?.find(o=>o.effect==='VOLITION_RELATION');
 const namedRelation=frame.options?.find(o=>o.effect==='VOLITION_RELATION');
 if(relation&&namedRelation){relation.attempt=namedRelation.attempt;relation.narrativeActors=clone(namedRelation.narrativeActors||[]);}
 if(next.contextual.narrative?.publicText){
  next.currentNarrative=next.contextual.narrative.publicText;
  const last=[...(next.narrativeLog||[])].reverse().find(x=>x.kind==='JOINT_INTENTION_FRAME'&&x.round===next.round);
  if(last)last.publicText=next.contextual.narrative.publicText;
 }
 next.history??=[];
 next.history.push({type:'GEN_R512_NARRATIVE_IDENTITIES_PROJECTED',round:next.round,actors:clone(frame.narrativeActors||[]),schema:frame.narrativeIdentitySchema||null});
}

function personalizeLatestAgencyNarrativeR512(live,playerId){
 const ref=narrativeAgencyRefR512(live,playerId);
 const player=(live?.players||[]).find(p=>p.id===playerId);
 if(!player||!ref)return;
 const subject=ref.charAt(0).toUpperCase()+ref.slice(1);
 const personalize=text=>String(text||'')
  .replace(/(?:El jugador|La app) hace actuar a (?:una Voluntad|un principio místico|una fuerza física) \([^)]*\):/,`${subject} actúa:`)
  .replace(/(?:una Voluntad|un principio místico|una fuerza física) \([^)]*\)/,ref);
 const last=[...(live.narrativeLog||[])].reverse().find(x=>x.kind==='AGENCY_CHOICE'&&x.round===live.round);
 if(last)last.publicText=personalize(last.publicText);
 if(live.currentNarrative)live.currentNarrative=personalize(live.currentNarrative);
}
