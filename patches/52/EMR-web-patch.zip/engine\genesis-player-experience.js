// GEN-UX-01 — player-facing orchestration for the physical Genesis loop.
// It composes canonical resolvers; it does not decide causal authority.
import {createGenesisState} from './primordial-signature.js';
import {createGravityPhysicalState} from './primordial-gravity.js';
import {createGenesisPhysicalBridge,moveEmbodiedPawn,performPhysicalAgencyAction,convergeGenesis,compileGenesisPhysicalHandoff} from './genesis-physical-bridge.js';

const clone=x=>structuredClone(x);
const LABELS={PHYSICS:'realidad física',MYSTIC:'realidad sobrenatural sin voluntad',WILL:'voluntad primordial'};
const INTENTION_LABELS={CONCENTRATE:'concentrar',TRANSFORM:'transformar',PRESERVE:'preservar'};
const SESSION_VERSION='EMR_GENESIS_PLAYER_SESSION_v1';

export function createGenesisPlayerSession({signature,primordialChoices,pawns,gravity,convergenceBudget=3}={}){
 const genesis=createGenesisState({signature,primordialChoices,pawns,convergenceBudget});
 return {version:SESSION_VERSION,phase:'INDIVIDUAL_ACTIONS',bridge:createGenesisPhysicalBridge({genesis,gravity:createGravityPhysicalState(gravity)}),secretIntentions:{},revealedIntentions:null,visible:[{title:'El primer despertar',text:`La realidad ha despertado. ${primordialChoices.length} fuerzas primordiales pueden actuar sobre la materia.`,screenRole:'BRIEF_THEN_TABLE'}],hiddenMemory:[],narrative:[]};
}
export function getGenesisPlayerView(session){
 const v={phase:session.phase,visible:clone(session.visible),narrative:clone(session.narrative)};
 if(session.revealedIntentions)v.intentions=clone(session.revealedIntentions);
 return v;
}
export function exportGenesisPlayerSession(session){validatePortableSession(session);return JSON.stringify(session);}
export function importGenesisPlayerSession(payload){let parsed;try{parsed=typeof payload==='string'?JSON.parse(payload):clone(payload);}catch{throw new Error('GEN_SAVE_INVALID_JSON');}validatePortableSession(parsed);return clone(parsed);}
function validatePortableSession(session){if(!session||session.version!==SESSION_VERSION)throw new Error('GEN_SAVE_VERSION_UNSUPPORTED');if(!session.phase||!session.bridge?.genesis||!session.bridge?.gravity||!session.secretIntentions||!Array.isArray(session.hiddenMemory)||!Array.isArray(session.narrative))throw new Error('GEN_SAVE_INVALID');return true;}
export function moveGenesisPawn(session,input){const n=clone(session);n.bridge=moveEmbodiedPawn(n.bridge,input);n.visible=[{text:`Mueve tu peón una posición y vuelve a la mesa.`,screenRole:'BRIEF_THEN_TABLE'}];return n;}
export function actGenesisPlayer(session,input){const n=clone(session);const r=performPhysicalAgencyAction(n.bridge,input);n.bridge=r.bridge;n.visible=[{text:naturalizeInstruction(r.instruction.text),screenRole:'BRIEF_THEN_TABLE'}];n.hiddenMemory.push({kind:'ACTION',playerId:input.playerId,nature:n.bridge.genesis.players.find(p=>p.id===input.playerId)?.nature,action:input.action,targetId:input.targetId});return n;}
export function submitSecretIntention(session,{playerId,intention}){const n=clone(session);if(!n.bridge.genesis.players.some(p=>p.id===playerId))throw new Error('GEN_PLAYER_UNKNOWN');if(!INTENTION_LABELS[intention])throw new Error('GEN_INTENTION_INVALID');n.secretIntentions[playerId]=intention;n.phase=Object.keys(n.secretIntentions).length===n.bridge.genesis.players.length?'READY_TO_REVEAL':'SECRET_INTENTIONS';n.visible=[{text:'Elige tu Intención en secreto. No la muestres todavía.',screenRole:'PRIVATE_BRIEF'}];return n;}
export function revealGenesisIntentions(session){const n=clone(session);if(Object.keys(n.secretIntentions).length!==n.bridge.genesis.players.length)throw new Error('GEN_VOTES_INCOMPLETE');n.revealedIntentions=n.bridge.genesis.players.map(p=>({playerId:p.id,intention:n.secretIntentions[p.id],text:INTENTION_LABELS[n.secretIntentions[p.id]]}));n.phase='CONVERGENCE';n.visible=[{text:`Revelad a la vez: ${n.revealedIntentions.map(x=>`${x.playerId} quiere ${x.text}`).join('; ')}.`,screenRole:'BRIEF_THEN_TABLE'}];return n;}
export function resolveGenesisPlayerConvergence(session,{subjectId,uncertaintyRoll=null,contextByPlayer={},exceptionsByPlayer={}}={}){
 const n=clone(session);if(!n.revealedIntentions)throw new Error('GEN_INTENTIONS_NOT_REVEALED');
 const votes=n.revealedIntentions.map(x=>({playerId:x.playerId,intention:x.intention,context:contextByPlayer[x.playerId]??0,...(exceptionsByPlayer[x.playerId]?{exception:exceptionsByPlayer[x.playerId]}:{})}));
 const r=convergeGenesis(n.bridge,{votes,subjectId,uncertaintyRoll});n.bridge=r.bridge;
 const text=narrateConvergence(r.result,n.bridge.genesis);
 n.narrative.push(text);n.visible=[{text,screenRole:'NARRATE_THEN_TABLE'}];n.hiddenMemory.push({kind:'CONVERGENCE',subjectId,result:clone(r.result)});n.secretIntentions={};n.revealedIntentions=null;n.phase=n.bridge.genesis.closed?'GENESIS_CLOSED':'INDIVIDUAL_ACTIONS';return n;
}
export function closeGenesisPlayerSession(session){const n=clone(session);if(!n.bridge.genesis.closed)throw new Error('GENESIS_OPEN');const handoff=compileGenesisPhysicalHandoff(n.bridge);n.phase='BOOT01_READY';n.visible=[{text:'La primera forma del mundo ha quedado fijada. Lo ocurrido aquí seguirá teniendo consecuencias.',screenRole:'BRIEF_THEN_TABLE'}];return{session:n,handoff,hiddenMemory:clone(n.hiddenMemory)};}
function naturalizeInstruction(text=''){return String(text).replace(/\bCORE\+FRAG\b/g,'los cuerpos vinculados').replace(/\bCORE\b/g,'el cuerpo central').replace(/\bFRAG\b/g,'el fragmento próximo').replace(/\bARC\b/g,'el fragmento exterior');}
function narrateConvergence(result,state){
 const winners=result.winners.map(id=>state.players.find(p=>p.id===id)).filter(Boolean);const kinds=[...new Set(winners.map(p=>LABELS[p.nature]))];
 let text=result.composition.length?`Las fuerzas no se anulan: sus impulsos se combinan y la materia conserva huellas de todos ellos.`:`Las fuerzas chocan. ${kinds.join(' y ')} impone la dirección principal, pero lo rechazado deja una huella en el mundo.`;
 if(result.exceptions?.length)text+=' Algo más débil no detiene la causa dominante, pero consigue preservar una excepción estrecha que podrá importar después.';
 if(result.dieUsed)text+=' Ninguna causa bastaba por sí sola; el desenlace dependió de una incertidumbre real.';
 return text;
}
