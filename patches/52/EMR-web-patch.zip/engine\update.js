export function parseVersion(v='0.0.0') {
  return String(v).replace(/^v/i,'').split('.').map(x=>Number.parseInt(x,10)||0).slice(0,3).concat([0,0,0]).slice(0,3);
}

export function compareVersions(a,b) {
  const av=parseVersion(a), bv=parseVersion(b);
  for(let i=0;i<3;i++) if(av[i]!==bv[i]) return av[i]>bv[i]?1:-1;
  return 0;
}

export function validateUpdateManifest(m) {
  if(!m || typeof m!=='object') throw new Error('UPDATE_MANIFEST_INVALID');
  for(const key of ['version','build','apkUrl','sha256']) if(!m[key]) throw new Error(`UPDATE_MANIFEST_MISSING:${key}`);
  if(!/^[a-f0-9]{64}$/i.test(m.sha256)) throw new Error('UPDATE_MANIFEST_SHA256_INVALID');
  if(!/^https:\/\//i.test(m.apkUrl)) throw new Error('UPDATE_MANIFEST_URL_INVALID');
  return m;
}

export function validatePatchManifest(m) {
  if(!m || typeof m!=='object') throw new Error('PATCH_MANIFEST_INVALID');
  if(m.type!=='web-patch') throw new Error('PATCH_MANIFEST_TYPE_INVALID');
  for(const key of ['version','build','sequence','sha256']) if(m[key]===undefined || m[key]===null || m[key]==='') throw new Error(`PATCH_MANIFEST_MISSING:${key}`);
  if(!Number.isInteger(Number(m.sequence)) || Number(m.sequence)<1) throw new Error('PATCH_MANIFEST_SEQUENCE_INVALID');
  if(!/^[a-f0-9]{64}$/i.test(m.sha256)) throw new Error('PATCH_MANIFEST_SHA256_INVALID');
  const hasUrl=typeof m.url==='string' && /^https:\/\//i.test(m.url);
  const hasParts=Array.isArray(m.base64Parts) && m.base64Parts.length>0 && m.base64Parts.every(x=>typeof x==='string' && /^https:\/\//i.test(x));
  if(!hasUrl && !hasParts) throw new Error('PATCH_MANIFEST_TRANSPORT_INVALID');
  if(m.minNativeVersionCode!=null && (!Number.isInteger(Number(m.minNativeVersionCode)) || Number(m.minNativeVersionCode)<1)) throw new Error('PATCH_MANIFEST_NATIVE_BASE_INVALID');
  return m;
}

export function updateAvailable(currentVersion, manifest) {
  validateUpdateManifest(manifest);
  return compareVersions(manifest.version,currentVersion)>0;
}

export function patchAvailable(currentSequence=0, manifest) {
  validatePatchManifest(manifest);
  return Number(manifest.sequence)>Number(currentSequence||0);
}
