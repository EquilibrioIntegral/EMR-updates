// R5.12 — Invisible-world causal primitives for Genesis.
// Genesis establishes objective metaphysical truth; later cultures may discover,
// distort, deny or mythologize it. No religion, sin, heaven/hell or doctrine is
// created here. Only engine-level truth with provenance and future consumers.

export const GENESIS_INVISIBLE_WORLD_R512_SCHEMA='EMR_GENESIS_INVISIBLE_WORLD_R512_v1';
export const GENESIS_INVISIBLE_WORLD_DECISION='D-GEN-R5.12-INVISIBLE-WORLD01';

const clone=x=>structuredClone(x);
const IW_PREFIX='IW:';

export function invisibleWorldOptionsR512(live,agency){
 if(live?.phase!=='AGENCY_ACTIONS'||!agency?.nature)return[];
 const o=live.runtime?.ontology;if(!o)return[];
 const kinds=appliedKinds(live.runtime),cm=o.consciousnessMetaphysics||{},nm=o.normativeMetaphysics||{},out=[];
 const add=(priority,row)=>out.push({schema:GENESIS_INVISIBLE_WORLD_R512_SCHEMA,decisionId:GENESIS_INVISIBLE_WORLD_DECISION,kind:'INVISIBLE_WORLD_PRIMITIVE',nonSpatial:true,spatial:{presence:'NON_SPATIAL'},priority,...row});
 const bridge=kinds.has('BRIDGE_CONSCIOUSNESS_MATTER'),persistenceTrace=kinds.has('IMPRINT')||kinds.has('CONDITIONAL_TRANSFORM'),cycle=kinds.has('CYCLE_ENTANGLE'),willMysticLinked=hasWillMysticEdge(o,agency);

 if(agency.nature==='MYSTIC'){
  if(bridge&&!isEstablished(cm.materialInvisiblePermeability))add(100,{id:`${IW_PREFIX}MATERIAL_INVISIBLE_PERMEABILITY`,primitive:'MATERIAL_INVISIBLE_PERMEABILITY',label:'Hacer permeable la frontera entre materia y realidad invisible',hint:'La posibilidad existe porque ya se abrió un puente causal entre conciencia y materia.',publicText:'La materia deja de ser una frontera absoluta. Algo no material podrá atravesarla bajo condiciones concretas.'});
  if(bridge&&persistenceTrace&&isEstablished(cm.materialInvisiblePermeability)&&!isEstablished(cm.postMortemPersistence)){
   add(95,{id:`${IW_PREFIX}POST_MORTEM_PERSISTENCE`,primitive:'POST_MORTEM_PERSISTENCE',label:'Permitir que una conciencia pueda persistir sin su soporte material',hint:'La continuidad necesita un puente previo y una huella capaz de persistir.',publicText:'Queda establecida una posibilidad nueva: una conciencia podrá sobrevivir a la pérdida del soporte material que la contenía.'});
   add(95,{id:`${IW_PREFIX}POST_MORTEM_DISSOLUTION`,primitive:'POST_MORTEM_DISSOLUTION',label:'Hacer que la conciencia termine al perder su soporte material',hint:'La frontera invisible existe, pero la conciencia no tiene por qué sobrevivir al soporte que la sostuvo.',publicText:'Queda fijado un límite: cuando una conciencia pierda definitivamente su soporte material, su continuidad se disolverá.'});
  }
  if(allowsPersistence(cm)&&!cm.memoryContinuity){
   add(90,{id:`${IW_PREFIX}MEMORY_CONTINUITY:PRESERVED`,primitive:'MEMORY_CONTINUITY',mode:'PRESERVED',label:'Conservar la memoria a través de la continuidad',hint:'La continuidad de identidad podrá transportar recuerdo.',publicText:'La continuidad podrá conservar memoria de una existencia a otra.'});
   add(90,{id:`${IW_PREFIX}MEMORY_CONTINUITY:LOST`,primitive:'MEMORY_CONTINUITY',mode:'LOST_BETWEEN_TRANSITIONS',label:'Separar continuidad y recuerdo',hint:'La identidad puede continuar aunque el recuerdo no atraviese la transición.',publicText:'La continuidad no conservará necesariamente el recuerdo: una conciencia podrá persistir y, aun así, olvidar.'});
  }
  if(allowsPersistence(cm)&&cm.memoryContinuity&&cycle&&!isEstablished(cm.rebirthAllowed)){
   add(85,{id:`${IW_PREFIX}REBIRTH_ALLOWED`,primitive:'REBIRTH_ALLOWED',label:'Permitir que una conciencia persistente pueda unirse a un nuevo soporte',hint:'Solo aparece porque ya existen continuidad y un ciclo causal capaz de enlazar estados.',publicText:'La continuidad invisible adquiere una salida material: una conciencia persistente podrá, bajo condiciones futuras, unirse de nuevo a un soporte.'});
   add(85,{id:`${IW_PREFIX}REBIRTH_FORBIDDEN`,primitive:'REBIRTH_FORBIDDEN',label:'Impedir que una conciencia persistente vuelva a unirse a la materia',hint:'La conciencia puede persistir sin que eso implique retorno material.',publicText:'La continuidad invisible queda separada del retorno material: persistir no permitirá volver a encarnarse en un nuevo soporte.'});
  }
 }

 if(agency.nature==='WILL'&&allowsPersistence(cm)&&willMysticLinked&&!isEstablished(nm.moralCausality)){
  add(80,{id:`${IW_PREFIX}MORAL_CAUSALITY_EXISTS`,primitive:'MORAL_CAUSALITY_EXISTS',label:'Vincular las consecuencias de los actos a la continuidad de la conciencia',hint:'No crea pecado ni doctrina. Crea una causalidad objetiva entre conducta y consecuencias futuras.',publicText:'Los actos dejan de terminar por completo en el instante en que se realizan. Algunas consecuencias podrán seguir a la conciencia más allá de una sola existencia material.'});
  add(80,{id:`${IW_PREFIX}MORAL_CAUSALITY_ABSENT`,primitive:'MORAL_CAUSALITY_ABSENT',label:'Mantener separadas conducta y continuidad invisible',hint:'No existirán recompensas o castigos metafísicos automáticos derivados de la conducta.',publicText:'La continuidad invisible no juzgará por sí misma. Los actos podrán tener consecuencias materiales y sociales, pero no una retribución metafísica automática.'});
 }
 if(agency.nature==='WILL'&&hasMoralCausality(nm)&&!isEstablished(nm.judgmentMechanism)){
  if(agency.volitionEntityId)add(75,{id:`${IW_PREFIX}JUDGMENT_AUTHORITY:${agency.volitionEntityId}`,primitive:'JUDGMENT_AUTHORITY',producerEntityId:agency.volitionEntityId,label:'Asumir autoridad causal de evaluación sobre esa continuidad',hint:'No crea culto ni religión. Registra quién puede intervenir objetivamente en esa evaluación.',publicText:'Una Voluntad asume una autoridad limitada sobre la evaluación causal de ciertas continuidades conscientes.'});
  add(75,{id:`${IW_PREFIX}IMPERSONAL_NORMATIVE_MECHANISM`,primitive:'IMPERSONAL_NORMATIVE_MECHANISM',label:'Hacer impersonal la evaluación causal',hint:'Las consecuencias no dependerán del juicio de una deidad concreta.',publicText:'La evaluación causal queda incorporada al funcionamiento invisible del mundo y no depende del juicio de una Voluntad concreta.'});
 }
 return out.sort((a,b)=>b.priority-a.priority||a.id.localeCompare(b.id));
}

export function applyInvisibleWorldOptionR512(runtime,{option,playerId=null,producerEntityId=null,round=null}={}){
 if(!runtime?.ontology||!option?.primitive)throw new Error('GEN_R512_INVISIBLE_WORLD_ACTION_REQUIRED');
 const next=clone(runtime),o=next.ontology;
 o.consciousnessMetaphysics??={status:'UNDETERMINED',mechanisms:[],conditions:[],producerIds:[]};
 o.normativeMetaphysics??={status:'UNDETERMINED',sources:[],effects:[]};
 o.objectiveSupernaturalFacts??=[];o.hiddenGenesisFacts??=[];o.futureHooks??=[];
 const producer=producerEntityId||option.producerEntityId||null,primitive=option.primitive;
 const factId=`FACT-IW-${primitive}${primitive==='JUDGMENT_AUTHORITY'&&producer?`-${producer}`:''}`;
 if(o.objectiveSupernaturalFacts.some(f=>f.factId===factId||f.primitive===primitive&&primitive!=='JUDGMENT_AUTHORITY'))throw new Error('GEN_R512_INVISIBLE_WORLD_ALREADY_ESTABLISHED');

 if(primitive==='MATERIAL_INVISIBLE_PERMEABILITY'){
  o.consciousnessMetaphysics.status='ESTABLISHED_PARTIAL';o.consciousnessMetaphysics.materialInvisiblePermeability={status:'ESTABLISHED',mode:'CONDITIONAL'};pushUnique(o.consciousnessMetaphysics.mechanisms,'MATERIAL_INVISIBLE_BRIDGE');
 }
 else if(primitive==='POST_MORTEM_PERSISTENCE'||primitive==='POST_MORTEM_DISSOLUTION'){
  requireEstablished(o.consciousnessMetaphysics.materialInvisiblePermeability,'GEN_R512_PERMEABILITY_REQUIRED');if(isEstablished(o.consciousnessMetaphysics.postMortemPersistence))throw new Error('GEN_R512_POST_MORTEM_ALREADY_DEFINED');
  o.consciousnessMetaphysics.status='ESTABLISHED_PARTIAL';o.consciousnessMetaphysics.postMortemPersistence={status:'ESTABLISHED',mode:primitive==='POST_MORTEM_PERSISTENCE'?'POSSIBLE_NOT_AUTOMATIC':'DISSOLVES_WITH_MATERIAL_SUPPORT'};
  pushUnique(o.consciousnessMetaphysics.mechanisms,primitive==='POST_MORTEM_PERSISTENCE'?'CONSCIOUSNESS_CAN_PERSIST_WITHOUT_CURRENT_MATERIAL_SUPPORT':'CONSCIOUSNESS_ENDS_WITH_CURRENT_MATERIAL_SUPPORT');
 }
 else if(primitive==='MEMORY_CONTINUITY'){
  requirePersistence(o.consciousnessMetaphysics);if(o.consciousnessMetaphysics.memoryContinuity)throw new Error('GEN_R512_MEMORY_CONTINUITY_ALREADY_DEFINED');
  const mode=option.mode||'PRESERVED';o.consciousnessMetaphysics.memoryContinuity={status:'ESTABLISHED',mode};pushUnique(o.consciousnessMetaphysics.conditions,`MEMORY_CONTINUITY:${mode}`);
 }
 else if(primitive==='REBIRTH_ALLOWED'||primitive==='REBIRTH_FORBIDDEN'){
  requirePersistence(o.consciousnessMetaphysics);if(isEstablished(o.consciousnessMetaphysics.rebirthAllowed))throw new Error('GEN_R512_REBIRTH_ALREADY_DEFINED');
  o.consciousnessMetaphysics.rebirthAllowed={status:'ESTABLISHED',mode:primitive==='REBIRTH_ALLOWED'?'CONDITIONAL':'FORBIDDEN'};
  pushUnique(o.consciousnessMetaphysics.mechanisms,primitive==='REBIRTH_ALLOWED'?'CONSCIOUSNESS_CAN_ATTACH_TO_NEW_MATERIAL_SUPPORT':'CONSCIOUSNESS_CANNOT_REATTACH_TO_MATERIAL_SUPPORT');
 }
 else if(primitive==='MORAL_CAUSALITY_EXISTS'||primitive==='MORAL_CAUSALITY_ABSENT'){
  requirePersistence(o.consciousnessMetaphysics);if(isEstablished(o.normativeMetaphysics.moralCausality))throw new Error('GEN_R512_MORAL_CAUSALITY_ALREADY_DEFINED');
  o.normativeMetaphysics.status='ESTABLISHED_PARTIAL';o.normativeMetaphysics.moralCausality={status:'ESTABLISHED',mode:primitive==='MORAL_CAUSALITY_EXISTS'?'OBJECTIVE_CAUSAL_EFFECT':'ABSENT'};
  pushUnique(o.normativeMetaphysics.effects,primitive==='MORAL_CAUSALITY_EXISTS'?'ACTION_CONSEQUENCES_CAN_FOLLOW_CONSCIOUSNESS':'NO_AUTOMATIC_METAPHYSICAL_RETRIBUTION');
 }
 else if(primitive==='JUDGMENT_AUTHORITY'||primitive==='IMPERSONAL_NORMATIVE_MECHANISM'){
  requireMoralCausality(o.normativeMetaphysics);if(isEstablished(o.normativeMetaphysics.judgmentMechanism))throw new Error('GEN_R512_JUDGMENT_MECHANISM_ALREADY_DEFINED');
  o.normativeMetaphysics.status='ESTABLISHED_PARTIAL';
  if(primitive==='JUDGMENT_AUTHORITY'){
   if(!producer)throw new Error('GEN_R512_JUDGMENT_PRODUCER_REQUIRED');o.normativeMetaphysics.judgmentMechanism={status:'ESTABLISHED',mode:'VOLITION_AUTHORITY'};o.normativeMetaphysics.judgmentAuthority={status:'ESTABLISHED',producerEntityId:producer,scope:'LIMITED_CAUSAL_EVALUATION'};pushUnique(o.normativeMetaphysics.sources,producer);
  }else{o.normativeMetaphysics.judgmentMechanism={status:'ESTABLISHED',mode:'IMPERSONAL'};pushUnique(o.normativeMetaphysics.sources,'IMPERSONAL_INVISIBLE_CAUSALITY');}
 }
 else throw new Error('GEN_R512_INVISIBLE_WORLD_PRIMITIVE_UNKNOWN');

 if(producer&&['MATERIAL_INVISIBLE_PERMEABILITY','POST_MORTEM_PERSISTENCE','POST_MORTEM_DISSOLUTION','MEMORY_CONTINUITY','REBIRTH_ALLOWED','REBIRTH_FORBIDDEN'].includes(primitive))pushUnique(o.consciousnessMetaphysics.producerIds,producer);
 if(producer&&['MORAL_CAUSALITY_EXISTS','MORAL_CAUSALITY_ABSENT'].includes(primitive))pushUnique(o.normativeMetaphysics.sources,producer);
 const fact={factId,type:'INVISIBLE_WORLD_PRIMITIVE_ESTABLISHED',primitive,mode:option.mode||null,producerEntityId:producer,playerId,round,visibility:'ENGINE_ONLY',culturalDoctrineCreated:false};
 o.objectiveSupernaturalFacts.push(clone(fact));o.hiddenGenesisFacts.push(clone(fact));
 const hook={hookId:`HOOK-${factId}`,sourceFactId:factId,type:'INVISIBLE_WORLD_CONSEQUENCE',consumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME'],visibility:'ENGINE_ONLY',status:'AVAILABLE'};o.futureHooks.push(hook);
 next.eventLog??=[];next.eventLog.push({type:'GEN_R512_INVISIBLE_WORLD_ESTABLISHED',decisionId:GENESIS_INVISIBLE_WORLD_DECISION,...clone(fact),hookId:hook.hookId});return next;
}

export function invisibleWorldProjectionR512(runtime){
 const o=runtime?.ontology||{};
 return{schema:GENESIS_INVISIBLE_WORLD_R512_SCHEMA,consciousnessMetaphysics:clone(o.consciousnessMetaphysics||null),normativeMetaphysics:clone(o.normativeMetaphysics||null),objectivePrimitives:(o.objectiveSupernaturalFacts||[]).filter(f=>f.type==='INVISIBLE_WORLD_PRIMITIVE_ESTABLISHED').map(f=>f.primitive),religionsCreated:false,cultsCreated:false,sinAsSocialConceptCreated:false,culturalLabelsCreated:false};
}

function appliedKinds(runtime){return new Set((runtime?.eventLog||[]).filter(e=>e.type==='GEN_R511_CAPABILITY_APPLIED').map(e=>e.kind));}
function hasWillMysticEdge(o,agency){const edges=o?.willMysticGraph?.edges||[];return edges.some(e=>!agency?.volitionEntityId||e.volitionEntityId===agency.volitionEntityId);}
function isEstablished(x){return x?.status==='ESTABLISHED';}
function allowsPersistence(cm){return isEstablished(cm?.postMortemPersistence)&&cm.postMortemPersistence.mode!=='DISSOLVES_WITH_MATERIAL_SUPPORT';}
function hasMoralCausality(nm){return isEstablished(nm?.moralCausality)&&nm.moralCausality.mode==='OBJECTIVE_CAUSAL_EFFECT';}
function requireEstablished(x,error){if(!isEstablished(x))throw new Error(error);}
function requirePersistence(cm){if(!allowsPersistence(cm))throw new Error('GEN_R512_POST_MORTEM_PERSISTENCE_REQUIRED');}
function requireMoralCausality(nm){if(!hasMoralCausality(nm))throw new Error('GEN_R512_MORAL_CAUSALITY_REQUIRED');}
function pushUnique(xs,v){if(!Array.isArray(xs))return;if(!xs.includes(v))xs.push(v);}
