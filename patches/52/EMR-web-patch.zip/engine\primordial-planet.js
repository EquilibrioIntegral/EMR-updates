const clone=x=>JSON.parse(JSON.stringify(x));

// R3.2: a planet is not created by a round counter. It must be a BODY whose
// physical history has actually accumulated the minimum formation evidence.
// These are app-owned facts; the table only materializes bodies and actions.
const REQUIRED_FORMATION_TAGS=Object.freeze(['NUCLEO_DENSO','MATERIA_ENFRIADA']);
const SUPPORTING_FORMATION_TAGS=Object.freeze(['ORBITAS_ESTABLES','MATERIA_DISTRIBUIDA']);
const FORMATIVE_OUTCOMES=new Set(['CLEAN_SUCCESS','SUCCESS_WITH_COST']);

function physicalDeltasFor(state,bodyId){
 return (state.deltas||[]).filter(d=>d.targetEntityId===bodyId&&d.consumer==='BOOT01_FORMACION_MUNDO'&&FORMATIVE_OUTCOMES.has(d.outcome));
}

export function derivePrimordialPlanetCandidates(state){
 return Object.values(state.entities||{}).filter(e=>e.kind==='BODY').map(body=>{
  const deltas=physicalDeltasFor(state,body.id);
  const producedTags=new Set(deltas.map(d=>d.resultTag));
  const missing=REQUIRED_FORMATION_TAGS.filter(tag=>!producedTags.has(tag));
  const hasMatter=(body.tags||[]).includes('MATTER')||deltas.length>0;
  const causalSourceIds=deltas.map(d=>d.id);
  return {id:body.id,name:body.name??null,eligible:hasMatter&&missing.length===0,missingFormationTags:missing,formationTags:[...producedTags].filter(t=>REQUIRED_FORMATION_TAGS.includes(t)||SUPPORTING_FORMATION_TAGS.includes(t)),causalSourceIds,x:body.x,y:body.y};
 }).filter(x=>x.eligible).sort((a,b)=>a.id.localeCompare(b.id));
}

export function reconcilePrimordialPlanetSelection(state){
 const s=clone(state); const candidates=derivePrimordialPlanetCandidates(s);
 if(s.selectedPlanetId&&!candidates.some(c=>c.id===s.selectedPlanetId)) s.selectedPlanetId=null;
 if(!s.selectedPlanetId&&candidates.length===1) s.selectedPlanetId=candidates[0].id;
 s.planetCandidates=candidates.map(c=>c.id);
 return s;
}

export function selectPrimordialPlanet(state,{planetId}={}){
 const s=reconcilePrimordialPlanetSelection(state); const candidates=derivePrimordialPlanetCandidates(s);
 if(!candidates.some(c=>c.id===planetId)) throw new Error('PRIMORDIAL_PLANET_NOT_ELIGIBLE');
 s.selectedPlanetId=planetId;s.planetCandidates=candidates.map(c=>c.id);
 s.eventLog??=[];s.eventLog.push({id:`EV-${s.eventLog.length+1}`,turn:s.turn,type:'PRIMORDIAL_PLANET_SELECTED',payload:{planetId}});return s;
}

export function getPrimordialPlanetClosureStatus(state){
 const candidates=derivePrimordialPlanetCandidates(state);
 const selected=state.selectedPlanetId?candidates.find(c=>c.id===state.selectedPlanetId):candidates.length===1?candidates[0]:null;
 if(!candidates.length)return {ready:false,candidates:[],selectedPlanet:null,reasons:['NO_FORMED_PLANET']};
 if(candidates.length>1&&!selected)return {ready:false,candidates,reasons:['PLANET_SELECTION_REQUIRED'],selectedPlanet:null};
 return {ready:true,candidates,selectedPlanet:clone(selected),reasons:[]};
}
