import {axialDistance} from './genesis-board-r5.js';

export const GENESIS_SPATIAL_R510_SCHEMA='EMR_GENESIS_SPATIAL_R510_v1';
export const GENESIS_SPATIAL_R510_DECISION='D-GEN-R5.10-SPATIAL-AGENCY02';
export const GENESIS_AGENCY_MOVEMENT_R510=2;

/**
 * Revised spatial canon, 2026-09-12.
 * The meeple may still be repositioned up to two cells before acting: movement and
 * authority are different things. The causal reach of an available action, however,
 * scales directly with the agency's primordial intensity (1..6). An intensity-6
 * deity/force can therefore affect legal targets up to six hexes from its current
 * locus, provided the action's own semantic/domain gates also allow that target.
 * A capability may explicitly declare a lower remoteReach, which acts as a stricter cap.
 */
export function agencyMovementLimitR510(){return GENESIS_AGENCY_MOVEMENT_R510;}

export function intensitySpatialCeilingR510(intensity=1){return validateIntensity(intensity);}

export function declaredRemoteReachR510(option={}){
 const raw=option?.spatialCapability?.remoteReach??option?.remoteReach??option?.maxCausalDistance??null;
 if(raw==null)return null;
 const n=Number(raw);if(!Number.isInteger(n)||n<1)throw new Error('GEN_R510_REMOTE_REACH_INVALID');
 return n;
}

export function effectiveCausalReachR510({intensity=1,option={}}={}){
 const intensityReach=intensitySpatialCeilingR510(intensity),declared=declaredRemoteReachR510(option);
 return declared==null?intensityReach:Math.min(intensityReach,declared);
}

export function classifyAgencyPresenceR510({board,from,target,intensity=1,option={}}={}){
 if(!board?.cells?.length)throw new Error('GEN_R510_BOARD_REQUIRED');
 const a=cellFor(board,from),b=cellFor(board,target),distance=axialDistance(a,b),reach=effectiveCausalReachR510({intensity,option});
 const presence=distance===0?'DIRECT':distance===1?'ADJACENT':distance<=reach?'REMOTE':'OUT_OF_REACH';
 return{schema:GENESIS_SPATIAL_R510_SCHEMA,decisionId:GENESIS_SPATIAL_R510_DECISION,from:a.code,target:b.code,distance,presence,effectiveReach:reach,remoteCapabilityDeclared:declaredRemoteReachR510(option)!=null,intensityScaled:true};
}

export function targetIsSpatiallyLegalR510(args={}){return classifyAgencyPresenceR510(args).presence!=='OUT_OF_REACH';}

/** Actual topology reachability: no jumping across missing cells. */
export function reachableAgencyCellsR510(board,from,movement=GENESIS_AGENCY_MOVEMENT_R510){
 if(!board?.cells?.length)throw new Error('GEN_R510_BOARD_INVALID');
 if(!Number.isInteger(movement)||movement<0)throw new Error('GEN_R510_MOVEMENT_INVALID');
 const start=cellFor(board,from),byCoord=new Map(board.cells.map(c=>[`${c.q},${c.r}`,c])),seen=new Map([[start.code,0]]),queue=[start];
 while(queue.length){
  const current=queue.shift(),depth=seen.get(current.code);if(depth>=movement)continue;
  for(const [dq,dr] of HEX_DIRS){
   const next=byCoord.get(`${current.q+dq},${current.r+dr}`);if(!next||seen.has(next.code))continue;
   seen.set(next.code,depth+1);queue.push(next);
  }
 }
 return [...seen.entries()].map(([code,distance])=>({code,distance})).sort((a,b)=>a.distance-b.distance||a.code.localeCompare(b.code));
}

export function validateAgencyRepositionR510({board,from,to}={}){
 const reachable=reachableAgencyCellsR510(board,from);
 const hit=reachable.find(x=>x.code===to);if(!hit)throw new Error('GEN_R510_REPOSITION_OUT_OF_RANGE');
 return{schema:GENESIS_SPATIAL_R510_SCHEMA,decisionId:GENESIS_SPATIAL_R510_DECISION,from,to,distance:hit.distance,movementLimit:GENESIS_AGENCY_MOVEMENT_R510};
}

const HEX_DIRS=Object.freeze([[1,0],[1,-1],[0,-1],[-1,0],[-1,1],[0,1]]);
function validateIntensity(n){if(!Number.isInteger(n)||n<1||n>6)throw new Error('GEN_R510_INTENSITY_INVALID');return n;}
function cellFor(board,code){const c=board.cells.find(x=>x.code===code);if(!c)throw new Error('GEN_R510_CELL_UNKNOWN');return c;}
