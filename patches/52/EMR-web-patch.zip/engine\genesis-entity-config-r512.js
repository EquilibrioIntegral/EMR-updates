export const GENESIS_ENTITY_CONFIG_R512_SCHEMA='EMR_GENESIS_ENTITY_CONFIG_R512_v1';

const clone=x=>structuredClone(x);
const WILL_FORMS=new Set(['ANTHROPOMORPHIC','NON_ANTHROPOMORPHIC','UNFIXED']);
const WILL_GENDERS=new Set(['MASCULINE','FEMININE','UNSPECIFIED']);

export function primePrimordialEntityConfigurationR512(live){
 const n=clone(live);
 n.entityConfiguration??={schema:GENESIS_ENTITY_CONFIG_R512_SCHEMA,confirmed:false,profiles:{},history:[]};
 if(n.entityConfiguration.schema!==GENESIS_ENTITY_CONFIG_R512_SCHEMA)throw new Error('GEN_R512_ENTITY_CONFIG_SCHEMA');
 ensureMysticForceModel(n);
 migrateLegacyMysticSubstrateProfile(n);
 for(const p of n.players){
  if(p.nature==='PHYSICS')continue;
  if(p.controller==='APP')ensureAutonomousProfile(n,p);
 }
 return n;
}

export function entityConfigurationProjectionR512(live){
 const n=primePrimordialEntityConfigurationR512(live);
 const pending=[];
 for(const p of n.players.filter(p=>p.controller!=='APP'&&p.nature==='MYSTIC')){
  const entityId=mysticEntityIdForPlayer(n,p.id);
  if(!n.entityConfiguration.profiles[entityId])pending.push({kind:'MYSTIC',entityId,playerId:p.id,playerIds:[p.id]});
 }
 for(const p of n.players.filter(p=>p.controller!=='APP'&&p.nature==='WILL')){
  const entityId=volitionEntityIdForPlayer(n,p.id);
  if(!n.entityConfiguration.profiles[entityId])pending.push({kind:'WILL',entityId,playerId:p.id,playerIds:[p.id]});
 }
 const complete=pending.length===0;
 return{schema:GENESIS_ENTITY_CONFIG_R512_SCHEMA,complete,confirmed:n.entityConfiguration.confirmed===true,pending,profiles:clone(n.entityConfiguration.profiles),summaryNarrative:complete?entityConfigurationNarrativeR512(n):null};
}

export function configureHumanPrimordialEntityR512(live,{playerId,name='',manifestation='UNFIXED',grammaticalGender='UNSPECIFIED'}={}){
 const n=primePrimordialEntityConfigurationR512(live);
 const p=n.players.find(x=>x.id===playerId);
 if(!p||p.controller==='APP')throw new Error('GEN_R512_HUMAN_ENTITY_REQUIRED');
 if(p.nature==='PHYSICS')throw new Error('GEN_R512_PHYSICS_HAS_NO_ENTITY_PROFILE');
 if(p.nature==='WILL'){
  const trueName=cleanName(name,false);
  if(!WILL_FORMS.has(manifestation))throw new Error('GEN_R512_WILL_FORM_INVALID');
  if(!WILL_GENDERS.has(grammaticalGender))throw new Error('GEN_R512_WILL_GENDER_INVALID');
  if(manifestation!=='ANTHROPOMORPHIC')grammaticalGender='UNSPECIFIED';
  if(trueName)assertPrimordialNameUnique(n,trueName);
  const entityId=volitionEntityIdForPlayer(n,p.id);
  const profile={kind:'WILL',entityClass:'VOLITION_ENTITY',entityId,controller:'HUMAN',controllerPlayerId:p.id,trueName:trueName||null,manifestation,grammaticalGender,ethicalCodeStatus:'UNDETERMINED_BY_GENESIS_ACTIONS'};
  n.entityConfiguration.profiles[entityId]=profile;
  const entity=n.runtime.ontology.volitionEntities.find(v=>v.entityId===entityId);
  if(!entity)throw new Error('GEN_R512_VOLITION_ENTITY_UNKNOWN');
  entity.primordialIdentity=clone(profile);
  applyPrimordialIdentityVocabularyR512(n,p,profile);
  n.entityConfiguration.history.push({type:'GEN_R512_WILL_IDENTITY_FIXED',playerId:p.id,entityId,trueName:profile.trueName,manifestation,grammaticalGender});
 }
 if(p.nature==='MYSTIC'){
  const designation=cleanName(name,false);
  if(designation)assertPrimordialNameUnique(n,designation);
  const entityId=mysticEntityIdForPlayer(n,p.id);
  const profile={kind:'MYSTIC',entityClass:'MYSTIC_FORCE',entityId,controller:'HUMAN',controllerPlayerId:p.id,substrateId:'MYSTIC_SUBSTRATE',primordialDesignation:designation||null,personhood:'IMPERSONAL_FORCE',metaphysicalRulesStatus:'UNDETERMINED_BY_GENESIS_ACTIONS'};
  n.entityConfiguration.profiles[entityId]=profile;
  const force=n.runtime.ontology.mysticForces.find(v=>v.entityId===entityId);
  if(!force)throw new Error('GEN_R512_MYSTIC_FORCE_UNKNOWN');
  force.primordialIdentity=clone(profile);
  applyPrimordialIdentityVocabularyR512(n,p,profile);
  n.entityConfiguration.history.push({type:'GEN_R512_MYSTIC_FORCE_IDENTITY_FIXED',playerId:p.id,entityId,designation:profile.primordialDesignation});
 }
 n.entityConfiguration.confirmed=false;
 n.history.push({type:'GEN_R512_ENTITY_CONFIGURATION_UPDATED',playerId:p.id,nature:p.nature});
 return n;
}

export function confirmPrimordialEntityConfigurationR512(live){
 const n=primePrimordialEntityConfigurationR512(live),p=entityConfigurationProjectionR512(n);
 if(!p.complete)throw new Error('GEN_R512_ENTITY_CONFIGURATION_INCOMPLETE');
 n.entityConfiguration.confirmed=true;
 n.history.push({type:'GEN_R512_ENTITY_CONFIGURATION_CONFIRMED'});
 return n;
}

export function primordialEntityNarrativeRefR512(profile){
 if(profile?.kind==='WILL'){
  const name=profile.trueName||'sin nombre';
  if(profile.manifestation!=='ANTHROPOMORPHIC')return `La Voluntad ${name}`;
  if(profile.grammaticalGender==='MASCULINE')return `El Dios ${name}`;
  if(profile.grammaticalGender==='FEMININE')return `La Diosa ${name}`;
  return `La deidad ${name}`;
 }
 if(profile?.kind==='MYSTIC')return profile.primordialDesignation?`La fuerza mística ${profile.primordialDesignation}`:'Una fuerza mística sin nombre';
 return 'La entidad primordial';
}

export function entityConfigurationNarrativeR512(live){
 const profiles=Object.values(live.entityConfiguration?.profiles||{}),parts=[];
 for(const profile of profiles){
  if(profile.kind==='WILL'){
   const form=profile.manifestation==='ANTHROPOMORPHIC'?'adoptó una forma reconocible como persona':profile.manifestation==='NON_ANTHROPOMORPHIC'?'no quedó ligada a una forma humana':'no fijó todavía una forma definitiva';
   const subject=primordialEntityNarrativeRefR512(profile);
   const nameFate=profile.trueName?'Ese nombre podría ser recordado, revelado, olvidado o deformado por las culturas.':'Permaneció sin nombre; culturas futuras podrían nombrarla de maneras distintas.';
   parts.push(`En esta edad quedó fijada una Voluntad primordial: ${subject}. ${subject} ${form}. Millones de años después, ${nameFate}`);
  }
  if(profile.kind==='MYSTIC'){
   if(profile.primordialDesignation)parts.push(`Una fuerza mística individual recibió una designación primordial: ${profile.primordialDesignation}. Nació del sustrato invisible del universo, pero no era el sustrato entero, una persona, una deidad ni una religión.`);
   else parts.push('Una fuerza mística individual permaneció sin nombre. Nació del sustrato invisible del universo, pero no era el sustrato entero, una persona, una deidad ni una religión.');
  }
 }
 return parts.join(' ');
}

function applyPrimordialIdentityVocabularyR512(n,p,profile){
 const narrativeRef=primordialEntityNarrativeRefR512(profile);
 p.controllerName??=p.name;
 p.primordialEntityId=profile.entityId;
 p.primordialNarrativeRef=narrativeRef;
 p.name=narrativeRef;
 const agency=n.runtime.binding.agencies.find(a=>a.playerId===p.id);
 if(agency){
  agency.controllerName??=p.controllerName;
  agency.primordialEntityId=profile.entityId;
  agency.primordialNarrativeRef=narrativeRef;
  agency.name=narrativeRef;
  agency.publicName=narrativeRef;
 }
 const entity=profile.kind==='WILL'?n.runtime.ontology.volitionEntities.find(v=>v.entityId===profile.entityId):n.runtime.ontology.mysticForces.find(v=>v.entityId===profile.entityId);
 if(entity){entity.name=narrativeRef;entity.publicName=narrativeRef;entity.controllerName=p.controllerName;}
 n.history.push({type:'GEN_R512_PRIMORDIAL_VOCABULARY_PROPAGATED',playerId:p.id,entityId:profile.entityId,narrativeRef,controllerName:p.controllerName});
}

function ensureMysticForceModel(n){
 n.runtime??={};
 n.runtime.binding??={agencies:[]};
 n.runtime.binding.agencies??=[];
 n.runtime.ontology??={};
 n.runtime.ontology.mysticForces??=[];
 n.runtime.ontology.mysticSubstrate??={};
 const mysticAgencies=n.runtime.binding.agencies.filter(a=>a.nature==='MYSTIC'||n.players?.find(p=>p.id===a.playerId)?.nature==='MYSTIC');
 let ordinal=0;
 for(const agency of mysticAgencies){
  ordinal++;
  agency.mysticForceId??=`MYS-${Number(agency.ordinal)||ordinal}`;
  let force=n.runtime.ontology.mysticForces.find(x=>x.entityId===agency.mysticForceId);
  if(!force){
   const intensity=Number(agency.universeIntensity??n.runtime.signatureRecord?.signature?.MYSTIC??n.runtime.ontology.mysticSubstrate.authority??0);
   force={entityId:agency.mysticForceId,controllerPlayerId:agency.playerId,substrateId:'MYSTIC_SUBSTRATE',globalMysticIntensity:intensity,powerLevel:Number(agency.powerLevel??intensity),unlockedLevels:[...(agency.unlockedLevels||[])],authorityBand:agency.authorityBand??null,facts:[],relations:[],promises:[]};
   n.runtime.ontology.mysticForces.push(force);
  }
 }
 n.runtime.ontology.mysticSubstrate.forceEntityIds=n.runtime.ontology.mysticForces.map(x=>x.entityId);
}

function migrateLegacyMysticSubstrateProfile(n){
 const legacy=n.entityConfiguration.profiles.MYSTIC_SUBSTRATE;
 if(!legacy)return;
 const mystics=n.players.filter(p=>p.nature==='MYSTIC');
 let target=null;
 if(legacy.controllerPlayerId)target=mystics.find(p=>p.id===legacy.controllerPlayerId);
 if(!target&&Array.isArray(legacy.controllerPlayerIds)&&legacy.controllerPlayerIds.length===1)target=mystics.find(p=>p.id===legacy.controllerPlayerIds[0]);
 if(!target&&mystics.length===1)target=mystics[0];
 if(target){
  const entityId=mysticEntityIdForPlayer(n,target.id);
  if(!n.entityConfiguration.profiles[entityId]){
   const profile={kind:'MYSTIC',entityClass:'MYSTIC_FORCE',entityId,controller:target.controller==='APP'?'APP':'HUMAN',controllerPlayerId:target.id,substrateId:'MYSTIC_SUBSTRATE',primordialDesignation:legacy.primordialDesignation||null,personhood:'IMPERSONAL_FORCE',metaphysicalRulesStatus:legacy.metaphysicalRulesStatus||'UNDETERMINED_BY_GENESIS_ACTIONS'};
   n.entityConfiguration.profiles[entityId]=profile;
   const force=n.runtime.ontology.mysticForces.find(v=>v.entityId===entityId);if(force)force.primordialIdentity=clone(profile);
   if(target.controller!=='APP')applyPrimordialIdentityVocabularyR512(n,target,profile);
  }
 }
 delete n.entityConfiguration.profiles.MYSTIC_SUBSTRATE;
 if(n.runtime.ontology.mysticSubstrate?.primordialIdentity)delete n.runtime.ontology.mysticSubstrate.primordialIdentity;
 n.entityConfiguration.history.push({type:'GEN_R512_MYSTIC_SUBSTRATE_PROFILE_MIGRATED',targetPlayerId:target?.id||null});
}

function ensureAutonomousProfile(n,p){
 if(p.nature==='MYSTIC'){
  const entityId=mysticEntityIdForPlayer(n,p.id);
  if(!n.entityConfiguration.profiles[entityId]){
   const profile={kind:'MYSTIC',entityClass:'MYSTIC_FORCE',entityId,controller:'APP',controllerPlayerId:p.id,substrateId:'MYSTIC_SUBSTRATE',primordialDesignation:null,personhood:'IMPERSONAL_FORCE',metaphysicalRulesStatus:'UNDETERMINED_BY_GENESIS_ACTIONS'};
   n.entityConfiguration.profiles[entityId]=profile;
   const force=n.runtime.ontology.mysticForces.find(v=>v.entityId===entityId);if(force)force.primordialIdentity=clone(profile);
  }
  return;
 }
 if(p.nature==='WILL'){
  const entityId=volitionEntityIdForPlayer(n,p.id);
  if(!n.entityConfiguration.profiles[entityId]){
   const profile={kind:'WILL',entityClass:'VOLITION_ENTITY',entityId,controller:'APP',controllerPlayerId:p.id,trueName:null,manifestation:'UNFIXED',grammaticalGender:'UNSPECIFIED',ethicalCodeStatus:'UNDETERMINED_BY_GENESIS_ACTIONS'};
   n.entityConfiguration.profiles[entityId]=profile;
   const entity=n.runtime.ontology.volitionEntities.find(v=>v.entityId===entityId);
   if(entity)entity.primordialIdentity=clone(profile);
  }
 }
}

function mysticEntityIdForPlayer(live,playerId){
 const agency=live.runtime.binding.agencies.find(a=>a.playerId===playerId&&(a.nature==='MYSTIC'||live.players?.find(p=>p.id===playerId)?.nature==='MYSTIC'));
 if(!agency?.mysticForceId)throw new Error('GEN_R512_MYSTIC_FORCE_UNKNOWN');
 return agency.mysticForceId;
}
function volitionEntityIdForPlayer(live,playerId){
 const agency=live.runtime.binding.agencies.find(a=>a.playerId===playerId);
 if(!agency?.volitionEntityId)throw new Error('GEN_R512_VOLITION_ENTITY_UNKNOWN');
 return agency.volitionEntityId;
}

function cleanName(value,required){
 const s=String(value??'').trim().replace(/\s+/g,' ');
 if(required&&!s)throw new Error('GEN_R512_NAME_REQUIRED');
 if(s.length>48)throw new Error('GEN_R512_NAME_TOO_LONG');
 return s;
}

function nameKey(value){return String(value??'').normalize('NFKD').replace(/\p{M}/gu,'').trim().replace(/\s+/g,' ').toLocaleLowerCase('es-ES');}
function assertPrimordialNameUnique(live,name){
 const key=nameKey(name);if(!key)return;
 for(const profile of Object.values(live.entityConfiguration?.profiles||{})){
  const existing=profile.kind==='WILL'?profile.trueName:profile.kind==='MYSTIC'?profile.primordialDesignation:null;
  if(existing&&nameKey(existing)===key)throw new Error('GEN_R512_PRIMORDIAL_NAME_DUPLICATE');
 }
}