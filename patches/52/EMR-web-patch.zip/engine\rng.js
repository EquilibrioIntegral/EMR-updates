export function hashSeed(input) {
  const text = String(input ?? 'EMR-A1');
  let h = 2166136261 >>> 0;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export class SeededRng {
  constructor(seed) { this.state = hashSeed(seed) || 0x6d2b79f5; }
  next() {
    let t = this.state += 0x6D2B79F5;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  pickWeighted(items, weightFn = x => x.weight ?? 1) {
    if (!items.length) return null;
    const weights = items.map(x => Math.max(0, Number(weightFn(x)) || 0));
    const total = weights.reduce((a,b)=>a+b,0);
    if (total <= 0) return items[0];
    let r = this.next() * total;
    for (let i=0;i<items.length;i++) {
      r -= weights[i];
      if (r <= 0) return items[i];
    }
    return items.at(-1);
  }
}
