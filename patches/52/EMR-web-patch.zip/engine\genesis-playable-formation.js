// GEN-R5.6 — Playable Genesis formation contract.
// Qualitative causal formation only: the app remembers why bodies became star/planet
// candidates without exposing astrophysics arithmetic to the players.
const clone=x=>structuredClone(x);
const membersOf=b=>Array.isArray(b?.members)&&b.members.length?b.members:[b?.id].filter(Boolean);
const actedOn=(s,id)=>[...(s.actions||[]),...(s.trace||[]).flatMap(e=>e.worldActions||[])].filter(a=>a?.target===id||a?.other===id);
const imprintsOn=(s,id)=>(s.imprints||[]).filter(x=>x.target===id);
const linksOn=(s,id)=>(s.links||[]).filter(x=>x.a===id||x.b===id);
const physicalHistory=(s,id)=>actedOn(s,id).filter(a=>['ATTRACT','COHERE','IMPULSE','PRESERVE'].includes(a.action));
const convergenceHistory=(s,id)=>(s.memory||[]).filter(m=>m.target===id&&m.event==='CONVERGENCE');
const cellOf=b=>b?.cell??(Number.isFinite(b?.q)&&Number.isFinite(b?.r)?{q:b.q,r:b.r}:null);
const qualitativeDistance=(a,b)=>{if(!a||!b)return null;const dq=a.q-b.q,dr=a.r-b.r;return Math.max(Math.abs(dq),Math.abs(dr),Math.abs(dq+dr));};

export function derivePlayableSolarSystem(state){
 const bodies=Object.values(state?.gravity?.masses||{}).map(clone);
 const ranked=[...bodies].sort((a,b)=>membersOf(b).length-membersOf(a).length||String(a.id).localeCompare(String(b.id)));
 // A star is not pre-drawn and not granted by elapsed rounds. It exists only after
 // matter has actually converged into a dominant multi-origin body on the table.
 const star=ranked.find(b=>membersOf(b).length>=2)||null;
 if(!star)return {stage:'FORMING_STAR',star:null,planetCandidates:[],selectedPlanet:null,ready:false,reasons:['STAR_NOT_FORMED']};
 const starCell=cellOf(star),remaining=bodies.filter(b=>b.id!==star.id);
 const planetCandidates=remaining.map(body=>{
  const causes=physicalHistory(state,body.id),inherited=membersOf(body),imprints=imprintsOn(state,body.id),links=linksOn(state,body.id),convergences=convergenceHistory(state,body.id);
  const evidence=[
   ...(inherited.length>=2?['MATTER_ACCRETION']:[]),
   ...(causes.length?['CAUSAL_PHYSICAL_HISTORY']:[]),
   ...(imprints.length?['PRIMORDIAL_IMPRINT']:[]),
   ...(links.length?['PRIMORDIAL_LINK']:[]),
   ...(convergences.length?['COSMIC_CONVERGENCE']:[])
  ];
  const distance=qualitativeDistance(starCell,cellOf(body));
  const orbitalBand=distance==null?'UNRESOLVED':distance<=1?'INNER':distance<=3?'MIDDLE':'OUTER';
  return {id:body.id,name:body.name||null,cell:cellOf(body),members:inherited,evidence:[...new Set(evidence)],causeRefs:[...causes.map(a=>a.memoryRef||a.id),...convergences.map(c=>c.id)].filter(Boolean),relationToStar:{band:orbitalBand,distanceClass:distance==null?'UNKNOWN':distance<=1?'NEAR':distance<=3?'INTERMEDIATE':'FAR'}};
 }).filter(p=>p.evidence.includes('MATTER_ACCRETION')||p.evidence.includes('CAUSAL_PHYSICAL_HISTORY')||p.evidence.includes('COSMIC_CONVERGENCE')).sort((a,b)=>a.id.localeCompare(b.id));
 const selected=state.selectedPlanetId?planetCandidates.find(p=>p.id===state.selectedPlanetId)||null:null;
 if(!planetCandidates.length)return {stage:'FORMING_PLANETS',star:clone(star),planetCandidates:[],selectedPlanet:null,ready:false,reasons:['NO_CAUSALLY_FORMED_PLANET']};
 if(!selected)return {stage:'SELECT_PLANET',star:clone(star),planetCandidates,selectedPlanet:null,ready:false,reasons:['PLANET_SELECTION_REQUIRED']};
 return {stage:'SYSTEM_READY',star:clone(star),planetCandidates,selectedPlanet:clone(selected),ready:true,reasons:[]};
}

export function selectPlayablePlanet(state,planetId,name=null){
 const status=derivePlayableSolarSystem({...state,selectedPlanetId:null});
 const candidate=status.planetCandidates.find(p=>p.id===planetId);
 if(!candidate)throw new Error('GENESIS_PLANET_NOT_SELECTABLE');
 state.selectedPlanetId=planetId;
 state.selectedPlanetName=String(name||candidate.name||`Mundo ${planetId}`).trim().slice(0,80);
 state.trace??=[];
 state.trace.push({event:'PLANET_SELECTED',planetId,name:state.selectedPlanetName,round:state.round,causeRefs:candidate.causeRefs});
 return derivePlayableSolarSystem(state);
}

export function compilePlayableSystemHandoff(state){
 const status=derivePlayableSolarSystem(state);
 if(!status.ready)throw new Error(`GENESIS_SYSTEM_NOT_READY:${status.reasons.join(',')}`);
 const selected={...status.selectedPlanet,name:state.selectedPlanetName||status.selectedPlanet.name||`Mundo ${status.selectedPlanet.id}`};
 return {
  schema:'EMR_GENESIS_PLAYABLE_SYSTEM_v2',
  star:{id:status.star.id,members:membersOf(status.star),cell:cellOf(status.star)},
  planets:status.planetCandidates.map(p=>({...p,name:p.id===selected.id?selected.name:p.name})),
  selectedPlanet:selected,
  preliminaryEnvironment:{stellarProximity:selected.relationToStar.distanceClass,orbitalBand:selected.relationToStar.band,authority:'GENESIS_CAUSAL_SPATIAL_RELATION'},
  causalHistory:(state.trace||[]).filter(e=>['DELTA','CONVERGENCE','PLANET_SELECTED'].includes(e.event)).map(clone),
  narrativeMemory:clone(state.narrativeMemory||[]),
  narrativeThreats:clone(state.narrativeThreats||[])
 };
}
