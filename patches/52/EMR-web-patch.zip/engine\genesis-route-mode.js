export const GENESIS_ROUTE_MODE=Object.freeze({R53_ENTRY:'R53_ENTRY',R5_LIVE:'R5_LIVE',LEGACY_GENESIS:'LEGACY_GENESIS',LEGACY_BOOT:'LEGACY_BOOT'});

/**
 * New games explicitly opt into the R5.3 entry path. Historical saves do not
 * gain that marker, so they keep using the 0.30 Genesis renderer/state machine.
 */
export function genesisRouteMode(state){
 const session=state?.session||{},phase=session.boot?.phase||null;
 if(phase==='GENESIS_ACTIVE'&&session.genesisR5)return GENESIS_ROUTE_MODE.R5_LIVE;
 if(phase==='GENESIS_ACTIVE'&&session.genesisTable)return GENESIS_ROUTE_MODE.LEGACY_GENESIS;
 if(phase==='CI03_CHOICE'&&session.genesisEntryMode==='R53')return GENESIS_ROUTE_MODE.R53_ENTRY;
 return GENESIS_ROUTE_MODE.LEGACY_BOOT;
}

export function optIntoGenesisR53ForNewGame(state){
 if(!state?.session)throw new Error('GEN_ROUTE_SESSION_REQUIRED');
 state.session.genesisEntryMode='R53';
 state.session.genesisEntryR53=null;
 state.session.genesisR5=null;
 return state;
}
