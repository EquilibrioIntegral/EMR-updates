// Adapter: R5.1/R5.3 legacy -> existing BOOT01/Worldgen legacy envelope.
// Keeps old consumers working while preserving the richer ontological truth.

export function adaptR5LegacyToBoot01Envelope(legacy,{id='LEGACY-GEN-R5'}={}){
 if(legacy?.schema!=='EMR_PRIMORDIAL_LEGACY_R5_v1')throw new Error('GEN_R5_LEGACY_REQUIRED');
 const p=legacy.physicalLegacy.selectedPlanetSignature,star=legacy.physicalLegacy.starSignature;
 const starBody={id:'STAR-01',tags:['STAR',star.family],x:0,y:0,signature:{...star}};
 const planetBody={id:p.id,tags:['PLANET',p.type,p.orbitBand,...compositionTags(p)],x:orbitX(p.orbitBand),y:0,signature:{...p}};
 const causalChain=(legacy.physicalLegacy.genealogy||[]).map((e,i)=>eventStep(e,i));
 return{
  id,consumer:'BOOT01_FORMACION_MUNDO',fingerprint:fingerprint(legacy),
  common:{selectedPlanet:{id:p.id},focusBody:{id:p.id},causalChain,residues:[],provenance:{causalFingerprint:fingerprint(legacy)},narrativeMemory:[],promises:[],threads:[],namedReferents:[{id:p.id,kind:'PLANET'},{id:'STAR-01',kind:'STAR'}]},
  extensions:{
   physics:{bodies:[starBody,planetBody,...legacy.physicalLegacy.systemBodies.filter(x=>x.id!==p.id).map(x=>({id:x.id,tags:['PLANET',x.type,x.orbitBand,...compositionTags(x)],x:orbitX(x.orbitBand),y:Number(x.id.match(/\d+/)?.[0]||1),signature:{...x}}))],sourceTags:physicsTags(legacy)},
   mystic:{imprints:(legacy.supernaturalLegacy.imprints||[]).map(x=>x.principle||x.type).filter(Boolean),sourceTags:legacy.supernaturalLegacy.sav.A>0?['VINCULO_IMPERSONAL']:[]},
   ontology:{supernaturalLegacy:structuredClone(legacy.supernaturalLegacy),consciousnessMetaphysics:structuredClone(legacy.consciousnessMetaphysics),normativeMetaphysics:structuredClone(legacy.normativeMetaphysics),knowledgeSeparation:structuredClone(legacy.knowledgeSeparation)},
   r5:{physicalLegacy:structuredClone(legacy.physicalLegacy),consumers:structuredClone(legacy.consumers)}
  }
 };
}

function compositionTags(p){const out=[];if(p.composition?.volatiles>=4)out.push('VOLATILE_RICH');if(p.composition?.refractories>=4)out.push('REFRACTORY_RICH');return out;}
const orbitX=band=>band==='INNER'?2:band==='MIDDLE'?4:6;
function physicsTags(l){const out=[];const f=l.physicalLegacy.starSignature.massFraction;if(f>=0.6)out.push('NUCLEO_DOMINANTE');else out.push('SISTEMA_DISTRIBUIDO');if(l.physicalLegacy.systemBodies.length>1)out.push('ORBITAS_ESTABLES');return out;}
function eventStep(e,i){return{id:`R5-E${i+1}`,outputRef:e.targetId||e.planetIds?.join('-')||`R5-E${i+1}`,producerId:e.actorId||e.type,transformId:e.type,resultTag:resultTag(e),outcome:'SUCCESS',sourceIds:[e.targetId].filter(Boolean),playerCauseIds:[e.actorId].filter(Boolean)};}
function resultTag(e){if(e.type==='STAR_IGNITION')return'NUCLEO_DOMINANTE';if(e.type==='DISK_RETAIN')return'SISTEMA_DISTRIBUIDO';if(e.type==='PLANET_FORMATION')return'ORBITAS_ESTABLES';if(e.type==='INTERVENTION'&&e.nature==='MYSTIC')return'VINCULO_IMPERSONAL';if(e.type==='INTERVENTION'&&e.nature==='WILL')return'HUELLA_CONSCIENTE';return e.type;}
function fingerprint(l){const s=JSON.stringify({star:l.physicalLegacy.starSignature,planet:l.physicalLegacy.selectedPlanetSignature,sav:l.supernaturalLegacy.sav,events:(l.physicalLegacy.genealogy||[]).map(x=>[x.type,x.targetId,x.actorId])});let h=2166136261;for(const ch of s)h=Math.imul(h^ch.charCodeAt(0),16777619);return`R5-${(h>>>0).toString(16).padStart(8,'0')}`;}
