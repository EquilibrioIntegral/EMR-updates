// GEN-R4.4 — Deterministic causal narration for the playable Genesis turn cycle.
// It interprets recorded causes; it never invents physical state.
const clone=x=>JSON.parse(JSON.stringify(x));

export function narrateGenesisRound(state){
 const turn=state?.genesisTurn;if(!turn)throw new Error('GEN_TURN_STATE_REQUIRED');
 const round=turn.round??1;
 const actions=(turn.events||[]).filter(e=>e.type==='FREE_ACTION'&&e.round===round);
 const moved=actions.filter(e=>e.effect?.type==='MATTER_REPOSITION');
 const abstentions=actions.filter(e=>e.operation==='NO_INTERVENE');
 const influences=actions.filter(e=>e.effect?.type==='AGENCY_INFLUENCE');
 const parts=[];
 if(moved.length){const names=moved.map(e=>matterName(state,e.targetId)).join(', ');parts.push(`La materia primordial cambia de disposición: ${names}.`);}
 if(influences.length)parts.push('Hay fuerzas cuya intervención aún no se materializa: su consecuencia queda pendiente de la evolución del universo.');
 if(abstentions.length)parts.push(abstentions.length===actions.length?'Nadie interviene. El universo continúa por sí mismo.':'Algunas agencias dejan que el universo siga su curso.');
 if(!parts.length)parts.push('El universo permanece expectante; todavía no hay una consecuencia material nueva que mostrar.');
 const years=turn.cosmicClock?.years??0;
 const event={type:'GENESIS_NARRATIVE_EVENT',round,cosmicYear:years,causeEventIndexes:actions.map((_,i)=>i),publicText:parts.join(' '),tableInstructions:moved.map(e=>e.tableInstruction).filter(Boolean),facts:moved.map(e=>({type:'MATTER_POSITION_CHANGED',reservoirId:e.targetId,to:e.effect?.to,playerCauseId:e.playerCauseId??null,producerId:e.effect?.producerId??null}))};
 return event;
}

export function applyGenesisNarrativeEvent(state,event=narrateGenesisRound(state)){
 const s=clone(state);s.genesisTurn??={};s.genesisTurn.events??=[];s.eventLog??=[];
 s.genesisTurn.events.push(clone(event));s.eventLog.push(clone(event));s.genesisTurn.phase='CONVERGENCE_CHECK';
 s.worldMemory??={};s.worldMemory.genesis??={events:[],facts:[]};s.worldMemory.genesis.events.push(clone(event));s.worldMemory.genesis.facts.push(...clone(event.facts||[]));
 return s;
}

function matterName(state,id){return (state.matterReservoirs||[]).find(r=>r.id===id)?.name||id||'materia primordial';}
