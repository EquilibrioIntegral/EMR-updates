// GEN-AGENCY-01 — CI03 votes become embodied primordial agencies.
// Internal engine contract. Signature is universe-level; agencies are player-level.

export const PRIMORDIAL_KINDS=Object.freeze(['PHYSICS','MYSTIC','WILL']);
const SPECIALIZATIONS=Object.freeze({
 PHYSICS:['GRAVITY','ENERGY_MOTION','MATTER_STRUCTURE','RADIATION_CHANGE'],
 MYSTIC:['CYCLE_RETURN','TRANSFORMATION','TRANSCENDENCE','PERSISTENCE_TRACE'],
 WILL:['PRESERVE','CREATE','TRANSFORM','OPPOSE']
});
const clamp5=n=>Math.max(0,Math.min(5,Math.trunc(Number(n)||0)));

export function derivePrimordialSetup(votes,{signatureBudget=5}={}){
 if(!Array.isArray(votes)||votes.length<1||votes.length>4)throw new Error('GEN_PLAYER_COUNT_INVALID');
 const normalized=votes.map((v,i)=>{
  const kind=String(v?.kind||'').toUpperCase();
  if(!PRIMORDIAL_KINDS.includes(kind))throw new Error('GEN_VOTE_KIND_INVALID');
  return{playerId:v.playerId||`P${i+1}`,kind};
 });
 if(new Set(normalized.map(v=>v.playerId)).size!==normalized.length)throw new Error('GEN_PLAYER_ID_DUPLICATE');
 const counts=Object.fromEntries(PRIMORDIAL_KINDS.map(k=>[k,normalized.filter(v=>v.kind===k).length]));
 const signature=allocateSignature(counts,signatureBudget);
 const used=Object.fromEntries(PRIMORDIAL_KINDS.map(k=>[k,0]));
 const agencies=normalized.map((v,i)=>{
  const slot=used[v.kind]++;
  return{id:`AG-${i+1}`,playerId:v.playerId,kind:v.kind,specialization:SPECIALIZATIONS[v.kind][slot],universeIntensity:signature[v.kind],pawnRequired:true,presence:null};
 });
 return{schema:'EMR_GENESIS_AGENCIES_v1',signature,agencies,counts};
}

// Largest-remainder apportionment over the whole universe-level budget.
// Player agencies express the Signature; they do not create extra intensity merely
// because several players embody the same nature. Represented natures are kept
// present whenever the budget permits.
function allocateSignature(counts,budget){
 const b=clamp5(budget);if(b<1)throw new Error('GEN_SIGNATURE_BUDGET_INVALID');
 const represented=PRIMORDIAL_KINDS.filter(k=>counts[k]>0);
 if(represented.length>b)throw new Error('GEN_SIGNATURE_BUDGET_TOO_SMALL');
 const out={PHYSICS:0,MYSTIC:0,WILL:0};
 const total=represented.reduce((s,k)=>s+counts[k],0);
 const quotas=represented.map(k=>({k,q:b*counts[k]/total}));
 let assigned=0;
 quotas.forEach(x=>{const f=Math.floor(x.q);out[x.k]=f;assigned+=f;});
 // A represented nature may not disappear from the primordial reality.
 for(const k of represented){if(out[k]===0){out[k]=1;assigned++;}}
 // If minimum-presence correction overshoots, take only from natures above 1,
 // preferring the smallest fractional claim first.
 if(assigned>b){
  const donors=[...quotas].sort((a,c)=>(a.q-Math.floor(a.q))-(c.q-Math.floor(c.q))||PRIMORDIAL_KINDS.indexOf(c.k)-PRIMORDIAL_KINDS.indexOf(a.k));
  for(const x of donors){while(assigned>b&&out[x.k]>1){out[x.k]--;assigned--;}}
 }
 let remaining=b-assigned;
 const ranked=[...quotas].sort((a,c)=>(c.q-Math.floor(c.q))-(a.q-Math.floor(a.q))||PRIMORDIAL_KINDS.indexOf(a.k)-PRIMORDIAL_KINDS.indexOf(c.k));
 for(let i=0;i<remaining;i++)out[ranked[i%ranked.length].k]++;
 return out;
}

export function presenceBand(intensity){
 const n=clamp5(intensity);
 return ['ABSENT','TENUOUS','MINOR','RELEVANT','DOMINANT','FOUNDATIONAL'][n];
}

export function presenceReach(intensity){
 const n=clamp5(intensity);return n===0?0:n<=2?1:n<=4?2:3;
}

export function effectiveAuthority({agency,targetDistance=0,prepared=false,cooperators=0,opposed=false}={}){
 if(!agency||!PRIMORDIAL_KINDS.includes(agency.kind))throw new Error('GEN_AGENCY_INVALID');
 const intensity=clamp5(agency.universeIntensity),reach=presenceReach(intensity);
 if(intensity===0||targetDistance>reach)return{legal:false,score:0,reason:'OUT_OF_PRESENCE'};
 let score=intensity+(targetDistance===0?1:0)+(prepared?1:0)+Math.min(2,Math.max(0,cooperators));
 if(opposed)score-=1;
 return{legal:true,score:Math.max(1,score),band:presenceBand(intensity),reach};
}

export function resolvePrimordialConvergence(intents){
 if(!Array.isArray(intents)||!intents.length)throw new Error('GEN_INTENTS_REQUIRED');
 const valid=intents.map(x=>({...x,effective:effectiveAuthority(x)})).filter(x=>x.effective.legal);
 const compatible=valid.filter(x=>x.compatible!==false);
 const incompatible=valid.filter(x=>x.compatible===false);
 if(!incompatible.length)return{mode:'COMPOSE',applied:compatible.map(x=>x.agency.id),uncertainty:false};
 const ranked=[...incompatible].sort((a,b)=>b.effective.score-a.effective.score||a.agency.id.localeCompare(b.agency.id));
 const top=ranked[0],second=ranked[1];
 if(!second)return{mode:'PRECEDENCE',winner:top.agency.id,applied:[...compatible.map(x=>x.agency.id),top.agency.id],uncertainty:false};
 const scoreGap=top.effective.score-second.effective.score;
 const signatureGap=clamp5(top.agency.universeIntensity)-clamp5(second.agency.universeIntensity);
 // Preparation, local presence and cooperation may let a weak agency challenge a
 // stronger law, but never turn that circumstantial boost into automatic supremacy.
 // It earns genuine uncertainty; the exceptional outcome is resolved later.
 if(scoreGap>=2&&signatureGap<0)return{mode:'UNCERTAIN',candidates:[top.agency.id,second.agency.id],applied:compatible.map(x=>x.agency.id),uncertainty:true};
 if(scoreGap>=2)return{mode:'PRECEDENCE',winner:top.agency.id,applied:[...compatible.map(x=>x.agency.id),top.agency.id],uncertainty:false};
 return{mode:'UNCERTAIN',candidates:ranked.filter(x=>top.effective.score-x.effective.score<=1).map(x=>x.agency.id),applied:compatible.map(x=>x.agency.id),uncertainty:true};
}
