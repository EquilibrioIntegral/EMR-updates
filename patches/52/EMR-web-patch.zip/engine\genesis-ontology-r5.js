import {authorityBandR53,actionTierR53} from './genesis-signature-r53.js';

export const GENESIS_ONTOLOGY_R5_SCHEMA='EMR_GENESIS_ONTOLOGY_R5_v1';
export const GENESIS_LAW_ORIGIN_GATE_R54_SCHEMA='EMR_GENESIS_LAW_ORIGIN_GATE_R54_v1';
export const LAW_ORIGIN_MODES_R54=Object.freeze(['MYSTIC_DERIVED','VOLITION_DECREED','RELATIONAL_CO_PRODUCED']);
export const GENESIS_R516_PHYSICAL_BASELINE_DECISION='D-GEN-R5.16-PHYSICAL-BASELINE01';

export function analyzeOntologyR5({signature,binding}={}){
 if(!signature)throw new Error('GEN_ONTOLOGY_SIGNATURE_REQUIRED');
 const gaps=[],facts=[],lawMode='AUTONOMOUS_PHYSICS_PRESENT';
 facts.push({type:'BASELINE_PHYSICAL_EVOLUTION',decisionId:GENESIS_R516_PHYSICAL_BASELINE_DECISION,mode:'ALWAYS_ACTIVE',reason:'MATTER_EVOLVES_PHYSICALLY_IN_EVERY_VALID_GENESIS'});
 if(signature.MYSTIC>0)facts.push({type:'MYSTIC_CAUSAL_LAYER_PRESENT',intensity:signature.MYSTIC,reason:'PRIMORDIAL_SIGNATURE'});
 if(signature.WILL>0)facts.push({type:'VOLITION_CAUSAL_LAYER_PRESENT',intensity:signature.WILL,reason:'PRIMORDIAL_SIGNATURE'});
 if(signature.PHYSICS>0)facts.push({type:'PHYSICAL_PRIMORDIAL_WEIGHT_PRESENT',intensity:signature.PHYSICS,reason:'PRIMORDIAL_SIGNATURE'});
 if(signature.PHYSICS===0)facts.push({type:'NO_EXTRAORDINARY_PHYSICAL_WEIGHT',decisionId:GENESIS_R516_PHYSICAL_BASELINE_DECISION,note:'PHYSICS=0 does not disable gravity, thermal evolution, accretion, ignition, disk formation or orbital dynamics.'});
 if(signature.PHYSICS>0&&signature.WILL>0)facts.push({type:'WILL_PHYSICS_PRECEDENCE_R53',decisionId:'D-GEN-R5.3-SIGNATURE-AUTHORITY01',mode:'R53_CAUSAL_PRECEDENCE_NO_SECOND_GATE'});
 if(signature.MYSTIC>0&&signature.WILL>0)facts.push({type:'WILL_MYSTIC_RELATION_GRAPH_R56',decisionId:'D-GEN-R5.6-WILL-MYSTIC-RELATION01',defaultRelation:'COEXISTENT_UNLINKED',crossAuthorityByDefault:false});
 if(binding?.volitionEntities?.length>1)facts.push({type:'VOLITION_RELATION_GRAPH_R57',decisionId:'D-GEN-R5.7-VOLITION-RELATIONS01',defaultRelation:'COEXISTENT_UNRELATED',relationsRequirePlayedCause:true,setupRelationGate:false});
 return{schema:GENESIS_ONTOLOGY_R5_SCHEMA,signature:{...signature},lawMode,facts,gaps,volitionEntities:(binding?.volitionEntities||[]).map(v=>({...v,authorityBand:authorityBandR53(signature.WILL),actionTier:actionTierR53(signature.WILL)}))};
}

// Historical compatibility catalogue grouped by R5.3 qualitative bands.
// D-GEN-R5.3-POWER-LADDER01 now requires exact data-driven requiredLevel 1..6.
// These are permissions used by the Guionista, never a player-facing power menu.
const VOLITION_ACTIONS=Object.freeze([
 {id:'PROTECT',minTier:1,requiresDomain:null,scope:'LOCAL'},
 {id:'CLAIM',minTier:1,requiresDomain:null,scope:'LOCAL'},
 {id:'IMPRINT_PURPOSE',minTier:1,requiresDomain:null,scope:'LOCAL'},
 {id:'PACT',minTier:2,requiresDomain:null,scope:'RELATIONAL'},
 {id:'AUTOLIMIT',minTier:2,requiresDomain:null,scope:'SELF'},
 {id:'OPPOSE_VOLITION',minTier:2,requiresDomain:null,scope:'RELATIONAL'},
 {id:'DECREE_LAW',minTier:3,requiresDomain:'COSMOGONIC_AUTHOR',scope:'SYSTEMIC'},
 {id:'EMANATE_VOLITION',minTier:3,requiresDomain:'CREATOR',scope:'ONTOLOGICAL'},
 {id:'GRANT_CONTINUITY',minTier:3,requiresDomain:'CONSCIOUSNESS',scope:'ONTOLOGICAL'}
]);

export function availableVolitionActionsR5({intensity,domains=[]}={}){
 const tier=actionTierR53(intensity),d=new Set(domains);
 return VOLITION_ACTIONS.filter(a=>tier>=a.minTier&&(!a.requiresDomain||d.has(a.requiresDomain))).map(a=>({...a}));
}

export function bootstrapVolitionDomainsR5({binding}={}){
 // R5.16 removes the old 0/0/6 assumption that a Volition must create physics.
 // Domains are no longer auto-granted merely to make a material universe possible;
 // baseline physics exists independently and extraordinary domains require played cause.
 return (binding?.volitionEntities||[]).map(v=>({entityId:v.entityId,domains:[]}));
}
