const clone=x=>structuredClone(x);
const commonOf=legacy=>legacy?.common??legacy;

export function getPrimordialLegacyTransforms(legacy){
  if(!legacy||legacy.consumer!=='BOOT01_FORMACION_MUNDO') throw new Error('BOOT01_PRIMORDIAL_LEGACY_REQUIRED');
  const source=commonOf(legacy); const values=[];
  for(const r of source.residues||[]) if(r.status==='ACTIVE'&&(r.transform||r.transformId||r.resultTag)) values.push(r.transform||r.transformId||r.resultTag);
  for(const d of source.causalChain||[]) for(const v of [d.transform,d.transformId,d.resultTag]) if(v) values.push(v);
  for(const v of legacy.extensions?.physics?.sourceTags||[]) if(v) values.push(v);
  for(const v of legacy.extensions?.mystic?.sourceTags||[]) if(v) values.push(v);
  return [...new Set(values)];
}

export function getPrimordialLegacyFingerprint(legacy){
  if(!legacy||legacy.consumer!=='BOOT01_FORMACION_MUNDO') throw new Error('BOOT01_PRIMORDIAL_LEGACY_REQUIRED');
  return legacy.fingerprint??legacy.causalFingerprint??legacy.common?.provenance?.causalFingerprint??getPrimordialLegacyTransforms(legacy).join('|');
}

export function projectLegacyToBoot01(legacy){
  const source=commonOf(legacy); const transforms=getPrimordialLegacyTransforms(legacy);
  const weights={EXTENDER:1,QUEBRAR:1,ENTRELAZAR:1};
  if(transforms.includes('SISTEMA_DISTRIBUIDO')) weights.EXTENDER+=2;
  if(transforms.includes('NUCLEO_DOMINANTE')) weights.QUEBRAR+=2;
  if(transforms.includes('ORBITAS_ESTABLES')) weights.EXTENDER+=1;
  if(transforms.includes('VINCULO_IMPERSONAL')) weights.ENTRELAZAR+=3;
  if(transforms.includes('HUELLA_CONSCIENTE')) weights.ENTRELAZAR+=1;
  return {producer:legacy.id,consumer:'BOOT01_FORMACION_MUNDO',causalFingerprint:getPrimordialLegacyFingerprint(legacy),weights,primordialResidues:clone(source.residues||[]),causalChain:clone(source.causalChain||[])};
}
