export function pickContextualActions(options){
 const out=[],seen=new Set();
 for(const o of options||[]){const key=o?.id||JSON.stringify(o);if(seen.has(key))continue;seen.add(key);out.push(o);}
 return out;
}
