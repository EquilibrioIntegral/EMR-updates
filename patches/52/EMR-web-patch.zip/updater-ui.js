import { GAME_VERSION } from './engine/state.js';
import { compareVersions, updateAvailable, validateUpdateManifest, validatePatchManifest } from './engine/update.js';

const DEFAULT_PATCH_CHANNEL='https://raw.githubusercontent.com/EquilibrioIntegral/EMR-updates/main/latest.json';
const PATCH_CHANNEL=localStorage.getItem('emr.patch.channel')||DEFAULT_PATCH_CHANNEL;
const EMERGENCY_IMPORT=new URLSearchParams(location.search).get('emergencyImport')==='1'||localStorage.getItem('emr.patch.emergencyImport')==='1';
const REQUIRED_MANIFEST_KEY='emr.update.requiredManifest';
const status=document.querySelector('#android-update-status');
const installButton=document.querySelector('#android-update-button');
const importPatchButton=document.querySelector('#patch-import-button');
const importPatchInput=document.querySelector('#patch-import-file');
const startupGate=document.querySelector('#emr-update-startup-gate');
const startupGateText=document.querySelector('#emr-update-startup-text');
const version=GAME_VERSION.replace('A1-HYB-','');
const versionLabel=document.querySelector('#app-version');
if(versionLabel) versionLabel.textContent=`Versión: ${version}`;
let manifest=null;
let patchState={sequence:0,active:false};
let checking=false;
let installing=false;
let blocker=null;
let blockerText=null;
let blockerButton=null;

function native(){return location.protocol==='capacitor:' || globalThis.Capacitor?.isNativePlatform?.();}
function msg(text=''){if(status)status.textContent=text;}
function removeLegacyUpdateUi(){for(const node of document.querySelectorAll('button,a')){const text=(node.textContent||'').trim();if(/buscar\s+actualizaci[oó]n|netlify/i.test(text))node.remove();}}
async function cleanNativePwaResidue(){if(!native())return;try{if('serviceWorker'in navigator){const regs=await navigator.serviceWorker.getRegistrations();await Promise.all(regs.map(reg=>reg.unregister()));}if('caches'in globalThis){const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith('emr-hybrid-')).map(k=>caches.delete(k)));}}catch{}}
async function refreshPatchState(){const pm=globalThis.Capacitor?.Plugins?.PatchManager;if(!pm)return;try{patchState=await pm.getState();}catch{patchState={sequence:0,active:false};}}

function markGatePending(text='Comprobando actualizaciones…'){
  document.documentElement.dataset.updateGate='pending';
  if(startupGate){startupGate.hidden=false;startupGate.setAttribute('aria-hidden','false');}
  if(startupGateText)startupGateText.textContent=text;
}
function releaseStartupGate(){
  if(startupGate){startupGate.hidden=true;startupGate.setAttribute('aria-hidden','true');}
  document.documentElement.dataset.updateGate='ready';
  window.dispatchEvent(new CustomEvent('emr:update-gate-ready'));
}

function ensureBlocker(){
  if(blocker)return blocker;
  blocker=document.createElement('div');
  blocker.id='emr-mandatory-update-blocker';
  blocker.setAttribute('role','dialog');
  blocker.setAttribute('aria-modal','true');
  blocker.style.cssText='position:fixed;inset:0;z-index:2147483647;background:rgba(7,9,14,.985);display:flex;align-items:center;justify-content:center;padding:24px;box-sizing:border-box;color:#f5f1e8;font-family:inherit;';
  const panel=document.createElement('div');
  panel.style.cssText='width:min(560px,100%);text-align:center;padding:28px 22px;border:1px solid rgba(255,255,255,.18);border-radius:18px;background:#111722;box-shadow:0 24px 80px rgba(0,0,0,.55);';
  const title=document.createElement('h2');
  title.textContent='Actualización obligatoria';
  title.style.cssText='margin:0 0 14px;font-size:1.6rem;';
  blockerText=document.createElement('p');
  blockerText.style.cssText='margin:0 0 22px;line-height:1.45;opacity:.9;';
  blockerButton=document.createElement('button');
  blockerButton.type='button';
  blockerButton.hidden=true;
  blockerButton.textContent='Reintentar actualización';
  blockerButton.style.cssText='width:100%;min-height:54px;border:0;border-radius:14px;font-size:1.05rem;font-weight:700;cursor:pointer;padding:12px 18px;';
  blockerButton.addEventListener('click',()=>{manifest=null;check();});
  panel.append(title,blockerText,blockerButton);
  blocker.append(panel);
  document.documentElement.append(blocker);
  document.documentElement.style.overflow='hidden';
  document.body&& (document.body.style.overflow='hidden');
  return blocker;
}

function hideBlocker(){
  blocker?.remove();
  blocker=null;blockerText=null;blockerButton=null;
  document.documentElement.style.overflow='';
  if(document.body)document.body.style.overflow='';
}

function rememberRequirement(candidate){localStorage.setItem(REQUIRED_MANIFEST_KEY,JSON.stringify(candidate));}
function clearRequirement(){localStorage.removeItem(REQUIRED_MANIFEST_KEY);hideBlocker();}
function readRequirement(){try{return JSON.parse(localStorage.getItem(REQUIRED_MANIFEST_KEY)||'null');}catch{return null;}}

function requirementStillPending(candidate){
  if(!candidate)return false;
  try{
    if(candidate.type==='web-patch'){
      const valid=validatePatchManifest(candidate);
      return Number(valid.sequence||0)>Number(patchState.sequence||0);
    }
    const valid=validateUpdateManifest(candidate);
    return compareVersions(valid.version,version)>0;
  }catch{return false;}
}

function enforceRequirement(candidate,{offline=false}={}){
  manifest=candidate;
  markGatePending(offline?'Actualización pendiente · conexión necesaria':'Actualizando El Mundo Recuerda…');
  ensureBlocker();
  blockerText.textContent=offline
    ? 'Hay una actualización obligatoria pendiente. Conéctate a Internet para actualizar y continuar.'
    : 'Hay una actualización obligatoria disponible. Se instalará automáticamente antes de continuar.';
  blockerButton.hidden=!offline;
  blockerButton.disabled=offline;
  blockerButton.textContent=offline?'Esperando conexión…':'Reintentar actualización';
  msg('Actualización obligatoria');
  if(installButton){installButton.hidden=true;installButton.disabled=true;}
}

function reconcileCachedRequirement(){
  const cached=readRequirement();
  if(!cached)return false;
  if(requirementStillPending(cached)){
    enforceRequirement(cached,{offline:!navigator.onLine});
    return true;
  }
  clearRequirement();
  return false;
}

async function setUpdateAvailable(candidate){
  rememberRequirement(candidate);
  enforceRequirement(candidate,{offline:false});
  await install({automatic:true});
}

async function fetchChunkedBase64(urls){
  const parts=[];
  for(const url of urls){
    const res=await fetch(`${url}${url.includes('?')?'&':'?'}t=${Date.now()}`,{cache:'no-store'});
    if(!res.ok)throw new Error(`PATCH_PART_HTTP_${res.status}`);
    parts.push((await res.text()).replace(/\s+/g,''));
  }
  return parts.join('');
}

async function check(){
  if(checking||installing)return;
  checking=true;
  markGatePending();
  removeLegacyUpdateUi();
  await refreshPatchState();
  const cachedPending=reconcileCachedRequirement();
  if(cachedPending&&!navigator.onLine){checking=false;return;}
  try{
    const res=await fetch(`${PATCH_CHANNEL}${PATCH_CHANNEL.includes('?')?'&':'?'}t=${Date.now()}`,{cache:'no-store'});
    if(!res.ok)throw new Error(`HTTP_${res.status}`);
    const candidate=await res.json();
    if(candidate.published===false){
      clearRequirement();
      manifest=null;msg('');releaseStartupGate();
      return;
    }
    if(candidate.type==='web-patch'){
      const valid=validatePatchManifest(candidate);
      if(Number(valid.sequence||0)>Number(patchState.sequence||0)) await setUpdateAvailable(valid);
      else {clearRequirement();manifest=null;msg('');releaseStartupGate();}
      return;
    }
    const valid=validateUpdateManifest(candidate);
    if(updateAvailable(version,valid)) await setUpdateAvailable(valid);
    else {clearRequirement();manifest=null;msg('');releaseStartupGate();}
  }catch{
    const cached=readRequirement();
    if(cached&&requirementStillPending(cached))enforceRequirement(cached,{offline:true});
    else{
      // Offline-first contract: if this device has never learned of a required
      // update, failure to reach the channel must not disable an offline game.
      manifest=null;msg('');releaseStartupGate();
    }
  }finally{checking=false;}
}

async function install({automatic=false}={}){
  if(installing)return;
  if(!manifest){await check();if(!manifest)return;}
  installing=true;
  markGatePending('Instalando actualización obligatoria…');
  if(blockerButton){blockerButton.hidden=true;blockerButton.disabled=true;}
  if(manifest.type==='web-patch'){
    const pm=globalThis.Capacitor?.Plugins?.PatchManager;
    if(!pm){
      installing=false;
      if(blockerText)blockerText.textContent='Esta instalación necesita una actualización completa para activar el sistema automático.';
      if(blockerButton){blockerButton.hidden=false;blockerButton.disabled=false;blockerButton.textContent='Reintentar';}
      msg('Esta instalación aún no soporta actualizaciones ligeras.');
      return;
    }
    try{
      msg('Descargando y verificando actualización…');
      if(Array.isArray(manifest.base64Parts)&&manifest.base64Parts.length){
        const base64=await fetchChunkedBase64(manifest.base64Parts);
        await pm.applyBase64({base64,sha256:manifest.sha256});
      }else{
        await pm.applyFromUrl({url:manifest.url,sha256:manifest.sha256});
      }
      msg('Actualización aplicada. Reiniciando…');
      location.reload();
      return;
    }catch(err){
      installing=false;
      if(blockerButton){blockerButton.hidden=false;blockerButton.disabled=false;blockerButton.textContent='Reintentar actualización';}
      if(blockerText)blockerText.textContent='No se pudo completar la actualización obligatoria. Comprueba tu conexión y vuelve a intentarlo.';
      msg(`No se pudo actualizar: ${err?.message||'error'}`);
      return;
    }
  }
  const updater=globalThis.Capacitor?.Plugins?.Updater;
  if(!updater){
    installing=false;
    if(blockerText)blockerText.textContent='Android necesita instalar una actualización completa para continuar.';
    if(blockerButton){blockerButton.hidden=false;blockerButton.disabled=false;blockerButton.textContent='Instalar actualización';blockerButton.onclick=()=>{window.location.href=manifest.apkUrl;};}
    if(automatic)msg('Actualización completa obligatoria');
    return;
  }
  try{
    const permission=await updater.canInstall();
    if(!permission.allowed){
      installing=false;
      msg('Android necesita permiso para instalar esta actualización.');
      if(blockerText)blockerText.textContent='Activa el permiso de instalación de Android para completar la actualización obligatoria.';
      if(blockerButton){blockerButton.hidden=false;blockerButton.disabled=false;blockerButton.textContent='Dar permiso';blockerButton.onclick=async()=>{await updater.openInstallPermission();};}
      return;
    }
    msg('Descargando y verificando actualización…');
    await updater.downloadAndInstall({url:manifest.apkUrl,sha256:manifest.sha256});
    msg('Descarga verificada. Android abrirá el instalador.');
  }catch(err){
    installing=false;
    if(blockerButton){blockerButton.hidden=false;blockerButton.disabled=false;blockerButton.textContent='Reintentar actualización';blockerButton.onclick=()=>install({automatic:false});}
    msg(err?.message?.includes('INSTALL_PERMISSION_REQUIRED')?'Activa el permiso de instalación y vuelve a intentarlo.':'No se pudo completar la actualización obligatoria.');
  }
}

async function sha256Hex(buffer){const hash=await crypto.subtle.digest('SHA-256',buffer);return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');}
function base64FromBuffer(buffer){const bytes=new Uint8Array(buffer);let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+32768,bytes.length)));return btoa(binary);}
async function importPatch(file){const pm=globalThis.Capacitor?.Plugins?.PatchManager;if(!pm){msg('Esta instalación aún no soporta actualizaciones ligeras.');return;}try{if(file.size>32*1024*1024)throw new Error('PATCH_TOO_LARGE');msg('Verificando actualización local…');const bytes=await file.arrayBuffer();const sha256=await sha256Hex(bytes);await pm.applyBase64({base64:base64FromBuffer(bytes),sha256});msg('Actualización aplicada. Reiniciando…');location.reload();}catch(err){msg(`Actualización rechazada: ${err?.message||'error'}`);}}

// The normal player flow never exposes a manual patch installer. It exists only
// behind ?emergencyImport=1 (or its localStorage equivalent) for recovery.
if(installButton)installButton.hidden=true;
if(importPatchButton&&importPatchInput&&native()&&EMERGENCY_IMPORT){
  importPatchButton.hidden=false;
  importPatchButton.addEventListener('click',()=>importPatchInput.click());
  importPatchInput.addEventListener('change',async()=>{const f=importPatchInput.files?.[0];if(f)await importPatch(f);importPatchInput.value='';});
}else if(importPatchButton){importPatchButton.hidden=true;}

markGatePending();
removeLegacyUpdateUi();
await cleanNativePwaResidue();
await refreshPatchState();
const pendingAtBoot=reconcileCachedRequirement();
if(pendingAtBoot&&navigator.onLine){manifest=null;await check();}
else if(!pendingAtBoot)await check();
removeLegacyUpdateUi();
window.addEventListener('online',async()=>{manifest=null;await check();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')check();});
