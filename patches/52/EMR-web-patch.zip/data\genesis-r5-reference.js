// GEN-R5 reference configuration for integration and human prototype testing.
// Values below are CANDIDATE parameters selected from simulation evidence and human E2E feedback, not frozen final canon.
export const GENESIS_R5_REFERENCE_CONFIG=Object.freeze({
 schema:'EMR_GENESIS_R5_REFERENCE_CONFIG_v1',
 status:'CANDIDATE_HUMAN_TEST',
 boardPreset:'A61',
 matterCount:10,
 alternatives:{matterCounts:[8,10,12],boardPresets:['A61','A60','B76']},
 targetMinutes:10,
 reasons:[
  'A61 replaces the rectangular A60 as the active human-test geometry: regular hexagon of radius 4 with one unique central cell for stellar formation.',
  'A60 remains available only for backward saves and direct comparison; it is no longer the reference board for new Genesis sessions.',
  '10 MAT remains the neutral integration default between faster 8 and richer 12; physical timing decides final calibration.',
  'Player-facing cell labels are 1-61; H001-H061 remain internal engine identifiers only.',
  'Canonical physical Intention decks IN-01..IN-04 remain unchanged for multiplayer; solo does not require physical Intention cards.'
 ]
});
