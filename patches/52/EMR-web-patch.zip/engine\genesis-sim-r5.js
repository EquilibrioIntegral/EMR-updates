import {deriveSignatureR53,deriveSoloSignatureR59,soloSecondaryRollPlanR59,signatureRollPlan,bindAgenciesToSignatureR53} from './genesis-signature-r53.js';
import {seededRng} from './genesis-material-r5.js';
import {createCosmogonyR5,applyCosmogonyIntervention,advanceCosmicEpoch,cosmogonySummary} from './genesis-cosmogony-r5.js';
import {compileGenesisLegacyR5} from './genesis-legacy-r5.js';

export const GENESIS_SIM_R5_SCHEMA='EMR_GENESIS_SIM_R5_v1';
const d6=r=>1+Math.floor(r()*6);

function signatureFor(seed,choices){
 const r=seededRng(`${seed}:signature`);
 if(choices.length===1){
  const plan=soloSecondaryRollPlanR59(choices[0]),rolls={};
  for(const spec of plan.rolls)rolls[spec.nature]=d6(r);
  return deriveSoloSignatureR59(choices[0],rolls);
 }
 const plan=signatureRollPlan(choices),rolls={};
 if(plan.mode==='TIED_SUPPORT'){
  const used=new Set();
  for(const spec of plan.rolls){let x=d6(r),guard=0;while(used.has(x)&&guard++<100)x=d6(r);if(used.has(x))throw new Error('GEN_SIM_TIE_EXHAUSTED');used.add(x);rolls[spec.nature]=x;}
 }else for(const spec of plan.rolls)rolls[spec.nature]=d6(r);
 return deriveSignatureR53(choices,rolls);
}

export function simulateGenesisR5({seed='SIM',boardPreset='B76',matterCount=10,choices=['PHYSICS'],strategy='NO_INTERVENE',maxEpochs=9}={}){
 const sig=signatureFor(seed,choices),binding=bindAgenciesToSignatureR53(choices,sig.signature),initial=createCosmogonyR5({seed,boardPreset,matterCount});
 let state=initial,decisionCount=0,meaningfulPhysicalActions=0;
 for(let epoch=0;epoch<maxEpochs&&!state.closed;epoch++){
  for(const agency of binding.agencies){
   const move=choosePolicyIntervention(state,agency,strategy);
   if(move){state=applyCosmogonyIntervention(state,move);decisionCount++;if(['CONCENTRATE','PRESERVE_DISK','PROTECT'].includes(move.kind))meaningfulPhysicalActions++;}
   else decisionCount++;
  }
  state=advanceCosmicEpoch(state);
 }
 const summary=cosmogonySummary(state),converged=state.closed&&state.star.state==='IGNITED'&&state.planets.length>0;
 const failureReason=converged?null:classifyFailure(state,maxEpochs);
 let legacy=null;if(converged)legacy=compileGenesisLegacyR5({cosmogony:state,signatureRecord:sig,binding});
 const estimated=estimatePlayTime({choices,decisionCount,meaningfulPhysicalActions,cosmicMoves:summary.physicalMoves,epochs:summary.epoch});
 return{schema:GENESIS_SIM_R5_SCHEMA,seed:String(seed),boardPreset,matterCount,choices:[...choices],strategy,signature:sig,binding,summary,converged,failureReason,decisionCount,meaningfulPhysicalActions,estimated,legacy,state};
}

function classifyFailure(state,maxEpochs){
 if(state.star.state!=='IGNITED')return state.epoch>=maxEpochs?'STAR_NOT_IGNITED_BY_LIMIT':'STAR_NOT_IGNITED';
 if(state.phase==='CLOSED_NO_PLANET'||state.planets.length===0)return'NO_PLANET_AFTER_IGNITION';
 if(!state.closed)return`NOT_CLOSED_PHASE_${state.phase}`;
 return`UNKNOWN_${state.phase}`;
}

function choosePolicyIntervention(state,agency,strategy){
 if(strategy==='NO_INTERVENE')return null;
 const free=state.matter.parcels.filter(p=>p.state==='FREE'||p.state==='DISK');if(!free.length)return null;
 const planetValue=p=>p.hidden.refractories+p.hidden.volatiles+p.hidden.mass/3;
 if(agency.nature==='PHYSICS'){
  if(strategy==='STAR_MAX'){const target=[...free].filter(p=>p.state==='FREE').sort((a,b)=>b.hidden.mass-a.hidden.mass||a.id.localeCompare(b.id))[0];return target?{actorId:agency.id,nature:'PHYSICS',kind:'CONCENTRATE',targetId:target.id}:null;}
  const target=[...free].sort((a,b)=>planetValue(b)-planetValue(a)||a.id.localeCompare(b.id))[0];return target?{actorId:agency.id,nature:'PHYSICS',kind:'PRESERVE_DISK',targetId:target.id}:null;
 }
 if(agency.nature==='MYSTIC'){
  const target=[...free].sort((a,b)=>planetValue(b)-planetValue(a)||a.id.localeCompare(b.id))[0];
  return target?{actorId:agency.id,nature:'MYSTIC',kind:'IMPRINT',targetId:target.id,principle:agency.actionTier>=2?'PERSISTENCE_TRACE':'LINKED_POTENTIAL'}:null;
 }
 if(agency.nature==='WILL'){
  const target=[...free].sort((a,b)=>planetValue(b)-planetValue(a)||a.id.localeCompare(b.id))[0];
  if(!target)return null;
  return{actorId:agency.id,nature:'WILL',kind:strategy==='STAR_MAX'?'CLAIM':'PROTECT',targetId:target.id};
 }
 return null;
}

function estimatePlayTime({choices,decisionCount,meaningfulPhysicalActions,cosmicMoves,epochs}){
 // QA heuristic only: setup 35s; each decision opportunity 6s screen/read + 6s choice;
 // significant physical manipulation 4s; cosmic move instruction+move 3s; epoch transition 4s.
 const setupSeconds=35,screenSeconds=decisionCount*6+epochs*4,tableDecisionSeconds=decisionCount*6,manipulationSeconds=meaningfulPhysicalActions*4+cosmicMoves*3,totalSeconds=setupSeconds+screenSeconds+tableDecisionSeconds+manipulationSeconds;
 return{heuristic:true,totalSeconds,screenSeconds,tableSeconds:totalSeconds-screenSeconds,screenShare:Number((screenSeconds/Math.max(1,totalSeconds)).toFixed(3)),playerCount:choices.length};
}

export function runBalanceMatrixR5({seeds=20,boards=['A60','B76'],matterCounts=[8,10,12],playerChoices=[['PHYSICS'],['PHYSICS','WILL'],['PHYSICS','MYSTIC','WILL'],['PHYSICS','PHYSICS','MYSTIC','WILL']],strategies=['NO_INTERVENE','DISK_PRESERVE','STAR_MAX']}={}){
 const rows=[];
 for(const boardPreset of boards)for(const matterCount of matterCounts)for(const choices of playerChoices)for(const strategy of strategies){
  const sims=[];for(let i=0;i<seeds;i++)sims.push(simulateGenesisR5({seed:`R5:${boardPreset}:${matterCount}:${choices.join('-')}:${strategy}:${i}`,boardPreset,matterCount,choices,strategy}));
  const conv=sims.filter(x=>x.converged),failed=sims.filter(x=>!x.converged),mean=fn=>conv.length?conv.reduce((s,x)=>s+fn(x),0)/conv.length:null;
  const failureReasons={};for(const x of failed)failureReasons[x.failureReason]=(failureReasons[x.failureReason]||0)+1;
  rows.push({boardPreset,matterCount,players:choices.length,choices:choices.join('/'),strategy,seeds,convergenceRate:conv.length/seeds,failureCount:failed.length,failureReasons,meanEpochs:mean(x=>x.summary.epoch),meanPlanets:mean(x=>x.summary.planetCount),meanStarFraction:mean(x=>x.summary.star.mass/x.state.totalInitialMass),meanPhysicalMoves:mean(x=>x.summary.physicalMoves+x.meaningfulPhysicalActions),meanEstimatedSeconds:mean(x=>x.estimated.totalSeconds),meanScreenShare:mean(x=>x.estimated.screenShare),starFamilies:Object.fromEntries([...new Set(conv.map(x=>x.summary.star.family))].map(f=>[f,conv.filter(x=>x.summary.star.family===f).length]))});
 }
 return{schema:'EMR_GENESIS_BALANCE_MATRIX_R5_v1',seedsPerCell:seeds,rows};
}
