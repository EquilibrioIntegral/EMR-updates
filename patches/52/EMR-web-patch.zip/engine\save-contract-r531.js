import {serializeState,deserializeState} from './state.js';

export const SAVE_CONTRACT_R531='EMR_SAVE_CONTRACT_R531_v1';
const clone=x=>structuredClone(x);

export function genesisResumeDescriptorR531(state){
  const live=state?.session?.genesisR5||null;
  const flow=live?.materializationFlow||null;
  return {
    schema:SAVE_CONTRACT_R531,
    campaignSchema:state?.meta?.schemaVersion||null,
    gameVersion:state?.meta?.gameVersion||null,
    build:state?.meta?.build||null,
    seed:state?.meta?.seed??null,
    bootPhase:state?.session?.boot?.phase||null,
    genesisPresent:Boolean(live),
    genesisPhase:live?.phase||null,
    round:Number(live?.round||0),
    actorIndex:Number(live?.actorIndex||0),
    materialization:flow?{
      schema:flow.schema||null,
      cursor:Number(flow.cursor||0),
      total:Number(flow.total||0),
      status:flow.status||null,
      confirmed:Number(flow.confirmed?.length||0),
      nextChange:flow.cursor<flow.total?clone(flow.queue?.[flow.cursor]||null):null
    }:null
  };
}

export function validateGenesisResumeR531(state){
  const errors=[];
  const d=genesisResumeDescriptorR531(state);
  if(!d.campaignSchema)errors.push('SAVE_SCHEMA_VERSION_MISSING');
  if(!d.gameVersion)errors.push('SAVE_GAME_VERSION_MISSING');
  if(!d.build)errors.push('SAVE_BUILD_MISSING');
  if(d.seed==null||String(d.seed).length===0)errors.push('SAVE_SEED_MISSING');
  const live=state?.session?.genesisR5;
  if(live){
    if(!live.phase)errors.push('GENESIS_PHASE_MISSING');
    if(!Number.isInteger(Number(live.actorIndex||0))||Number(live.actorIndex||0)<0)errors.push('GENESIS_ACTOR_INDEX_INVALID');
    if(live.phase==='MATERIALIZE'){
      const f=live.materializationFlow;
      if(!f)errors.push('MATERIALIZATION_FLOW_MISSING');
      else{
        const cursor=Number(f.cursor),total=Number(f.total),queue=Array.isArray(f.queue)?f.queue:[];
        if(!Number.isInteger(cursor)||cursor<0)errors.push('MATERIALIZATION_CURSOR_INVALID');
        if(!Number.isInteger(total)||total<0)errors.push('MATERIALIZATION_TOTAL_INVALID');
        if(queue.length!==total)errors.push('MATERIALIZATION_QUEUE_TOTAL_DRIFT');
        if(cursor>total)errors.push('MATERIALIZATION_CURSOR_OVERFLOW');
        if((f.confirmed?.length||0)!==Math.min(cursor,total))errors.push('MATERIALIZATION_CONFIRMED_CURSOR_DRIFT');
      }
    }
  }
  return {ok:errors.length===0,errors,descriptor:d};
}

export function roundTripPortableSaveR531(state){
  const before=clone(state);
  const text=serializeState(before);
  const restored=deserializeState(text);
  const text2=serializeState(restored);
  const exact=JSON.stringify(JSON.parse(text))===JSON.stringify(JSON.parse(text2));
  const validation=validateGenesisResumeR531(restored);
  return {schema:SAVE_CONTRACT_R531,text,restored,exact,validation,descriptor:genesisResumeDescriptorR531(restored)};
}
