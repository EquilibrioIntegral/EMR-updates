// GEN-ACTION-01 — differentiated embodied actions for the physical Genesis table.
// Players act through pawns; the app validates reach and records causal meaning.
import {getAgency,recordIndividualAction} from './primordial-signature.js';
import {hexDistance} from './primordial-gravity.js';
const clone=x=>JSON.parse(JSON.stringify(x));
export const GENESIS_AGENCY_ACTIONS_SCHEMA='EMR_GENESIS_AGENCY_ACTIONS_v1';
export const ACTIONS=Object.freeze({
 PHYSICS:Object.freeze(['ATTRACT','IMPULSE','COHERE']),
 MYSTIC:Object.freeze(['IMPRINT','LINK','TRANSFORM_POTENTIAL']),
 WILL:Object.freeze(['PRESERVE','CREATE_SEED','OPPOSE_NARROW'])
});
const tags=Object.freeze({
 ATTRACT:['FORMATION','GRAVITY'],IMPULSE:['FORMATION','MOTION'],COHERE:['FORMATION','STRUCTURE'],
 IMPRINT:['IMPREGNATION','PRINCIPLE'],LINK:['RELATION','MYSTIC_LINK'],TRANSFORM_POTENTIAL:['POTENTIAL','TRANSFORMATION'],
 PRESERVE:['WILL_ACT','PRESERVATION'],CREATE_SEED:['WILL_ACT','CREATION_SEED'],OPPOSE_NARROW:['WILL_ACT','NARROW_EXCEPTION']
});
export function availableAgencyActions(state,playerId){const a=getAgency(state,playerId);return ACTIONS[a.nature].map(id=>({id,nature:a.nature,reach:a.profile.reach,cost:a.profile.cost}));}
export function performAgencyAction(state,{playerId,action,targetId,targetPosition=null,futureHooks=[],preparation=0}={}){
 const a=getAgency(state,playerId);if(!ACTIONS[a.nature].includes(action))throw new Error('GEN_ACTION_NOT_OWNED');
 if(targetPosition&&hexDistance(a.position,targetPosition)>a.profile.reach)throw new Error('GEN_ACTION_OUT_OF_REACH');
 if(action==='OPPOSE_NARROW'&&a.nature==='WILL'&&a.profile.authority>1)throw new Error('GEN_NARROW_EXCEPTION_ONLY_WEAK_WILL');
 const next=recordIndividualAction(state,{playerId,operation:action,targetId,position:a.position,preparation,causalTags:tags[action],futureHooks});
 const instruction=physicalInstruction({nature:a.nature,action,targetId});
 return{schema:GENESIS_AGENCY_ACTIONS_SCHEMA,state:next,instruction,trace:clone(next.history.at(-1))};
}
export function physicalInstruction({nature,action,targetId}){
 const t=targetId||'el objetivo elegido';
 const map={
  ATTRACT:`Acerca físicamente las masas vinculadas a ${t}.`,IMPULSE:`Desplaza físicamente ${t} una posición permitida.`,COHERE:`Agrupa físicamente los cuerpos de ${t} que hayan entrado en contacto.`,
  IMPRINT:`Coloca temporalmente tu principio junto a ${t}; retíralo cuando la app confirme que ha quedado impregnado.`,LINK:`Señala físicamente la relación entre ${t} y el segundo objetivo de tu Intención.`,TRANSFORM_POTENTIAL:`Orienta el principio sobre ${t} para indicar qué puede llegar a transformarse.`,
  PRESERVE:`Protege físicamente ${t} con tu peón hasta la Convergencia.`,CREATE_SEED:`Coloca una semilla primordial junto a ${t}; todavía no representa una criatura ni una cultura.`,OPPOSE_NARROW:`Mantén tu peón junto a ${t}: intentas salvar o alterar solo ese elemento, no cancelar la ley dominante.`
 };
 if(!map[action])throw new Error('GEN_ACTION_UNKNOWN');return{nature,action,text:map[action],screenRole:'BRIEF_INSTRUCTION_THEN_RETURN_TO_TABLE'};
}
