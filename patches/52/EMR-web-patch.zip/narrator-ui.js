import {narratorService,NARRATOR_TTS_CONFIG} from './narrator-service.js';

const boot=document.querySelector('#boot');
const bootText=document.querySelector('#boot-fiction[data-narration="enabled"]');
let button=null;
let previousVolumes=new Map();
let rampFrame=0;
let autoTimer=0;
let lastAutoKey='';
let lastNarration=null;

function installStyle(){
  if(document.querySelector('#narrator-style'))return;
  const style=document.createElement('style');style.id='narrator-style';style.textContent=`
  .narrator-row{display:flex;justify-content:flex-start;align-items:center;gap:.55rem;min-height:2.75rem;margin:.35rem 0 .8rem;padding-left:.1rem;position:relative;z-index:2}
  .narrator-button{width:2.55rem;height:2.55rem;min-width:2.55rem;padding:0;border-radius:999px;border:1px solid rgba(255,255,255,.18);background:rgba(10,13,18,.62);color:inherit;font-size:1.08rem;line-height:1;display:grid;place-items:center;opacity:.95;backdrop-filter:blur(6px)}
  .narrator-button:hover,.narrator-button:focus-visible{opacity:1}.narrator-button[data-state="loading"]{animation:narratorPulse 1s ease-in-out infinite}.narrator-button[data-enabled="false"]{opacity:.55}
  .narrator-label{font-size:.78rem;opacity:.66}.narrator-button[data-state="playing"]{opacity:1}
  @keyframes narratorPulse{50%{opacity:.45}} @media (prefers-reduced-motion:reduce){.narrator-button[data-state="loading"]{animation:none}}
  `;document.head.appendChild(style);
}

function ensureButton(){
  if(!bootText||button)return;
  installStyle();const row=document.createElement('div');row.className='narrator-row';
  button=document.createElement('button');button.type='button';button.className='narrator-button';button.dataset.state='idle';button.title=`Guionista · ${NARRATOR_TTS_CONFIG.voice} · ${NARRATOR_TTS_CONFIG.speed}`;
  const label=document.createElement('span');label.className='narrator-label';label.textContent='Voz del Guionista';
  row.append(button,label);bootText.insertAdjacentElement('afterend',row);
  button.addEventListener('click',()=>{
    const wasEnabled=narratorService.getPreferences().enabled;
    const next=narratorService.toggleEnabled();syncToggle(next.enabled);
    if(wasEnabled&&!next.enabled){lastNarration=narratorService.getResumeSnapshot?.()||lastNarration;return;}
    if(next.enabled){const resumed=narratorService.resume?.();if(!resumed)scheduleAutoplay(true);}
  });
  syncToggle(narratorService.getPreferences().enabled);
}

function syncToggle(enabled){if(!button)return;button.dataset.enabled=String(enabled);button.textContent=enabled?'🔊':'🔇';button.setAttribute('aria-pressed',String(enabled));button.setAttribute('aria-label',enabled?'Silenciar voz del Guionista':'Activar voz del Guionista');}
function setState(state){if(!button)return;button.dataset.state=state;if(state==='loading'){button.setAttribute('aria-label','Preparando narración');}else syncToggle(narratorService.getPreferences().enabled);}
function ramp(audio,target,duration=280){if(!audio)return;const start=audio.volume;const began=performance.now();const tick=now=>{const t=Math.min(1,(now-began)/duration);audio.volume=start+(target-start)*(1-Math.pow(1-t,2));if(t<1)rampFrame=requestAnimationFrame(tick);};rampFrame=requestAnimationFrame(tick);}
function duck(){cancelAnimationFrame(rampFrame);if(previousVolumes.size===0){for(const audio of [document.querySelector('#menu-theme'),document.querySelector('#genesis-theme')]){if(!audio)continue;previousVolumes.set(audio,audio.volume);}}for(const audio of previousVolumes.keys()){if(!audio.paused)ramp(audio,Math.min(audio.volume,0.06),220);}}
function restore(){cancelAnimationFrame(rampFrame);for(const [audio,volume] of previousVolumes)ramp(audio,volume,520);previousVolumes.clear();}

function visible(el){return el&&el.getClientRects().length>0&&!el.hidden;}
function collectNarration(){
  if(!boot||boot.hidden)return null;
  const parts=[];
  if(visible(bootText)&&bootText.textContent?.trim())parts.push(bootText.textContent.trim());
  const host=boot.querySelector('#boot-step');
  if(host){
    const nodes=[...host.querySelectorAll('[data-narration="enabled"],[data-guionista],.genesis-emergence-narrative,.genesis-story,.genesis-copy')]
      .filter(visible)
      .filter((node,idx,arr)=>!arr.some((other,j)=>j!==idx&&other.contains(node)));
    for(const node of nodes){const text=node.textContent?.trim();if(text&&!parts.includes(text))parts.push(text);}
  }
  const text=parts.join('\n\n').replace(/\s+/g,' ').trim();
  if(!text)return null;
  return {text,id:`guionista-${hashText(text)}`};
}
function hashText(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36);}
function scheduleAutoplay(force=false){
  clearTimeout(autoTimer);autoTimer=setTimeout(async()=>{
    if(!narratorService.getPreferences().enabled||!boot||boot.hidden)return;
    const current=collectNarration();if(!current)return;
    if(!force&&current.id===lastAutoKey)return;
    lastAutoKey=current.id;lastNarration=current;
    await narratorService.speak(current.text,{id:current.id});
  },70);
}

async function stopForNavigation(reason='screen-change'){
  clearTimeout(autoTimer);
  await narratorService.stop(reason);
}

window.addEventListener('emr:narration-loading',()=>{setState('loading');duck();});
window.addEventListener('emr:narration-start',()=>setState('playing'));
for(const evt of ['emr:narration-end','emr:narration-stop'])window.addEventListener(evt,()=>{setState('idle');restore();});
window.addEventListener('emr:narration-error',event=>{setState('idle');restore();const status=document.querySelector('#boot-status');if(status)status.textContent=event.detail?.message||'No se ha podido reproducir la narración.';});
window.addEventListener('emr:narration-preference',event=>syncToggle(event.detail?.enabled!==false));

ensureButton();
if(boot){
  let lastScreenKey='';
  const screenKey=()=>{
    if(boot.hidden)return 'hidden';
    const host=boot.querySelector('#boot-step');
    return `${host?.dataset?.step||''}|${host?.getAttribute('data-screen')||''}|${collectNarration()?.id||''}`;
  };
  const syncBoot=()=>{
    const key=screenKey();
    if(key!==lastScreenKey&&lastScreenKey){stopForNavigation('screen-change');}
    lastScreenKey=key;
    if(boot.hidden){stopForNavigation('navigation');}
    else{narratorService.warmEngine();scheduleAutoplay();}
  };
  new MutationObserver(()=>syncBoot()).observe(boot,{attributes:true,attributeFilter:['hidden','data-step','data-screen'],childList:true,subtree:true,characterData:true});
  document.addEventListener('click',event=>{
    const target=event.target?.closest?.('button,a,[role="button"]');
    if(!target||target===button)return;
    if(narratorService.isPlaying())stopForNavigation('ui-navigation');
  },true);
  window.addEventListener('hashchange',()=>stopForNavigation('hash-navigation'));
  window.addEventListener('popstate',()=>stopForNavigation('history-navigation'));
  syncBoot();
}
