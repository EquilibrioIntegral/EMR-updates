import {composeGenesisEvent,applyGenesisNarrativeEvent} from './genesis-guionista.js';

export const GENESIS_TABLE_GUI_BRIDGE='EMR_GENESIS_TABLE_GUI_BRIDGE_v1';
const OP={COHERE:'ATTRACT',ATTRACT:'ATTRACT',IMPULSE:'DISPERSE',LINK:'BIND',IMPRINT:'BIND',PRESERVE:'PRESERVE',CREATE_SEED:'CREATE',WAIT:'NO_INTERVENE'};

export function projectTableForGuionista(s){
 const players=s?.agencies?.players||[];
 const byId=new Map(players.map(p=>[p.id,p]));
 return {
  agencies:players.map((p,i)=>({id:p.id,kind:p.nature,name:s.names?.[i]||`Jugador ${i+1}`})),
  eventLog:(s.actions||[]).map(a=>({id:a.memoryRef||a.id,type:'FREE_ACTION',round:a.round,agencyId:a.actor,agencyKind:byId.get(a.actor)?.nature,operation:OP[a.action]||a.action,targetId:a.target})),
  narrativeMemory:s.narrativeMemory||[],
  narrativeThreats:s.narrativeThreats||[],
  physicalSignals:s.physicalSignals||[],
  genesisTurn:{round:s.round||1}
 };
}

export function resolveTableNarrativeBeat(s,rng=0,round=s.round){
 const projected=projectTableForGuionista(s);
 const event=composeGenesisEvent({state:projected,round,rng});
 const applied=applyGenesisNarrativeEvent(projected,event);
 s.narrativeMemory=applied.narrativeMemory;
 s.narrativeThreats=applied.narrativeThreats||[];
 s.lastNarrativeBeat={kind:event.kind,dramaticRole:event.dramaticRole,publicText:event.publicText,decisionPrompt:event.decisionPrompt||null,materializationHint:event.materializationHint||null};
 s.trace??=[];
 s.trace.push({event:'NARRATIVE_BEAT',round,kind:event.kind,memoryTags:event.memoryTags});
 return structuredClone(s.lastNarrativeBeat);
}

export function publicNarrativeBeat(s){
 const b=s?.lastNarrativeBeat;
 return b?{kind:b.kind,dramaticRole:b.dramaticRole,publicText:b.publicText,decisionPrompt:b.decisionPrompt||null,materializationHint:b.materializationHint||null}:null;
}
