// GEN-UI-01 — brief player-facing controls for the physical Genesis loop.
// The screen only orchestrates; physical actions happen on the table.
import {restoreGenesisSession,replaceGenesisSession} from '../engine/genesis-persistence.js';
import {actGenesisPlayer,submitSecretIntention,revealGenesisIntentions,resolveGenesisPlayerConvergence,closeGenesisPlayerSession} from '../engine/genesis-player-experience.js';
import {installWeightedGenesisHandoffForBoot01} from '../engine/genesis-boot01-adapter.js';

const INTENTIONS=[['CONCENTRATE','Concentrar'],['TRANSFORM','Transformar'],['PRESERVE','Preservar']];
const actionFor=nature=>nature==='WILL'?{action:'PRESERVE',targetId:'FRAG'}:nature==='MYSTIC'?{action:'IMPRINT',targetId:'ARC'}:{action:'ATTRACT',targetId:'CORE+FRAG'};
const playerName=(state,id)=>state.session.players[Number(String(id).replace('P',''))-1]?.name||`Jugador ${String(id).replace('P','')}`;
function save(state,session,persist){replaceGenesisSession(state,session);persist();}

export function renderGenesisUi({state,host,persist,rerender}){
 const session=restoreGenesisSession(state),players=session.bridge.genesis.players;
 session.ui??={actor:0,intention:0};
 if(session.phase==='INDIVIDUAL_ACTIONS'){
  const i=Math.min(session.ui.actor||0,players.length-1),p=players[i],name=playerName(state,p.id),a=actionFor(p.nature);
  const instruction=p.nature==='WILL'?'Protege con tu peón un único fragmento. No intentas detener las leyes del universo.':p.nature==='MYSTIC'?'Sitúa tu peón junto al fragmento exterior e imprégnalo con tu principio.':'Sitúa tu peón junto a los cuerpos indicados y acerca físicamente ambos una posición.';
  host.innerHTML=`<p class="preshow-progress">GÉNESIS · EL PRIMER DESPERTAR</p><h2>${name}, actúas sobre la creación</h2><p>${instruction}</p><p>Hazlo primero sobre la mesa. Cuando esté hecho, confirma para que el mundo lo recuerde.</p><button id="gen-action-done">Hecho en la mesa →</button>`;
  host.querySelector('#gen-action-done').onclick=()=>{let next=actGenesisPlayer(session,{playerId:p.id,...a});next.ui={...session.ui,actor:i+1,intention:0};if(i+1>=players.length){next.phase='SECRET_INTENTIONS';next.ui.actor=0;}save(state,next,persist);rerender();};return;
 }
 if(session.phase==='SECRET_INTENTIONS'){
  const i=Math.min(session.ui.intention||0,players.length-1),p=players[i],name=playerName(state,p.id);
  host.innerHTML=`<p class="preshow-progress">INTENCIÓN SECRETA · ${i+1}/${players.length}</p><h2>${name}, elige sin mostrarlo</h2><p>Los demás jugadores no deben mirar la pantalla hasta que hayas elegido.</p><div class="choices">${INTENTIONS.map(([id,label])=>`<button data-gen-intention="${id}">${label}</button>`).join('')}</div>`;
  host.querySelectorAll('[data-gen-intention]').forEach(b=>b.onclick=()=>{let next=submitSecretIntention(session,{playerId:p.id,intention:b.dataset.genIntention});next.ui={...session.ui,intention:i+1,actor:0};save(state,next,persist);rerender();});return;
 }
 if(session.phase==='READY_TO_REVEAL'){
  host.innerHTML=`<p class="preshow-progress">CONVERGENCIA</p><h2>Todas las Intenciones están elegidas</h2><p>Volved a mirar juntos la pantalla. Revelad ahora vuestras Intenciones a la vez.</p><button id="gen-reveal">Revelar →</button>`;
  host.querySelector('#gen-reveal').onclick=()=>{const next=revealGenesisIntentions(session);next.ui={...session.ui};save(state,next,persist);rerender();};return;
 }
 if(session.phase==='CONVERGENCE'){
  const revealed=session.revealedIntentions.map(x=>`${playerName(state,x.playerId)} quiere ${x.text}`).join('; ');
  host.innerHTML=`<p class="preshow-progress">CONVERGENCIA</p><h2>La creación responde</h2><p>${revealed}.</p><p>La aplicación resolverá únicamente la causalidad que no resulte evidente y conservará las huellas de lo ocurrido.</p><button id="gen-converge">Resolver la Convergencia →</button>`;
  host.querySelector('#gen-converge').onclick=()=>{let next=resolveGenesisPlayerConvergence(session,{subjectId:'CORE+FRAG',contextByPlayer:Object.fromEntries(players.map(p=>[p.id,1]))});next.ui={actor:0,intention:0};save(state,next,persist);rerender();};return;
 }
 if(session.phase==='GENESIS_CLOSED'){
  const last=session.narrative.at(-1)||'La primera forma del mundo ha quedado fijada.';
  host.innerHTML=`<p class="preshow-progress">EL MUNDO RECUERDA</p><h2>La primera forma ha quedado fijada</h2><p>${last}</p><p>Dejad los componentes donde están. Lo ocurrido aquí será heredado por la formación del mundo.</p><button id="gen-close">Continuar →</button>`;
  host.querySelector('#gen-close').onclick=()=>{const closed=closeGenesisPlayerSession(session);installWeightedGenesisHandoffForBoot01(state,closed.handoff);replaceGenesisSession(state,closed.session);persist();rerender();};return;
 }
 host.innerHTML='<h2>La creación permanece en curso</h2><p>La partida conserva exactamente su estado para poder continuar.</p>';
}

