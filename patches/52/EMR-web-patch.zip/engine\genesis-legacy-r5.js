import {authorityBandR53} from './genesis-signature-r53.js';
import {createWillMysticGraphR56} from './genesis-will-mystic-r56.js';
import {createVolitionRelationGraphR57,projectVolitionRelationsLegacyR57} from './genesis-volition-relations-r57.js';

export const GENESIS_LEGACY_R5_SCHEMA='EMR_PRIMORDIAL_LEGACY_R5_v1';

const clone=x=>structuredClone(x);

export function createOntologyR5({signature,binding,mysticSubstrate=null,lawAuthority=null,consciousnessMetaphysics=null,normativeMetaphysics=null}={}){
 if(!signature)throw new Error('GEN_LEGACY_SIGNATURE_REQUIRED');
 const volitionEntities=(binding?.volitionEntities||[]).map(v=>({entityId:v.entityId,controllerPlayerId:v.controllerPlayerId,globalVolitionIntensity:signature.WILL,powerLevel:signature.WILL,unlockedLevels:[...(v.unlockedLevels||[])],authorityBand:authorityBandR53(signature.WILL),domains:[],limits:[],relations:[],facts:[],promises:[]}));
 const bindingMystic=(binding?.mysticForces||[]);
 const mysticAgencies=(binding?.agencies||[]).filter(a=>a.nature==='MYSTIC');
 const mysticForces=(bindingMystic.length?bindingMystic:mysticAgencies.map((a,i)=>({entityId:a.mysticForceId||`MYS-${Number(a.ordinal)||i+1}`,controllerPlayerId:a.playerId,substrateId:'MYSTIC_SUBSTRATE',globalMysticIntensity:signature.MYSTIC,powerLevel:Number(a.powerLevel??signature.MYSTIC),unlockedLevels:[...(a.unlockedLevels||[])]}))).map(v=>({entityId:v.entityId,controllerPlayerId:v.controllerPlayerId,substrateId:v.substrateId||'MYSTIC_SUBSTRATE',globalMysticIntensity:Number(v.globalMysticIntensity??signature.MYSTIC),powerLevel:Number(v.powerLevel??signature.MYSTIC),unlockedLevels:[...(v.unlockedLevels||[])],authorityBand:v.authorityBand||authorityBandR53(signature.MYSTIC),facts:[],relations:[],promises:[]}));
 const substrate=mysticSubstrate||{present:signature.MYSTIC>0,authority:signature.MYSTIC,powerLevel:signature.MYSTIC,scope:signature.MYSTIC>=5?'SYSTEMIC':signature.MYSTIC>=3?'REGIONAL':'LOCAL',rules:[],relationsToMatter:[],relationsToConsciousness:[]};
 substrate.forceEntityIds=mysticForces.map(x=>x.entityId);
 return{
  sav:{S:signature.PHYSICS,A:signature.MYSTIC,V:signature.WILL},
  lawAuthority:lawAuthority||defaultLawAuthority(signature),
  mysticSubstrate:substrate,
  mysticForces,
  volitionEntities,
  willMysticGraph:createWillMysticGraphR56({signature,binding}),
  volitionRelationGraph:createVolitionRelationGraphR57({binding,volitionEntities}),
  consciousnessMetaphysics:consciousnessMetaphysics||{status:'UNDETERMINED',mechanisms:[],conditions:[],producerIds:[]},
  normativeMetaphysics:normativeMetaphysics||{status:'UNDETERMINED',sources:[],effects:[]},
  objectiveSupernaturalFacts:[],publicGenesisFacts:[],hiddenGenesisFacts:[],futureHooks:[],imprints:[],promises:[]
 };
}

function defaultLawAuthority(signature){
 return{
  physicalAutonomy:'BASELINE_ALWAYS_ACTIVE',
  originOfPhysicalRegularities:'BASELINE_PHYSICAL_EVOLUTION',
  originMode:'PHYSICAL_BASELINE',
  producerIds:['BASELINE_PHYSICS'],
  decisionId:'D-GEN-R5.16-PHYSICAL-BASELINE01',
  primordialPhysicalWeight:Number(signature.PHYSICS||0),
  primordialPhysicalAuthorityBand:authorityBandR53(signature.PHYSICS),
  exceptionsAndSelfLimits:[]
 };
}

export function compileGenesisLegacyR5({cosmogony,signatureRecord,binding,selectedPlanetId=null,ontology=null}={}){
 if(!cosmogony?.star||cosmogony.star.state!=='IGNITED')throw new Error('GEN_LEGACY_STAR_NOT_FORMED');
 if(!cosmogony.planets?.length)throw new Error('GEN_LEGACY_PLANET_NOT_FORMED');
 const selected=selectedPlanetId?cosmogony.planets.find(p=>p.id===selectedPlanetId):cosmogony.planets[0];
 if(!selected)throw new Error('GEN_LEGACY_SELECTED_PLANET_UNKNOWN');
 const signature=signatureRecord?.signature||signatureRecord;if(!signature)throw new Error('GEN_LEGACY_SIGNATURE_REQUIRED');
 const ont=ontology||createOntologyR5({signature,binding});
 absorbCosmogonySupernatural(ont,cosmogony,binding);
 return{
  schema:GENESIS_LEGACY_R5_SCHEMA,
  physicalLegacy:{
   starSignature:starSignature(cosmogony),
   selectedPlanetId:selected.id,
   selectedPlanetSignature:clone(selected),
   systemBodies:cosmogony.planets.map(clone),
   genealogy:clone(cosmogony.history)
  },
  supernaturalLegacy:{
   sav:clone(ont.sav),lawAuthority:clone(ont.lawAuthority),mysticSubstrate:clone(ont.mysticSubstrate),mysticForces:clone(ont.mysticForces||[]),volitionEntities:clone(ont.volitionEntities),willMysticGraph:clone(ont.willMysticGraph),
   volitionRelationGraph:projectVolitionRelationsLegacyR57(ont.volitionRelationGraph),objectiveSupernaturalFacts:clone(ont.objectiveSupernaturalFacts),publicGenesisFacts:clone(ont.publicGenesisFacts||[]),hiddenGenesisFacts:clone(ont.hiddenGenesisFacts||[]),futureHooks:clone(ont.futureHooks||[]),imprints:clone(ont.imprints),promises:clone(ont.promises)
  },
  consciousnessMetaphysics:clone(ont.consciousnessMetaphysics),
  normativeMetaphysics:clone(ont.normativeMetaphysics),
  knowledgeSeparation:{objectiveTruthStoredPrivately:true,publicFactsSeparated:true,hiddenFactsSeparated:true,futureHooksMayRemainHidden:true,religionsCreated:false,cultsCreated:false,sinAsSocialConceptCreated:false,demonAsCulturalLabelCreated:false},
  consumers:{
   BOOT01:['starSignature','selectedPlanetSignature','supernaturalLegacy.objectiveSupernaturalFacts'],
   BOOT02:['selectedPlanetSignature','supernaturalLegacy.mysticSubstrate','supernaturalLegacy.mysticForces','consciousnessMetaphysics'],
   BOOT03:['supernaturalLegacy','consciousnessMetaphysics','normativeMetaphysics'],
   BOOT04:['BOOT03 social outputs only; objective truth read-only'],
   FUTURE_BOOTS:['supernaturalLegacy.futureHooks','supernaturalLegacy.hiddenGenesisFacts','supernaturalLegacy.volitionRelationGraph','supernaturalLegacy.mysticForces'],
   RUNTIME:['mysticForces','volitionEntities','willMysticGraph','volitionRelationGraph','promises','futureHooks','objectiveSupernaturalFacts','genealogy']
  }
 };
}

function starSignature(c){
 const diskMass=c.matter.parcels.filter(p=>!['STAR','MERGED'].includes(p.state)).reduce((s,p)=>s+p.hidden.mass,0);
 return{family:c.star.family,mass:c.star.mass,massFraction:Number((c.star.mass/c.totalInitialMass).toFixed(3)),ignitionEpoch:c.star.ignitionEpoch,residualDiskMass:diskMass,causalSources:[...c.star.members],formationProfile:clone(c.star.formationProfile||null),activityForcing:activityForFamily(c.star.family)};
}

function activityForFamily(f){return f==='M_RED_DWARF'?'LOW_LUMINOSITY_LONG_LIFE':f==='K_ORANGE'?'MODERATE_STABLE':f==='G_YELLOW'?'SOLAR_LIKE':f==='F_A_WHITE_YELLOW'?'HIGHER_RADIATION':f==='B_O_BLUE_MASSIVE'?'EXTREME_RADIATION_SHORT_LIFE':'UNKNOWN';}

function absorbCosmogonySupernatural(ont,c,binding){
 const agencyToVol=new Map((binding?.agencies||[]).filter(a=>a.volitionEntityId).map(a=>[a.id,a.volitionEntityId]));
 const agencyToMystic=new Map((binding?.agencies||[]).filter(a=>a.mysticForceId).map(a=>[a.id,a.mysticForceId]));
 for(const p of c.matter.parcels){
  if(p.state==='MERGED')continue;
  for(const i of p.imprints){
   const mysticForceId=agencyToMystic.get(i.source)||null;
   const imprint={targetMatterId:p.id,sourceAgencyId:i.source,sourceEntityId:mysticForceId||i.source,producerMysticForceId:mysticForceId,principle:i.principle,type:'MYSTIC_IMPRINT'};
   ont.imprints.push(imprint);
   if(mysticForceId){const force=ont.mysticForces?.find(v=>v.entityId===mysticForceId);if(force)force.relations.push({type:'IMPRINTS_MATTER',targetMatterId:p.id,principle:i.principle});}
  }
  for(const source of p.preservedBy){const vol=agencyToVol.get(source);if(vol){const entity=ont.volitionEntities.find(v=>v.entityId===vol);if(entity){entity.relations.push({type:'PROTECTS_OR_CLAIMS_MATTER',targetMatterId:p.id});ont.objectiveSupernaturalFacts.push({producerId:vol,type:'VOLITION_RELATION',targetMatterId:p.id});}}}
 }
 for(const planet of c.planets){
  for(const rel of planet.volitionRelations||[]){const vol=agencyToVol.get(rel.source);if(vol){const entity=ont.volitionEntities.find(v=>v.entityId===vol);if(entity)entity.relations.push({type:'RELATION_TO_PLANET',planetId:planet.id,sourceMatter:rel.sourceMatter});}}
  for(const imp of planet.mysticImprints||[]){
   const mysticForceId=agencyToMystic.get(imp.source)||null;
   ont.imprints.push({targetPlanetId:planet.id,producerAgencyId:imp.source,sourceEntityId:mysticForceId||imp.source,producerMysticForceId:mysticForceId,principle:imp.principle,sourceMatter:imp.sourceMatter});
   if(mysticForceId){const force=ont.mysticForces?.find(v=>v.entityId===mysticForceId);if(force)force.relations.push({type:'IMPRINTS_PLANET',targetPlanetId:planet.id,principle:imp.principle,sourceMatter:imp.sourceMatter});}
  }
 }
}