// QA-only deterministic fixture for GEN-R522-STELLAR-GENEALOGY-E2E-01.
// It is not normal game content and must never be selected by the player-facing runtime.
// Purpose: provide a reproducible branch where a legal R5.11 Physics intervention
// changes the star that forms and, consequently, the environment of later worlds.

export const GENESIS_R522_E2E_FIXTURE=Object.freeze({
  id:'GEN-R522-STELLAR-GENEALOGY-E2E-01',
  seed:'R522-CAUSAL-BRANCH-FIXTURE',
  boardPreset:'A61',
  matterCount:10,
  // Late-collapse snapshot; R5.28 minimum ignition is epoch 3.
  preIgnitionEpoch:2,
  starBeforeIgnition:Object.freeze({
    memberIds:Object.freeze(['MAT-01','MAT-02']),
    mass:8,
    hidden:Object.freeze({mass:4,lightGas:6,refractories:3,volatiles:2,thermal:6,angularMomentum:2,density:6})
  }),
  interventionTarget:Object.freeze({
    id:'MAT-03',
    radius:2,
    hidden:Object.freeze({mass:2,lightGas:1,refractories:4,volatiles:3,thermal:1,angularMomentum:4,density:1})
  }),
  residualDisk:Object.freeze({
    memberIds:Object.freeze(['MAT-04','MAT-05','MAT-06','MAT-07','MAT-08','MAT-09','MAT-10']),
    masses:Object.freeze([2,2,2,1,1,1,1]),
    radius:3,
    hidden:Object.freeze({lightGas:3,refractories:5,volatiles:3,thermal:3,angularMomentum:6,density:3})
  }),
  intervention:Object.freeze({
    actorId:'QA-PHYSICS-AGENCY',
    producerEntityId:null,
    nature:'PHYSICS',
    kind:'CONCENTRATE',
    targetId:'MAT-03'
  }),
  expected:Object.freeze({
    totalInitialMass:20,
    ignitionThreshold:8,
    noIntervention:Object.freeze({starMass:8,starFamily:'K_ORANGE',planetEnvironmentClass:'COLD_ROCKY_TERRESTRIAL'}),
    intervention:Object.freeze({starMass:10,starFamily:'G_YELLOW',planetEnvironmentClass:'TEMPERATE_ROCKY_TERRESTRIAL'})
  })
});
