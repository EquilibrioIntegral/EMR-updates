// BOOT-07 · START_LINK causal solver · A1
// Authority: EMR_BOOT07_START_LINK_CAUSAL_A1_v0.2 + SW source v0.2

const LEVEL={A:0,B:1,C:2};
const uniq=a=>[...new Set(a)];
const stable=a=>[...a].sort((x,y)=>String(x).localeCompare(String(y)));

export function legalBoot07Fact(f){
  return !!f && f.valid!==false && f.public===true && f.secret!==true && f.missionLike!==true && f.contradiction!==true;
}
function pcId(f){ return String(f.origin||'').startsWith('PC-') ? f.origin : null; }
function tags(f){ return new Set(f.causalTags||[]); }
function overlap(a,b){ for(const x of tags(a)) if(tags(b).has(x)) return true; return false; }
function specificity(f){ return Number(f.specificity||0); }

function candidate(id,level,anchor,facts,coverage,inferences=0){
  return {id,level,anchorId:anchor?.referentId||anchor?.id,coverage:stable(coverage),sourceIds:stable(facts.map(f=>f.id)),specificity:Math.max(0,...facts.map(specificity)),inferences};
}

export function generateBoot07Candidates(facts){
  const legal=facts.filter(legalBoot07Fact), pcs=legal.filter(pcId), worlds=legal.filter(f=>f.origin==='WORLD');
  const pcIds=stable(uniq(pcs.map(pcId))); const out=[];
  // A: direct shared referent. 1P requires PC↔WORLD; 2–4P requires >=2 PCs.
  for(const ref of stable(uniq(legal.map(f=>f.referentId).filter(Boolean)))){
    const p=pcs.filter(f=>f.referentId===ref), w=worlds.filter(f=>f.referentId===ref), cov=uniq(p.map(pcId));
    if((pcIds.length===1 && cov.length===1 && w.length) || (pcIds.length>1 && cov.length>=2)) out.push(candidate(`A:${ref}`,'A',w[0]||p[0],[...p,...w],cov,0));
  }
  // B/C: PCs connect to same existing WORLD fact by explicit causal tags.
  for(const w of worlds){
    const matched=pcs.filter(p=>overlap(p,w)), cov=uniq(matched.map(pcId));
    if(cov.length){
      const lvl=(pcIds.length===1 || cov.length>=2)?'B':'C';
      out.push(candidate(`${lvl}:${w.id}`,lvl,w,[w,...matched],cov,lvl==='B'?1:2));
    }
  }
  return out;
}

export function rankBoot07Candidates(candidates){
  return [...candidates].sort((a,b)=>
    b.coverage.length-a.coverage.length || LEVEL[a.level]-LEVEL[b.level] || b.sourceIds.length-a.sourceIds.length || b.specificity-a.specificity || a.inferences-b.inferences || a.id.localeCompare(b.id));
}

function validExisting(existing, facts){
  if(!existing?.sourceIds?.length) return false;
  const byId=new Map(facts.map(f=>[f.id,f]));
  return existing.sourceIds.every(id=>legalBoot07Fact(byId.get(id)));
}

function convergence(facts,pcIds){
  const worlds=facts.filter(f=>f.origin==='WORLD'&&legalBoot07Fact(f));
  if(!worlds.length) throw new Error('BOOT07_NO_MATCH_FATAL');
  const pcs=facts.filter(f=>pcId(f)&&legalBoot07Fact(f));
  worlds.sort((a,b)=>{
    const ca=uniq(pcs.filter(p=>overlap(p,a)).map(pcId)).length, cb=uniq(pcs.filter(p=>overlap(p,b)).map(pcId)).length;
    return cb-ca || specificity(b)-specificity(a) || a.id.localeCompare(b.id);
  });
  const w=worlds[0];
  return Object.freeze({id:`START_LINK:CONVERGENCE:${w.id}`,subtype:'CONVERGENCE_LINK',anchorId:w.referentId||w.id,coverage:stable(pcIds),sourceIds:[w.id],template:'CONVERGENCIA_PRESENTE',persistent:true,mission:false,canRetcon:false});
}

export function solveBoot07({facts,existingStartLink=null}){
  const legal=facts.filter(legalBoot07Fact), pcIds=stable(uniq(legal.map(pcId).filter(Boolean)));
  if(pcIds.length<1||pcIds.length>4) throw new Error('BOOT07_REQUIRES_1_TO_4_PCS');
  if(validExisting(existingStartLink,facts)) return existingStartLink;
  const ranked=rankBoot07Candidates(generateBoot07Candidates(facts));
  const best=ranked[0];
  if(!best) return convergence(facts,pcIds);
  const subtype=pcIds.length===1?'START_ANCHOR':'GROUP_LINK';
  // Multiplayer causal link must explain every PC; otherwise fallback present convergence.
  if(pcIds.length>1 && best.coverage.length<pcIds.length) return convergence(facts,pcIds);
  return Object.freeze({id:`START_LINK:${subtype}:${best.id}`,subtype,anchorId:best.anchorId,coverage:best.coverage,sourceIds:best.sourceIds,template:best.level==='A'?'INTERSECCION_DIRECTA':'INTERSECCION_MUNDO',persistent:true,mission:false,canRetcon:false});
}

export function adaptStartLinkToBoot08(link){
  if(!link) throw new Error('BOOT07_START_LINK_REQUIRED');
  const roles={GROUP_LINK:'MOTIVO_DE_CONVERGENCIA_PREVIO',START_ANCHOR:'ANCLA_DE_PRESENCIA_1P',CONVERGENCE_LINK:'MOTIVO_DE_CONVERGENCIA_PRESENTE'};
  if(!roles[link.subtype]) throw new Error('BOOT07_BAD_START_LINK_SUBTYPE');
  return Object.freeze({startLinkId:link.id,subtype:link.subtype,roleBoot08:roles[link.subtype],anchorId:link.anchorId,coverage:[...link.coverage],sourceIds:[...link.sourceIds],canDefineMission:false,canRetcon:false,persistent:true});
}
