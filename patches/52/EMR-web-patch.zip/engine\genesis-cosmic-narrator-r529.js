import {visibleGenesisCellR513} from './genesis-player-facing-r513.js';

export const GENESIS_COSMIC_NARRATOR_R529='EMR_GENESIS_COSMIC_NARRATOR_R529_v1';

const CURRENT_EPOCH_TYPES=new Set([
  'COSMIC_MOVE','MATTER_COLLISION_COALESCENCE','DISK_RETAIN','STAR_ACCRETION',
  'STELLAR_IGNITION_HELD_FOR_AGENCY','INNER_DISK_INFALL','COSMIC_COMPRESSION',
  'STELLAR_FORMATION_PROFILE','STAR_IGNITION','DISK_SETTLE','PLANET_FORMATION'
]);

export function composeCosmicNarrativeR529(live){
  const c=live?.runtime?.cosmogony;
  if(!c)return{schema:GENESIS_COSMIC_NARRATOR_R529,title:'La creación aguarda',paragraphs:['Todavía no existe un estado físico de Génesis que narrar.'],causeEventTypes:[]};
  const epoch=Number(c.epoch||0),round=Number(live?.round||1),board=c.board;
  const events=(c.history||[]).filter(e=>Number(e.epoch||0)===epoch&&CURRENT_EPOCH_TYPES.has(e.type));
  const paragraphs=[];

  if(epoch===0&&events.length===0){
    const free=(c.matter?.parcels||[]).filter(p=>p.state==='FREE').length;
    paragraphs.push(free?`La materia primordial permanece dispersa por el sistema. Hay ${free} concentraciones materiales sobre la mesa y todavía no existe una estrella.`:'La materia primordial todavía no ha iniciado una evolución física registrable.');
  }

  const moves=events.filter(e=>e.type==='COSMIC_MOVE');
  if(moves.length){
    const shown=moves.slice(0,3).map(e=>`${cell(e.from,board)} → ${cell(e.to,board)}`);
    const tail=moves.length>3?` y ${moves.length-3} desplazamiento${moves.length-3===1?'':'s'} más`:'';
    paragraphs.push(`La gravedad desplaza materia hacia regiones más interiores: ${shown.join(', ')}${tail}.`);
  }

  const collisions=events.filter(e=>e.type==='MATTER_COLLISION_COALESCENCE');
  for(const e of collisions.slice(0,2)){
    const count=Number(e.absorbedIds?.length||0)+1;
    paragraphs.push(`En la casilla ${cell(e.atCell,board)}, ${count} concentraciones chocan y acrecen en una sola masa. La materia no desaparece: su procedencia queda incorporada al cuerpo resultante.`);
  }
  if(collisions.length>2)paragraphs.push(`Se producen además ${collisions.length-2} acreciones materiales en otras regiones del sistema.`);

  const retained=events.filter(e=>e.type==='DISK_RETAIN');
  if(retained.length){
    const cells=retained.map(e=>parcelCell(c,e.targetId)).filter(Boolean).slice(0,4);
    paragraphs.push(`${retained.length===1?'Una concentración conserva':'Varias concentraciones conservan'} suficiente movimiento lateral para no caer al centro${cells.length?` en torno a ${joinCells(cells,board)}`:''}. Esa materia queda retenida en el disco en formación.`);
  }

  const acc=events.filter(e=>e.type==='STAR_ACCRETION');
  if(acc.length){
    const mass=acc.reduce((n,e)=>n+Number(e.mass||0),0);
    const starExists=c.star?.state==='IGNITED';
    paragraphs.push(`${acc.length===1?'Una concentración cae':'Varias concentraciones caen'} al centro y añaden ${mass} unidad${mass===1?'':'es'} de masa a la concentración central${starExists?' estelar':''}.`);
  }

  const held=events.find(e=>e.type==='STELLAR_IGNITION_HELD_FOR_AGENCY');
  if(held)paragraphs.push('La concentración central alcanza masa suficiente para aproximarse a la ignición, pero la estrella todavía no nace: el sistema permanece en colapso durante esta ventana causal.');

  const infall=events.filter(e=>e.type==='INNER_DISK_INFALL');
  if(infall.length)paragraphs.push(`${infall.length===1?'Una porción del disco interior pierde':'Varias porciones del disco interior pierden'} estabilidad y cae hacia la concentración central.`);

  const compression=events.find(e=>e.type==='COSMIC_COMPRESSION');
  if(compression)paragraphs.push(`La contracción global fuerza una convergencia final: ${Number(compression.absorbedParcels||0)} concentración${Number(compression.absorbedParcels||0)===1?'':'es'} adicional${Number(compression.absorbedParcels||0)===1?'':'es'} alimentan el centro.`);

  const ignition=events.find(e=>e.type==='STAR_IGNITION');
  if(ignition){
    paragraphs.push('La presión y la temperatura centrales sostienen por primera vez la fusión. Ha nacido una estrella; su materia y su historia de formación quedan fijadas como causa para los mundos posteriores.');
  }

  const settle=events.find(e=>e.type==='DISK_SETTLE');
  if(settle)paragraphs.push('Tras la ignición, la materia que no cayó a la estrella se reorganiza en el disco que dará origen a los primeros mundos.');

  const planets=events.find(e=>e.type==='PLANET_FORMATION');
  if(planets){
    const count=Array.isArray(planets.planetIds)?planets.planetIds.length:Number(c.planets?.length||0);
    paragraphs.push(`El disco se agrupa en ${count} mundo${count===1?'':'s'} planetario${count===1?'':'s'}. Su composición conserva las condiciones y las huellas causales de la materia de la que proceden.`);
  }

  if(!paragraphs.length){
    const phase=String(c.phase||'');
    paragraphs.push(phase==='COLLAPSE'?'En esta edad no se registra ningún cambio físico visible. La configuración de la mesa permanece como estaba al comenzar la evolución.':'En esta edad no se registra ningún cambio material nuevo que deba representarse en la mesa.');
  }

  return{
    schema:GENESIS_COSMIC_NARRATOR_R529,
    title:ignition?'Ha nacido una estrella':planets?'Nacen los primeros mundos':epoch===0?'Antes de la primera caída':`Edad cósmica ${round}`,
    paragraphs,
    causeEventTypes:events.map(e=>e.type),
    epoch,
    round
  };
}

function parcelCell(c,id){return c?.matter?.parcels?.find(p=>p.id===id)?.cell||null;}
function cell(code,board){return visibleGenesisCellR513(code,board);}
function joinCells(codes,board){const xs=codes.map(x=>`la casilla ${cell(x,board)}`);if(xs.length<2)return xs[0]||'';if(xs.length===2)return`${xs[0]} y ${xs[1]}`;return`${xs.slice(0,-1).join(', ')} y ${xs.at(-1)}`;}
