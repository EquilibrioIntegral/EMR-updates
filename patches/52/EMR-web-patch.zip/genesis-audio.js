const boot=document.querySelector('#boot');
const menuAudio=document.querySelector('#menu-theme');
const genesisAudio=document.querySelector('#genesis-theme');

if(boot&&genesisAudio){
  const TARGET_VOLUME=0.72;
  const BOOT_RETRY_DELAYS=[0,180,480,950,1650,2600,3800,5200];
  const COLD_START_STABILITY_MS=6200;
  let fadeFrame=0;
  let gestureArmed=false;
  let pauseTimer=0;
  let stableTimer=0;
  let retryTimers=[];

  genesisAudio.volume=0;
  genesisAudio.loop=true;
  genesisAudio.preload='auto';

  const text=()=>boot.textContent||'';
  const updateGateReady=()=>document.documentElement?.dataset?.updateGate!=='pending';
  const inGenesisZone=()=>{
    if(!updateGateReady()||document.visibilityState==='hidden'||boot.hidden)return false;
    const t=text();
    // Genesis finishes before BOOT-01 world formation begins.
    if(/BOOT-01|FORMACIÓN DEL MUNDO|Construcción del mundo/i.test(t))return false;
    return true;
  };
  const cancelFade=()=>{if(fadeFrame){cancelAnimationFrame(fadeFrame);fadeFrame=0;}};
  const cancelPause=()=>{if(pauseTimer){clearTimeout(pauseTimer);pauseTimer=0;}};
  const cancelStable=()=>{if(stableTimer){clearTimeout(stableTimer);stableTimer=0;}};
  const clearRetries=()=>{retryTimers.forEach(clearTimeout);retryTimers=[];};
  const fadeTo=(target,duration=900,onDone)=>{
    cancelFade();
    const from=genesisAudio.volume,start=performance.now();
    const tick=now=>{
      const p=Math.min(1,(now-start)/duration);
      genesisAudio.volume=from+(target-from)*(p*(2-p));
      if(p<1)fadeFrame=requestAnimationFrame(tick);else{fadeFrame=0;onDone?.();}
    };
    fadeFrame=requestAnimationFrame(tick);
  };
  const removeGestureFallback=()=>{
    if(!gestureArmed)return;
    gestureArmed=false;
    for(const name of ['pointerdown','touchstart','keydown','click'])window.removeEventListener(name,onFirstGesture,true);
  };
  const armGestureFallback=()=>{
    if(gestureArmed)return;
    gestureArmed=true;
    for(const name of ['pointerdown','touchstart','keydown','click'])window.addEventListener(name,onFirstGesture,{capture:true,passive:true});
  };
  const markStable=()=>{
    cancelStable();
    stableTimer=setTimeout(()=>{
      stableTimer=0;
      if(inGenesisZone()&&!genesisAudio.paused){clearRetries();removeGestureFallback();}
    },COLD_START_STABILITY_MS);
  };
  const startGenesis=async({fromGesture=false}={})=>{
    if(!inGenesisZone())return false;
    cancelPause();
    try{
      // menu-audio.js is already fading the menu track out as setup closes.
      if(menuAudio&&!menuAudio.paused)menuAudio.volume=Math.min(menuAudio.volume,0.45);
      if(genesisAudio.paused){cancelFade();genesisAudio.volume=0;await genesisAudio.play();}
      if(!fadeFrame&&genesisAudio.volume<TARGET_VOLUME-0.02)fadeTo(TARGET_VOLUME,fromGesture?650:1050);
      if(fromGesture)removeGestureFallback();
      markStable();
      return true;
    }catch{armGestureFallback();return false;}
  };
  const stopGenesis=()=>{
    clearRetries();cancelStable();cancelPause();
    if(genesisAudio.paused){genesisAudio.volume=0;return;}
    fadeTo(0,900,()=>{pauseTimer=setTimeout(()=>{if(!inGenesisZone())genesisAudio.pause();pauseTimer=0;},20);});
  };
  async function onFirstGesture(){await startGenesis({fromGesture:true});}
  const scheduleRecovery=()=>{
    if(!inGenesisZone())return;
    clearRetries();cancelPause();armGestureFallback();
    BOOT_RETRY_DELAYS.forEach(delay=>retryTimers.push(setTimeout(()=>{
      if(!inGenesisZone())return;
      if(genesisAudio.paused)startGenesis();
      else if(!fadeFrame&&genesisAudio.volume<TARGET_VOLUME-0.02)fadeTo(TARGET_VOLUME,520);
    },delay)));
  };
  const sync=()=>{
    if(inGenesisZone())scheduleRecovery();
    else stopGenesis();
  };
  const recoverUnexpectedPause=()=>{
    if(!inGenesisZone())return;
    cancelStable();
    scheduleRecovery();
  };

  new MutationObserver(sync).observe(boot,{attributes:true,attributeFilter:['hidden'],childList:true,subtree:true,characterData:true});
  genesisAudio.addEventListener('loadeddata',sync,{once:true});
  genesisAudio.addEventListener('canplay',sync,{once:true});
  genesisAudio.addEventListener('pause',recoverUnexpectedPause);
  document.addEventListener('visibilitychange',sync);
  window.addEventListener('emr:update-gate-ready',sync);
  window.addEventListener('pageshow',sync);
  window.addEventListener('focus',sync);
  try{genesisAudio.load();}catch{}
  sync();
}
