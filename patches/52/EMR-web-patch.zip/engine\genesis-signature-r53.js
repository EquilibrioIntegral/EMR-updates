// GEN-R5.3/R5.9 — canonical implementation of the approved 0..6 primordial signature.
// The signature expresses global ontological authority/presence. It is NOT a pool,
// NOT a turn count, and is never multiplied by the number of agencies/entities.

export const GENESIS_SIGNATURE_R53_SCHEMA='EMR_GENESIS_SIGNATURE_R53_v1';
export const GENESIS_SOLO_R59_SCHEMA='EMR_GENESIS_SOLO_SIGNATURE_R59_v1';
export const R53_NATURES=Object.freeze(['PHYSICS','MYSTIC','WILL']);

const assertDie=n=>{if(!Number.isInteger(n)||n<1||n>6)throw new Error('GEN_R53_D6_INVALID');return n;};
const assertIntensity=n=>{if(!Number.isInteger(n)||n<0||n>6)throw new Error('GEN_R53_INTENSITY_INVALID');return n;};
const assertRequiredLevel=n=>{if(!Number.isInteger(n)||n<1||n>6)throw new Error('GEN_R53_REQUIRED_LEVEL_INVALID');return n;};
const countsFor=choices=>Object.fromEntries(R53_NATURES.map(n=>[n,choices.filter(x=>x===n).length]));

export function validateAgencyChoicesR53(choices){
 if(!Array.isArray(choices)||choices.length<1||choices.length>4)throw new Error('GEN_R53_PLAYER_COUNT_INVALID');
 if(choices.some(x=>!R53_NATURES.includes(x)))throw new Error('GEN_R53_NATURE_INVALID');
 return true;
}

export function validateR53Choices(choices){validateAgencyChoicesR53(choices);if(choices.length<2)throw new Error('GEN_R53_MULTIPLAYER_SIGNATURE_REQUIRED');return true;}

export function signatureRollPlan(choices){
 validateR53Choices(choices);const counts=countsFor(choices),represented=R53_NATURES.filter(n=>counts[n]>0);
 if(represented.length===1)return{mode:'SINGLE',counts,rolls:[]};
 const max=Math.max(...represented.map(n=>counts[n]));const leaders=represented.filter(n=>counts[n]===max);
 if(leaders.length===represented.length)return{mode:'TIED_SUPPORT',counts,rolls:represented.map(n=>({nature:n,kind:'DIRECT_D6',min:1,max:6,rerollEqual:true}))};
 const majority=leaders[0],minorities=represented.filter(n=>n!==majority);
 return{mode:'UNIQUE_MAJORITY',counts,majority,rolls:minorities.map(n=>({nature:n,kind:'CAPPED_D6',min:1,max:Math.round(6*counts[n]/counts[majority]),rerollEqual:false}))};
}

export function deriveSignatureR53(choices,rolls={}){
 const plan=signatureRollPlan(choices),signature={PHYSICS:0,MYSTIC:0,WILL:0},used={};
 if(plan.mode==='SINGLE'){const nature=R53_NATURES.find(n=>plan.counts[n]>0);signature[nature]=6;return{schema:GENESIS_SIGNATURE_R53_SCHEMA,signature,counts:plan.counts,mode:plan.mode,rolls:used};}
 if(plan.mode==='TIED_SUPPORT'){
  const values=[];for(const spec of plan.rolls){const die=assertDie(rolls[spec.nature]);used[spec.nature]=die;values.push(die);signature[spec.nature]=die;}
  if(new Set(values).size!==values.length)throw new Error('GEN_R53_TIE_REROLL_REQUIRED');
  return{schema:GENESIS_SIGNATURE_R53_SCHEMA,signature,counts:plan.counts,mode:plan.mode,rolls:used};
 }
 signature[plan.majority]=6;for(const spec of plan.rolls){const die=assertDie(rolls[spec.nature]);used[spec.nature]=die;signature[spec.nature]=Math.ceil(die*spec.max/6);}
 return{schema:GENESIS_SIGNATURE_R53_SCHEMA,signature,counts:plan.counts,mode:plan.mode,majority:plan.majority,rolls:used};
}

export function soloSecondaryRollPlanR59(nature){
 if(!R53_NATURES.includes(nature))throw new Error('GEN_R53_NATURE_INVALID');
 return{schema:GENESIS_SOLO_R59_SCHEMA,mode:'SOLO_SECONDARY_DICE',primaryNature:nature,rolls:R53_NATURES.filter(n=>n!==nature).map(n=>({nature:n,kind:'SOLO_SECONDARY_EXACT',min:1,max:6,mapsTo:[0,1,2],rerollEqual:false}))};
}

export function deriveSoloSignatureR59(nature,rolls={}){
 // 0.31.7 entry can transport a privately resolved signature through the established
 // runtime API. It is engine-only provenance; no player-facing dice/input is reintroduced.
 if(rolls?.__signatureOverride){
  const r=structuredClone(rolls.__signatureOverride);if(!r?.signature)throw new Error('GEN_R53_SOLO_OVERRIDE_INVALID');
  for(const n of R53_NATURES)assertIntensity(r.signature[n]);
  return{schema:GENESIS_SIGNATURE_R53_SCHEMA,signature:{...r.signature},counts:{...(r.counts||countsFor([nature]))},mode:r.mode||'SOLO_ENTRY_RESOLVED',primaryNature:nature,rolls:{...(r.rolls||{})},autonomousSecondaryNatures:R53_NATURES.filter(n=>n!==nature&&r.signature[n]>0),canonicalSoloRule:true,privateEntryResolution:true};
 }
 const plan=soloSecondaryRollPlanR59(nature),signature={PHYSICS:0,MYSTIC:0,WILL:0},used={},secondaryLevels={},occupied=new Set();signature[nature]=6;
 for(const spec of plan.rolls){const die=assertDie(rolls[spec.nature]);used[spec.nature]=die;const candidate=die===1?1:die===2?2:0;const level=candidate>0&&occupied.has(candidate)?0:candidate;if(level>0)occupied.add(candidate);signature[spec.nature]=level;secondaryLevels[spec.nature]=level;}
 return{schema:GENESIS_SIGNATURE_R53_SCHEMA,soloSchema:GENESIS_SOLO_R59_SCHEMA,signature,counts:Object.fromEntries(R53_NATURES.map(n=>[n,n===nature?1:0])),mode:'SOLO_R59_CANONICAL',primaryNature:nature,rolls:used,secondaryLevels,autonomousSecondaryNatures:R53_NATURES.filter(n=>n!==nature&&signature[n]>0),canonicalSoloRule:true};
}

export function deriveSoloSignatureBaselineR53(nature,rolls={}){return deriveSoloSignatureR59(nature,rolls);}

export function authorityBandR53(intensity){assertIntensity(intensity);if(intensity===0)return'ABSENT';if(intensity<=2)return'LIMITED';if(intensity<=4)return'IMPORTANT';return'EXTENSIVE';}
export function actionTierR53(intensity){const band=authorityBandR53(intensity);return band==='ABSENT'?0:band==='LIMITED'?1:band==='IMPORTANT'?2:3;}
export function unlockedPowerLevelsR53(intensity){const n=assertIntensity(intensity);return Array.from({length:n},(_,i)=>i+1);}
export function isCapabilityUnlockedR53(intensity,requiredLevel){const n=assertIntensity(intensity),r=assertRequiredLevel(requiredLevel);return n>=r;}
export function experimentalRollModifierR53(intensity){const tier=actionTierR53(intensity);return tier===0?null:tier-1;}

export function bindAgenciesToSignatureR53(choices,signature,{playerIds=[]}={}){
 validateAgencyChoicesR53(choices);if(!signature||R53_NATURES.some(n=>!Number.isInteger(signature[n])||signature[n]<0||signature[n]>6))throw new Error('GEN_R53_SIGNATURE_INVALID');
 const kindIndex={PHYSICS:0,MYSTIC:0,WILL:0};
 const agencies=choices.map((nature,i)=>{
  const ordinal=++kindIndex[nature],powerLevel=signature[nature];
  return{
   id:`AG-${i+1}`,
   playerId:playerIds[i]||`P${i+1}`,
   nature,
   ordinal,
   universeIntensity:powerLevel,
   powerLevel,
   unlockedLevels:unlockedPowerLevelsR53(powerLevel),
   authorityBand:authorityBandR53(powerLevel),
   actionTier:actionTierR53(powerLevel),
   volitionEntityId:nature==='WILL'?`VOL-${ordinal}`:null,
   mysticForceId:nature==='MYSTIC'?`MYS-${ordinal}`:null
  };
 });
 const volitionEntities=agencies.filter(a=>a.nature==='WILL').map(a=>({entityId:a.volitionEntityId,controllerPlayerId:a.playerId,globalVolitionIntensity:signature.WILL,powerLevel:signature.WILL,unlockedLevels:unlockedPowerLevelsR53(signature.WILL)}));
 const mysticForces=agencies.filter(a=>a.nature==='MYSTIC').map(a=>({entityId:a.mysticForceId,controllerPlayerId:a.playerId,substrateId:'MYSTIC_SUBSTRATE',globalMysticIntensity:signature.MYSTIC,powerLevel:signature.MYSTIC,unlockedLevels:unlockedPowerLevelsR53(signature.MYSTIC)}));
 return{schema:'EMR_GENESIS_AGENCY_BINDING_R53_v1',signature:{...signature},agencies,volitionEntities,mysticForces};
}
