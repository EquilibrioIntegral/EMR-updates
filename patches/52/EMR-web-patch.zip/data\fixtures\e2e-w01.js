// E2E0-W01 canonical software fixture.
// Authority: EMR_BOOT_WORLDGEN_MINIPROJECT_CANON_v0.46 sheets 44 + 51.
// This is a serialization of an already-produced canonical run, not new world design.
export const W01_RNG=Object.freeze({sequenceId:'E2E0-W01-RNG-C01',current:8,next:9});

export const W01_WG_STATE_REFS=Object.freeze([
 {id:'WG-STATE-SUPERNATURAL',gene:'SOBRENATURAL_REALIDAD',value:'AUSENTE_EXPLICITO'},
 {id:'WG-STATE-TERRITORY',gene:'TERRITORIO',value:'E2E0-W01-TERR-v1'},
 {id:'WG-STATE-CLIMATE',gene:'CLIMA_ENTORNO',value:'GELIDO/ABUNDANTE+EPISODICO/HIPERHUMEDO/SUAVE/CAOTICA_RARA/MARITIMO/ALT_ALTO/HYD_MOSAICO/REG_MOSAICO/EXT_ALTOS'},
 {id:'WG-STATE-ECOLOGY-FAUNA',gene:'ECOLOGIA_FAUNA',value:'PULSANTE/WATER_DOMINANTE/DIST_EXTREMO/COV_DENSA/BIOG_MOSAICO/DIV_MEDIA/FAUNA_ABUNDANTE/TROPH_MEDIA/MOB_MIXTA/THREAT_ALTA'},
 {id:'WG-STATE-POPULATION',gene:'POBLACION',value:'MEDIA/MIXTO/RED_MIXTA/MIXTA/MOSAICO/OSCILANTE'},
 {id:'WG-STATE-MATERIAL',gene:'DESARROLLO_MATERIAL',value:'ESPECIALIZADA/ESPECIALIZADA/COMPLEJA/RESERVA_DURABLE/CARGA_ESPECIALIZADA/MECANICA_SIMPLE/REPARACION_ESPECIALIZADA/SUP_AUSENTE'},
 {id:'WG-STATE-ECONOMY',gene:'ECONOMIA',value:'EXCEDENTE_LOCAL/LOCAL/RECIPROCIDAD+INTERCAMBIO_DIRECTO/MON_AUSENTE/VECINAL/PERIODICA/VARIABLE'},
 {id:'WG-STATE-GOVERNMENT',gene:'GOBIERNO',value:'CONSEJO/NEGOCIADA/MULTILOCAL/DISTRIBUIDA/ROLES_ESTABLES/NORMAS_ESTABLES/ELECCION'},
 {id:'WG-STATE-RELIGION',gene:'RELIGION_CREENCIAS',value:'AUSENTE/NINGUNA/AUSENTE/VACIO/NULO/SEPARADA/SIN_REFERENCIA'},
 {id:'WG-STATE-FORCE',gene:'FUERZA_ORGANIZADA',value:'COMUNITARIA/ATOMIZADA/ESTACIONAL/COORDINACION_OCASIONAL/MULTILOCAL/OPERACION_LIMITADA/ROLES_BASICO'}
]);

const region=id=>({id:`WF-W01-${id}`,referentId:id,type:'REGION_LOGICA',origin:'WORLD',valid:true,public:id==='RGN-01',secret:false,missionLike:false,contradiction:false,causalTags:['TERRITORIO_W01'],specificity:2,knowledge:id==='RGN-01'?'CONOCIMIENTO_PUBLICO':'HECHO_OBJETIVO'});
export const W01_WORLD_FACTS=Object.freeze(['RGN-01','RGN-02','RGN-03','RGN-04','RGN-05'].map(region));
export const W01_PUBLIC_ANCHORS=Object.freeze([{id:'W_PUBLIC_ANCHOR_01',referentId:'RGN-01',type:'REGION_LOGICA',public:true}]);
export const W01_WORLD_PAYLOAD=Object.freeze({fixtureId:'E2E0-W01-v1',configFirmaRef:'FIRMA-W01-v1',wgStateRefs:W01_WG_STATE_REFS,save0Refs:W01_WORLD_FACTS,knowledgeClasses:{'WF-W01-RGN-01':'CONOCIMIENTO_PUBLICO','WF-W01-RGN-02':'HECHO_OBJETIVO','WF-W01-RGN-03':'HECHO_OBJETIVO','WF-W01-RGN-04':'HECHO_OBJETIVO','WF-W01-RGN-05':'HECHO_OBJETIVO'},rng:W01_RNG});

export const W01_MEC21_EVENT=Object.freeze({
 id:'WF-W01-OPP-MO04',referentId:'RGN-01',type:'ENVIRONMENTAL_EVENT',origin:'WORLD',valid:true,public:true,secret:false,missionLike:false,contradiction:false,
 causalTags:['TERRITORIO_W01','RGN-01','CLIMA','OBSTRUCCION_AMBIENTAL'],specificity:4,knowledge:'CONOCIMIENTO_PUBLICO',transient:true,
 phenomenon:'NIEVE',effect:'OBSTRUCCION_DE_ASCENSO',
 // Player-facing realization belongs to the sourced MEC-21 world event, not to BOOT-08.
 publicText:'Una lengua de nieve reciente corta el ascenso en el entorno de RGN-01.',
 sourceIds:['WG-STATE-TERRITORY','WG-STATE-CLIMATE','MEC21:V-MO04']
});
