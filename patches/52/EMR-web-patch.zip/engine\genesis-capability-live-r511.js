import {axialDistance,nearestCells} from './genesis-board-r5.js';
import {capabilityByIdR511,unlockedCapabilitiesR511,catalogEligibilityR511} from './genesis-capabilities-r511.js';
import {applyRuntimeAgencyActionR5,runtimeAgencyR5,establishVolitionRelationR5} from './genesis-runtime-r5.js';
import {revealMatterHint} from './genesis-material-r5.js';

export const GENESIS_R511_LIVE_ADAPTER_SCHEMA='EMR_GENESIS_R511_LIVE_ADAPTER_v1';
export const GENESIS_R511_NUCLEAR_CALIBRATION='A1_DEV031_DENSITY5_THERMAL5_MASS4';
export const GENESIS_R511_CONTEXTUAL_MAX_PER_CAPABILITY=2;

const clone=x=>structuredClone(x);
const ACTIVE_STATES=new Set(['FREE','DISK']);

export function contextualAgencyActionsR511(live,agency){
 if(!live?.runtime?.cosmogony||!agency?.nature)throw new Error('GEN_R511_LIVE_CONTEXT_REQUIRED');
 const unlocked=unlockedCapabilitiesR511({nature:agency.nature,intensity:agency.universeIntensity});
 let out=[];
 for(const cap of unlocked)out.push(...buildForCapability(live,agency,cap));
 out=out.filter(o=>!blockedBySelfLimit(live,agency,o));
 return out.map(o=>decorateAndValidate(agency,o));
}

export function curateContextualAgencyActionsR511(options=[]){
 const groups=new Map(),wait=[];
 for(const o of options){
  if(o.kind==='WAIT'){wait.push(o);continue;}
  const key=o.capabilityId||'LEGACY';if(!groups.has(key))groups.set(key,[]);groups.get(key).push(o);
 }
 const selected=[];
 for(const rows of groups.values()){
  const modes=new Set();
  for(const row of rows){
   const mode=row.mode||row.kind;
   if(modes.has(mode)&&selected.filter(x=>x.capabilityId===row.capabilityId).length>=1)continue;
   selected.push(row);modes.add(mode);
   if(selected.filter(x=>x.capabilityId===row.capabilityId).length>=GENESIS_R511_CONTEXTUAL_MAX_PER_CAPABILITY)break;
  }
 }
 return [...selected,...wait.slice(0,1)];
}

export function applyContextualCapabilityActionR511(runtime,action){
 if(!runtime||!action?.playerId||!action.capabilityId)throw new Error('GEN_R511_ACTION_REQUIRED');
 const agency=runtimeAgencyR5(runtime,action.playerId),cap=capabilityByIdR511(action.capabilityId);
 const eligibility=catalogEligibilityR511({nature:agency.nature,intensity:agency.universeIntensity,capabilityId:cap.id,context:{remote:Number(action.remoteReach||0)>1,remotePathAuthorized:action.remotePathAuthorized===true}});
 if(!eligibility.legal)throw new Error(`GEN_R511_ACTION_INELIGIBLE:${eligibility.reason}`);
 let next;
 if(['CONCENTRATE','PRESERVE_DISK','IMPRINT','LINK','PROTECT','CLAIM'].includes(action.kind)){
  next=applyRuntimeAgencyActionR5(runtime,{playerId:action.playerId,kind:action.kind,targetId:action.targetId,otherId:action.otherId||null,principle:action.principle||null});
 }else if(action.kind==='REDISTRIBUTE')next=applyRedistribute(runtime,agency,action);
 else if(action.kind==='TRANSFER_ENERGY')next=applyEnergyTransfer(runtime,agency,action);
 else if(action.kind==='ACTIVATE_NUCLEAR_CHANGE')next=applyNuclearActivation(runtime,agency,action);
 else if(action.kind==='SYSTEMIC_APPLICATION')next=applySystemic(runtime,agency,action);
 else if(action.kind==='RESONATE_MARK')next=applyResonance(runtime,agency,action);
 else if(['CONDITIONAL_TRANSFORM','CYCLE_ENTANGLE','BRIDGE_CONSCIOUSNESS_MATTER','DESIGNATE_PURPOSE','MANIFEST_TRACE','AUTOLIMIT','BOUNDED_DECREE'].includes(action.kind))next=applySemantic(runtime,agency,action);
 else if(action.kind==='VOLITION_RELATION')next=applyVolitionRelation(runtime,agency,action);
 else throw new Error('GEN_R511_ACTION_KIND_UNKNOWN');
 next.eventLog.push({type:'GEN_R511_CAPABILITY_APPLIED',decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01',capabilityId:cap.id,requiredLevel:cap.requiredLevel,playerId:action.playerId,agencyId:agency.id,producerEntityId:causalProducerIdR511(agency),nature:agency.nature,kind:action.kind,targetId:action.targetId||null,otherId:action.otherId||null,mode:action.mode||null,round:action.round||null});
 return next;
}

function buildForCapability(live,agency,cap){
 const parcels=activeParcels(live),board=live.runtime.cosmogony.board;
 if(cap.id==='PHYSICS_CONCENTRATE')return top(parcels,p=>p.hidden.mass+p.hidden.density-p.hidden.angularMomentum,5).map(p=>opt(cap,{id:`CONCENTRATE:${p.id}`,kind:'CONCENTRATE',targetId:p.id,mode:'CONCENTRATE',label:`Concentrar ${p.id}`,hint:revealMatterHint(p,'STAR_FEED')}));
 if(cap.id==='PHYSICS_REDISTRIBUTE')return top(parcels,p=>p.hidden.angularMomentum+distance(board,p),5).map(p=>opt(cap,{id:`REDISTRIBUTE:${p.id}`,kind:'REDISTRIBUTE',targetId:p.id,mode:'REDIRECT_OUTWARD',label:`Redistribuir ${p.id} hacia una órbita más externa`,hint:publicHint(p)}));
 if(cap.id==='PHYSICS_TRANSFER_ENERGY')return top(parcels,p=>Math.abs(Number(p.hidden.thermal)-3.5),5).map(p=>{const mode=Number(p.hidden.thermal)>=4?'COOL':'HEAT';return opt(cap,{id:`TRANSFER_ENERGY:${mode}:${p.id}`,kind:'TRANSFER_ENERGY',targetId:p.id,mode,label:mode==='COOL'?`Disipar energía de ${p.id}`:`Transferir energía a ${p.id}`,hint:publicHint(p)});});
 if(cap.id==='PHYSICS_STABILIZE_CAPTURE')return top(parcels,p=>planetValue(p),5).map(p=>opt(cap,{id:`PRESERVE_DISK:${p.id}`,kind:'PRESERVE_DISK',targetId:p.id,mode:'STABILIZE_CAPTURE',label:`Estabilizar ${p.id} para que pueda permanecer en el sistema`,hint:revealMatterHint(p,'PLANET')}));
 if(cap.id==='PHYSICS_ACTIVATE_NUCLEAR_CHANGE')return top(parcels.filter(nuclearEligible),p=>p.hidden.mass+p.hidden.density+p.hidden.thermal,4).map(p=>opt(cap,{id:`NUCLEAR_CHANGE:${p.id}`,kind:'ACTIVATE_NUCLEAR_CHANGE',targetId:p.id,mode:'ACTIVATE',label:`Favorecer un cambio nuclear en ${p.id}`,hint:'La app ha detectado condiciones físicas compatibles',calibration:GENESIS_R511_NUCLEAR_CALIBRATION}));
 if(cap.id==='PHYSICS_SYSTEMIC_APPLICATION')return connectedPairs(board,parcels).slice(0,4).map(([a,b])=>opt(cap,{id:`SYSTEMIC_CONCENTRATE:${a.id}:${b.id}`,kind:'SYSTEMIC_APPLICATION',targetId:a.id,otherId:b.id,spatialTargetIds:[a.id,b.id],mode:'CONCENTRATE_CONNECTED_SET',label:`Concentrar de forma coordinada ${a.id} y ${b.id}`,hint:'Dos masas físicamente conectadas por proximidad',payload:{lowerCapabilityId:'PHYSICS_CONCENTRATE',targetIds:[a.id,b.id],subKind:'CONCENTRATE'}}));

 if(cap.id==='MYSTIC_BIND')return candidatePairs(parcels).slice(0,8).filter(([a,b])=>!linked(a,b.id)).map(([a,b])=>opt(cap,{id:`LINK:${a.id}:${b.id}`,kind:'LINK',targetId:a.id,otherId:b.id,spatialTargetIds:[a.id,b.id],mode:'BIND',label:`Vincular ${a.id} y ${b.id}`}));
 if(cap.id==='MYSTIC_PERSIST_IMPRINT')return top(parcels,p=>planetValue(p),5).map(p=>opt(cap,{id:`IMPRINT:${p.id}`,kind:'IMPRINT',targetId:p.id,mode:'PERSIST_IMPRINT',principle:'PERSISTENCE_TRACE',label:`Hacer persistir una huella mística en ${p.id}`,hint:publicHint(p)}));
 if(cap.id==='MYSTIC_RESONATE_MARK')return linkedPairs(parcels).slice(0,6).map(([a,b])=>opt(cap,{id:`RESONATE:${a.id}:${b.id}`,kind:'RESONATE_MARK',targetId:a.id,otherId:b.id,spatialTargetIds:[a.id],mode:'RESONATE',label:`Hacer resonar el vínculo entre ${a.id} y ${b.id}`,hint:'Existe un vínculo místico previo',remoteReach:2,remotePathAuthorized:true}));
 if(cap.id==='MYSTIC_CONDITIONAL_TRANSFORM')return top(parcels.filter(p=>p.imprints?.length),p=>p.imprints.length+planetValue(p),5).map(p=>opt(cap,{id:`CONDITIONAL_TRANSFORM:${p.id}`,kind:'CONDITIONAL_TRANSFORM',targetId:p.id,mode:'WHEN_SUPPORT_CHANGES_STATE',label:`Preparar una transformación condicional en ${p.id}`,hint:'Solo se activará si su soporte cambia de estado',payload:{condition:'SUPPORT_STATE_CHANGES'}}));
 if(cap.id==='MYSTIC_CYCLE_ENTANGLE')return linkedPairs(parcels).slice(0,6).map(([a,b])=>opt(cap,{id:`CYCLE_ENTANGLE:${a.id}:${b.id}`,kind:'CYCLE_ENTANGLE',targetId:a.id,otherId:b.id,spatialTargetIds:[a.id],mode:'ENTANGLE_LINKED_PROCESS',label:`Entrelazar el ciclo de ${a.id} y ${b.id}`,hint:'El vínculo existente puede transportar consecuencias futuras',remoteReach:2,remotePathAuthorized:true}));
 if(cap.id==='MYSTIC_BRIDGE_CONSCIOUSNESS_MATTER'){
  const edge=live.runtime.ontology?.willMysticGraph?.edges?.[0],v=edge?.volitionEntityId;if(!edge||!v||Number(live.runtime.ontology?.sav?.V||0)<=0)return[];
  return top(parcels,p=>planetValue(p),4).map(p=>opt(cap,{id:`BRIDGE_CM:${v}:${p.id}`,kind:'BRIDGE_CONSCIOUSNESS_MATTER',targetId:p.id,mode:'BRIDGE',label:`Abrir un puente causal entre ${v} y ${p.id}`,hint:'Solo existe porque una relación Mística↔Voluntad ya fue causada',payload:{volitionEntityId:v,willMysticEdgeId:edge.id}}));
 }

 if(cap.id==='WILL_PROTECT_CLAIM_REJECT'){
  const rows=top(parcels,p=>planetValue(p),4),out=[];
  for(const p of rows){out.push(opt(cap,{id:`PROTECT:${p.id}`,kind:'PROTECT',targetId:p.id,mode:'PROTECT',label:`Proteger ${p.id}`,hint:revealMatterHint(p,'PLANET')}));out.push(opt(cap,{id:`CLAIM:${p.id}`,kind:'CLAIM',targetId:p.id,mode:'CLAIM',label:`Reclamar una relación con ${p.id}`,hint:publicHint(p)}));}
  return out;
 }
 if(cap.id==='WILL_DESIGNATE_IMPRINT_PURPOSE')return top(parcels,p=>planetValue(p),5).map(p=>{const purpose=purposeFor(p);return opt(cap,{id:`DESIGNATE_PURPOSE:${p.id}:${purpose}`,kind:'DESIGNATE_PURPOSE',targetId:p.id,mode:purpose,label:`Imprimir en ${p.id} el propósito: ${purposeLabel(purpose)}`,hint:'El propósito quedará como promesa causal, no como garantía',payload:{purpose}});});
 if(cap.id==='WILL_REVEAL_HIDE')return manifestationOptions(live,agency,cap);
 if(cap.id==='WILL_PACT_OPPOSE_RELATE')return relationOptions(live,agency,cap);
 if(cap.id==='WILL_AUTOLIMIT_CONTINUITY'){
  const entity=volitionEntity(live.runtime,agency);if(!entity||!hasOriginAuthority(live.runtime,entity.entityId))return[];
  const target=top(parcels,p=>planetValue(p),1)[0];if(!target)return[];
  return[opt(cap,{id:`AUTOLIMIT:${target.id}`,kind:'AUTOLIMIT',targetId:target.id,mode:'NO_DIRECT_INTERVENTION_ON',label:`Autolimitarte: renunciar a intervenir directamente sobre ${target.id}`,hint:'La limitación persistirá y reducirá tus opciones futuras',payload:{limitType:'NO_DIRECT_INTERVENTION_ON',targetId:target.id}})];
 }
 if(cap.id==='WILL_DECREE_EMANATE'){
  const entity=volitionEntity(live.runtime,agency);if(!entity||!hasOriginAuthority(live.runtime,entity.entityId))return[];
  const target=top(parcels,p=>planetValue(p),1)[0];if(!target)return[];
  return[opt(cap,{id:`BOUNDED_DECREE:${target.id}`,kind:'BOUNDED_DECREE',targetId:target.id,mode:'CAUSAL_CONTINUITY_BOUNDARY',label:`Decretar una ley acotada para la continuidad causal de ${target.id}`,hint:'No concede omnipotencia ni dominio fuera de este referente',payload:{law:'TARGET_CAUSAL_TRACE_MUST_REMAIN_CONSUMABLE',targetId:target.id}})];
 }
 return[];
}

function decorateAndValidate(agency,o){
 const remote=Number(o.remoteReach||0)>1;
 const e=catalogEligibilityR511({nature:agency.nature,intensity:agency.universeIntensity,capabilityId:o.capabilityId,context:{remote,remotePathAuthorized:o.remotePathAuthorized===true}});
 if(!e.legal)throw new Error(`GEN_R511_GENERATED_ILLEGAL:${e.reason}`);
 return{...o,schema:GENESIS_R511_LIVE_ADAPTER_SCHEMA,decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01',capabilityLevel:e.capability.requiredLevel,playerFacingCapabilityMenu:false};
}
function opt(cap,row){return{...row,capabilityId:cap.id,capabilityLevel:cap.requiredLevel,requiredLevel:cap.requiredLevel};}
function activeParcels(live){return live.runtime.cosmogony.matter.parcels.filter(p=>ACTIVE_STATES.has(p.state));}
function top(rows,score,n){return [...rows].sort((a,b)=>score(b)-score(a)||String(a.id).localeCompare(String(b.id))).slice(0,n);}
function publicHint(p){return p.public?.traits?.join(' · ')||p.public?.label||'Materia primordial';}
function planetValue(p){return Number(p.hidden.refractories||0)+Number(p.hidden.volatiles||0)+Number(p.hidden.mass||0)/3;}
function distance(board,p){const c=board.cells.find(x=>x.code===p.cell);return c?axialDistance(c,board.center):0;}
function candidatePairs(parcels){const out=[];for(let i=0;i<parcels.length;i++)for(let j=i+1;j<parcels.length;j++)out.push([parcels[i],parcels[j]]);return out;}
function connectedPairs(board,parcels){return candidatePairs(parcels).filter(([a,b])=>{const ca=board.cells.find(c=>c.code===a.cell),cb=board.cells.find(c=>c.code===b.cell);return ca&&cb&&axialDistance(ca,cb)<=1;}).sort((x,y)=>String(x[0].id+x[1].id).localeCompare(String(y[0].id+y[1].id)));}
function linked(a,otherId){return Array.isArray(a.links)&&a.links.some(x=>x.otherId===otherId);}
function linkedPairs(parcels){const by=new Map(parcels.map(p=>[p.id,p])),seen=new Set(),out=[];for(const a of parcels)for(const l of a.links||[]){const b=by.get(l.otherId);if(!b)continue;const key=[a.id,b.id].sort().join('::');if(seen.has(key))continue;seen.add(key);out.push([a,b]);}return out.sort((x,y)=>String(x[0].id+x[1].id).localeCompare(String(y[0].id+y[1].id)));}
function nuclearEligible(p){return Number(p.hidden.density)>=5&&Number(p.hidden.thermal)>=5&&Number(p.hidden.mass)>=4;}
function purposeFor(p){if(Number(p.hidden.volatiles)>=5)return'PRESERVE_VOLATILE_POTENTIAL';if(Number(p.hidden.refractories)>=5)return'BECOME_STABLE_FOUNDATION';return'ENDURE_TRANSFORMATION';}
function purposeLabel(p){return p==='PRESERVE_VOLATILE_POTENTIAL'?'conservar potencial volátil':p==='BECOME_STABLE_FOUNDATION'?'servir de fundamento estable':'perdurar a través de la transformación';}

function manifestationOptions(live,agency,cap){
 const entity=volitionEntity(live.runtime,agency);if(!entity)return[];const purposes=(entity.promises||[]).filter(x=>x.type==='VOLITION_PURPOSE_DESIGNATED'&&x.targetMatterId);
 const out=[];for(const p of purposes.slice(-4)){
  const hidden=(entity.facts||[]).filter(f=>f.type==='VOLITION_MANIFESTATION'&&f.targetMatterId===p.targetMatterId).at(-1)?.mode==='HIDE';
  out.push(opt(cap,{id:`MANIFEST_TRACE:${hidden?'REVEAL':'HIDE'}:${p.targetMatterId}`,kind:'MANIFEST_TRACE',targetId:p.targetMatterId,mode:hidden?'REVEAL':'HIDE',label:hidden?`Revelar tu huella ya existente sobre ${p.targetMatterId}`:`Ocultar tu huella ya existente sobre ${p.targetMatterId}`,hint:'Solo cambia su descubribilidad; la verdad objetiva permanece'}));
 }
 return out;
}
function relationOptions(live,agency,cap){
 const self=volitionEntity(live.runtime,agency);if(!self)return[];const others=live.runtime.binding.agencies.filter(a=>a.nature==='WILL'&&a.volitionEntityId&&a.volitionEntityId!==self.entityId),out=[];
 for(const other of others){const target=sharedTouchedTarget(live.runtime,agency.id,other.id);if(!target)continue;
  out.push(opt(cap,{id:`VOLITION_RELATION:OPPOSES:${other.volitionEntityId}:${target}`,kind:'VOLITION_RELATION',targetId:target,mode:'OPPOSES',label:`Oponerte a ${other.volitionEntityId} por ${target}`,hint:'La relación solo aparece porque ambas Voluntades tocaron el mismo referente',payload:{fromEntityId:self.entityId,toEntityId:other.volitionEntityId,type:'OPPOSES',symmetry:'DIRECTED',producerIds:[self.entityId],scope:`TARGET:${target}`,provenance:`R5.11:${target}`,visibility:'PUBLIC',futureConsumers:['BOOT03','FUTURE_BOOTS','RUNTIME']}}));
  out.push(opt(cap,{id:`VOLITION_RELATION:PROMISED_TO:${other.volitionEntityId}:${target}`,kind:'VOLITION_RELATION',targetId:target,mode:'PROMISED_TO',label:`Prometer cooperación a ${other.volitionEntityId} respecto a ${target}`,hint:'Es una promesa dirigida, no un pacto automático de la otra Voluntad',payload:{fromEntityId:self.entityId,toEntityId:other.volitionEntityId,type:'PROMISED_TO',symmetry:'DIRECTED',producerIds:[self.entityId],scope:`TARGET:${target}`,provenance:`R5.11:${target}`,visibility:'PUBLIC',futureConsumers:['BOOT03','FUTURE_BOOTS','RUNTIME']}}));
 }
 return out;
}
function sharedTouchedTarget(runtime,aId,bId){const ia=new Set(runtime.cosmogony.interventions.filter(x=>x.actorId===aId).map(x=>x.targetId));return runtime.cosmogony.interventions.find(x=>x.actorId===bId&&ia.has(x.targetId))?.targetId||null;}
function volitionEntity(runtime,agency){return agency.volitionEntityId?runtime.ontology.volitionEntities.find(v=>v.entityId===agency.volitionEntityId)||null:null;}
function causalProducerIdR511(agency){if(agency?.nature==='WILL'&&agency.volitionEntityId)return agency.volitionEntityId;if(agency?.nature==='MYSTIC'&&agency.mysticForceId)return agency.mysticForceId;return agency?.id||null;}
function hasOriginAuthority(runtime,entityId){return runtime.ontology.lawAuthority?.producerIds?.includes(entityId)||runtime.ontology.volitionEntities.find(v=>v.entityId===entityId)?.domains?.includes('COSMOGONIC_AUTHOR');}
function blockedBySelfLimit(live,agency,o){const e=volitionEntity(live.runtime,agency);if(!e||['AUTOLIMIT','BOUNDED_DECREE','VOLITION_RELATION','MANIFEST_TRACE'].includes(o.kind))return false;return(e.limits||[]).some(l=>l.type==='NO_DIRECT_INTERVENTION_ON'&&l.targetId&&[o.targetId,o.otherId,...(o.payload?.targetIds||[])].includes(l.targetId));}

function applyRedistribute(runtime,agency,action){
 const next=clone(runtime),p=parcel(next,action.targetId),board=next.cosmogony.board,center=board.center,current=board.cells.find(c=>c.code===p.cell);if(!current)throw new Error('GEN_R511_TARGET_CELL_UNKNOWN');
 const candidates=nearestCells(board,current,Math.min(board.cells.length,12),{excludeCodes:[current.code]}).filter(c=>axialDistance(c,center)>axialDistance(current,center));const dest=candidates.sort((a,b)=>axialDistance(b,center)-axialDistance(a,center)||a.code.localeCompare(b.code))[0]||null;const from=p.cell;
 if(dest){p.cell=dest.code;p.q=dest.q;p.r=dest.r;}p.hidden.angularMomentum=Math.min(6,Number(p.hidden.angularMomentum||1)+1);
 recordPhysical(next,agency,action,{from,to:p.cell,angularMomentumDelta:+1});return next;
}
function applyEnergyTransfer(runtime,agency,action){const next=clone(runtime),p=parcel(next,action.targetId),before=Number(p.hidden.thermal||1);p.hidden.thermal=action.mode==='COOL'?Math.max(1,before-1):Math.min(6,before+1);recordPhysical(next,agency,action,{thermalFrom:before,thermalTo:p.hidden.thermal});return next;}
function applyNuclearActivation(runtime,agency,action){const next=clone(runtime),p=parcel(next,action.targetId);if(!nuclearEligible(p))throw new Error('GEN_R511_NUCLEAR_CONDITIONS_NOT_MET');p.hidden.nuclearActivationCount=Number(p.hidden.nuclearActivationCount||0)+1;p.hidden.thermal=Math.min(6,Number(p.hidden.thermal)+1);p.hidden.density=Math.min(6,Number(p.hidden.density)+1);recordPhysical(next,agency,action,{nuclearActivation:true,calibration:GENESIS_R511_NUCLEAR_CALIBRATION});return next;}
function applySystemic(runtime,agency,action){const ids=[...(action.payload?.targetIds||[])];if(ids.length<2)throw new Error('GEN_R511_SYSTEMIC_TARGETS_REQUIRED');const before=runtime.turn;let next=runtime;for(const id of ids)next=applyRuntimeAgencyActionR5(next,{playerId:action.playerId,kind:action.payload.subKind||'CONCENTRATE',targetId:id});next.turn=before+1;next.eventLog.push({type:'GEN_R511_SYSTEMIC_SUBEFFECTS',capabilityId:action.capabilityId,playerId:action.playerId,targetIds:ids,subKind:action.payload.subKind||'CONCENTRATE'});return next;}
function applyResonance(runtime,agency,action){const before=runtime.turn,producerEntityId=causalProducerIdR511(agency);let next=applyRuntimeAgencyActionR5(runtime,{playerId:action.playerId,kind:'IMPRINT',targetId:action.targetId,principle:'RESONANCE_MARK'});next=applyRuntimeAgencyActionR5(next,{playerId:action.playerId,kind:'IMPRINT',targetId:action.otherId,principle:'RESONANCE_MARK'});next.turn=before+1;next.ontology.objectiveSupernaturalFacts.push({factId:`R511-RESONANCE-${before+1}`,type:'MYSTIC_RESONANCE',producerId:producerEntityId,producerAgencyId:agency.id,targetMatterIds:[action.targetId,action.otherId],provenance:action.capabilityId});return next;}
function applyVolitionRelation(runtime,agency,action){if(agency.nature!=='WILL'||!agency.volitionEntityId)throw new Error('GEN_R511_VOLITION_REQUIRED');let next=establishVolitionRelationR5(runtime,{...clone(action.payload),createdAt:runtime.turn});next.turn=runtime.turn+1;return next;}
function applySemantic(runtime,agency,action){
 const next=clone(runtime),turn=Number(next.turn||0)+1,factId=`FACT-R511-${String(turn).padStart(3,'0')}-${action.kind}`,producerEntityId=causalProducerIdR511(agency),base={factId,type:semanticFactType(action.kind),producerId:producerEntityId,producerAgencyId:agency.id,targetMatterId:action.targetId||null,otherMatterId:action.otherId||null,mode:action.mode||null,capabilityId:action.capabilityId,createdAtTurn:turn,provenance:'D-GEN-R5.11-CAPABILITY-SEMANTICS01'};
 const entity=volitionEntity(next,agency);
 if(action.kind==='DESIGNATE_PURPOSE'){
  const promise={...base,type:'VOLITION_PURPOSE_DESIGNATED',purpose:action.payload?.purpose,status:'ACTIVE'};entity?.promises.push(clone(promise));next.ontology.promises.push(clone(promise));next.ontology.objectiveSupernaturalFacts.push(clone(promise));next.ontology.publicGenesisFacts.push(clone(promise));next.ontology.futureHooks.push({hookId:`HOOK-${factId}`,sourceFactId:factId,type:'PURPOSE_CONSEQUENCE',consumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME'],visibility:'ENGINE_ONLY',status:'AVAILABLE'});
 }else if(action.kind==='MANIFEST_TRACE'){
  const fact={...base,type:'VOLITION_MANIFESTATION',mode:action.mode};entity?.facts.push(clone(fact));next.ontology.objectiveSupernaturalFacts.push(clone(fact));if(action.mode==='HIDE')next.ontology.hiddenGenesisFacts.push(clone(fact));else next.ontology.publicGenesisFacts.push(clone(fact));
 }else if(action.kind==='AUTOLIMIT'){
  if(!entity||!hasOriginAuthority(next,entity.entityId))throw new Error('GEN_R511_AUTOLIMIT_AUTHORITY_REQUIRED');const limit={id:`LIMIT-${factId}`,type:action.payload?.limitType||'NO_DIRECT_INTERVENTION_ON',targetId:action.payload?.targetId||action.targetId,createdAtTurn:turn,producerId:entity.entityId};entity.limits.push(limit);next.ontology.lawAuthority.exceptionsAndSelfLimits??=[];next.ontology.lawAuthority.exceptionsAndSelfLimits.push(clone(limit));next.ontology.objectiveSupernaturalFacts.push({...base,type:'VOLITION_SELF_LIMIT',limit:clone(limit)});
 }else if(action.kind==='BOUNDED_DECREE'){
  if(!entity||!hasOriginAuthority(next,entity.entityId))throw new Error('GEN_R511_DECREE_AUTHORITY_REQUIRED');const fact={...base,type:'BOUNDED_VOLITION_DECREE',law:action.payload?.law,scope:`TARGET:${action.targetId}`};entity.facts.push(clone(fact));next.ontology.objectiveSupernaturalFacts.push(clone(fact));next.ontology.publicGenesisFacts.push(clone(fact));next.ontology.futureHooks.push({hookId:`HOOK-${factId}`,sourceFactId:factId,type:'BOUNDED_DECREE_CONSEQUENCE',consumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME'],visibility:'ENGINE_ONLY',status:'AVAILABLE'});
 }else if(action.kind==='BRIDGE_CONSCIOUSNESS_MATTER'){
  const fact={...base,type:'CONSCIOUSNESS_MATTER_BRIDGE',volitionEntityId:action.payload?.volitionEntityId,willMysticEdgeId:action.payload?.willMysticEdgeId};next.ontology.consciousnessMetaphysics.status='CONDITIONALLY_LINKED';next.ontology.consciousnessMetaphysics.mechanisms.push({type:'MYSTIC_VOLITION_MATTER_BRIDGE',producerId:producerEntityId,producerAgencyId:agency.id,targetMatterId:action.targetId,sourceRelationId:action.payload?.willMysticEdgeId});next.ontology.objectiveSupernaturalFacts.push(clone(fact));next.ontology.hiddenGenesisFacts.push(clone(fact));next.ontology.futureHooks.push({hookId:`HOOK-${factId}`,sourceFactId:factId,type:'CONSCIOUSNESS_MATTER_CONSEQUENCE',consumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME'],visibility:'ENGINE_ONLY',status:'AVAILABLE'});
 }else{
  const fact={...base,condition:action.payload?.condition||null};next.ontology.objectiveSupernaturalFacts.push(clone(fact));next.ontology.hiddenGenesisFacts.push(clone(fact));next.ontology.futureHooks.push({hookId:`HOOK-${factId}`,sourceFactId:factId,type:action.kind==='CYCLE_ENTANGLE'?'MYSTIC_CYCLE_CONSEQUENCE':'MYSTIC_CONDITIONAL_CONSEQUENCE',consumers:['BOOT03','FUTURE_BOOTS','RUNTIME'],visibility:'ENGINE_ONLY',status:'AVAILABLE'});
 }
 next.eventLog.push({type:'GEN_R511_SEMANTIC_EFFECT',factId,playerId:action.playerId,agencyId:agency.id,producerEntityId,capabilityId:action.capabilityId,kind:action.kind});next.turn=turn;return next;
}
function semanticFactType(kind){return kind==='CONDITIONAL_TRANSFORM'?'MYSTIC_CONDITIONAL_TRANSFORM':kind==='CYCLE_ENTANGLE'?'MYSTIC_CYCLE_ENTANGLEMENT':kind;}
function parcel(runtime,id){const p=runtime.cosmogony.matter.parcels.find(x=>x.id===id);if(!p||!ACTIVE_STATES.has(p.state))throw new Error('GEN_R511_TARGET_INELIGIBLE');return p;}
function recordPhysical(next,agency,action,delta){next.cosmogony.history.push({type:'R511_INTERVENTION',epoch:next.cosmogony.epoch,actorId:agency.id,nature:agency.nature,kind:action.kind,targetId:action.targetId,otherId:action.otherId||null,capabilityId:action.capabilityId,delta:clone(delta)});next.cosmogony.interventions.push({epoch:next.cosmogony.epoch,actorId:agency.id,nature:agency.nature,kind:action.kind,targetId:action.targetId,otherId:action.otherId||null,capabilityId:action.capabilityId});next.eventLog.push({type:'GEN_R5_AGENCY_ACTION',playerId:action.playerId,agencyId:agency.id,nature:agency.nature,kind:action.kind,targetId:action.targetId,otherId:action.otherId||null,capabilityId:action.capabilityId,epoch:next.cosmogony.epoch});next.turn=Number(next.turn||0)+1;}
