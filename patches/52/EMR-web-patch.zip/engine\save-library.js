export const SAVE_LIBRARY_SCHEMA='EMR-SAVE-LIBRARY-1';
export const SAVE_LIBRARY_BUNDLE_FORMAT='EMR-SAVE-LIBRARY-BUNDLE-1';
export const SAVE_LIBRARY_KEY='emr.save.library.v1';
export const LEGACY_SAVE_KEY='emr.hybrid.save.v0.21';
const STORY_SAVE_PREFIX='emr.save.story.';

const now=()=>new Date().toISOString();
const uid=(prefix)=>`${prefix}-${globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
const cleanName=(v,fallback)=>String(v??'').trim().replace(/\s+/g,' ').slice(0,80)||fallback;
const isRuntimeSave=(saveText)=>{try{return JSON.parse(String(saveText))?.session?.boot?.phase==='RUNTIME';}catch{return false;}};

export function emptyLibrary(){return{schema:SAVE_LIBRARY_SCHEMA,createdAt:now(),updatedAt:now(),active:{profileId:null,universeId:null,storyId:null},profiles:[],universes:[],stories:[]};}

export function parseLibrary(raw){
 if(!raw)return emptyLibrary();
 const x=typeof raw==='string'?JSON.parse(raw):structuredClone(raw);
 if(x?.schema!==SAVE_LIBRARY_SCHEMA)throw new Error('SAVE_LIBRARY_SCHEMA_UNSUPPORTED');
 x.active??={profileId:null,universeId:null,storyId:null};x.profiles??=[];x.universes??=[];x.stories??=[];return x;
}

export function parseBundle(raw){
 const b=typeof raw==='string'?JSON.parse(raw):structuredClone(raw);
 if(b?.format!==SAVE_LIBRARY_BUNDLE_FORMAT)throw new Error('SAVE_LIBRARY_BUNDLE_UNSUPPORTED');
 const library=parseLibrary(b.library);
 if(!b.saves||typeof b.saves!=='object'||Array.isArray(b.saves))throw new Error('SAVE_LIBRARY_BUNDLE_SAVES_INVALID');
 const profiles=new Set(library.profiles.map(x=>x.id));
 const universes=new Map(library.universes.map(x=>[x.id,x]));
 const stories=new Map(library.stories.map(x=>[x.id,x]));
 if(profiles.size!==library.profiles.length||universes.size!==library.universes.length||stories.size!==library.stories.length)throw new Error('SAVE_LIBRARY_BUNDLE_DUPLICATE_ID');
 for(const u of library.universes)if(!profiles.has(u.profileId))throw new Error('SAVE_LIBRARY_BUNDLE_ORPHAN_UNIVERSE');
 for(const s of library.stories){const u=universes.get(s.universeId);if(!u||u.profileId!==s.profileId)throw new Error('SAVE_LIBRARY_BUNDLE_ORPHAN_STORY');}
 for(const [storyId,value] of Object.entries(b.saves)){if(!stories.has(storyId))throw new Error('SAVE_LIBRARY_BUNDLE_ORPHAN_SAVE');if(typeof value!=='string')throw new Error('SAVE_LIBRARY_BUNDLE_SAVE_INVALID');}
 for(const s of library.stories)if(Boolean(s.hasSave)!==Object.prototype.hasOwnProperty.call(b.saves,s.id))throw new Error('SAVE_LIBRARY_BUNDLE_SAVE_INDEX_MISMATCH');
 const {profileId,universeId,storyId}=library.active||{};
 if(profileId&&!profiles.has(profileId))throw new Error('SAVE_LIBRARY_BUNDLE_ACTIVE_PROFILE_INVALID');
 if(universeId){const u=universes.get(universeId);if(!u||profileId&&u.profileId!==profileId)throw new Error('SAVE_LIBRARY_BUNDLE_ACTIVE_UNIVERSE_INVALID');}
 if(storyId){const s=stories.get(storyId);if(!s||universeId&&s.universeId!==universeId||profileId&&s.profileId!==profileId)throw new Error('SAVE_LIBRARY_BUNDLE_ACTIVE_STORY_INVALID');}
 return{format:SAVE_LIBRARY_BUNDLE_FORMAT,library,saves:{...b.saves}};
}

export class SaveLibrary{
 constructor(storage=globalThis.localStorage){this.storage=storage;this.data=this.load();}
 load(){try{return parseLibrary(this.storage?.getItem?.(SAVE_LIBRARY_KEY));}catch{return emptyLibrary();}}
 commit(){this.data.updatedAt=now();this.storage?.setItem?.(SAVE_LIBRARY_KEY,JSON.stringify(this.data));return this.data;}
 reload(){this.data=this.load();return this.data;}
 profile(id=this.data.active.profileId){return this.data.profiles.find(x=>x.id===id)||null;}
 universe(id=this.data.active.universeId){return this.data.universes.find(x=>x.id===id)||null;}
 story(id=this.data.active.storyId){return this.data.stories.find(x=>x.id===id)||null;}
 profiles(){return[...this.data.profiles];}
 universes(profileId=this.data.active.profileId){return this.data.universes.filter(x=>x.profileId===profileId);}
 stories(universeId=this.data.active.universeId){return this.data.stories.filter(x=>x.universeId===universeId);}
 createProfile(name){const p={id:uid('P'),name:cleanName(name,'Jugador'),createdAt:now(),updatedAt:now()};this.data.profiles.push(p);this.data.active.profileId=p.id;this.data.active.universeId=null;this.data.active.storyId=null;this.commit();return p;}
 createUniverse({profileId=this.data.active.profileId,name='Mi universo',seed=null,baseSave=null}={}){if(!this.profile(profileId))throw new Error('PROFILE_REQUIRED');const u={id:uid('U'),profileId,name:cleanName(name,'Mi universo'),seed:seed||uid('SEED'),createdAt:now(),updatedAt:now(),baseSave:baseSave||null,status:'active'};this.data.universes.push(u);this.data.active={profileId,universeId:u.id,storyId:null};this.commit();return u;}
 createStory({universeId=this.data.active.universeId,name='Nueva historia',saveText=null,parentStoryId=null}={}){const u=this.universe(universeId);if(!u)throw new Error('UNIVERSE_REQUIRED');const s={id:uid('S'),profileId:u.profileId,universeId:u.id,name:cleanName(name,'Nueva historia'),createdAt:now(),updatedAt:now(),lastPlayedAt:null,parentStoryId:parentStoryId||null,hasSave:Boolean(saveText)};this.data.stories.push(s);this.data.active={profileId:u.profileId,universeId:u.id,storyId:s.id};if(saveText)this.writeStorySave(s.id,saveText);this.commit();return s;}
 activateProfile(profileId){if(!this.profile(profileId))throw new Error('PROFILE_NOT_FOUND');this.data.active={profileId,universeId:null,storyId:null};this.commit();}
 activateUniverse(universeId){const u=this.universe(universeId);if(!u)throw new Error('UNIVERSE_NOT_FOUND');this.data.active={profileId:u.profileId,universeId:u.id,storyId:null};this.commit();}
 activateStory(storyId){const s=this.story(storyId);if(!s)throw new Error('STORY_NOT_FOUND');this.data.active={profileId:s.profileId,universeId:s.universeId,storyId:s.id};s.lastPlayedAt=now();s.updatedAt=now();this.commit();return s;}
 storySaveKey(storyId){return STORY_SAVE_PREFIX+storyId;}
 readStorySave(storyId=this.data.active.storyId){if(!storyId)return null;return this.storage?.getItem?.(this.storySaveKey(storyId))||null;}
 writeStorySave(storyId,saveText){const s=this.story(storyId);if(!s)throw new Error('STORY_NOT_FOUND');this.storage?.setItem?.(this.storySaveKey(storyId),String(saveText));s.hasSave=true;s.updatedAt=now();s.lastPlayedAt=now();this.commit();return s;}
 renameStory(storyId,name){const s=this.story(storyId);if(!s)throw new Error('STORY_NOT_FOUND');s.name=cleanName(name,s.name);s.updatedAt=now();this.commit();return s;}
 deleteStory(storyId){const i=this.data.stories.findIndex(x=>x.id===storyId);if(i<0)return false;this.storage?.removeItem?.(this.storySaveKey(storyId));this.data.stories.splice(i,1);if(this.data.active.storyId===storyId)this.data.active.storyId=null;this.commit();return true;}
 freezeUniverseBase(universeId,saveText){const u=this.universe(universeId);if(!u)throw new Error('UNIVERSE_NOT_FOUND');if(u.baseSave)return u;u.baseSave=String(saveText);u.updatedAt=now();this.commit();return u;}
 forkStory({universeId=this.data.active.universeId,name='Nueva historia'}={}){const u=this.universe(universeId);if(!u)throw new Error('UNIVERSE_NOT_FOUND');if(!u.baseSave)throw new Error('UNIVERSE_BASE_NOT_FROZEN');return this.createStory({universeId,name,saveText:u.baseSave});}
 exportBundle(){const saves={};for(const s of this.data.stories){const txt=this.readStorySave(s.id);if(txt)saves[s.id]=txt;}return JSON.stringify({format:SAVE_LIBRARY_BUNDLE_FORMAT,library:this.data,saves},null,2);}
 importBundle(raw){
  const imported=parseBundle(raw),oldStoryIds=this.data.stories.map(x=>x.id),newStoryIds=imported.library.stories.map(x=>x.id);
  for(const id of new Set([...oldStoryIds,...newStoryIds]))this.storage?.removeItem?.(this.storySaveKey(id));
  for(const [id,saveText] of Object.entries(imported.saves))this.storage?.setItem?.(this.storySaveKey(id),saveText);
  this.data=structuredClone(imported.library);
  this.storage?.setItem?.(SAVE_LIBRARY_KEY,JSON.stringify(this.data));
  return this.data;
 }
 migrateLegacy({profileName='Jugador local',universeName='Universo recuperado',storyName='Partida recuperada'}={}){if(this.data.profiles.length)return null;const legacy=this.storage?.getItem?.(LEGACY_SAVE_KEY);if(!legacy)return null;const p=this.createProfile(profileName),u=this.createUniverse({profileId:p.id,name:universeName}),s=this.createStory({universeId:u.id,name:storyName,saveText:legacy});return{profile:p,universe:u,story:s};}
}

export function installLegacySaveBridge({storage=globalThis.localStorage}={}){
 if(!storage||globalThis.__EMR_SAVE_LIBRARY_BRIDGE__)return globalThis.__EMR_SAVE_LIBRARY_BRIDGE__||null;
 const lib=new SaveLibrary(storage);lib.migrateLegacy();
 const proto=Object.getPrototypeOf(storage),nativeGet=proto.getItem,nativeSet=proto.setItem,nativeRemove=proto.removeItem;
 const bridge={lib,nativeGet,nativeSet,nativeRemove};
 proto.getItem=function(key){if(this===storage&&key===LEGACY_SAVE_KEY){const id=lib.reload().active.storyId;const routed=id?nativeGet.call(storage,STORY_SAVE_PREFIX+id):null;return routed??nativeGet.call(storage,key);}return nativeGet.call(this,key);};
 proto.setItem=function(key,value){if(this===storage&&key===LEGACY_SAVE_KEY){const active=lib.reload().active,id=active.storyId;if(id){const u=active.universeId?lib.universe(active.universeId):null;if(u&&!u.baseSave&&isRuntimeSave(value))lib.freezeUniverseBase(u.id,String(value));nativeSet.call(storage,STORY_SAVE_PREFIX+id,String(value));const s=lib.story(id);if(s){s.hasSave=true;s.updatedAt=now();s.lastPlayedAt=now();lib.commit();}}nativeSet.call(storage,key,String(value));return;}return nativeSet.call(this,key,value);};
 proto.removeItem=function(key){if(this===storage&&key===LEGACY_SAVE_KEY){const id=lib.reload().active.storyId;if(id)nativeRemove.call(storage,STORY_SAVE_PREFIX+id);nativeRemove.call(storage,key);return;}return nativeRemove.call(this,key);};
 globalThis.__EMR_SAVE_LIBRARY_BRIDGE__=bridge;return bridge;
}
