export const PRIMORDIAL_RESOLVER_SCHEMA='EMR_PRIMORDIAL_RESOLVER_v1';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const bands=['ABSENT','TENUOUS','MINOR','RELEVANT','DOMINANT','FOUNDATIONAL'];
export const intensityBand=n=>bands[clamp(Number(n)||0,0,5)];
export function effectiveAuthority({intensity=0,presence='DIRECT',prepared=false,worldFit=0,support=0,opposition=0}={}){
 const p={DIRECT:2,ADJACENT:1,REMOTE:-2}[presence]??-2;
 const score=(Number(intensity)||0)*3+p+(prepared?2:0)+clamp(worldFit,-2,2)+clamp(support,0,3)-clamp(opposition,0,3);
 return {score,band:intensityBand(intensity),canAct:intensity>0&&score>0};
}
export function resolvePrimordialConvergence({intentions=[],uncertaintyRoll=null}={}){
 const active=intentions.map((x,i)=>({...x,id:x.id||`I${i+1}`,authority:effectiveAuthority(x)})).filter(x=>x.authority.canAct);
 const groups=new Map(); for(const x of active){const k=x.conflictKey||x.target||'WORLD';if(!groups.has(k))groups.set(k,[]);groups.get(k).push(x);}
 const outcomes=[];
 for(const [key,xs] of groups){
  const compatible=xs.filter(x=>x.compatible!==false); const opposed=xs.filter(x=>x.compatible===false);
  if(opposed.length===0){outcomes.push({key,type:'COMPOSED',applied:compatible.map(x=>x.id),residues:[]});continue;}
  const all=[...compatible,...opposed].sort((a,b)=>b.authority.score-a.authority.score||a.id.localeCompare(b.id));
  const top=all[0],second=all[1]; const gap=top.authority.score-(second?.authority.score??-99);
  if(gap>=3){outcomes.push({key,type:'CLEAR_CAUSAL_PRECEDENCE',applied:[top.id],residues:all.slice(1).filter(x=>x.authority.score>=top.authority.score-5).map(x=>x.id)});continue;}
  if(uncertaintyRoll==null){outcomes.push({key,type:'UNCERTAINTY_REQUIRED',candidates:all.slice(0,2).map(x=>x.id),residues:all.slice(2).map(x=>x.id)});continue;}
  const idx=clamp(Number(uncertaintyRoll),1,6)<=3?0:1;outcomes.push({key,type:'UNCERTAINTY_RESOLVED',applied:[all[idx].id],roll:clamp(Number(uncertaintyRoll),1,6),residues:all.filter((_,i)=>i!==idx).map(x=>x.id)});
 }
 return {schema:PRIMORDIAL_RESOLVER_SCHEMA,outcomes,active:active.map(x=>({id:x.id,score:x.authority.score,band:x.authority.band}))};
}
