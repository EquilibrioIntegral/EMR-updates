import {isCapabilityUnlockedR53,unlockedPowerLevelsR53} from './genesis-signature-r53.js';

export const GENESIS_WILL_MYSTIC_R56_SCHEMA='EMR_GENESIS_WILL_MYSTIC_R56_v1';
export const WILL_MYSTIC_DEFAULT_RELATION_R56='COEXISTENT_UNLINKED';
export const WILL_MYSTIC_RELATION_TYPES_R56=Object.freeze([
 'CO_PRODUCER_OF_MATERIAL_LAW',
 'VOLITION_AUTHORED_MYSTIC',
 'MYSTIC_EMERGED_VOLITION',
 'VOLITION_CHANNELS_MYSTIC',
 'VOLITION_BOUND_BY_MYSTIC',
 'VOLITION_PACTED_WITH_MYSTIC',
 'VOLITION_IMPRINTS_MYSTIC',
 'MYSTIC_VOLITION_TENSION'
]);

const clone=x=>structuredClone(x);
const assertIntensity=n=>{if(!Number.isInteger(n)||n<0||n>6)throw new Error('GEN_R56_INTENSITY_INVALID');return n;};
const assertLevel=n=>{if(!Number.isInteger(n)||n<1||n>6)throw new Error('GEN_R56_REQUIRED_LEVEL_INVALID');return n;};

export function createWillMysticGraphR56({signature,binding}={}){
 if(!signature)throw new Error('GEN_R56_SIGNATURE_REQUIRED');
 const mysticPowerLevel=assertIntensity(signature.MYSTIC),willPowerLevel=assertIntensity(signature.WILL);
 const entityIds=(binding?.volitionEntities||[]).map(v=>v.entityId);
 return{
  schema:GENESIS_WILL_MYSTIC_R56_SCHEMA,
  decisionId:'D-GEN-R5.6-WILL-MYSTIC-RELATION01',
  substrateId:'MYSTIC_SUBSTRATE',
  active:mysticPowerLevel>0&&willPowerLevel>0,
  mysticPowerLevel,
  mysticUnlockedLevels:unlockedPowerLevelsR53(mysticPowerLevel),
  willPowerLevel,
  willUnlockedLevels:unlockedPowerLevelsR53(willPowerLevel),
  defaultRelation:WILL_MYSTIC_DEFAULT_RELATION_R56,
  entities:entityIds.map(volitionEntityId=>({volitionEntityId,baseline:WILL_MYSTIC_DEFAULT_RELATION_R56})),
  edges:[]
 };
}

export function recordWillMysticRelationR56(graph,{type,volitionEntityId,producerId=null,subjectId=null,objectId='MYSTIC_SUBSTRATE',scope='LOCAL',limits=[],createdAt=0,provenance='GENESIS',actorNature='WILL',actorIntensity=null,requiredLevel=1}={}){
 validateGraph(graph);
 if(!graph.active)throw new Error('GEN_R56_RELATION_GRAPH_INACTIVE');
 if(!WILL_MYSTIC_RELATION_TYPES_R56.includes(type))throw new Error('GEN_R56_RELATION_TYPE_INVALID');
 if(!graph.entities.some(e=>e.volitionEntityId===volitionEntityId))throw new Error('GEN_R56_VOLITION_UNKNOWN');
 const level=assertLevel(requiredLevel);
 const nature=String(actorNature||'').toUpperCase();
 if(!['WILL','MYSTIC'].includes(nature))throw new Error('GEN_R56_ACTOR_NATURE_INVALID');
 const intensity=actorIntensity==null?(nature==='WILL'?graph.willPowerLevel:graph.mysticPowerLevel):assertIntensity(actorIntensity);
 if(!isCapabilityUnlockedR53(intensity,level))throw new Error('GEN_R56_CAPABILITY_LEVEL_LOCKED');
 const next=clone(graph);
 const edge={
  id:`WM-${next.edges.length+1}`,
  type,
  volitionEntityId,
  producerId:producerId||volitionEntityId,
  subjectId:subjectId||volitionEntityId,
  objectId,
  scope,
  limits:[...(limits||[])],
  createdAt,
  provenance,
  actorNature:nature,
  requiredLevel:level
 };
 next.edges.push(edge);
 return next;
}

export function relationsForVolitionR56(graph,volitionEntityId){
 validateGraph(graph);
 if(!graph.entities.some(e=>e.volitionEntityId===volitionEntityId))throw new Error('GEN_R56_VOLITION_UNKNOWN');
 const edges=graph.edges.filter(e=>e.volitionEntityId===volitionEntityId).map(clone);
 return{volitionEntityId,baseline:WILL_MYSTIC_DEFAULT_RELATION_R56,relationState:edges.length?'LINKED':WILL_MYSTIC_DEFAULT_RELATION_R56,edges};
}

export function relationAllowsInteractionR56(graph,{volitionEntityId,type,scope=null,actorNature='WILL',actorIntensity=null,requiredLevel=1}={}){
 validateGraph(graph);
 const level=assertLevel(requiredLevel),nature=String(actorNature||'').toUpperCase();
 if(!['WILL','MYSTIC'].includes(nature))return false;
 const intensity=actorIntensity==null?(nature==='WILL'?graph.willPowerLevel:graph.mysticPowerLevel):actorIntensity;
 if(!Number.isInteger(intensity)||intensity<0||intensity>6||!isCapabilityUnlockedR53(intensity,level))return false;
 return graph.edges.some(e=>e.volitionEntityId===volitionEntityId&&e.type===type&&(!scope||e.scope===scope||e.scope==='UNIVERSAL'||e.scope==='SYSTEMIC'));
}

export function validateWillMysticGraphR56(graph){validateGraph(graph);return true;}

function validateGraph(graph){
 if(graph?.schema!==GENESIS_WILL_MYSTIC_R56_SCHEMA)throw new Error('GEN_R56_GRAPH_INVALID');
 assertIntensity(graph.mysticPowerLevel);assertIntensity(graph.willPowerLevel);
 if(!Array.isArray(graph.entities)||!Array.isArray(graph.edges))throw new Error('GEN_R56_GRAPH_INVALID');
}
