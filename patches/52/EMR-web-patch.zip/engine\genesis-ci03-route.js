import {createGenesisTable} from './genesis-table.js';
// GEN-ROUTE-01 — transition from CI-03 into the physical Genesis session.
// This adapter owns no causal resolution; it only translates the existing CI-03 result
// into the canonical Genesis player experience and campaign persistence.
import {compilePrimordialConfig,ensureBootState,setBootPhase} from './boot.js';
import {createGenesisPlayerSession} from './genesis-player-experience.js';
import {attachGenesisSession} from './genesis-persistence.js';

const KIND_BY_OPTION={1:'PHYSICS',2:'MYSTIC',3:'WILL'};
const DEFAULT_POSITIONS=[{q:-1,r:0},{q:0,r:-1},{q:1,r:-1},{q:0,r:1}];

function choicesForPlayers(result,count){
 const raw=Array.isArray(result?.choices)?result.choices:[result?.winner??result?.chosen];
 const fallback=raw[0]??1;
 return Array.from({length:count},(_,i)=>KIND_BY_OPTION[raw[i]??fallback]??'PHYSICS');
}
function genesisSignature(result){
 const s=result?.signature??{};
 return {PHYSICS:Number(s[1]??0),MYSTIC:Number(s[2]??0),WILL:Number(s[3]??0)};
}
export function beginGenesisFromCi03(state,result,{convergenceBudget=3}={}){
 if(!state?.session?.players?.length)throw new Error('GEN_ROUTE_PLAYERS_REQUIRED');
 const count=state.session.players.length;
 const primordialChoices=choicesForPlayers(result,count);
 const table=createGenesisTable(primordialChoices,state.meta?.seed,state.session.players.map(p=>p.name));
 const signature=table.signature;
 state.session.genesisTable=table;
 const pawns=state.session.players.map((_,i)=>({position:{...DEFAULT_POSITIONS[i]}}));
 const gravity={agency:{q:0,r:0},decisionBudget:4,masses:[
  {id:'CORE',q:-2,r:0},{id:'FRAG',q:1,r:0},{id:'ARC',q:0,r:-2}
 ]};
 const session=createGenesisPlayerSession({signature,primordialChoices,pawns,gravity,convergenceBudget});
 const boot=ensureBootState(state);
 boot.primordialConfig=compilePrimordialConfig({...result,signature:{1:signature.PHYSICS,2:signature.MYSTIC,3:signature.WILL}});
 boot.ci03Result=structuredClone(result);
 attachGenesisSession(state,session);
 setBootPhase(state,'GENESIS_ACTIVE');
 state.eventLog??=[];
 state.eventLog.push({type:'CI03_TO_PHYSICAL_GENESIS',gameTime:state.meta?.gameTime??0,playerCount:count,signature});
 return session;
}

