import {prepareNarrationText,chunkNarrationText} from './narrator-text.js';

export const NARRATOR_TTS_CONFIG=Object.freeze({engine:'kokoro-sherpa-onnx',engineVersion:'1.13.8',voice:'em_santa',speakerId:53,language:'es-ES',speed:0.8});

const PREF_KEY='emr.narrator.preferences.v1';
const QA_KEY='emr.narrator.qa.v1';
const DEFAULT_PREFS=Object.freeze({enabled:true,speed:NARRATOR_TTS_CONFIG.speed});

function clampSpeed(value){const n=Number(value);return Number.isFinite(n)?Math.min(1.2,Math.max(0.65,n)):NARRATOR_TTS_CONFIG.speed;}
export function loadNarratorPreferences(){try{const saved=JSON.parse(localStorage.getItem(PREF_KEY)||'{}');return {...DEFAULT_PREFS,...saved,speed:clampSpeed(saved.speed)}}catch{return {...DEFAULT_PREFS}}}
export function saveNarratorPreferences(next){const prefs={enabled:next.enabled!==false,speed:clampSpeed(next.speed)};localStorage.setItem(PREF_KEY,JSON.stringify(prefs));return prefs;}

function qa(event,detail={}){try{const rows=JSON.parse(localStorage.getItem(QA_KEY)||'[]');rows.push({event,at:new Date().toISOString(),...detail});localStorage.setItem(QA_KEY,JSON.stringify(rows.slice(-240)));}catch{} }
function emit(name,detail={}){window.dispatchEvent(new CustomEvent(name,{detail}));}
function nativePlugin(){return globalThis.Capacitor?.Plugins?.Narrator||null;}

class NarratorService{
  constructor(){
    this.state='idle';this.token=0;this.prefs=loadNarratorPreferences();this.currentId=null;this.initialized=false;this.initPromise=null;this.preparePromise=null;this.resumeSnapshot=null;this.currentChunks=[];this.currentIndex=0;
    window.addEventListener('pagehide',()=>this.stop('pagehide'));
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')this.stop('hidden');});
    const startPrewarm=()=>{if(this.isAvailable())this.init().catch(()=>{});};
    if(document.readyState==='loading')window.addEventListener('DOMContentLoaded',()=>setTimeout(startPrewarm,120),{once:true});else setTimeout(startPrewarm,120);
  }
  isAvailable(){return Boolean(nativePlugin());}
  isPlaying(){return this.state==='playing'||this.state==='loading';}
  getPreferences(){return {...this.prefs};}
  getResumeSnapshot(){return this.resumeSnapshot?{...this.resumeSnapshot,chunks:[...this.resumeSnapshot.chunks]}:null;}
  setEnabled(enabled){this.prefs=saveNarratorPreferences({...this.prefs,enabled});if(!this.prefs.enabled)this.stop('disabled',{preserveResume:true});emit('emr:narration-preference',{enabled:this.prefs.enabled});return this.getPreferences();}
  toggleEnabled(){return this.setEnabled(!this.prefs.enabled);}
  setSpeed(speed){this.prefs=saveNarratorPreferences({...this.prefs,speed});return this.getPreferences();}
  async prepare(){
    if(this.preparePromise)return this.preparePromise;
    const plugin=nativePlugin();if(!plugin?.prepare)return false;
    const started=performance.now();qa('TTS_PREPARE_START');
    this.preparePromise=plugin.prepare().then(result=>{qa('TTS_PREPARE_READY',{elapsedMs:Math.round(performance.now()-started),native:result||null});emit('emr:narration-prepared',result||{});return true;}).catch(error=>{qa('TTS_PREPARE_ERROR',{message:String(error?.message||error)});this.preparePromise=null;throw error;});
    return this.preparePromise;
  }
  async init(){
    if(this.initialized)return true;
    if(this.initPromise)return this.initPromise;
    const plugin=nativePlugin();
    if(!plugin){qa('TTS_ERROR',{code:'NATIVE_PLUGIN_UNAVAILABLE'});return false;}
    const started=performance.now();
    qa('TTS_INIT',{engine:NARRATOR_TTS_CONFIG.engine,engineVersion:NARRATOR_TTS_CONFIG.engineVersion,voice:NARRATOR_TTS_CONFIG.voice,speakerId:NARRATOR_TTS_CONFIG.speakerId});
    this.initPromise=(async()=>{
      try{
        await this.prepare().catch(()=>false);
        const result=await plugin.initialize({voice:NARRATOR_TTS_CONFIG.voice,speakerId:NARRATOR_TTS_CONFIG.speakerId,language:NARRATOR_TTS_CONFIG.language});
        this.initialized=true;
        qa('TTS_INIT_READY',{elapsedMs:Math.round(performance.now()-started),native:result||null});
        return true;
      }finally{if(!this.initialized)this.initPromise=null;}
    })();
    return this.initPromise;
  }
  warmEngine(){if(!this.initialized&&!this.initPromise)this.init().catch(()=>{});}
  async speak(text,{id='narrative',startIndex=0,chunksOverride=null}={}){
    if(!this.prefs.enabled)return false;
    const prepared=prepareNarrationText(text);if(!prepared&&!chunksOverride)return false;
    await this.stop('replace');
    const myToken=++this.token;this.currentId=id;this.state='loading';emit('emr:narration-loading',{id});
    qa('TTS_PIPELINE_START',{id,startIndex});
    try{
      if(!await this.init())throw new Error('KOKORO_NATIVE_UNAVAILABLE');
      const chunks=chunksOverride||chunkNarrationText(prepared);if(!chunks.length)return false;
      this.currentChunks=chunks;this.currentIndex=Math.max(0,Math.min(startIndex,chunks.length-1));
      this.resumeSnapshot={id,text:prepared||chunks.join(' '),chunks:[...chunks],index:this.currentIndex};
      this.state='playing';qa('TTS_PLAY',{id,chunks:chunks.length,startIndex:this.currentIndex,speed:this.prefs.speed,mode:'sentence-prefetch'});emit('emr:narration-start',{id});
      for(let i=this.currentIndex;i<chunks.length;i++){
        if(myToken!==this.token)return false;
        this.currentIndex=i;this.resumeSnapshot={id,text:prepared||chunks.join(' '),chunks:[...chunks],index:i};
        const started=performance.now();
        const result=await nativePlugin().speak({text:chunks[i],speakerId:NARRATOR_TTS_CONFIG.speakerId,speed:this.prefs.speed,language:NARRATOR_TTS_CONFIG.language,sequence:i,total:chunks.length});
        qa('TTS_SENTENCE_QUEUED',{id,sequence:i,synthesisMs:Math.round(performance.now()-started),chars:chunks[i].length,native:result||null});
      }
      if(myToken!==this.token)return false;
      const drainStarted=performance.now();
      const drained=await nativePlugin().drain?.();
      qa('TTS_DRAIN',{id,elapsedMs:Math.round(performance.now()-drainStarted),native:drained||null});
      if(myToken!==this.token)return false;
      this.state='idle';this.currentId=null;this.currentChunks=[];this.currentIndex=0;this.resumeSnapshot=null;emit('emr:narration-end',{id});return true;
    }catch(error){
      if(myToken===this.token){this.state='idle';this.currentId=null;qa('TTS_ERROR',{id,message:String(error?.message||error)});emit('emr:narration-error',{id,message:'No se ha podido reproducir la narración.'});}
      return false;
    }
  }
  resume(){
    if(!this.prefs.enabled||!this.resumeSnapshot)return false;
    const snap=this.getResumeSnapshot();
    this.speak(snap.text,{id:snap.id,startIndex:snap.index,chunksOverride:snap.chunks});
    qa('TTS_RESUME',{id:snap.id,index:snap.index});return true;
  }
  async stop(reason='user',{preserveResume=false}={}){
    if(preserveResume&&this.currentId&&this.currentChunks.length){this.resumeSnapshot={id:this.currentId,text:this.currentChunks.join(' '),chunks:[...this.currentChunks],index:this.currentIndex};}
    else if(reason!=='replace')this.resumeSnapshot=null;
    this.token++;const had=this.isPlaying()||this.currentId!=null;const id=this.currentId;this.state='idle';this.currentId=null;this.currentChunks=[];this.currentIndex=0;
    try{await nativePlugin()?.stop?.();}catch{}
    if(had){qa('TTS_STOP',{id,reason,preserveResume});emit('emr:narration-stop',{id,reason});}
    return true;
  }
}

export const narratorService=new NarratorService();
globalThis.EMRNarrator=narratorService;
