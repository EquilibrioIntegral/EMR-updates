import { configurePlayers } from './hybrid-loop.js';

export function playerNameKey(value='') {
  return String(value)
    .trim()
    .replace(/\s+/g,' ')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .toLocaleLowerCase('es');
}

export function validateUniquePlayerNames(players=[]) {
  if (!Array.isArray(players)) throw new Error('PLAYER_NAMES_INVALID');
  const seen=new Set();
  for (const player of players) {
    const raw=typeof player==='object' ? player?.name : player;
    const key=playerNameKey(raw);
    if (!key) throw new Error('PLAYER_NAME_EMPTY');
    if (seen.has(key)) throw new Error('PLAYER_NAME_DUPLICATE');
    seen.add(key);
  }
  return true;
}

export function configureUniquePlayers(engine, players=[]) {
  validateUniquePlayerNames(players);
  return configurePlayers(engine, players);
}
