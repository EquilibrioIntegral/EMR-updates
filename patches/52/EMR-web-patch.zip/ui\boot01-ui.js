import { createBoot01PlayerExperience,getBoot01PlayerView,submitBoot01SecretIntention,revealBoot01Intentions,resolveBoot01PlayerIntentions,resolveBoot01SoloIntention,formBoot01World,nameBoot01Feature,finishBoot01PlayerExperience } from '../engine/boot01-player-experience.js';
import { ensureBootState } from '../engine/boot.js';

const intention=[[1,'Extender','Favorecer continuidad y alcance.'],[2,'Quebrar','Favorecer separación y barreras.'],[3,'Entrelazar','Favorecer conexiones complejas.']];
const diceOptions=()=>[1,2,3,4,5,6].map(x=>`<option value="${x}">${x}</option>`).join('');

export function renderBoot01Ui({state,host,persist,rerender}){
  const b=ensureBootState(state); if(!b.boot01Player) createBoot01PlayerExperience(state);
  const x=b.boot01Player,players=state.session?.players??[],worldName=b.genesisR5?.selectedWorldPublicName??null; host.innerHTML='';
  if(b.phase==='BOOT01_INTENTION'){
    if(players.length===1){
      const name=players[0]?.name??'Jugador 1';
      host.innerHTML=`<p class="preshow-progress">BOOT-01 · FORMACIÓN DEL MUNDO</p><h2>${worldName?`${worldName}: `:''}${name}, ¿qué quieres favorecer?</h2><p>${x.visible.at(0)??'La materia del mundo debe tomar forma.'}</p><p>Elige directamente una Intención. En solitario no necesitas ocultar una carta, pasar el dispositivo ni revelar una elección que solo tú has hecho.</p><div class="choices">${intention.map(([id,label,desc])=>`<button data-b01-solo-intent="${id}"><strong>${label}</strong><br><span>${desc}</span></button>`).join('')}</div>`;
      host.querySelectorAll('[data-b01-solo-intent]').forEach(btn=>btn.onclick=()=>{resolveBoot01SoloIntention(state,Number(btn.dataset.b01SoloIntent));persist();rerender();});return;
    }
    if(!x.revealed){
      const i=x.entry??0;
      if(i<players.length){const name=players[i]?.name??`Jugador ${i+1}`;host.innerHTML=`<p class="preshow-progress">BOOT-01 · FORMACIÓN DEL MUNDO</p><h2>${name}: elige en secreto</h2><p>${i===0?(x.visible.at(0)??''):''}</p><p>Escoge una Intención y pasa el dispositivo. No enseñes tu elección. La carta física puede permanecer boca abajo sobre la mesa.</p><div class="choices">${intention.map(([id,label,desc])=>`<button data-b01-intent="${id}"><strong>${label}</strong><br><span>${desc}</span></button>`).join('')}</div>`;host.querySelectorAll('[data-b01-intent]').forEach(btn=>btn.onclick=()=>{submitBoot01SecretIntention(state,i,Number(btn.dataset.b01Intent));persist();rerender();});return;}
      host.innerHTML=`<p class="preshow-progress">BOOT-01 · FORMACIÓN DEL MUNDO</p><h2>Todas las Intenciones están sobre la mesa</h2><p>Revelad ahora las cartas físicas a la vez.</p><button id="b01-reveal">Revelar Intenciones →</button>`;host.querySelector('#b01-reveal').onclick=()=>{revealBoot01Intentions(state);persist();rerender();};return;
    }
    const vals=Object.values(x.secretIntentions),needDie=new Set(vals).size>1;
    host.innerHTML=`<p class="preshow-progress">BOOT-01 · FORMACIÓN DEL MUNDO</p><h2>Las Intenciones se encuentran</h2><p>${x.revealed.map(r=>`${r.player}: <strong>${r.intention}</strong>`).join(' · ')}</p>${needDie?`<p>Hay impulsos incompatibles. Lanza <strong>1d6 físico</strong> y comunica únicamente el resultado.</p><label>Resultado <select id="b01-conflict-die">${diceOptions()}</select></label>`:'<p>Todos empujáis la formación en la misma dirección. No hace falta tirar.</p>'}<button id="b01-resolve">Resolver la formación →</button>`;
    host.querySelector('#b01-resolve').onclick=()=>{resolveBoot01PlayerIntentions(state,needDie?Number(host.querySelector('#b01-conflict-die').value):null);persist();rerender();};return;
  }
  if(b.phase==='BOOT01_WORLDGEN'){
    host.innerHTML=`<p class="preshow-progress">BOOT-01 · LA MATERIA TOMA FORMA</p><h2>${worldName?`${worldName} aún no tiene geografía`:'El mundo aún no tiene geografía'}</h2><p>Lanza <strong>7d6 físicos</strong>. La app cruzará el resultado con el Legado Primordial y las Intenciones. No tienes que consultar ninguna tabla.</p><div class="boot-dice">${Array.from({length:7},(_,i)=>`<label>Dado ${i+1}<select data-b01-world-die>${diceOptions()}</select></label>`).join('')}</div><button id="b01-form">Formar el mundo →</button>`;
    host.querySelector('#b01-form').onclick=()=>{const dice=[...host.querySelectorAll('[data-b01-world-die]')].map(e=>Number(e.value));formBoot01World(state,dice);persist();rerender();};return;
  }
  if(b.phase==='BOOT01_FEATURE_NAMING'){
    const view=getBoot01PlayerView(state),plan=x.physical??[];
    host.innerHTML=`<p class="preshow-progress">BOOT-01 · MATERIALIZA EL MUNDO</p><h2>La primera geografía</h2><p>${view.narrative.at(-1)??''}</p><ol>${plan.map(p=>`<li>${p}</li>`).join('')}</ol><p><strong>Hazlo ahora sobre la mesa.</strong> Cuando la forma física coincida con estas instrucciones, nombra un rasgo público que haya surgido de ella. Ese nombre será también la confirmación de que la geografía ya está materializada; no habrá un clic administrativo adicional.</p><p>No estás nombrando todavía pueblos ni culturas.</p><label>Tipo <select id="b01-feature-type"><option>CORDILLERA</option><option>GRAN_RIO</option><option>MAR_INTERIOR</option><option>ARCHIPIELAGO</option><option>LLANURA</option></select></label><label>Zona <select id="b01-feature-scope"><option>NORTE</option><option>SUR</option><option>ESTE</option><option>OESTE</option><option>CENTRO</option></select></label><label>Nombre <input id="b01-feature-name" maxlength="60" placeholder="Nombre del rasgo"></label><p id="b01-feature-error" class="form-error"></p><button id="b01-name">Ya está en mesa · inscribir en el mundo →</button>`;
    host.querySelector('#b01-name').onclick=()=>{const name=host.querySelector('#b01-feature-name').value.trim();if(!name){host.querySelector('#b01-feature-error').textContent='Pon un nombre para continuar.';return;}nameBoot01Feature(state,{refId:'MACRO-BOOT01-01',featureType:host.querySelector('#b01-feature-type').value,scope:host.querySelector('#b01-feature-scope').value,displayName:name});persist();rerender();};return;
  }
  if(b.phase==='BOOT01_CLOSED'){
    host.innerHTML=`<p class="preshow-progress">BOOT-01 · CIERRE</p><h2>${b.boot01.worldFact.DISPLAY_NAME} ya existe</h2><p>${x.narrative.at(-1)}</p><p>La geografía ya está materializada y sincronizada con la app. Su forma, su nombre público y la causa de su nacimiento quedan guardados; no hace falta conservar marcadores administrativos.</p><button id="b01-finish">Continuar hacia la aparición de la vida →</button>`;host.querySelector('#b01-finish').onclick=()=>{finishBoot01PlayerExperience(state);persist();rerender();};return;
  }
  throw new Error(`BOOT01_UI_PHASE_UNSUPPORTED:${b.phase}`);
}