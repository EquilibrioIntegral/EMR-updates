// R5.27 / P12 — Canonical seed ledger over already-established Genesis ontology.
// This module DOES NOT invent metaphysical truth. It normalizes existing truth,
// relations, law origins, mystic rules and self-limits so later BOOTs/runtime can
// consume them with stable provenance and strict player-knowledge separation.

export const GENESIS_ONTOLOGY_SEEDS_R527_SCHEMA='EMR_GENESIS_ONTOLOGY_SEEDS_R527_v1';
export const GENESIS_ONTOLOGY_SEEDS_R527_DECISION='D-GEN-R5.27-ONTOLOGY-SEEDS01';

const clone=x=>structuredClone(x);
const uniq=xs=>[...new Set((xs||[]).filter(Boolean).map(String))];
const DEFAULT_CONSUMERS=Object.freeze(['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME']);

export function compileGenesisOntologySeedsR527(source={}){
 const ontology=source?.runtime?.ontology||source?.ontology||source;
 if(!ontology||typeof ontology!=='object')throw new Error('GEN_R527_ONTOLOGY_REQUIRED');
 const seeds=[];
 const add=row=>{
  const normalized=normalizeSeed(row);
  if(!seeds.some(x=>x.seedId===normalized.seedId))seeds.push(normalized);
 };

 // R5.12 objective invisible-world truth already carries explicit facts/hooks.
 for(const fact of ontology.objectiveSupernaturalFacts||[]){
  if(fact?.type!=='INVISIBLE_WORLD_PRIMITIVE_ESTABLISHED'||!fact.factId)continue;
  const hook=(ontology.futureHooks||[]).find(h=>h?.sourceFactId===fact.factId);
  add({seedId:`SEED:${fact.factId}`,category:'INVISIBLE_WORLD',truthRef:fact.factId,kind:fact.primitive||fact.type,mode:fact.mode||null,status:'ESTABLISHED',producerEntityIds:[fact.producerEntityId],playerCauseIds:[fact.playerId],provenance:{sourceType:'OBJECTIVE_SUPERNATURAL_FACT',sourceId:fact.factId,round:fact.round??null,decisionId:fact.decisionId||'D-GEN-R5.12-INVISIBLE-WORLD01'},consumers:hook?.consumers||DEFAULT_CONSUMERS,visibility:fact.visibility||'ENGINE_ONLY'});
 }

 // R5.7 relations between Volitions: preserve exact edge provenance and consumers.
 for(const edge of ontology.volitionRelationGraph?.edges||[]){
  if(edge?.state&&edge.state!=='ACTIVE')continue;
  add({seedId:`SEED:VOLITION_RELATION:${edge.relationId||edge.id}`,category:'VOLITION_RELATION',truthRef:edge.relationId||edge.id,kind:edge.type,mode:edge.symmetry||null,status:edge.state||'ACTIVE',producerEntityIds:edge.producerIds||[],provenance:{sourceType:'VOLITION_RELATION_EDGE',sourceId:edge.relationId||edge.id,createdAt:edge.createdAt??null,detail:clone(edge.provenance),decisionId:ontology.volitionRelationGraph?.decisionId||'D-GEN-R5.7-VOLITION-RELATIONS01'},consumers:edge.futureConsumers?.length?edge.futureConsumers:['FUTURE_BOOTS','RUNTIME','GUIONISTA'],visibility:edge.visibility||'ENGINE_ONLY'});
 }

 // R5.6 Will↔Mystic relations are already causal edges; normalize, don't reinterpret.
 for(const edge of ontology.willMysticGraph?.edges||[]){
  add({seedId:`SEED:WILL_MYSTIC:${edge.id}`,category:'WILL_MYSTIC_RELATION',truthRef:edge.id,kind:edge.type,mode:edge.scope||null,status:'ACTIVE',producerEntityIds:[edge.producerId],provenance:{sourceType:'WILL_MYSTIC_EDGE',sourceId:edge.id,createdAt:edge.createdAt??null,detail:clone(edge.provenance),decisionId:ontology.willMysticGraph?.decisionId||'D-GEN-R5.6-WILL-MYSTIC-RELATION01'},consumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME','GUIONISTA'],visibility:'ENGINE_ONLY'});
 }

 // Existing law authority establishes origin/provenance of physical regularities.
 const law=ontology.lawAuthority;
 if(law?.originOfPhysicalRegularities||law?.originMode){
  add({seedId:'SEED:PHYSICAL_LAW_ORIGIN',category:'PHYSICAL_LAW_ORIGIN',truthRef:law.originOfPhysicalRegularities||law.originMode,kind:law.originOfPhysicalRegularities||'PHYSICAL_REGULARITIES',mode:law.originMode||null,status:'ESTABLISHED',producerEntityIds:law.producerIds||[],provenance:{sourceType:'LAW_AUTHORITY',sourceId:law.originOfPhysicalRegularities||'PHYSICAL_LAW_ORIGIN',decisionId:law.decisionId||null},consumers:['BOOT01','BOOT02','FUTURE_BOOTS','RUNTIME','WORLD_MEMORY'],visibility:'ENGINE_ONLY'});
 }

 // Mystic substrate rules are existing objective rules, if any have been played.
 for(const [i,rule] of (ontology.mysticSubstrate?.rules||[]).entries()){
  const id=rule?.id||rule?.ruleId||`R${i+1}`;
  add({seedId:`SEED:MYSTIC_RULE:${id}`,category:'MYSTIC_RULE',truthRef:id,kind:rule?.type||rule?.kind||'MYSTIC_RULE',mode:rule?.mode||null,status:rule?.status||'ESTABLISHED',producerEntityIds:rule?.producerIds||[rule?.producerId],provenance:{sourceType:'MYSTIC_SUBSTRATE_RULE',sourceId:id,detail:clone(rule?.provenance||null),decisionId:rule?.decisionId||null},consumers:rule?.futureConsumers?.length?rule.futureConsumers:['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME'],visibility:rule?.visibility||'ENGINE_ONLY'});
 }

 // Existing divine/self-imposed exceptions and limits become future causal constraints.
 for(const [i,limit] of (law?.exceptionsAndSelfLimits||[]).entries()){
  const id=limit?.id||limit?.limitId||`L${i+1}`;
  add({seedId:`SEED:AUTOLIMIT:${id}`,category:'AUTOLIMIT_OR_DECREE',truthRef:id,kind:limit?.type||limit?.kind||'AUTOLIMIT',mode:limit?.mode||null,status:limit?.status||'ACTIVE',producerEntityIds:limit?.producerIds||[limit?.producerEntityId,limit?.producerId],provenance:{sourceType:'LAW_EXCEPTION_OR_SELF_LIMIT',sourceId:id,detail:clone(limit?.provenance||null),decisionId:limit?.decisionId||null},consumers:limit?.futureConsumers?.length?limit.futureConsumers:['FUTURE_BOOTS','RUNTIME','GUIONISTA'],visibility:limit?.visibility||'ENGINE_ONLY'});
 }

 seeds.sort((a,b)=>a.category.localeCompare(b.category)||a.seedId.localeCompare(b.seedId));
 return{schema:GENESIS_ONTOLOGY_SEEDS_R527_SCHEMA,decisionId:GENESIS_ONTOLOGY_SEEDS_R527_DECISION,authority:'DERIVED_INDEX_OVER_EXISTING_ONTOLOGY',createsNewWorldTruth:false,visibility:'ENGINE_ONLY',seeds,knowledgeContract:{worldTruthSeparateFromCulture:true,noAutomaticDisclosure:true,culturalDoctrineCreated:false,religionCreated:false,sinAsSocialConceptCreated:false}};
}

export function validateGenesisOntologySeedsR527(ledger){
 if(ledger?.schema!==GENESIS_ONTOLOGY_SEEDS_R527_SCHEMA||!Array.isArray(ledger.seeds))return{ok:false,reason:'GEN_R527_LEDGER_INVALID'};
 const ids=new Set();
 for(const seed of ledger.seeds){
  if(!seed?.seedId||ids.has(seed.seedId))return{ok:false,reason:'GEN_R527_SEED_ID_INVALID'};
  ids.add(seed.seedId);
  if(!seed.category||!seed.truthRef)return{ok:false,reason:'GEN_R527_TRUTH_REF_REQUIRED',seedId:seed.seedId};
  if(!seed.provenance?.sourceType||!seed.provenance?.sourceId)return{ok:false,reason:'GEN_R527_PROVENANCE_REQUIRED',seedId:seed.seedId};
  if(!Array.isArray(seed.consumers)||seed.consumers.length===0)return{ok:false,reason:'GEN_R527_CONSUMER_REQUIRED',seedId:seed.seedId};
  if(seed.visibility!=='ENGINE_ONLY'&&seed.visibility!=='HIDDEN'&&seed.visibility!=='PRIVATE')return{ok:false,reason:'GEN_R527_VISIBILITY_LEAK',seedId:seed.seedId};
 }
 return{ok:true,count:ledger.seeds.length};
}

export function playerSafeOntologySeedsR527(ledger){
 const check=validateGenesisOntologySeedsR527(ledger);if(!check.ok)throw new Error(check.reason);
 return{schema:ledger.schema,decisionId:ledger.decisionId,seedCount:ledger.seeds.length,worldTruthDisclosed:false};
}

function normalizeSeed(row){
 return{seedId:String(row.seedId),category:String(row.category),truthRef:String(row.truthRef),kind:String(row.kind||row.category),mode:row.mode??null,status:String(row.status||'ESTABLISHED'),producerEntityIds:uniq(row.producerEntityIds),playerCauseIds:uniq(row.playerCauseIds),provenance:clone(row.provenance),consumers:uniq(row.consumers?.length?row.consumers:DEFAULT_CONSUMERS),visibility:['HIDDEN','PRIVATE'].includes(row.visibility)?row.visibility:'ENGINE_ONLY'};
}
