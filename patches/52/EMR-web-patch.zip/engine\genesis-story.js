import {hexDistance} from './primordial-gravity.js';
import {BODY_LABELS} from '../data/genesis-director.js';
const label=id=>BODY_LABELS[id]||'la formación';
const stableId=value=>String(value?.id??value?.sourceId??value?.name??'');
const compareStableId=(a,b)=>stableId(a).localeCompare(stableId(b));
export function seedHash(x){let h=2166136261;for(const c of String(x))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;}
const source='1-Mh9js18zS1VAa0X_pNDMbR4QX4RSBexiHKHGoPBiuE:Voluntad_anchor_V_S01_R1';
// Generic agencies from the recovered V-S01/V-S02 motifs. No named pantheon,
// religion or later civilisation is invented. Referents are existing bodies.
export function initializeGenesisStory(s){
 const bodies=Object.keys(s.gravity.masses),target=bodies[seedHash(s.seed)%bodies.length];
 s.story={schema:'GEN-STORY-1',agents:[],threads:[],secrets:[],events:[],reveals:[],relations:[],sequence:0};
 if(s.signature.WILL>0){
  s.story.agents=[{id:'V-S01',label:'la presencia que preserva',goal:'PRESERVE',anchor:target,authority:source,attitude:0},{id:'V-S02',label:'la conciencia que reúne',goal:'REUNITE',anchor:target,authority:source,attitude:0}];
  s.story.threads.push({id:'GS-T1',kind:'CONFLICT',anchors:[target],actors:['V-S01','V-S02'],pressure:1,status:'OPEN',origin:source,lastEvent:null});
  s.story.relations.push({source:'V-S01',target:'V-S02',kind:'OPPOSED_PURPOSES',origin:source});
  // Hidden priority is fixed now, not fabricated when revealed. Its discovery
  // requires an actual intervention on its referent; it changes later focus.
  s.story.secrets.push({id:'GS-S1',actor:'V-S02',target,kind:'PRIORITY_ANCHOR',known:false,origin:source,implementationStatus:'CANDIDATE_DERIVED_FROM_MOTIF',trigger:'NON_WAIT_ACTION_ON_ANCHOR'});
 }
 return s.story;
}
export function activeStoryThread(s){return s.story?.threads.filter(t=>t.status==='OPEN'||t.status==='ESCALATING').sort((a,b)=>b.pressure-a.pressure||String(a.id??'').localeCompare(String(b.id??'')))[0]||null;}
export function observeGenesisAction(s,action,memoryId,physicalBefore=null){
 const g=s.story;if(!g)return;const targets=[action.target,action.other].filter(Boolean);g.sequence++;
 const event={id:`GS-E${g.sequence}`,memoryRef:memoryId,action:action.action,targets,round:s.round};g.events.push(event);
 if(action.action==='WAIT'){
  for(const t of g.threads)if(t.status!=='CLOSED'&&t.anchors.some(a=>targets.includes(a)))t.status='LATENT';
  return; // omission is not an adverse event and never manufactures pressure.
 }
 // Only an actual subsequent event on an anchor matures a conditioned Promise.
 for(const p of s.promises)if(p.status==='LATENT'&&p.origin!==memoryId&&p.anchors?.some(a=>targets.includes(a))){p.status='MATURE';p.triggerEvent=event.id;}
 for(const t of g.threads)if(t.status==='LATENT'&&t.anchors.some(a=>targets.includes(a)))t.status='OPEN';
 for(const secret of g.secrets)if(!secret.known&&targets.includes(secret.target)){
  secret.known=true;secret.revealedBy=event.id;g.reveals.push({secretId:secret.id,eventId:event.id,round:s.round});
  const a=g.agents.find(a=>a.id===secret.actor);a.revealedPriority=secret.target;
 }
 // Observe the actual displacement rather than treating every IMPULSE as
 // separation. Keep the same physical reference on both sides of the event.
 const effects=[];
 for(const agent of g.agents){
  const direct=targets.includes(agent.anchor);
  if(!direct&&!(action.action==='IMPULSE'&&physicalBefore?.[agent.anchor]&&physicalBefore?.[action.target]))continue;
  let direction=0;
  if(action.action==='IMPULSE'&&physicalBefore?.[agent.anchor]){
   const anchor=physicalBefore[agent.anchor];
   const other=action.target!==agent.anchor?physicalBefore[action.target]:Object.values(physicalBefore).filter(m=>m.id!==agent.anchor).sort((a,b)=>hexDistance(anchor,a)-hexDistance(anchor,b)||compareStableId(a,b))[0];
   if(other&&s.gravity.masses[other.id]){
    const before=hexDistance(anchor,other),after=hexDistance(s.gravity.masses[agent.anchor],s.gravity.masses[other.id]);
    direction=Math.sign(before-after);
    event.displacement={anchor:agent.anchor,reference:other.id,before,after};
   }
  }
  const advances=agent.goal==='PRESERVE'?action.action==='PRESERVE':['COHERE','ATTRACT'].includes(action.action)||direction>0;
  const opposes=agent.goal==='PRESERVE'?action.action==='COHERE':action.action==='PRESERVE'||direction<0;
  const delta=advances?1:opposes?-1:0;
  if(delta)agent.attitude+=delta;
  effects.push({actorId:agent.id,delta});
 }
 event.goalEffects=effects;
 // A shared thread processes each cause once, irrespective of actor count.
 for(const t of [...g.threads]){
  if(t.status==='CLOSED'||(!t.anchors.some(a=>targets.includes(a))&&!effects.some(e=>e.delta&&t.actors.includes(e.actorId))))continue;
  const affected=effects.filter(e=>t.actors.includes(e.actorId));
  if(action.action==='COHERE'){
   t.status='CLOSED';t.closure={cause:memoryId,reason:'BODY_INDIVIDUALITY_TRANSFORMED'};
   if(Object.keys(s.gravity.masses).length>1&&!g.threads.some(x=>x.origin===memoryId))g.threads.push({id:`GS-T${g.threads.length+1}`,kind:'AFTERMATH',anchors:[action.target],actors:[...t.actors],pressure:1,status:'OPEN',origin:memoryId,lastEvent:event.id});
  }else if(affected.some(e=>e.delta<0)){
   t.pressure=Math.min(3,t.pressure+1);t.status=t.pressure===3?'ESCALATING':'OPEN';t.lastEvent=event.id;
  }else if(action.action==='LINK'){
   t.pressure=Math.max(1,t.pressure-1);t.lastEvent=event.id;
  }else if(affected.some(e=>e.delta>0))t.lastEvent=event.id;
 }
 // These are the recovered impersonal bond/asymmetry motifs, instantiated over
 // actual bodies. No Promise is created for an unrelated administrative action.
 if(['LINK','IMPRINT','PRESERVE','COHERE'].includes(action.action)){
  s.promises.push({id:`GP${s.promises.length+1}`,origin:memoryId,anchors:targets,target:action.target,status:'LATENT',trigger:'LATER_NON_WAIT_EVENT_ON_ANCHOR',transforms:['CALLBACK','COMPLICATION','REVELATION','CLOSURE'],kind:action.action,consumer:'GENESIS_FOCUS_AND_RELATION'});
 }
}
export function retargetStory(s,consumed,kept){
 const g=s.story;if(!g)return;
 for(const a of g.agents)if(a.anchor===consumed){a.originalAnchor??=consumed;a.anchor=kept;}
 for(const t of g.threads)t.anchors=t.anchors.map(x=>x===consumed?kept:x);
 for(const p of s.promises){p.anchors=p.anchors?.map(x=>x===consumed?kept:x);if(p.target===consumed)p.target=kept;}
 for(const secret of g.secrets)if(secret.target===consumed){secret.originalTarget??=consumed;secret.target=kept;}
}
export function storySituation(s){
 const g=s.story;if(!g?.agents.length)return null;
 const t=activeStoryThread(s);if(!t)return null;
 const body=t.anchors.find(id=>s.gravity.masses[id])||Object.keys(s.gravity.masses)[0];
 const recentReveal=g.reveals.find(r=>!r.consumed&&g.secrets.some(secret=>secret.id===r.secretId&&secret.known&&t.anchors.includes(secret.target)));
 let title,text,kind='CONFLICT';
 if(recentReveal){
  const secret=g.secrets.find(x=>x.id===recentReveal.secretId);
  title='El centro de su deseo';kind='REVELATION';
  text=`La intervención sobre ${label(secret.target)} ha puesto al descubierto lo que la conciencia que reúne no había mostrado: esa formación es el centro de su propósito. La presencia que preserva intenta mantener su independencia. Lo que hagáis con ella afectará ahora a las dos voluntades.`;
  
 }else if(t.kind==='AFTERMATH'){
  title='Lo unido conserva su pasado';kind='AFTERMATH';
  text=`La unión ha cambiado la disputa: ${label(body)} reúne ahora materia que antes existía por separado. La conciencia que reúne ha visto avanzar su propósito; la presencia que preserva no puede recuperar la forma perdida como si nada hubiera ocurrido. Aún podéis mantener el conjunto o cambiar su relación con lo que permanece fuera.`;
 }else{
  title=t.pressure===3?'Dos propósitos ante la misma creación':'Lo que una quiere reunir, otra quiere preservar';
  text=`En la materia naciente han despertado dos voluntades todavía sin nombre. Una intenta preservar lo que empieza a formarse; la otra desea reunir lo separado. La primera quiere preservar ${label(body)}. La segunda aún no ha mostrado qué formación le importa más. Acercar, separar o preservar la materia puede poner sus deseos en conflicto.`;
  if(t.lastEvent){const a=g.agents.find(a=>a.goal==='PRESERVE'),b=g.agents.find(a=>a.goal==='REUNITE');text=`${label(body)} conserva las consecuencias de vuestra intervención. ${a.attitude<0?'La presencia que preserva ha visto contrariarse su propósito.':'La presencia que preserva trata de mantener lo que queda separado.'} ${b.attitude>0?'La conciencia que reúne encuentra ahora más cerca lo que buscaba.':b.attitude<0?'La conciencia que reúne encuentra resistencia a su deseo.':'La conciencia que reúne sigue buscando cómo acercar lo separado.'} Cambiar su posición o su continuidad volverá a afectar a esta disputa.`;}
 }
 return {kind,title,text,focus:body,revealId:recentReveal?.secretId||null,threadId:t.id,causeRefs:[t.origin,t.lastEvent].filter(Boolean),pressure:t.pressure};
}
export function settleStory(s){
 const g=s.story;if(!g)return '';
 const closed=g.threads.filter(t=>t.status==='CLOSED').length,open=g.threads.filter(t=>t.status!=='CLOSED').length;
 if(!g.agents.length)return '';
 return `${closed?'Alguna disputa cambió al cambiar la materia. ':''}${open?'Lo que sigue abierto no se borra: las voluntades y sus diferencias acompañarán al mundo que está por nacer.':'Las tensiones abiertas han encontrado una transformación real.'}`;
}
