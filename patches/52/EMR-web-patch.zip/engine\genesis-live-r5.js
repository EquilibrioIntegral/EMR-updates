// Stable Genesis live facade. R5.10 remains preserved as design capital.
// R5.11 supplies capability-driven individual actions; R5.12 overlays identity-aware
// narrative projection; R5.15 aligns A61 numbering/artwork; R5.16 restores the
// approved R4 contract: physical evolution is always active, individual actions
// advance cosmic time, movement is only meaningful when it changes intervention
// possibilities, and joint resolution precedes autonomous universe evolution.
// R5.17 derives the changing player objective from the real cosmogony and guards
// world selection/handoff without exposing internal PLANET ids to the player.
// R5.25/P10 preserves public declarations separately from private commitments and
// records declaration-vote differences as future-consumable memory.
// R5.30/P15 turns physical deltas into a persistent one-by-one materialization queue
// so the table can be synchronized exactly and a session can resume mid-update.
export * from './genesis-live-r510-legacy.js';
export {createGenesisLiveR5,deserializeGenesisLiveR5,confirmLiveSetupR5,resumePhysicalBaselineR516,normalizePhysicalBaselineR516,meaningfulAgencyMovementR516,liveAgencyOptionsR5,simulatedAgencyDecisionR59,applyLiveAgencyOptionR5,capabilityDebugProjectionR511} from './genesis-live-r516-layer.js';
export {applySharedDecisionResolutionR530 as applySharedDecisionResolutionR58,confirmLiveMaterializationR530 as confirmLiveMaterializationR5,primeMaterializationFlowR530,currentMaterializationStepR530,confirmMaterializationStepR530,GENESIS_MATERIALIZATION_R530} from './genesis-materialization-r530.js';
export {recordRevealedLiveIntentionsR525 as recordRevealedLiveIntentionsR5} from './genesis-intention-memory-r525.js';
export {setupProjectionR5} from './genesis-board-projection-r515.js';
export {genesisProgressionR517,genesisObjectiveR517,livePlanetOptionsR5,chooseLivePlanetR5,closeLiveGenesisR5} from './genesis-live-r517-layer.js';
