// GEN-SAVE-02 — binds the player-facing Genesis session to the canonical campaign save.
// The campaign state owns persistence; Genesis keeps its own validated portable contract.
import {exportGenesisPlayerSession,importGenesisPlayerSession} from './genesis-player-experience.js';

const KEY='genesisPlayerSession';

export function attachGenesisSession(state,session){
  if(!state||typeof state!=='object') throw new Error('GEN_CAMPAIGN_STATE_REQUIRED');
  state.session??={};
  state.session[KEY]=JSON.parse(exportGenesisPlayerSession(session));
  return state.session[KEY];
}

export function hasGenesisSession(state){return Boolean(state?.session?.[KEY]);}

export function restoreGenesisSession(state){
  if(!hasGenesisSession(state)) throw new Error('GEN_CAMPAIGN_SESSION_MISSING');
  return importGenesisPlayerSession(state.session[KEY]);
}

export function replaceGenesisSession(state,session){return attachGenesisSession(state,session);}

export function clearGenesisSession(state){
  if(state?.session) delete state.session[KEY];
}

export function physicalReconstructionBrief(state){
  const session=restoreGenesisSession(state),g=session.bridge.gravity,t=session.bridge.table;
  const masses=Object.values(g.masses||{}).map(m=>({id:m.id,position:{q:m.q,r:m.r}}));
  const pawns=session.bridge.genesis.players.map(p=>({playerId:p.id,position:{...p.position}}));
  return {
    phase:session.phase,
    instruction:'Reconstruid la mesa con estas posiciones antes de continuar. La aplicación conserva en secreto todo lo que aún no debe revelarse.',
    masses,pawns,
    preserved:[...(t?.preserved||[])],
    tokens:structuredClone(t?.tokens||[]),
    links:structuredClone(t?.links||[])
  };
}
