import { resolveBoot01Intentions, compileBoot01Territory, encodeBoot01Entropy, ensureBootState } from './boot.js';
import { projectLegacyToBoot01,getPrimordialLegacyTransforms,getPrimordialLegacyFingerprint } from './primordial-legacy.js';
import {installGenesisWorldgenInheritance} from './genesis-worldgen-contract.js';

export const BOOT01_INTENTIONS={1:'EXTENDER',2:'QUEBRAR',3:'ENTRELAZAR'};
const clone=x=>structuredClone(x);

export function deriveBoot01PrimordialForm(legacy,fallback=null){
  const transforms=getPrimordialLegacyTransforms(legacy);
  const has=transform=>transforms.includes(transform);
  const base={DISTRIBUCION:fallback?.DISTRIBUCION??fallback?.distribution??'DISTRIBUIDA',INTEGRIDAD:fallback?.INTEGRIDAD??fallback?.integrity??'TENSIONADA',DINAMICA:fallback?.DINAMICA??fallback?.dynamics??'MOVIL_CAMBIANTE',DIFERENCIACION:fallback?.DIFERENCIACION??fallback?.differentiation??'HOMOGENEA'};
  if(has('SISTEMA_DISTRIBUIDO')) base.DISTRIBUCION='DISTRIBUIDA';
  if(has('NUCLEO_DOMINANTE')) base.DISTRIBUCION='CONCENTRADA';
  if(has('ORBITAS_ESTABLES')) base.DINAMICA='CICLICA_ORBITAL';
  if(has('FRACTURA_PRIMORDIAL')) base.INTEGRIDAD='FRACTURADA';
  if(has('COHESION_PRIMORDIAL')) base.INTEGRIDAD='COHESIONADA';
  if(has('VINCULO_IMPERSONAL')||has('HUELLA_CONSCIENTE')) base.DIFERENCIACION='ESTRATIFICADA';
  return base;
}

export function beginBoot01(state){
  const b=ensureBootState(state);
  if(!b.legadoPrimordial) throw new Error('BOOT01_LEGADO_PRIMORDIAL_REQUIRED');
  const projection=projectLegacyToBoot01(b.legadoPrimordial); const fingerprint=getPrimordialLegacyFingerprint(b.legadoPrimordial);
  // R3.3 bridge enriches modern Genesis with selected-planet/worldgen evidence while
  // remaining compatible with historical BOOT01 fixtures that predate planet identity.
  // The R3.2 Genesis closure gate itself is responsible for forbidding a new canonical
  // Genesis from closing without a formed/selected planet.
  const inheritance=installGenesisWorldgenInheritance(state,b.legadoPrimordial);
  const selectedPlanetId=inheritance?.selectedPlanet?.id??b.selectedPlanetId??null;
  b.boot01??={}; b.boot01.legacyProjection=clone(projection); b.boot01.legacyConsumed={id:b.legadoPrimordial.id,causalFingerprint:fingerprint}; b.boot01.genesisInheritance=clone(inheritance);
  b.phase='BOOT01_INTENTION'; state.eventLog??=[];
  state.eventLog.push({type:'BOOT01_PRIMORDIAL_LEGACY_CONSUMED',gameTime:state.meta?.gameTime??0,legacyId:b.legadoPrimordial.id,causalFingerprint:fingerprint,selectedPlanetId});
  return {phase:b.phase,physical:{source:'Biblioteca → Intenciones',codes:[1,2,3],faceDown:true,simultaneous:(state.session?.players?.length??1)>1},fiction:'La realidad ya existe. Ahora la materia del mundo debe tomar forma.'};
}

export function commitBoot01Intentions(state,intentions,die=null){
  const b=ensureBootState(state); if(b.phase!=='BOOT01_INTENTION') throw new Error('BOOT01_PHASE_INVALID');
  const resolved=resolveBoot01Intentions(intentions,die); b.boot01??={}; b.boot01.intentResolution=resolved; b.phase='BOOT01_WORLDGEN'; state.eventLog??=[];
  state.eventLog.push({type:'BOOT01_INTENTION_RESOLVED',gameTime:state.meta?.gameTime??0,intentions:resolved.intentions,intent:resolved.label,secondary:resolved.secondary}); return resolved;
}

export function compileBoot01World(state,{primordialForm=null,dice}){
  const b=ensureBootState(state); if(b.phase!=='BOOT01_WORLDGEN') throw new Error('BOOT01_WORLDGEN_PHASE_INVALID');
  if(!b.legadoPrimordial||!b.boot01?.legacyProjection) throw new Error('BOOT01_PRIMORDIAL_LEGACY_REQUIRED');
  if(!Array.isArray(dice)||dice.length!==7) throw new Error('BOOT01_BT_SEVEN_D6_REQUIRED');
  const inherited=b.boot01?.genesisInheritance;
  const causalForm=inherited?.primordialForm??deriveBoot01PrimordialForm(b.legadoPrimordial,primordialForm); const intent=b.boot01?.intentResolution?.label; const fingerprint=getPrimordialLegacyFingerprint(b.legadoPrimordial);
  const compiled=compileBoot01Territory(causalForm,intent,dice); if(!compiled?.ok) throw new Error(`BOOT01_NO_LEGAL_WORLD:${compiled?.reason??'UNKNOWN'}`);
  b.primordialForm=clone(causalForm);
  b.boot01.territory={schemaVersion:'WG-STATE-TERRITORY-0.3',profile:compiled.selected,hardLegalCount:compiled.legalCount,bestSetCount:compiled.bestCount,minCost:compiled.minCost,entropy:encodeBoot01Entropy(dice),dice:[...dice],authorityOrder:['HARD','PRIMORDIAL_LEGACY','INTENTION','RNG'],legacySource:b.legadoPrimordial.id,causalFingerprint:fingerprint,primordialForm:clone(causalForm),selectedPlanetId:inherited?.selectedPlanet?.id??b.selectedPlanetId??null,genesisClimateInputs:clone(inherited?.climateInputs??null)};
  b.phase='BOOT01_FEATURE_NAMING'; state.eventLog.push({type:'BOOT01_TERRITORY_COMPILED',gameTime:state.meta?.gameTime??0,intent,profileId:compiled.selected.id,hardLegalCount:compiled.legalCount,bestSetCount:compiled.bestCount,legacyId:b.legadoPrimordial.id,causalFingerprint:fingerprint,selectedPlanetId:b.boot01.territory.selectedPlanetId}); return b.boot01.territory;
}

export function commitBoot01PublicFeature(state,{refId,featureType,scope,displayName}){
  const b=ensureBootState(state); if(b.phase!=='BOOT01_FEATURE_NAMING') throw new Error('BOOT01_FEATURE_PHASE_INVALID');
  for(const [k,v] of Object.entries({refId,featureType,scope,displayName})) if(!String(v??'').trim()) throw new Error(`BOOT01_FEATURE_${k.toUpperCase()}_REQUIRED`);
  const fact={REF_ID:String(refId),FEATURE_TYPE:String(featureType),SCOPE:String(scope),DISPLAY_NAME:String(displayName).trim(),KNOWLEDGE:'PUBLIC'}; b.boot01.worldFact=fact; b.boot01.geoObligation={REF_ID:fact.REF_ID,FEATURE_TYPE:fact.FEATURE_TYPE,SCOPE:fact.SCOPE,status:'PENDING_MATERIALIZATION'}; b.phase='BOOT01_CLOSED';
  state.eventLog.push({type:'BOOT01_PUBLIC_WORLD_FACT_NAMED',gameTime:state.meta?.gameTime??0,refId:fact.REF_ID,featureType:fact.FEATURE_TYPE,scope:fact.SCOPE}); return fact;
}

export function advanceBoot01ToBoot02(state){
  const b=ensureBootState(state); if(b.phase!=='BOOT01_CLOSED'||!b.boot01?.territory||!b.boot01?.worldFact) throw new Error('BOOT01_NOT_CLOSED');
  b.phase='BOOT02_READY'; return {phase:b.phase,territory:clone(b.boot01.territory),worldFact:clone(b.boot01.worldFact),geoObligation:clone(b.boot01.geoObligation),primordialLegacy:clone(b.boot01.legacyConsumed),genesisInheritance:clone(b.boot01.genesisInheritance),rule:'BOOT02_CONSUMES_PERSISTED_STATE_NOT_BOOT01_CARD'};
}