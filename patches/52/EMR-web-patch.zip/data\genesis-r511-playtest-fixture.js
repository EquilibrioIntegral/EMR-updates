export const GENESIS_R511_PLAYTEST_SCHEMA='EMR_GENESIS_R511_PLAYTEST_v1';

export const GENESIS_R511_PLAYTEST=Object.freeze({
 schema:GENESIS_R511_PLAYTEST_SCHEMA,
 id:'R511-HUMAN-FUN-BALANCE-001',
 decisionId:'D-GEN-R5.11-CAPABILITY-SEMANTICS01',
 status:'READY_AS_CONTRACT_NOT_EXECUTED',
 purpose:'Validar en partida real si las capacidades canónicas producen decisiones claras, variadas, equilibradas, narrativas y compatibles con Génesis de ~10 minutos.',
 releaseBlocking:true,
 claimsNotYetAllowed:Object.freeze(['FUN','BALANCED','EQUILIBRATED','HH4_PASS','CVI_PASS','TEN_MINUTE_VALIDATED']),
 requiredModes:Object.freeze(['SOLO_WITH_APP_SECONDARIES','TWO_PLAYER','THREE_OR_FOUR_PLAYER_SAMPLE']),
 targetExperience:Object.freeze({
  totalSecondsMax:600,
  screenShareMax:0.35,
  noRuleInvention:true,
  noDeadTurnLoop:true,
  noAutomaticMajorityResolution:true,
  noPowerMenuFeel:true,
  boardGameSupportedByApp:true
 }),
 capturePerOffer:Object.freeze([
  'round','agencyNature','agencyIntensity','agencyController','position','capabilityId','requiredLevel','contextualOptionText','legalAlternativesCount','noInterveneAvailable'
 ]),
 capturePerChoice:Object.freeze([
  'selectedCapabilityId','selectedNoIntervene','decisionSeconds','reasonShort','requiredRoll','result','residue','visibleMaterialization','futureHookCreated'
 ]),
 runMetrics:Object.freeze([
  'setupSeconds','totalSeconds','screenSeconds','tableSeconds','screenActions','manualInputs','ruleQuestions','desyncIncidents',
  'capabilityOfferCounts','capabilitySelectionCounts','noInterveneOffers','noInterveneSelections','roundCount','starReached','planetReached','legacyProduced',
  'dominantChoiceWarnings','deadCapabilityWarnings','alwaysOptimalWarnings','neverRelevantWarnings','appHumanAsymmetryWarnings',
  'causalChangeRecognized','consequencesUnderstood','feltAgency','narrativeInterest','feltBoardGameSupportedByApp','desireToContinue'
 ]),
 interpretation:Object.freeze({
  fun:'HUMAN_JUDGMENT_REQUIRED',
  balance:'MULTIPLE_RUNS_REQUIRED_FOR_CONFIDENCE',
  technicalSimulation:'SUPPORTING_EVIDENCE_ONLY_NOT_HUMAN_VALIDATION',
  capabilityNeverAppears:'FLAG_FOR_GATE_OR_LEVEL_REVIEW_NOT_AUTOMATIC_FAILURE',
  capabilityAlwaysBest:'BALANCE_WARNING',
  noInterveneNeverUseful:'DESIGN_WARNING',
  noInterveneAlwaysBest:'DESIGN_WARNING'
 }),
 passPolicy:'NO AUTOMATIC PASS FROM THIS FIXTURE. A human run may close usability/flow evidence; fun and balance remain provisional until repeated observed runs show no dominant/dead patterns and the experience remains narratively interesting.'
});

export function summarizeGenesisR511Playtest(run={}){
 const total=Number(run.totalSeconds),screen=Number(run.screenSeconds),table=Number(run.tableSeconds);
 const timing=Number.isFinite(total)&&total>0&&Number.isFinite(screen)&&screen>=0&&Number.isFinite(table)&&table>=0;
 const checks={
  humanRunRecorded:run.humanRun===true,
  underTenMinutes:timing&&total<=GENESIS_R511_PLAYTEST.targetExperience.totalSecondsMax,
  screenMinority:timing&&screen/total<=GENESIS_R511_PLAYTEST.targetExperience.screenShareMax&&table>screen,
  noRuleInvention:Number(run.ruleInventions||0)===0,
  noDesync:Number(run.desyncIncidents||0)===0,
  converged:run.starReached===true&&run.planetReached===true&&run.legacyProduced===true,
  boardGameSupportedByApp:run.feltBoardGameSupportedByApp===true
 };
 return{
  fixtureId:GENESIS_R511_PLAYTEST.id,
  flowCandidatePass:Object.values(checks).every(Boolean),
  checks,
  screenShare:timing?screen/total:null,
  funStatus:run.narrativeInterest===true&&run.desireToContinue===true?'POSITIVE_SINGLE_RUN_NOT_VALIDATED':'UNVALIDATED_OR_NEGATIVE',
  balanceStatus:'REQUIRES_REPEATED_RUNS_AND_DISTRIBUTION_REVIEW'
 };
}
