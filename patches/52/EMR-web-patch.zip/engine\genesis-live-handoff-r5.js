// Direct R5 live handoff. Do not downgrade through weighted/legacy Genesis adapters.
// Historical adapters remain available for old saves; new R5 sessions preserve the
// richer physical + ontological legacy in the existing BOOT01 consumer envelope.
import {compileGenesisOntologySeedsR527,validateGenesisOntologySeedsR527} from './genesis-ontology-seeds-r527.js';

const clone=x=>structuredClone(x);

export function installClosedGenesisR5ForBoot01(state,live){
 if(!state?.session)throw new Error('BOOT_STATE_SESSION_REQUIRED');
 if(live?.schema!=='EMR_GENESIS_LIVE_R5_v1'||live.phase!=='CLOSED')throw new Error('GEN_R5_LIVE_CLOSED_REQUIRED');
 const runtime=live.runtime,envelope=runtime?.boot01Envelope,legacy=runtime?.legacy;
 if(!envelope||envelope.consumer!=='BOOT01_FORMACION_MUNDO'||!legacy)throw new Error('GEN_R5_BOOT01_ENVELOPE_REQUIRED');
 const planets=Array.isArray(runtime?.cosmogony?.planets)?runtime.cosmogony.planets:[];
 const selectedIndex=planets.findIndex(p=>p.id===runtime.selectedPlanetId);
 if(selectedIndex<0)throw new Error('GEN_R518_SELECTED_WORLD_PROJECTION_REQUIRED');
 const selectedWorldPublicIndex=selectedIndex+1;
 const selectedWorldPublicName=`Mundo ${selectedWorldPublicIndex}`;
 const ontologySeeds=compileGenesisOntologySeedsR527(runtime?.ontology||{});
 const seedValidation=validateGenesisOntologySeedsR527(ontologySeeds);
 if(!seedValidation.ok)throw new Error(seedValidation.reason);
 state.session.boot??={};const boot=state.session.boot;
 boot.legadoPrimordial=clone(envelope);
 boot.primordialLegacy=clone(legacy);
 boot.genesisR5={schema:live.schema,version:live.version,signature:clone(runtime.signatureRecord.signature),selectedPlanetId:runtime.selectedPlanetId,selectedWorldPublicIndex,selectedWorldPublicName,referenceConfig:clone(live.referenceConfig),legacySchema:legacy.schema,ontologySeedSchema:ontologySeeds.schema,ontologySeedCount:ontologySeeds.seeds.length};
 boot.genesisOntologySeeds=clone(ontologySeeds);
 boot.selectedPlanetId=runtime.selectedPlanetId;
 boot.selectedPlanet=clone(legacy.physicalLegacy?.selectedPlanetSignature||null);
 boot.phase='BOOT01_READY';
 state.session.worldMemory??={};state.session.worldMemory.genesisR5=clone({physicalLegacy:legacy.physicalLegacy,supernaturalLegacy:legacy.supernaturalLegacy,consciousnessMetaphysics:legacy.consciousnessMetaphysics,normativeMetaphysics:legacy.normativeMetaphysics,knowledgeSeparation:legacy.knowledgeSeparation,ontologySeeds});
 state.eventLog??=[];state.eventLog.push({type:'GENESIS_R5_LEGACY_INSTALLED_FOR_BOOT01',gameTime:state.meta?.gameTime??0,legacyId:envelope.id,selectedPlanetId:runtime.selectedPlanetId,selectedWorldPublicIndex,fingerprint:envelope.fingerprint,ontologySeedSchema:ontologySeeds.schema,ontologySeedCount:ontologySeeds.seeds.length});
 return clone(envelope);
}