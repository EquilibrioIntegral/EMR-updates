import './save-library-ui.js';
import {HybridEngine} from './engine/engine.js';
import {loadGameData} from './engine/load-data.js';
import {configureUniquePlayers} from './engine/player-names.js';
import {renderGenesisR5Ui} from './ui/genesis-ui-r5.js';
import {GENESIS_R523_QA_ROUTE,GENESIS_R523_QA_SAVE_KEY,GENESIS_R523_QA_BRANCH,GENESIS_R523_QA_HARNESS_SCHEMA,installGenesisR523QaHarness,genesisR523QaStatus} from './engine/genesis-r523-qa-harness.js';

const $=s=>document.querySelector(s);
const initialParams=new URLSearchParams(location.search);
let data=null,engine=null,loadedFromSave=false,qaActive=false;
let tapTimes=[];

function ensureBanner(){
 let el=$('#qa-r523-banner');
 if(!el){el=document.createElement('aside');el.id='qa-r523-banner';el.className='card debug';const boot=$('#boot');boot?.insertBefore(el,$('#boot-step'));}
 return el;
}
function setQaSurface(){
 qaActive=true;
 for(const id of ['home','setup','game','debug']){const node=$('#'+id);if(node)node.hidden=true;}
 const boot=$('#boot');if(boot)boot.hidden=false;
 const exit=$('#session-exit');if(exit)exit.hidden=true;
 const title=$('#boot-title');if(title)title.hidden=true;
 const fiction=$('#boot-fiction');if(fiction)fiction.hidden=true;
 try{$('#menu-theme')?.pause();}catch{}
}
function branchQueryValue(branch){return branch===GENESIS_R523_QA_BRANCH.CONCENTRATE?'concentrate':'natural';}
function keepQaRoute(branch=null){const u=new URL(location.href);u.searchParams.set('qa',GENESIS_R523_QA_ROUTE);if(branch)u.searchParams.set('branch',branchQueryValue(branch));else u.searchParams.delete('branch');u.searchParams.delete('reset');history.replaceState(null,'',u.pathname+u.search+u.hash);}
function humanFamily(code){return({M_RED_DWARF:'estrella roja de baja masa',K_ORANGE:'estrella naranja',G_YELLOW:'estrella amarilla',F_A_WHITE_YELLOW:'estrella blanco-amarilla',B_O_BLUE_MASSIVE:'estrella azul masiva'})[code]||String(code||'estrella aún no formada');}
function humanEnvironment(code){const raw=String(code||'').replace(/_/g,' ').toLowerCase();return raw?raw.replace(/^cold /,'frío · ').replace(/^temperate /,'templado · ').replace(/^hot /,'caliente · '):'mundo aún no formado';}
function checkLine(label,value){if(value==null)return`<li>${label}: pendiente</li>`;return`<li>${label}: <strong>${value?'OK':'NO COINCIDE'}</strong></li>`;}
function phaseInstruction(status){
 const p=status?.observed?.phase;
 if(p==='AGENCY_ACTIONS')return status.branch===GENESIS_R523_QA_BRANCH.CONCENTRATE?`Elige la intervención que <strong>concentra la materia de la casilla ${status.targetVisibleCell}</strong>. No elijas otra concentración.`:'Elige <strong>No intervenir</strong> con la fuerza física.';
 if(p==='PHYSICAL_INTENTION_CHOICE')return'Para aislar la variable de esta prueba, elige <strong>No intervenir</strong> en la decisión conjunta.';
 if(p==='JOINT_RESOLUTION')return'La decisión ya está fijada. Resuelve las consecuencias y observa qué estrella nace.';
 if(p==='MATERIALIZE')return'Actualiza físicamente el Tablero Primordial siguiendo las instrucciones de la app y confirma cuando la mesa refleje el cambio.';
 if(p==='SELECT_PLANET')return'Los mundos ya existen. Comprueba abajo la consecuencia estelar y elige un mundo para continuar el recorrido de persistencia.';
 if(p==='READY_TO_CLOSE')return'Cierra Génesis para fijar el Legado.';
 if(p==='CLOSED')return'Génesis está cerrado. Pulsa “Guardar y recargar QA” para comprobar que esta misma rama reaparece desde el save aislado.';
 return'Continúa con la interfaz normal de Génesis hasta cerrar esta rama.';
}
function renderBanner(){
 const banner=ensureBanner(),status=genesisR523QaStatus(engine?.state);
 if(!status){banner.hidden=true;return;}
 banner.hidden=false;
 const exp=status.expected,obs=status.observed,setup=status.setup;
 banner.innerHTML=`<p class="eyebrow">QA INTERNA · DEV031.23 · R5.22</p><h2>Prueba causal reproducible</h2><p><strong>No forma parte de una partida normal.</strong> Usa el Tablero Primordial A61 R5.15 v0.5. Este arnés utiliza el mismo motor y la misma interfaz de Génesis, pero parte de un estado QA controlado.</p><p><strong>Preparación física:</strong> coloca ${setup.starCoreTokenCount} fichas juntas en el centro <strong>${setup.centerVisibleCell}</strong>; coloca la ficha objetivo en la casilla <strong>${setup.targetCell}</strong>; coloca las otras siete fichas en <strong>${setup.residualDiskCells.join(', ')}</strong>.</p><p><strong>Rama:</strong> ${status.branch===GENESIS_R523_QA_BRANCH.CONCENTRATE?'B · Concentrar la ficha objetivo':'A · No intervenir'}.</p><p class="table-cue">${phaseInstruction(status)}</p><p><strong>Resultado esperado:</strong> masa estelar ${exp.starMass}; ${humanFamily(exp.starFamily)}; mundo de referencia ${humanEnvironment(exp.planetEnvironmentClass)}.</p><p><strong>Observado:</strong> masa ${obs.starMass??'—'}; ${humanFamily(obs.starFamily)}; ${humanEnvironment(obs.planetEnvironmentClass)}.</p><ul>${checkLine('Acción de rama',status.checks.branchAction)}${checkLine('Masa estelar',status.checks.starMass)}${checkLine('Familia estelar',status.checks.starFamily)}${checkLine('Entorno planetario',status.checks.planetEnvironment)}</ul>${loadedFromSave?'<p><strong>Save/load:</strong> esta sesión acaba de ser reconstruida con <code>HybridEngine.fromSave()</code> desde el almacenamiento QA aislado.</p>':''}<div class="actions"><button id="qa-r523-reload" class="secondary">Guardar y recargar QA</button><button id="qa-r523-reset" class="quiet">Reiniciar esta rama</button><button id="qa-r523-switch" class="quiet">Cambiar de rama</button><button id="qa-r523-exit" class="quiet">Salir de QA</button></div>`;
 $('#qa-r523-reload')?.addEventListener('click',()=>{persist();keepQaRoute(status.branch);location.reload();});
 $('#qa-r523-reset')?.addEventListener('click',()=>startBranch(status.branch,{fresh:true}));
 $('#qa-r523-switch')?.addEventListener('click',()=>startBranch(status.branch===GENESIS_R523_QA_BRANCH.CONCENTRATE?GENESIS_R523_QA_BRANCH.NATURAL:GENESIS_R523_QA_BRANCH.CONCENTRATE,{fresh:true}));
 $('#qa-r523-exit')?.addEventListener('click',exitQa);
}
function persist(){if(engine)localStorage.setItem(GENESIS_R523_QA_SAVE_KEY,engine.saveText());}
function renderQaSession(){
 if(!engine)return;
 setQaSurface();renderBanner();
 const host=$('#boot-step');
 try{renderGenesisR5Ui({state:engine.state,host,persist,rerender:renderQaSession});}
 catch(e){host.innerHTML=`<article class="genesis-reader"><h2>QA detenida</h2><p>${String(e?.message||e)}</p></article>`;}
}
async function startBranch(branch,{fresh=false}={}){
 setQaSurface();data??=await loadGameData('.');loadedFromSave=false;
 const normalized=branch===GENESIS_R523_QA_BRANCH.CONCENTRATE?GENESIS_R523_QA_BRANCH.CONCENTRATE:GENESIS_R523_QA_BRANCH.NATURAL;
 keepQaRoute(normalized);
 if(fresh)localStorage.removeItem(GENESIS_R523_QA_SAVE_KEY);
 const saved=!fresh?localStorage.getItem(GENESIS_R523_QA_SAVE_KEY):null;
 if(saved){
  try{const candidate=HybridEngine.fromSave(data,saved),qa=candidate.state?.session?.qaHarness;if(qa?.schema===GENESIS_R523_QA_HARNESS_SCHEMA&&qa.branch===normalized){engine=candidate;loadedFromSave=true;}else localStorage.removeItem(GENESIS_R523_QA_SAVE_KEY);}catch{localStorage.removeItem(GENESIS_R523_QA_SAVE_KEY);}
 }
 if(!engine||engine.state?.session?.qaHarness?.branch!==normalized){engine=new HybridEngine(data,'R522-CAUSAL-BRANCH-FIXTURE');configureUniquePlayers(engine,[{name:'QA R5.22'}]);installGenesisR523QaHarness(engine.state,{branch:normalized});persist();}
 renderQaSession();
}
function chooser(){
 setQaSurface();engine=null;loadedFromSave=false;keepQaRoute();const banner=ensureBanner();banner.hidden=false;banner.innerHTML='<p class="eyebrow">QA INTERNA · DEV031.23</p><h2>R5.22 · bifurcación estrella → mundo</h2><p>Esta herramienta no aparece durante el juego normal y usa un save independiente. Ejecuta primero una rama y después la otra sobre el mismo estado inicial.</p>';
 const host=$('#boot-step');host.innerHTML=`<article class="genesis-reader"><h2>Elige la rama de control</h2><div class="genesis-action-grid"><button id="qa-r523-natural" class="genesis-choice-card"><h3>Rama A · No intervenir</h3><p>La protoestrella conserva la materia que habría capturado sin una nueva causa.</p></button><button id="qa-r523-concentrate" class="genesis-choice-card"><h3>Rama B · Concentrar</h3><p>La fuerza física concentra la ficha objetivo antes del siguiente intervalo cósmico.</p></button></div><button id="qa-r523-close" class="quiet">Volver al menú normal</button></article>`;
 $('#qa-r523-natural')?.addEventListener('click',()=>startBranch(GENESIS_R523_QA_BRANCH.NATURAL));
 $('#qa-r523-concentrate')?.addEventListener('click',()=>startBranch(GENESIS_R523_QA_BRANCH.CONCENTRATE));
 $('#qa-r523-close')?.addEventListener('click',exitQa);
}
function exitQa(){localStorage.removeItem(GENESIS_R523_QA_SAVE_KEY);const u=new URL(location.href);u.searchParams.delete('qa');u.searchParams.delete('branch');u.searchParams.delete('reset');location.href=u.pathname+u.search+u.hash;}
async function activateFromUrl(){
 const params=new URLSearchParams(location.search);
 if(params.get('qa')!==GENESIS_R523_QA_ROUTE)return false;
 if(params.get('reset')==='1')localStorage.removeItem(GENESIS_R523_QA_SAVE_KEY);
 const branch=params.get('branch');
 if(branch==='concentrate')await startBranch(GENESIS_R523_QA_BRANCH.CONCENTRATE,{fresh:params.get('reset')==='1'});
 else if(branch==='natural')await startBranch(GENESIS_R523_QA_BRANCH.NATURAL,{fresh:params.get('reset')==='1'});
 else chooser();
 return true;
}

$('#app-version')?.addEventListener('click',()=>{
 if(qaActive)return;
 const now=Date.now();tapTimes=[...tapTimes.filter(t=>now-t<4000),now];
 if(tapTimes.length>=7){tapTimes=[];chooser();}
});

await activateFromUrl();
