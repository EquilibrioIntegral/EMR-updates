import {createCosmogonyR5} from './genesis-cosmogony-r5.js';
import {createGenesisLiveR5} from './genesis-live-r5.js';
import {visibleGenesisCellR515} from './genesis-board-display-r515.js';
import {GENESIS_R522_E2E_FIXTURE as F} from '../data/genesis-r522-e2e-fixture.js';

export const GENESIS_R523_QA_HARNESS_SCHEMA='EMR_GENESIS_R523_QA_HARNESS_v1';
export const GENESIS_R523_QA_DECISION='D-QA-GEN-R5.23-R522-DEVICE-HARNESS01';
export const GENESIS_R523_QA_ROUTE='r522-causal';
export const GENESIS_R523_QA_SAVE_KEY='emr.qa.r522.causal.v1';
export const GENESIS_R523_QA_BRANCH=Object.freeze({NATURAL:'NO_INTERVENE',CONCENTRATE:'CONCENTRATE'});

const clone=x=>structuredClone(x);
const distance=(a,b)=>{const aq=Number(a?.q)||0,ar=Number(a?.r)||0,bq=Number(b?.q)||0,br=Number(b?.r)||0;return(Math.abs(aq-bq)+Math.abs(ar-br)+Math.abs((aq+ar)-(bq+br)))/2;};
const put=(parcel,cell)=>{parcel.cell=cell.code;parcel.q=cell.q;parcel.r=cell.r;};
function publicTraits(v){const out=[];if(Number(v.mass)>=8)out.push('MUY_MASIVA');else if(Number(v.mass)<=2)out.push('LIGERA');if(Number(v.volatiles)>=5)out.push('RICA_EN_VOLATILES');if(Number(v.refractories)>=5)out.push('RICA_EN_REFRACTARIOS');if(Number(v.thermal)>=5)out.push('CALIENTE');else if(Number(v.thermal)<=2)out.push('FRIA');if(Number(v.angularMomentum)>=5)out.push('ALTO_MOMENTO');if(Number(v.density)>=5)out.push('DENSA');return out.slice(0,3);}
const setHidden=(parcel,values)=>{parcel.hidden={...parcel.hidden,...clone(values)};parcel.public={label:'Materia primordial',traits:publicTraits(parcel.hidden)};};

export function buildGenesisR522QaCosmogony(){
 const s=createCosmogonyR5({seed:F.seed,boardPreset:F.boardPreset,matterCount:F.matterCount});
 const byId=new Map(s.matter.parcels.map(p=>[p.id,p])),center=s.board.center;
 const ring2=s.board.cells.filter(c=>distance(c,center)===2);
 const ring3=s.board.cells.filter(c=>distance(c,center)===3);
 if(ring2.length<1||ring3.length<F.residualDisk.memberIds.length)throw new Error('GEN_R523_QA_BOARD_GEOMETRY');
 for(const p of s.matter.parcels){p.state='DISK';p.preservedBy=[];p.imprints=[];p.links=[];p.diskBias=0;p.protectionUntilEpoch=0;delete p.mergedInto;}
 for(const id of F.starBeforeIgnition.memberIds){const p=byId.get(id);if(!p)throw new Error('GEN_R523_QA_STAR_MEMBER');p.state='STAR';setHidden(p,F.starBeforeIgnition.hidden);put(p,center);}
 const target=byId.get(F.interventionTarget.id);if(!target)throw new Error('GEN_R523_QA_TARGET');target.state='FREE';setHidden(target,F.interventionTarget.hidden);put(target,ring2[0]);
 F.residualDisk.memberIds.forEach((id,i)=>{const p=byId.get(id);if(!p)throw new Error('GEN_R523_QA_DISK_MEMBER');p.state='DISK';setHidden(p,{...F.residualDisk.hidden,mass:F.residualDisk.masses[i]});put(p,ring3[i]);});
 s.star={state:'NONE',mass:F.starBeforeIgnition.mass,members:[...F.starBeforeIgnition.memberIds],family:null,ignitionEpoch:null,formationProfile:null};
 s.totalInitialMass=s.matter.parcels.reduce((n,p)=>n+Number(p.hidden.mass||0),0);
 s.epoch=F.preIgnitionEpoch;s.phase='COLLAPSE';s.closed=false;s.planets=[];s.satellites=[];s.interventions=[];
 s.history=F.starBeforeIgnition.memberIds.map(id=>({type:'STAR_ACCRETION',epoch:0,targetId:id,sourceIds:[id],mass:byId.get(id).hidden.mass,fixture:true}));
 return s;
}

function qaEntryResult(){
 const signature={PHYSICS:6,MYSTIC:0,WILL:0};
 return{schema:'EMR_GENESIS_ENTRY_RESULT_R53_v1',mode:'QA_R522_CAUSAL',choices:[1],natures:['PHYSICS'],signature,rolls:{__signatureOverride:{signature:{...signature},counts:{PHYSICS:1,MYSTIC:0,WILL:0},mode:'SOLO_ENTRY_RESOLVED',rolls:{}}}};
}

function normalizeBranch(branch){return branch===GENESIS_R523_QA_BRANCH.CONCENTRATE?GENESIS_R523_QA_BRANCH.CONCENTRATE:GENESIS_R523_QA_BRANCH.NATURAL;}

export function createGenesisR523QaLive({player,branch=GENESIS_R523_QA_BRANCH.NATURAL}={}){
 if(!player?.id||!player?.name)throw new Error('GEN_R523_QA_PLAYER_REQUIRED');
 const entryResult=qaEntryResult();
 const live=createGenesisLiveR5({entryResult,seed:F.seed,players:[{id:player.id,name:player.name}],config:{boardPreset:F.boardPreset,matterCount:F.matterCount}});
 const cosmogony=buildGenesisR522QaCosmogony(),target=cosmogony.matter.parcels.find(p=>p.id===F.interventionTarget.id);
 live.runtime.cosmogony=cosmogony;live.runtime.phase='PLAY';live.runtime.selectedPlanetId=null;live.runtime.legacy=null;live.runtime.boot01Envelope=null;
 live.phase='AGENCY_ACTIONS';live.round=F.preIgnitionEpoch+1;live.actorIndex=0;live.pendingAgencyActions=[];live.contextual=null;live.revealedSelections=null;live.jointPlan=null;live.jointTestResults={};live.lastJointResolution=null;live.lastMaterialization=[];live.afterMaterializationPhase=null;
 live.players[0].position=target.cell;live.players[0].spawn={slot:'QA',cell:target.cell,q:target.q,r:target.r};live.players[0].lastRepositionRound=live.round;
 live.spawnPlan={...(live.spawnPlan||{}),assignments:[{participantId:live.players[0].id,controller:'HUMAN',nature:'PHYSICS',slot:'QA',cell:target.cell,q:target.q,r:target.r}]};
 live.playerFacingFlow={...(live.playerFacingFlow||{}),originSeen:true};
 live.currentNarrative='QA interna R5.22: el sistema está exactamente al borde de formar una estrella. Esta sesión existe para comprobar si una intervención física concreta altera de forma comprensible la estrella y el entorno de los mundos posteriores.';
 live.narrativeLog.push({round:1,kind:'QA_R522_CAUSAL_BRANCH_READY',publicText:live.currentNarrative});
 live.history.push({type:'GEN_R523_QA_HARNESS_READY',decisionId:GENESIS_R523_QA_DECISION,fixtureId:F.id,branch:normalizeBranch(branch),targetId:F.interventionTarget.id,targetCell:target.cell});
 return live;
}

export function installGenesisR523QaHarness(state,{branch=GENESIS_R523_QA_BRANCH.NATURAL}={}){
 if(!state?.session?.players||state.session.players.length!==1)throw new Error('GEN_R523_QA_SINGLE_PLAYER_REQUIRED');
 const normalized=normalizeBranch(branch),player=state.session.players[0],live=createGenesisR523QaLive({player,branch:normalized});
 const target=live.runtime.cosmogony.matter.parcels.find(p=>p.id===F.interventionTarget.id);
 state.session.genesisEntryMode='R53';state.session.genesisEntryR53=null;state.session.genesisR5=live;state.session.boot??={};state.session.boot.phase='GENESIS_ACTIVE';state.session.boot.ci03Result=qaEntryResult();
 state.session.qaHarness={schema:GENESIS_R523_QA_HARNESS_SCHEMA,decisionId:GENESIS_R523_QA_DECISION,qaOnly:true,fixtureId:F.id,branch:normalized,seed:F.seed,targetVisibleCell:visibleGenesisCellR515(live.runtime.cosmogony.board,target.cell),expected:clone(normalized===GENESIS_R523_QA_BRANCH.CONCENTRATE?F.expected.intervention:F.expected.noIntervention)};
 state.eventLog??=[];state.eventLog.push({type:'GEN_R523_QA_HARNESS_INSTALLED',decisionId:GENESIS_R523_QA_DECISION,fixtureId:F.id,branch:normalized,gameTime:state.meta?.gameTime??0});
 return live;
}

export function genesisR523QaStatus(state){
 const qa=state?.session?.qaHarness,live=state?.session?.genesisR5;if(qa?.schema!==GENESIS_R523_QA_HARNESS_SCHEMA||!live)return null;
 const initial=buildGenesisR522QaCosmogony(),board=initial.board,target=initial.matter.parcels.find(p=>p.id===F.interventionTarget.id),starCells=initial.matter.parcels.filter(p=>p.state==='STAR').map(p=>visibleGenesisCellR515(board,p.cell)),diskCells=initial.matter.parcels.filter(p=>p.state==='DISK').map(p=>visibleGenesisCellR515(board,p.cell));
 const c=live.runtime?.cosmogony,expected=qa.expected||{},referenceWorld=c?.planets?.find(p=>p.members?.includes(F.residualDisk.memberIds[0]))||null;
 const concentrateObserved=Boolean(c?.interventions?.some(i=>i.kind==='CONCENTRATE'&&i.targetId===F.interventionTarget.id));
 const starReady=c?.star?.state==='IGNITED',worldReady=Boolean(referenceWorld);
 return{schema:GENESIS_R523_QA_HARNESS_SCHEMA,branch:qa.branch,fixtureId:qa.fixtureId,targetVisibleCell:visibleGenesisCellR515(board,target.cell),setup:{centerVisibleCell:visibleGenesisCellR515(board,board.center.code),starCoreTokenCount:starCells.length,starCoreCells:[...starCells],targetCell:visibleGenesisCellR515(board,target.cell),residualDiskCells:diskCells},expected:clone(expected),observed:{phase:live.phase,cosmicPhase:c?.phase||null,concentrateObserved,starMass:c?.star?.mass??null,starFamily:c?.star?.family??null,planetEnvironmentClass:referenceWorld?.environmentClass??null},checks:{branchAction:qa.branch===GENESIS_R523_QA_BRANCH.CONCENTRATE?concentrateObserved:!concentrateObserved,starMass:starReady?Number(c.star.mass)===Number(expected.starMass):null,starFamily:starReady?c.star.family===expected.starFamily:null,planetEnvironment:worldReady?referenceWorld.environmentClass===expected.planetEnvironmentClass:null}};
}
