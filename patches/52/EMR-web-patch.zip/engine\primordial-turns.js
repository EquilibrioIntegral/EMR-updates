// GEN-R4.3 — Free agency turns + cosmic clock + tabletop-causal matter actions.
// The app orchestrates; the table plays. No player-facing mass bookkeeping.
import {effectiveAuthority} from './primordial-agencies.js';

const clone=x=>JSON.parse(JSON.stringify(x));
export const GENESIS_PHASES=Object.freeze(['FREE_ACTIONS','JOINT_INTENTION','COSMIC_EVOLUTION','NARRATIVE_EVENT','CONVERGENCE_CHECK']);

export function ensureGenesisTurnState(state){
 const s=clone(state);
 s.genesisTurn??={phase:'FREE_ACTIONS',round:1,currentPlayerAgencyId:null,actedAgencyIds:[],cosmicClock:{years:0,epoch:'PRIMORDIAL'},events:[]};
 return s;
}
export function assumeAgencyTurn(state,agencyId){const s=ensureGenesisTurnState(state);if(s.genesisTurn.phase!=='FREE_ACTIONS')throw new Error('GEN_FREE_ACTION_PHASE_REQUIRED');const agency=(s.agencies||[]).find(a=>a.id===agencyId);if(!agency)throw new Error('GEN_AGENCY_NOT_FOUND');if(s.genesisTurn.actedAgencyIds.includes(agencyId))throw new Error('GEN_AGENCY_ALREADY_ACTED');s.genesisTurn.currentPlayerAgencyId=agencyId;return s;}

export function getContextualFreeActions(state,agencyId){
 const s=ensureGenesisTurnState(state),agency=(s.agencies||[]).find(a=>a.id===agencyId);if(!agency)throw new Error('GEN_AGENCY_NOT_FOUND');
 const origin=agency.presence?.hexId??agency.presence??null;
 const entities=[...(s.entities||s.bodies||[]),...(s.matterReservoirs||[]).map(r=>({id:r.id,name:r.name||r.id,hexId:r.location?.hexId??r.location,kind:'MATTER'}))].filter((e,i,a)=>e?.id&&e.id!==agency.id&&a.findIndex(x=>x.id===e.id)===i);
 const actions=[];
 for(const target of entities){const targetHex=target.hexId??target.position?.hexId??target.position??null;const distance=distanceFor(s,origin,targetHex);const authority=effectiveAuthority({agency,targetDistance:distance});if(!authority.legal)continue;
  for(const op of operationsFor(agency.kind)){if((op.id==='ATTRACT'||op.id==='DISPERSE')&&target.kind!=='MATTER'&&!findMatter(s,target.id))continue;actions.push({id:`FREE:${agency.id}:${op.id}:${target.id}`,kind:'INTERVENE',agencyId:agency.id,operation:op.id,targetId:target.id,legal:true,reach:authority.reach,distance,explanation:explain(agency,op,target,distance)});}
 }
 actions.push({id:`FREE:${agency.id}:NO_INTERVENE`,kind:'NO_INTERVENE',agencyId:agency.id,operation:'NO_INTERVENE',targetId:null,legal:true,explanation:'No intervenir. El universo seguirá evolucionando y el tiempo cósmico avanzará.'});return actions;
}

export function applyAgencyFreeAction(state,action,{timeYears}={}){
 let s=ensureGenesisTurnState(state);if(s.genesisTurn.phase!=='FREE_ACTIONS')throw new Error('GEN_FREE_ACTION_PHASE_REQUIRED');if(s.genesisTurn.currentPlayerAgencyId!==action?.agencyId)throw new Error('GEN_AGENCY_TURN_NOT_ASSUMED');
 const legal=getContextualFreeActions(s,action.agencyId).find(a=>a.id===action.id);if(!legal)throw new Error('GEN_FREE_ACTION_ILLEGAL');const agency=(s.agencies||[]).find(a=>a.id===action.agencyId);
 const physical=applyTabletopEffect(s,agency,legal);s=physical.state;
 const years=normalizeTime(timeYears??defaultTimeYears(legal.operation));s.genesisTurn.cosmicClock.years+=years;
 const event={type:'FREE_ACTION',round:s.genesisTurn.round,agencyId:action.agencyId,playerCauseId:agency?.playerId??null,operation:legal.operation,targetId:legal.targetId,timeDeltaYears:years,cosmicYear:s.genesisTurn.cosmicClock.years,tableInstruction:physical.tableInstruction,effect:physical.effect};
 s.genesisTurn.events.push(event);s.eventLog??=[];s.eventLog.push(clone(event));s.genesisTurn.actedAgencyIds.push(action.agencyId);s.genesisTurn.currentPlayerAgencyId=null;if((s.agencies||[]).every(a=>s.genesisTurn.actedAgencyIds.includes(a.id)))s.genesisTurn.phase='JOINT_INTENTION';return s;
}

function applyTabletopEffect(state,agency,action){const s=clone(state);if(action.operation==='NO_INTERVENE')return {state:s,effect:null,tableInstruction:'No muevas ningún componente por esta acción.'};const r=findMatter(s,action.targetId);if(!r||!['ATTRACT','DISPERSE'].includes(action.operation))return {state:s,effect:{type:'AGENCY_INFLUENCE',operation:action.operation,targetId:action.targetId},tableInstruction:'Mantén la disposición de la mesa hasta que el Guionista resuelva la consecuencia.'};
 const from=r.location?.hexId??r.location;const agencyHex=agency?.presence?.hexId??agency?.presence??from;const destination=action.operation==='ATTRACT'?stepToward(s,from,agencyHex):stepAway(s,from,agencyHex);r.location=typeof r.location==='object'?{...r.location,hexId:destination}:destination;
 const effect={type:'MATTER_REPOSITION',producerId:'BOOT00_GENESIS_PHYSICS',playerCauseId:agency?.playerId??null,reservoirId:r.id,from,to:destination,operation:action.operation};r.provenance??=[];r.provenance.push(clone(effect));
 return {state:s,effect,tableInstruction:`Mueve ${r.name||r.id} de ${from} a ${destination}.`};}
function findMatter(s,id){return (s.matterReservoirs||[]).find(r=>r.id===id&&r.status!=='DEPLETED');}
function stepToward(s,from,to){if(from===to)return from;return s.topology?.nextToward?.[`${from}|${to}`]??to;}
function stepAway(s,from,awayFrom){return s.topology?.nextAway?.[`${from}|${awayFrom}`]??from;}
export function advanceGenesisPhase(state,nextPhase){const s=ensureGenesisTurnState(state);if(!GENESIS_PHASES.includes(nextPhase))throw new Error('GEN_PHASE_INVALID');s.genesisTurn.phase=nextPhase;return s;}
export function beginNextGenesisRound(state){const s=ensureGenesisTurnState(state);s.genesisTurn.round+=1;s.genesisTurn.phase='FREE_ACTIONS';s.genesisTurn.currentPlayerAgencyId=null;s.genesisTurn.actedAgencyIds=[];return s;}
export function formatCosmicTime(years){const n=normalizeTime(years);if(n<1e3)return `${n} años`;if(n<1e6)return `${trim(n/1e3)} mil años`;if(n<1e9)return `${trim(n/1e6)} millones de años`;return `${trim(n/1e9)} mil millones de años`;}
function operationsFor(kind){if(kind==='PHYSICS')return [{id:'ATTRACT'},{id:'DISPERSE'},{id:'DISSIPATE_HEAT'},{id:'STABILIZE_RELATION'}];if(kind==='MYSTIC')return [{id:'BIND'},{id:'TRANSFORM_RELATION'}];if(kind==='WILL')return [{id:'PRESERVE'},{id:'CREATE'},{id:'TRANSFORM'},{id:'OPPOSE'}];return [];}
function explain(a,op,t,d){const role=a.specialization?` que encarna ${a.specialization}`:'';return `Como ${a.kind}${role}, puedes ${op.id} sobre ${t.name||t.id}: está a distancia ${d} y dentro de tu influencia causal.`;}
function distanceFor(s,a,b){if(a==null||b==null)return 0;if(a===b)return 0;const key=`${a}|${b}`,rev=`${b}|${a}`;const d=s.topology?.distances?.[key]??s.topology?.distances?.[rev];return Number.isFinite(d)?d:1;}
function defaultTimeYears(op){return op==='NO_INTERVENE'?1e6:op==='DISSIPATE_HEAT'?5e5:op==='STABILIZE_RELATION'?2e6:1e5;}
function normalizeTime(v){const n=Math.floor(Number(v));if(!Number.isFinite(n)||n<0)throw new Error('GEN_COSMIC_TIME_INVALID');return n;}
function trim(n){return Number(n.toFixed(n>=100?0:n>=10?1:2)).toLocaleString('es-ES');}
