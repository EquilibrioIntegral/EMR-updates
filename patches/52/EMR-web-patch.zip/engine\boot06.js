// BOOT-06 · PROTAGONISTAS · world-first orchestrator
// Authority: EMR_BOOT06_SOFTWARE_ORCHESTRATOR_A1_v0.1 (+ v0.2 passthrough patch)

function clone(v){ return v == null ? v : JSON.parse(JSON.stringify(v)); }
function stable(items=[]){ return [...items].sort((a,b)=>String(a.id).localeCompare(String(b.id))); }

export function buildBoot06Input(boot05, { publicAnchors=[], contextFilters={}, worldPayloadRef={} }={}) {
  if (boot05?.phase !== 'BOOT05_CLOSED') throw new Error('BOOT06_REQUIRES_BOOT05_CLOSED');
  return Object.freeze({
    configFirmaRef: { config: boot05.config, signature: boot05.signature },
    save0Refs: boot05.save0,
    vistaInicial: boot05.atlasChronicle,
    publicAnchors: stable(publicAnchors),
    contextFilters: clone(contextFilters),
    worldPayloadRef: clone(worldPayloadRef)
  });
}

export function legalOccupations(input, occupations=[]) {
  return occupations.filter(o => {
    if (o.kind === 'BASE') return true;
    if (o.kind !== 'CONTEXTUAL') return false;
    return (o.hardPredicates ?? []).every(p => p(input) === true);
  });
}

function addAttributes(base={}, mod={}) {
  const out={...base};
  for (const [k,v] of Object.entries(mod)) out[k]=(out[k]??0)+v;
  return out;
}

export function instantiateProtagonist(input, spec, catalogs) {
  const legal=legalOccupations(input,catalogs.occupations);
  const occupation=legal.find(x=>x.id===spec.occupationId);
  if(!occupation) throw new Error(`BOOT06_ILLEGAL_OCCUPATION:${spec.occupationId}`);
  const appearance=catalogs.appearances.find(x=>x.id===spec.appearanceId);
  const experience=catalogs.experiences.find(x=>x.id===spec.experienceId);
  const personalObject=catalogs.personalObjects.find(x=>x.id===spec.personalObjectId);
  if(!appearance||!experience||!personalObject) throw new Error('BOOT06_MISSING_PC_SOURCE');
  const origin=input.publicAnchors.find(x=>x.id===spec.originRef);
  if(!origin) throw new Error(`BOOT06_ORIGIN_NOT_PUBLIC:${spec.originRef}`);

  return Object.freeze({
    id: spec.id,
    sources: Object.freeze({ appearance:appearance.id, occupation:occupation.id, experience:experience.id, personalObject:personalObject.id }),
    originRef: origin.id,
    appearance: clone(appearance.pcOnly),
    occupation: Object.freeze({ id:occupation.id, name:occupation.name, traits:clone(occupation.traits??[]), actions:clone(occupation.actions??[]) }),
    experience: Object.freeze({ id:experience.id, name:experience.name, pendingState:'LATENTE', pcOnly:clone(experience.pcOnly??{}) }),
    personalObject: Object.freeze({ id:personalObject.id, name:personalObject.name, state:personalObject.state??'INTACTO', pcOnly:clone(personalObject.pcOnly??{}) }),
    attributes: Object.freeze(addAttributes(occupation.attributes, experience.attributeMods)),
    invariants: Object.freeze(['NO_WORLD_RETCON','NO_WORLD_TRUTH_COPY','EXTERNAL_REFERENTS_LATENT'])
  });
}

export function compileBoot06({ boot05, publicAnchors, contextFilters, worldPayloadRef, protagonistSpecs, catalogs }) {
  const input=buildBoot06Input(boot05,{publicAnchors,contextFilters,worldPayloadRef});
  if(!input.publicAnchors.length) return { phase:'BOOT06_GAP', gap:'NO_PUBLIC_ANCHOR' };
  const protagonists=protagonistSpecs.map(spec=>instantiateProtagonist(input,spec,catalogs));
  const handoff=Object.freeze({
    worldPayloadRef: input.worldPayloadRef,
    protagonists,
    pcFacts: protagonists.flatMap(pc=>[
      {id:`${pc.id}-ORIGIN`,referentId:pc.originRef,type:'ORIGIN'},
      {id:`${pc.id}-OCC`,referentId:pc.occupation.id,type:'OCCUPATION'},
      {id:`${pc.id}-EX`,referentId:pc.experience.id,type:'EXPERIENCE',state:'LATENTE'},
      {id:`${pc.id}-OP`,referentId:pc.personalObject.id,type:'PERSONAL_OBJECT',state:pc.personalObject.state}
    ]),
    rules:Object.freeze({ canDefineMission:false, canRetcon:false, guionistaEnabled:false, runtimeEnabled:false })
  });
  return Object.freeze({ phase:'BOOT06_CLOSED', input, protagonists, handoff, nextPhase:'BOOT07_VINCULO_GRUPO' });
}
