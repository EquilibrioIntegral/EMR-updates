export async function loadGameData(base='.') {
  const [modules,world,scenes,gen04,realizerV3,mapCatalog,ruiContract,ruiCatalog,physicalContracts,bootCi00,boot01]=await Promise.all([
    fetch(`${base}/data/modules.json`).then(r=>r.json()),
    fetch(`${base}/data/world.json`).then(r=>r.json()),
    fetch(`${base}/data/scenes.json`).then(r=>r.json()),
    fetch(`${base}/data/gen04.json`).then(r=>r.json()),
    fetch(`${base}/data/realizer-v3.json`).then(r=>r.json()),
    fetch(`${base}/data/map-catalog.json`).then(r=>r.json()),
    fetch(`${base}/data/rui-contract.json`).then(r=>r.json()),
    fetch(`${base}/data/rui-catalog.json`).then(r=>r.json()),
    fetch(`${base}/data/physical-contracts.json`).then(r=>r.json()),
    fetch(`${base}/data/boot-ci00.json`).then(r=>r.json()),
    fetch(`${base}/data/boot01.json`).then(r=>r.json())
  ]);
  return {modules,scenes,gen04,realizerV3,mapCatalog,ruiContract,ruiCatalog,physicalContracts,bootCi00,boot01,...world};
}
