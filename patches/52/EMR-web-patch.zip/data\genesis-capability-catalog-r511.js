// D-GEN-R5.11-CAPABILITY-SEMANTICS01
// Approved 2026-09-09. Canonical design semantics; human fun/balance validation pending.
// The 18 slots are causal capability families, not player-facing buttons.

export const GENESIS_R511_DECISION_ID='D-GEN-R5.11-CAPABILITY-SEMANTICS01';
export const GENESIS_R511_CATALOG_SCHEMA='EMR_GENESIS_R511_CAPABILITY_CATALOG_v1';
export const GENESIS_R511_HUMAN_VALIDATION='PENDING';
export const GENESIS_R511_NATURES=Object.freeze(['PHYSICS','MYSTIC','WILL']);

const c=(nature,requiredLevel,id,label,scope,remoteEligible,modes,purpose,risks,consumers=[])=>Object.freeze({
 nature,requiredLevel,id,label,scope,remoteEligible,modes:Object.freeze([...modes]),purpose,risks:Object.freeze([...risks]),consumers:Object.freeze([...consumers]),
 playerFacing:false,implementationContract:'GUIÓN_CONTEXTUAL_NOT_POWER_MENU',humanValidation:GENESIS_R511_HUMAN_VALIDATION
});

export const GENESIS_R511_CAPABILITY_CATALOG=Object.freeze([
 c('PHYSICS',1,'PHYSICS_CONCENTRATE','Concentrar','LOCAL',false,['ATTRACT','CONCENTRATE'],'Reducir separación y concentrar materia existente para formar/reforzar núcleos o cuerpos.',['COLLISION','PARTIAL_COLLAPSE','OVERHEAT'],['BOOT01_FORMACION_MUNDO']),
 c('PHYSICS',2,'PHYSICS_REDISTRIBUTE','Redistribuir','LOCAL',false,['SEPARATE','DISPERSE','REDIRECT'],'Separar, dispersar o redistribuir materia/trayectorias existentes sin crear materia.',['FRAGMENTATION','LOSS_OF_USEFUL_MATTER','DELAYED_FORMATION'],['BOOT01_FORMACION_MUNDO']),
 c('PHYSICS',3,'PHYSICS_TRANSFER_ENERGY','Transferir energía','LOCAL_OR_CONDITIONAL_REMOTE',true,['HEAT','COOL','DISSIPATE','TRANSFER_MOMENTUM'],'Modificar estado energético por un mecanismo físico legal; REMOTE solo mediante campo/radiación compatible.',['DESTABILIZE_OTHER_REGION','CLOSE_FUTURE_GATE'],['BOOT01_FORMACION_MUNDO']),
 c('PHYSICS',4,'PHYSICS_STABILIZE_CAPTURE','Estabilizar / capturar','LOCAL_OR_CONDITIONAL_REMOTE',true,['STABILIZE','CAPTURE'],'Estabilizar una relación dinámica/orbital físicamente posible o capturar un cuerpo elegible.',['TENSIONED_CAPTURE','UNSTABLE_RELATION'],['BOOT01_FORMACION_MUNDO','FUTURE_BOOTS']),
 c('PHYSICS',5,'PHYSICS_ACTIVATE_NUCLEAR_CHANGE','Activar cambio nuclear','LOCAL',false,['ACTIVATE_NUCLEAR_CHANGE'],'Favorecer un proceso nuclear únicamente cuando composición, presión y temperatura lo permiten.',['ENERGY_RELEASE','NEARBY_DISPERSAL'],['BOOT01_FORMACION_MUNDO']),
 c('PHYSICS',6,'PHYSICS_SYSTEMIC_APPLICATION','Aplicación sistémica','INHERITED',false,['APPLY_ONE_LOWER_CAPABILITY_SYSTEMICALLY'],'Aplicar de forma coordinada UNA capacidad física inferior desbloqueada sobre un conjunto causalmente conectado.',['SYSTEM_WIDE_CONSEQUENCES'],['BOOT01_FORMACION_MUNDO','FUTURE_BOOTS']),

 c('MYSTIC',1,'MYSTIC_BIND','Vincular','LOCAL_ADJACENT',false,['BIND'],'Crear un vínculo sobrenatural objetivo e impersonal entre referentes elegibles.',['TRANSMITTED_TENSION','FUTURE_SEPARATION_LIMIT'],['BOOT03','BOOT06','RUNTIME_GUIONISTA']),
 c('MYSTIC',2,'MYSTIC_PERSIST_IMPRINT','Persistir huella','LOCAL',false,['PERSIST_IMPRINT'],'Hacer que una propiedad/huella mística impersonal sobreviva a transformaciones de su soporte.',['PERSISTENT_ANOMALY'],['BOOT03','BOOT06','RUNTIME_GUIONISTA']),
 c('MYSTIC',3,'MYSTIC_RESONATE_MARK','Resonar / marcar','MYSTIC_TOPOLOGY_REMOTE_ELIGIBLE',true,['MARK','RESONATE'],'Establecer resonancia mediante topología/vínculo místico real; nunca concede alcance remoto universal.',['UNWANTED_FUTURE_PROPAGATION'],['BOOT03','BOOT06','RUNTIME_GUIONISTA']),
 c('MYSTIC',4,'MYSTIC_CONDITIONAL_TRANSFORM','Transformación condicional','LOCAL_OR_AUTHORIZED_LINK',false,['CONDITIONAL_TRANSFORM'],'Transformar o dejar preparado un cambio bajo una condición concreta y un principio místico válido.',['CONDITION_NEVER_OCCURS','LATE_HARMFUL_TRIGGER'],['FUTURE_BOOTS','RUNTIME_GUIONISTA']),
 c('MYSTIC',5,'MYSTIC_CYCLE_ENTANGLE','Ciclo / entrelazamiento','MYSTIC_TOPOLOGY_REMOTE_ELIGIBLE',true,['CYCLE','ENTANGLE_PHYSICAL_MYSTIC'],'Crear recurrencia o entrelazar un proceso místico con uno físico mediante causalidad establecida.',['RECURRING_TENSION','COSTLY_TO_BREAK'],['FUTURE_BOOTS','RUNTIME_GUIONISTA']),
 c('MYSTIC',6,'MYSTIC_BRIDGE_CONSCIOUSNESS_MATTER','Puente consciencia↔materia','ONTOLOGICAL_RELATIONAL',false,['BRIDGE_CONSCIOUSNESS_MATTER'],'Crear un puente causal específico entre consciencia y materia cuando A, V, relación y ontología lo permiten.',['BIDIRECTIONAL_CAUSALITY','BOUND_BY_MYSTIC_OR_MATERIAL_CONDITION'],['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME_GUIONISTA']),

 c('WILL',1,'WILL_PROTECT_CLAIM_REJECT','Proteger / reclamar / rechazar','LOCAL_ADJACENT',false,['PROTECT','CLAIM','REJECT'],'Expresar una frontera consciente sobre un referente legítimo sin crear invulnerabilidad, propiedad absoluta ni veto gratuito.',['RIVALRY','COMMITMENT','FUTURE_CONFLICT'],['BOOT02','BOOT03','RUNTIME_GUIONISTA']),
 c('WILL',2,'WILL_DESIGNATE_IMPRINT_PURPOSE','Designar / imprimir propósito','LOCAL_ADJACENT',false,['DESIGNATE','IMPRINT_PURPOSE'],'Dejar una intención consciente persistente sobre un referente con productor, límites y consumidor futuro.',['BROKEN_PROMISE','FAILED_PURPOSE','FUTURE_TENSION'],['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME_GUIONISTA']),
 c('WILL',3,'WILL_REVEAL_HIDE','Revelarse / ocultarse','RELATIONAL_KNOWLEDGE',false,['REVEAL','HIDE'],'Cambiar descubribilidad/manifestación de una verdad ya existente sin borrar la verdad objetiva ni crear religión.',['ATTRACT_OPPOSITION','DELAY_COOPERATION'],['FUTURE_BOOTS','RUNTIME_GUIONISTA']),
 c('WILL',4,'WILL_PACT_OPPOSE_RELATE','Pactar / oponerse / relacionarse','RELATIONAL',false,['PACT','COOPERATE','OPPOSE','RIVAL'],'Formalizar una relación persistente solo cuando una historia causal real la hace pertinente.',['FUTURE_LEGALITY_CONSTRAINT','RIVALRY_ESCALATION'],['BOOT03','FUTURE_BOOTS','RUNTIME_GUIONISTA']),
 c('WILL',5,'WILL_AUTOLIMIT_CONTINUITY','Autolimitar / continuidad','SELF_ONTOLOGICAL',false,['AUTOLIMIT','CONTINUITY'],'Imponer límites persistentes a la propia Voluntad o gobernar continuidad solo donde exista autoridad causal legítima.',['REDUCED_FUTURE_OPTIONS','INDEPENDENT_EMANATION_PERSISTS'],['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME_GUIONISTA']),
 c('WILL',6,'WILL_DECREE_EMANATE','Decretar / emanar','ONTOLOGICAL',false,['DECREE','EMANATE'],'Establecer una ley acotada o emanar otra Voluntad solo con autoridad de origen/creación explícita.',['LAW_LIMITS_FUTURE','EMANATED_VOLITION_BECOMES_INDEPENDENT'],['BOOT02','BOOT03','FUTURE_BOOTS','RUNTIME_GUIONISTA'])
]);

export const GENESIS_R511_NO_INTERVENE=Object.freeze({
 id:'NO_INTERVENE',slot:'N',nature:'ANY',requiredLevel:0,playerFacing:true,
 meaning:'La agencia no introduce una nueva causa en esta resolución; el mundo, otras agencias y consecuencias pendientes siguen avanzando.',
 antiStall:true,humanValidation:GENESIS_R511_HUMAN_VALIDATION
});

export function validateGenesisR511Catalog(){
 if(GENESIS_R511_CAPABILITY_CATALOG.length!==18)throw new Error('GEN_R511_CATALOG_SIZE');
 for(const nature of GENESIS_R511_NATURES){
  const rows=GENESIS_R511_CAPABILITY_CATALOG.filter(x=>x.nature===nature);
  if(rows.length!==6)throw new Error(`GEN_R511_${nature}_COUNT`);
  const levels=rows.map(x=>x.requiredLevel).sort((a,b)=>a-b);
  if(JSON.stringify(levels)!==JSON.stringify([1,2,3,4,5,6]))throw new Error(`GEN_R511_${nature}_LEVELS`);
 }
 if(GENESIS_R511_CAPABILITY_CATALOG.some(x=>x.playerFacing!==false))throw new Error('GEN_R511_CAPABILITIES_ARE_NOT_BUTTONS');
 return true;
}
