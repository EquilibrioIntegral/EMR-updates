// R5.15 player-facing numbering for the approved A61 artwork.
// Internal H-codes and axial coordinates remain unchanged for engine/save stability.
// The physical/app board is read top-to-bottom and left-to-right: rows 5/6/7/8/9/8/7/6/5.

export const GENESIS_BOARD_DISPLAY_R515='EMR_GENESIS_BOARD_DISPLAY_R515_v1';
export const A61_VISIBLE_ROWS_R515=[5,6,7,8,9,8,7,6,5];

function legacyVisible(code){
  const s=String(code??'');
  const m=s.match(/^H0*(\d+)$/i);
  return m?String(Number(m[1])):s;
}

function sortedA61Cells(board){
  if(board?.id!=='A61'||!Array.isArray(board.cells))return [];
  return [...board.cells].sort((a,b)=>Number(a.r)-Number(b.r)||Number(a.q)-Number(b.q)||String(a.code).localeCompare(String(b.code)));
}

export function a61VisibleMapR515(board){
  const cells=sortedA61Cells(board);
  if(cells.length!==61)return null;
  const map=new Map();
  cells.forEach((cell,index)=>map.set(String(cell.code),index+1));
  return map;
}

export function visibleGenesisCellR515(board,code){
  const s=String(code??'');
  if(board?.id==='A61'){
    const map=a61VisibleMapR515(board);
    const number=map?.get(s);
    if(number!=null)return String(number);
  }
  return legacyVisible(s);
}

export function a61VisibleRowsR515(board){
  const cells=sortedA61Cells(board);
  if(cells.length!==61)return [];
  let offset=0;
  return A61_VISIBLE_ROWS_R515.map(length=>{
    const row=cells.slice(offset,offset+length).map((cell,index)=>({
      ...cell,
      visibleNumber:offset+index+1
    }));
    offset+=length;
    return row;
  });
}

export function a61CenterVisibleNumberR515(board){
  if(board?.id!=='A61')return null;
  const center=board.center||board.cells?.find(c=>Number(c.q)===0&&Number(c.r)===0);
  if(!center)return null;
  const value=visibleGenesisCellR515(board,center.code);
  return /^\d+$/.test(value)?Number(value):null;
}
