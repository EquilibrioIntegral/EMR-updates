
export const MAP_SCHEMA_VERSION = "EMR-MAP-STATE-0.1";

export function normalizeOrientation(orientation = 0, orientationCount = 4) {
  const count = Number(orientationCount);
  if (!Number.isInteger(count) || count < 1) throw new Error("MAP_ORIENTATION_COUNT_INVALID");
  if (typeof orientation === "number" && Number.isInteger(orientation)) return ((orientation % count) + count) % count;
  const legacy = {UP:0, RIGHT:1, DOWN:2, LEFT:3};
  if (orientation in legacy && count === 4) return legacy[orientation];
  throw new Error("MAP_ORIENTATION_INVALID");
}

export function createMapState(catalog = { tiles: [] }) {
  const inventory = {};
  for (const tile of catalog.tiles ?? []) {
    inventory[tile.id] = {
      tileId: tile.id,
      status: tile.available === false ? "IN_USE" : "LIBRARY",
      placementId: null
    };
  }
  return {
    schemaVersion: MAP_SCHEMA_VERSION,
    placements: {},
    discoveredLocations: {},
    inventory,
    activeWindows: [],
    nextPlacementSeq: 1
  };
}

export function availableTiles(catalog, mapState, { scale, families = [] } = {}) {
  const familySet = new Set(families);
  return (catalog.tiles ?? []).filter(tile => {
    if (scale && tile.scale !== scale) return false;
    if (familySet.size && !familySet.has(tile.family)) return false;
    return mapState.inventory?.[tile.id]?.status === "LIBRARY";
  });
}

export function materializeTile(mapState, tile, {
  locationId,
  parentPlacementId = null,
  anchor = null,
  rotation = 0,
  orientationCount = 4,
  visibleFacts = {}
} = {}) {
  if (!tile?.id) throw new Error("MAP_TILE_REQUIRED");
  const inv = mapState.inventory?.[tile.id];
  if (!inv || inv.status !== "LIBRARY") throw new Error("MAP_TILE_NOT_AVAILABLE");
  const orientation = normalizeOrientation(rotation, orientationCount);
  if (!locationId) throw new Error("MAP_LOCATION_REQUIRED");

  const placementId = `PL-${String(mapState.nextPlacementSeq++).padStart(4,"0")}`;
  mapState.placements[placementId] = {
    placementId, tileId: tile.id, locationId, scale: tile.scale,
    parentPlacementId, anchor, rotation: orientation, orientationCount, visibleFacts,
    materialized: true
  };
  inv.status = "TABLE";
  inv.placementId = placementId;
  mapState.discoveredLocations[locationId] ??= {
    locationId, scale: tile.scale, discovered: true, placementHistory: []
  };
  mapState.discoveredLocations[locationId].placementHistory.push(placementId);
  return mapState.placements[placementId];
}

export function returnTileToLibrary(mapState, placementId) {
  const placement = mapState.placements?.[placementId];
  if (!placement) throw new Error("MAP_PLACEMENT_UNKNOWN");
  const inv = mapState.inventory?.[placement.tileId];
  if (!inv) throw new Error("MAP_INVENTORY_UNKNOWN");
  placement.materialized = false;
  inv.status = "LIBRARY";
  inv.placementId = null;
  return placement;
}

export function reconstructLocation(mapState, catalog, locationId) {
  const loc = mapState.discoveredLocations?.[locationId];
  if (!loc) return { ok:false, reason:"LOCATION_NOT_DISCOVERED" };
  const lastId = [...loc.placementHistory].reverse().find(id => mapState.placements[id]);
  const previous = mapState.placements[lastId];
  if (!previous) return { ok:false, reason:"NO_PLACEMENT_HISTORY" };
  const tile = (catalog.tiles ?? []).find(t => t.id === previous.tileId);
  if (!tile) return { ok:false, reason:"PHYSICAL_TILE_MISSING" };
  const inv = mapState.inventory?.[tile.id];
  if (!inv || inv.status !== "LIBRARY") return { ok:false, reason:"PHYSICAL_TILE_NOT_AVAILABLE" };
  return { ok:true, instruction:{
    action:"PLACE_TILE", tileId:tile.id, locationId,
    rotation:previous.rotation, orientationCount:previous.orientationCount ?? 4, anchor:previous.anchor,
    visibleFacts:previous.visibleFacts
  }};
}

export function makePlacementInstruction(tile, {locationId, rotation=0, orientationCount=4, anchor=null}={}) {
  return {
    action:"PLACE_TILE",
    tileId:tile.id,
    locationId,
    rotation: normalizeOrientation(rotation, orientationCount),
    orientationCount,
    anchor,
    playerText:`Busca ${tile.id} en la Biblioteca y colócala en la mesa.`
  };
}
