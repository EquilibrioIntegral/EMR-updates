import {composeGenesisSharedDecisionR58 as composeBaseSharedDecisionR58} from './genesis-guionista.js';
import {primordialEntityNarrativeRefR512} from './genesis-entity-config-r512.js';

export * from './genesis-guionista.js';

const genericRef=(nature,index=0)=>nature==='WILL'?(index===0?'una Voluntad':'otra Voluntad'):nature==='MYSTIC'?(index===0?'una fuerza mística':'otra fuerza mística'):'una fuerza física';

export function narrativeAgencyRefR512(live,playerId,{fallbackIndex=0}={}){
 const player=(live?.players||[]).find(p=>p.id===playerId);
 const agency=live?.runtime?.binding?.agencies?.find(a=>a.playerId===playerId);
 if(!player&&!agency)return 'una fuerza primordial';
 const explicit=player?.primordialNarrativeRef||agency?.primordialNarrativeRef;
 if(explicit)return explicit;
 const entityId=agency?.volitionEntityId||agency?.mysticForceId||player?.primordialEntityId;
 const profile=entityId?live?.entityConfiguration?.profiles?.[entityId]:null;
 if(profile){
  const ref=primordialEntityNarrativeRefR512(profile);
  if(ref&&!/sin nombre$/i.test(ref))return ref;
 }
 return genericRef(player?.nature||agency?.nature,fallbackIndex);
}

export function composeGenesisSharedDecisionR512(live){
 const base=composeBaseSharedDecisionR58(live);
 const round=live?.round||1;
 const recent=(live?.history||[]).filter(e=>e.type==='GEN_LIVE_R5_AGENCY_CHOICE'&&e.round===round&&e.optionId!=='WAIT');
 const willActions=recent.map(e=>{
  const player=(live?.players||[]).find(p=>p.id===e.playerId);
  if(player?.nature!=='WILL')return null;
  const [kind,targetId]=String(e.optionId||'').split(':');
  const agency=live?.runtime?.binding?.agencies?.find(a=>a.playerId===e.playerId);
  return agency?.volitionEntityId&&targetId?{playerId:e.playerId,kind,targetId,volitionEntityId:agency.volitionEntityId}:null;
 }).filter(Boolean);
 const byTarget=new Map();
 for(const action of willActions){const xs=byTarget.get(action.targetId)||[];xs.push(action);byTarget.set(action.targetId,xs);}
 const shared=[...byTarget.entries()].map(([targetId,actions])=>({targetId,actions})).filter(x=>new Set(x.actions.map(a=>a.volitionEntityId)).size>=2).sort((a,b)=>a.targetId.localeCompare(b.targetId))[0]||null;
 if(!shared)return base;
 const actors=[];
 for(const action of shared.actions){if(!actors.some(a=>a.volitionEntityId===action.volitionEntityId))actors.push(action);if(actors.length===2)break;}
 if(actors.length<2)return base;
 const a=narrativeAgencyRefR512(live,actors[0].playerId,{fallbackIndex:0});
 const b=narrativeAgencyRefR512(live,actors[1].playerId,{fallbackIndex:1});
 const publicText=`${a} y ${b} han actuado sobre la misma concentración de materia. El mundo recuerda ambos actos, pero todavía no existe entre ellas un vínculo persistente. Ambas pueden intentar convertir esa coincidencia en una relación real o dejar que siga siendo solo una coincidencia.`;
 base.narrative={...(base.narrative||{}),publicText};
 base.narrativeActors=[
  {playerId:actors[0].playerId,entityId:actors[0].volitionEntityId,publicRef:a},
  {playerId:actors[1].playerId,entityId:actors[1].volitionEntityId,publicRef:b}
 ];
 base.narrativeIdentitySchema='EMR_GENESIS_NARRATIVE_IDENTITY_R512_v1';
 const relation=base.options?.find(o=>o.effect==='VOLITION_RELATION');
 if(relation){
  relation.narrativeActors=structuredClone(base.narrativeActors);
  relation.attempt=relation.relationSpec?.type==='COOPERATES_WITH'
   ?`Convertir las intervenciones compatibles de ${a} y ${b} sobre el mismo objetivo en una cooperación persistente y limitada.`
   :`Establecer un pacto concreto entre ${a} y ${b} acerca del objetivo sobre el que ambas han intervenido.`;
 }
 return base;
}

// Compatibility name used by the live R5 bridge. This deliberately overrides
// the R5.8 export while retaining every other Guionista function unchanged.
export const composeGenesisSharedDecisionR58=composeGenesisSharedDecisionR512;
