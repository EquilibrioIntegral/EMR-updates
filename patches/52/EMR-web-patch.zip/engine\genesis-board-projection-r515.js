import {setupProjectionR5 as setupProjectionR514} from './genesis-board-projection-r514.js';
import {A61_VISIBLE_ROWS_R515,a61CenterVisibleNumberR515} from './genesis-board-display-r515.js';

// R5.24 P1: one player-facing A61 authority.
// Geometry/internal H-codes remain engine data; every player-facing projection must
// derive numbering from genesis-board-display-r515.js instead of re-declaring it.
export function setupProjectionR5(live){
  const projection=setupProjectionR514(live);
  const runtimeBoard=live?.runtime?.cosmogony?.board||null;
  const boardId=runtimeBoard?.id||live?.referenceConfig?.boardPreset||projection?.board?.preset;
  if(boardId==='A61'){
    const centerCell=a61CenterVisibleNumberR515(runtimeBoard)||31;
    projection.board={
      ...projection.board,
      visibleNumbering:'ROW_MAJOR_TOP_LEFT_TO_BOTTOM_RIGHT_1_61',
      rowLengths:[...A61_VISIBLE_ROWS_R515],
      centerCell,
      playerFacingDesign:'COSMIC_GOLD_A61_R515',
      internalCenterCode:'H001',
      playerFacingAuthority:'engine/genesis-board-display-r515.js'
    };
    projection.warning=`A61 es la geometría activa del E2E humano. En mesa y app se numera por filas, de arriba abajo y de izquierda a derecha: 1-5 / 6-11 / 12-18 / 19-26 / 27-35 / 36-43 / 44-50 / 51-56 / 57-61. La casilla central visible es la ${centerCell}; H001 sigue siendo únicamente el identificador interno del centro.`;
  }
  return projection;
}
