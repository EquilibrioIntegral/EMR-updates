import {createGenesisEntryR53,recordRevealedPrimordialCards,signatureDiceInstructionsR53,resolveGenesisEntryDiceR53,genesisEntryPublicResultR53,migrateLegacySoloSignatureEntryR53} from '../engine/genesis-entry-r53.js';
import {installGenesisLiveFromEntryR53} from '../engine/genesis-entry-to-live-r5.js';
import {PLAYER_COLORS_R513} from '../engine/genesis-player-facing-r513.js';

const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PRIMORDIAL_SINGULARITY_ASSET='./assets/pre-genesis/singularity-primordial-canonical.webp';
const primordial=[
 ['Realidad física','Las fuerzas físicas del universo comienzan a surgir de la singularidad. Materia, energía, espacio y tiempo impondrán sus leyes sobre cuanto llegue a existir.'],
 ['Realidad sobrenatural sin voluntad','Junto a las leyes de la materia despiertan fuerzas que no pertenecen por completo a lo físico. No piensan ni desean, pero alteran la realidad como mareas invisibles que obedecen a reglas todavía desconocidas.'],
 ['Realidad sobrenatural con voluntad','En el nacimiento del universo aparece algo más que fuerza: aparece voluntad. Existen poderes capaces de querer, elegir e intervenir, y sus deseos podrán dejar huella en la creación.']
];
const openingText='Al principio no había mundo. No había nombres, memoria ni caminos. Solo una singularidad imposible, cerrada sobre sí misma, guardando todas las formas que algún día podrían existir. Durante un instante que aún no podía llamarse tiempo, nada cambió. Hasta que el equilibrio se quebró. La primera huella de la realidad apareció… y entonces ocurrió algo.';

export function renderGenesisEntryR53Ui({state,host,persist,rerender}){
 const players=state.session.players,seed=state.meta?.seed||'EMR';
 const bootTitle=document.querySelector('#boot-title'),bootFiction=document.querySelector('#boot-fiction');if(bootTitle)bootTitle.hidden=true;if(bootFiction)bootFiction.hidden=true;
 state.session.genesisEntryR53??=createGenesisEntryR53({playerIds:players.map(p=>p.id),playerNames:players.map(p=>p.name)});
 let entry=state.session.genesisEntryR53;
 if(players.length===1&&entry.phase==='SIGNATURE_DICE'){
  entry=migrateLegacySoloSignatureEntryR53(entry,{seed});state.session.genesisEntryR53=entry;persist();
 }
 const set=next=>{state.session.genesisEntryR53=next;persist();rerender();};
 const layout=(title,body)=>{host.innerHTML=`<article class="genesis-reader"><h2>${esc(title)}</h2>${body}<p id="gen-r53-error" role="alert" class="form-error"></p></article>`;};
 const bind=(id,fn)=>host.querySelector('#'+id)?.addEventListener('click',()=>{try{fn();}catch(e){host.querySelector('#gen-r53-error').textContent=e.message==='GEN_R53_ENTRY_REROLL_EQUAL_DICE'?'Hay empate entre dados que deben distinguir intensidades. Repite únicamente los dados empatados e introdúcelos de nuevo.':e.message;}});
 const button=(id,text,attrs='')=>`<button id="${id}" ${attrs}>${text}</button>`;
 const playerRef=i=>{const c=PLAYER_COLORS_R513[i]||PLAYER_COLORS_R513[2];return`<span class="controller-ref" style="color:${c.css}">Jugador ${i+1}: ${esc(players[i]?.name||`Jugador ${i+1}`)}</span>`;};
 const optionCards=()=>`<div class="primordial-options">${primordial.map((x,i)=>`<button type="button" class="primordial-option primordial-option-button" data-primordial-choice="${i+1}" aria-pressed="false"><strong>${i+1}. ${esc(x[0])}</strong><span>${esc(x[1])}</span></button>`).join('')}</div>`;

 if(entry.phase==='PHYSICAL_CHOICE'&&!entry.openingSeen){
  layout('Antes del mundo',`<img class="genesis-book-illustration" src="${PRIMORDIAL_SINGULARITY_ASSET}" alt="La singularidad primordial antes del nacimiento del universo"><p class="genesis-copy genesis-opening-copy">${esc(openingText)}</p><p class="table-cue">Coloca el Tablero Primordial, aún cerrado, en el centro de la mesa.</p>${button('gen-r53-opening-next','¿Qué ocurrió?')}`);
  bind('gen-r53-opening-next',()=>set({...entry,openingSeen:true}));return;
 }

 if(entry.phase==='PHYSICAL_CHOICE'){
  const ui=entry.uiR516||{playerIndex:0,choices:Array(players.length).fill(null)};
  const i=Math.min(ui.playerIndex,players.length-1);
  layout(players.length===1?'Elige qué clase de realidad despierta':'Elegid qué clase de realidad despierta',`${players.length>1?`<p>${playerRef(i)}</p>`:''}${optionCards()}<p class="genesis-choice-help">Toca una realidad para seleccionarla. Después confirma tu elección.</p>${button('gen-r53-record','Confirmar elección','disabled')}`);
  let selected=ui.choices[i]||null;const confirm=host.querySelector('#gen-r53-record');
  const sync=()=>{host.querySelectorAll('[data-primordial-choice]').forEach(card=>{const on=Number(card.dataset.primordialChoice)===Number(selected);card.classList.toggle('is-selected',on);card.setAttribute('aria-pressed',String(on));});confirm.disabled=!selected;};
  host.querySelectorAll('[data-primordial-choice]').forEach(card=>card.addEventListener('click',()=>{selected=Number(card.dataset.primordialChoice);sync();}));sync();
  bind('gen-r53-record',()=>{
    if(!selected)throw new Error('Elige una realidad antes de confirmar.');
    const next=structuredClone(entry),nextUi=next.uiR516||{playerIndex:0,choices:Array(players.length).fill(null)};nextUi.choices[i]=selected;
    if(i+1<players.length){nextUi.playerIndex=i+1;next.uiR516=nextUi;set(next);return;}
    const choices=[...nextUi.choices];delete next.uiR516;set(recordRevealedPrimordialCards(next,choices,{seed}));
  });return;
 }

 if(entry.phase==='SIGNATURE_DICE'){
  const instructions=signatureDiceInstructionsR53(entry);
  layout('La realidad necesita desempate físico',`<p>La elección conjunta ya está cerrada. Solo ahora intervienen dados físicos para determinar aquello que el empate todavía no ha fijado.</p><ol class="physical-instructions">${instructions.map(x=>`<li>${esc(x.text)}${x.rerollEqual?' Si dos naturalezas que se comparan empatan, repetid únicamente esos dados.':''}</li>`).join('')}</ol>${instructions.map((x,i)=>`<label>${esc(x.nature)} · 1d6<select id="gen-r53-die-${i}">${[1,2,3,4,5,6].map(n=>`<option value="${n}">${n}</option>`).join('')}</select></label>`).join('')}${button('gen-r53-dice','Registrar dados')}`);
  bind('gen-r53-dice',()=>{const rolls={};instructions.forEach((x,i)=>{rolls[x.nature]=Number(host.querySelector(`#gen-r53-die-${i}`).value);});set(resolveGenesisEntryDiceR53(entry,rolls));});return;
 }

 if(entry.phase==='RESOLVED'){
  // R5.16: first create the actual primordial entities, then narrate the origin
  // using their chosen names/forms. The former giant pre-identity narrative screen
  // is deliberately removed from the player flow.
  const result=genesisEntryPublicResultR53(entry);
  installGenesisLiveFromEntryR53(state,result);
  persist();rerender();return;
 }
 throw new Error(`GEN_R53_ENTRY_UI_PHASE_UNKNOWN:${entry.phase}`);
}
