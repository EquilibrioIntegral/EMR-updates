// GEN-R4.2 — Primordial matter is conserved causal state, not a progress token.
const clone=x=>structuredClone(x);
const normComposition=c=>Object.fromEntries(Object.entries(c||{}).filter(([,v])=>Number.isFinite(v)&&v>0));
const total=c=>Object.values(c||{}).reduce((a,b)=>a+b,0);
function assertAmount(n){if(!Number.isFinite(n)||n<=0)throw new Error('PRIMORDIAL_MATTER_AMOUNT_INVALID');}
export function createMatterReservoir({id,name=null,location,composition,sourceIds=[],provenance=[]}){
 if(!id)throw new Error('PRIMORDIAL_MATTER_ID_REQUIRED');if(!location)throw new Error('PRIMORDIAL_MATTER_LOCATION_REQUIRED');
 const c=normComposition(composition);if(total(c)<=0)throw new Error('PRIMORDIAL_MATTER_COMPOSITION_REQUIRED');
 return {schema:'EMR_PRIMORDIAL_MATTER_v1',id,name,location:clone(location),composition:c,sourceIds:[...new Set(sourceIds)],provenance:clone(provenance),status:'AVAILABLE'};
}
export function matterMass(r){return total(r?.composition);}
function takeComposition(r,amount){assertAmount(amount);const mass=matterMass(r);if(amount>mass)throw new Error('PRIMORDIAL_MATTER_INSUFFICIENT');const ratio=amount/mass;const moved={},left={};for(const [k,v] of Object.entries(r.composition)){moved[k]=v*ratio;const rest=v-moved[k];if(rest>1e-12)left[k]=rest;}return {moved,left};}
export function transferMatter({reservoir,amount,toLocation,actionId,playerCauseId=null,producerId='BOOT00_GENESIS_PHYSICS'}){
 if(!reservoir||reservoir.status!=='AVAILABLE')throw new Error('PRIMORDIAL_MATTER_NOT_AVAILABLE');if(!toLocation)throw new Error('PRIMORDIAL_MATTER_TARGET_REQUIRED');
 const {moved,left}=takeComposition(reservoir,amount);const event={type:'MATTER_TRANSFER',actionId,producerId,playerCauseId,from:clone(reservoir.location),to:clone(toLocation),composition:clone(moved),sourceReservoirId:reservoir.id};
 const remainder={...clone(reservoir),composition:left,status:total(left)>1e-12?'AVAILABLE':'DEPLETED',provenance:[...(reservoir.provenance||[]),event]};
 const packet=createMatterReservoir({id:`${reservoir.id}:${actionId||'TRANSFER'}`,location:toLocation,composition:moved,sourceIds:[...(reservoir.sourceIds||[]),reservoir.id],provenance:[...(reservoir.provenance||[]),event]});
 return {remainder,packet,event};
}
export function combineMatter({id,location,reservoirs,actionId,playerCauseId=null,producerId='BOOT00_GENESIS_PHYSICS'}){
 if(!id||!location||!Array.isArray(reservoirs)||reservoirs.length<1)throw new Error('PRIMORDIAL_MATTER_COMBINE_INVALID');const composition={};const sourceIds=[];const provenance=[];
 for(const r of reservoirs){if(r.status!=='AVAILABLE')throw new Error('PRIMORDIAL_MATTER_NOT_AVAILABLE');for(const [k,v] of Object.entries(r.composition||{}))composition[k]=(composition[k]||0)+v;sourceIds.push(...(r.sourceIds||[]),r.id);provenance.push(...(r.provenance||[]));}
 const event={type:'MATTER_COMBINE',actionId,producerId,playerCauseId,location:clone(location),inputReservoirIds:reservoirs.map(r=>r.id)};provenance.push(event);
 return createMatterReservoir({id,location,composition,sourceIds,provenance});
}
export function matterFingerprint(r){return JSON.stringify(Object.entries(r?.composition||{}).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,Number(v.toFixed(9))]));}
