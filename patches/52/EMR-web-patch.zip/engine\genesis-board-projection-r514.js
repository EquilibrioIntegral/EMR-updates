import {setupProjectionR5 as legacySetupProjectionR5} from './genesis-live-r510-legacy.js';

// Narrow R5.14 overlay: the legacy setup structure remains save-compatible,
// but new player sessions must no longer describe A60 as the active board.
export function setupProjectionR5(live){
  const projection=legacySetupProjectionR5(live);
  const boardId=live?.runtime?.cosmogony?.board?.id||live?.referenceConfig?.boardPreset||projection?.board?.preset;
  if(boardId==='A61'){
    projection.board={
      ...projection.board,
      preset:'A61',
      cellCount:61,
      visibleNumbering:'1-61',
      centerCell:1,
      canonicalFinal:false,
      printPrototype:{
        format:'A4_LANDSCAPE',
        openMm:[297,210],
        closedMm:[148.5,210],
        fold:'WINDOW_OUTER_QUARTERS_INWARD',
        foldsMm:[74.25,222.75],
        cover:'CANONICAL_PRIMORDIAL_SINGULARITY_SPLIT_ACROSS_OUTER_FLAPS',
        interior:'A61_POINTY_HEX_STARFIELD'
      }
    };
    projection.warning='A61/10 es la geometría activa del E2E humano: hexágono regular de 61 casillas con una única casilla central para la formación estelar. El prototipo físico activo es A4 apaisado, se abre como una ventana y muestra numeración 1-61; tamaño, plegado y acabado siguen pendientes de validación humana.';
  }
  return projection;
}
