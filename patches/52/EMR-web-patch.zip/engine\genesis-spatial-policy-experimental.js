import {axialDistance} from './genesis-board-r5.js';
import {peripheralSpawnSlotsR59} from './genesis-autonomous-agencies-r59.js';

export const GENESIS_SPATIAL_EXPERIMENT_SCHEMA='EMR_GENESIS_SPATIAL_EXPERIMENT_v1';
export const GENESIS_SPATIAL_EXPERIMENT_STATUS='EXPERIMENTAL_NONCANONICAL';

// G8/G11 experiment only. Nothing in this table is a live rule.
export const SPATIAL_POLICIES=Object.freeze({
 M1_LOCAL:Object.freeze({id:'M1_LOCAL',movement:1,reachMode:'LOCAL'}),
 M2_LOCAL:Object.freeze({id:'M2_LOCAL',movement:2,reachMode:'LOCAL'}),
 M3_LOCAL:Object.freeze({id:'M3_LOCAL',movement:3,reachMode:'LOCAL'}),
 M2_TIERED:Object.freeze({id:'M2_TIERED',movement:2,reachMode:'TIERED'})
});

export function movementLimitExperimental(policyId){return policy(policyId).movement;}

/**
 * Causal radius is deliberately distinct from meeple movement.
 * radius 0 = same cell only; radius 1 = direct + adjacent access.
 * TIERED preserves GEN-PRESENCE-01: low authority stays local while stronger
 * authority may reach remotely. It is a candidate to test, not canon.
 */
export function causalRadiusExperimental(policyId,intensity=1){
 const p=policy(policyId),n=validateIntensity(intensity);
 if(p.reachMode==='LOCAL')return 1;
 if(p.reachMode==='TIERED')return 1+Math.floor((Math.max(1,n)-1)/2); // 1-2=>1, 3-4=>2, 5-6=>3
 throw new Error('GEN_SPATIAL_REACH_MODE_UNKNOWN');
}

export function classifyPresenceExperimental({distance,policyId,intensity=1}={}){
 const d=Number(distance);if(!Number.isFinite(d)||d<0)throw new Error('GEN_SPATIAL_DISTANCE_INVALID');
 const reach=causalRadiusExperimental(policyId,intensity);
 if(d===0)return'DIRECT';
 if(d===1)return'ADJACENT';
 if(d<=reach)return'REMOTE_ALLOWED';
 return'OUT_OF_REACH';
}

export function analyzeSpatialPolicyExperimental({board,policyId='M2_LOCAL',intensity=1,formationRadius=2}={}){
 if(!board?.cells?.length)throw new Error('GEN_SPATIAL_BOARD_REQUIRED');
 const p=policy(policyId),reach=causalRadiusExperimental(policyId,intensity),center=board.center||nearestOrigin(board.cells);
 const spawns=peripheralSpawnSlotsR59(board),formation=board.cells.filter(c=>axialDistance(c,center)<=formationRadius);
 const perSpawn=spawns.map(spawn=>{
  const start=cellFor(board,spawn.cell),distanceToCenter=axialDistance(start,center);
  const oneReposition=board.cells.filter(c=>axialDistance(start,c)<=p.movement+reach);
  const formationAccessible=formation.filter(c=>axialDistance(start,c)<=p.movement+reach);
  return{
   slot:spawn.slot,
   cell:spawn.cell,
   distanceToCenter,
   directRepositionsToCenter:Math.ceil(distanceToCenter/p.movement),
   causalRepositionsToCenter:Math.ceil(Math.max(0,distanceToCenter-reach)/p.movement),
   oneRepositionBoardCoverage:oneReposition.length/board.cells.length,
   oneRepositionFormationCoverage:formation.length?formationAccessible.length/formation.length:0
  };
 });
 return{
  schema:GENESIS_SPATIAL_EXPERIMENT_SCHEMA,
  status:GENESIS_SPATIAL_EXPERIMENT_STATUS,
  policyId:p.id,
  movement:p.movement,
  causalRadius:reach,
  intensity:validateIntensity(intensity),
  boardId:board.id||'CUSTOM',
  formationRadius,
  formationCellCount:formation.length,
  perSpawn,
  meanDirectRepositionsToCenter:mean(perSpawn.map(x=>x.directRepositionsToCenter)),
  maxDirectRepositionsToCenter:Math.max(...perSpawn.map(x=>x.directRepositionsToCenter)),
  meanCausalRepositionsToCenter:mean(perSpawn.map(x=>x.causalRepositionsToCenter)),
  maxCausalRepositionsToCenter:Math.max(...perSpawn.map(x=>x.causalRepositionsToCenter)),
  meanOneRepositionBoardCoverage:mean(perSpawn.map(x=>x.oneRepositionBoardCoverage)),
  minOneRepositionBoardCoverage:Math.min(...perSpawn.map(x=>x.oneRepositionBoardCoverage)),
  meanOneRepositionFormationCoverage:mean(perSpawn.map(x=>x.oneRepositionFormationCoverage)),
  minOneRepositionFormationCoverage:Math.min(...perSpawn.map(x=>x.oneRepositionFormationCoverage))
 };
}

export function analyzeMatterAccessExperimental({board,parcels=[],policyId='M2_LOCAL',intensity=1}={}){
 if(!board?.cells?.length)throw new Error('GEN_SPATIAL_BOARD_REQUIRED');
 const p=policy(policyId),reach=causalRadiusExperimental(policyId,intensity),spawns=peripheralSpawnSlotsR59(board);
 const targets=parcels.map(x=>x.cell?cellFor(board,x.cell):x);
 const accessibleBySpawn=spawns.map(spawn=>{
  const start=cellFor(board,spawn.cell);
  return targets.filter(target=>axialDistance(start,target)<=p.movement+reach).length;
 });
 return{
  schema:GENESIS_SPATIAL_EXPERIMENT_SCHEMA,
  status:GENESIS_SPATIAL_EXPERIMENT_STATUS,
  policyId:p.id,
  movement:p.movement,
  causalRadius:reach,
  intensity:validateIntensity(intensity),
  targetCount:targets.length,
  accessibleBySpawn,
  meanAccessibleTargets:mean(accessibleBySpawn),
  minAccessibleTargets:Math.min(...accessibleBySpawn),
  maxAccessibleTargets:Math.max(...accessibleBySpawn)
 };
}

function policy(id){const p=SPATIAL_POLICIES[id];if(!p)throw new Error('GEN_SPATIAL_POLICY_UNKNOWN');return p;}
function validateIntensity(n){if(!Number.isInteger(n)||n<1||n>6)throw new Error('GEN_SPATIAL_INTENSITY_INVALID');return n;}
function cellFor(board,code){const c=board.cells.find(x=>x.code===code);if(!c)throw new Error('GEN_SPATIAL_CELL_UNKNOWN');return c;}
function nearestOrigin(cells){return [...cells].sort((a,b)=>axialDistance(a,{q:0,r:0})-axialDistance(b,{q:0,r:0})||a.code.localeCompare(b.code))[0];}
function mean(xs){return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:0;}
