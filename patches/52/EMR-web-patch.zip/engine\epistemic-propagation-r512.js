import {compileBoot02MetaphysicalConstraintsR512} from './boot-metaphysics-r512.js';

export const EPISTEMIC_PROPAGATION_R512_SCHEMA='EMR_EPISTEMIC_PROPAGATION_R512_v1';

const clamp=v=>Math.round(Math.max(0,Math.min(1,Number.isFinite(Number(v))?Number(v):1))*1e12)/1e12;
const uniq=a=>[...new Set(a.filter(Boolean))];

const EVENT_TO_OBSERVATION={
 CONSCIOUSNESS_AFTER_DEATH_MANIFESTATION:{type:'POST_MORTEM_ANOMALY',check:c=>c.postMortem==='PERSISTENCE_POSSIBLE'},
 REBIRTH_MEMORY_ECHO:{type:'REBIRTH_MEMORY_CLAIM',check:c=>c.rebirth==='ALLOWED_CONDITIONALLY'},
 MORAL_CAUSAL_EFFECT:{type:'MORAL_CONSEQUENCE_PATTERN',check:c=>c.moralCausality==='OBJECTIVE_CAUSAL_EFFECT'},
 VOLITION_NORMATIVE_INTERVENTION:{type:'VOLITION_INTERVENTION_TRACE',check:c=>c.judgment?.mode==='VOLITION_AUTHORITY'},
 MATERIAL_INVISIBLE_INTERACTION:{type:'MATERIAL_INVISIBLE_EVENT',check:c=>c.materialInvisiblePermeability!=='UNDETERMINED'}
};

function ensureEpistemic(state){
 state.epistemic??={schema:EPISTEMIC_PROPAGATION_R512_SCHEMA,observations:[],memories:[],transmissions:[],doctrineSeeds:[]};
 state.epistemic.observations??=[];state.epistemic.memories??=[];state.epistemic.transmissions??=[];state.epistemic.doctrineSeeds??=[];
 return state.epistemic;
}

function genesisSource(state){return state?.session?.genesisLegacy||state?.session?.genesis||state?.genesisLegacy||state?.genesis||null;}

export function validateEpistemicStateR512(epistemic){
 if(epistemic==null)return [];
 const errors=[];
 if(epistemic.schema!==EPISTEMIC_PROPAGATION_R512_SCHEMA)errors.push('EPISTEMIC_SCHEMA_INVALID');
 for(const key of ['observations','memories','transmissions','doctrineSeeds'])if(!Array.isArray(epistemic[key]))errors.push(`EPISTEMIC_${key.toUpperCase()}_INVALID`);
 const obsIds=new Set();
 for(const o of epistemic.observations||[]){
  if(!o?.id)errors.push('EPISTEMIC_OBSERVATION_ID_MISSING');
  else if(obsIds.has(o.id))errors.push(`EPISTEMIC_OBSERVATION_DUPLICATE:${o.id}`);else obsIds.add(o.id);
 }
 const memIds=new Set();
 for(const m of epistemic.memories||[]){
  if(!m?.id)errors.push('EPISTEMIC_MEMORY_ID_MISSING');
  else if(memIds.has(m.id))errors.push(`EPISTEMIC_MEMORY_DUPLICATE:${m.id}`);else memIds.add(m.id);
  if(!m?.observationId||!obsIds.has(m.observationId))errors.push(`EPISTEMIC_MEMORY_ORPHAN:${m?.id||'UNKNOWN'}`);
 }
 for(const t of epistemic.transmissions||[]){
  if(!t?.observationId||!obsIds.has(t.observationId))errors.push(`EPISTEMIC_TRANSMISSION_ORPHAN:${t?.id||'UNKNOWN'}`);
  if(!t?.fromEntityId||!t?.toEntityId)errors.push(`EPISTEMIC_TRANSMISSION_ACTOR_MISSING:${t?.id||'UNKNOWN'}`);
 }
 for(const s of epistemic.doctrineSeeds||[]){
  if(s?.religionCreated===true)errors.push(`EPISTEMIC_RELIGION_AUTO_CREATED:${s?.id||'UNKNOWN'}`);
  if(s?.objectiveTruthDisclosed===true)errors.push(`EPISTEMIC_TRUTH_LEAK:${s?.id||'UNKNOWN'}`);
 }
 return errors;
}

export function deriveMetaphysicalObservationR512(state,event){
 if(!event?.id||!event?.type)return null;
 const rule=EVENT_TO_OBSERVATION[event.type];if(!rule)return null;
 const source=genesisSource(state);if(!source)return null;
 const constraints=compileBoot02MetaphysicalConstraintsR512(source);
 if(!rule.check(constraints))return null;
 return {
  id:`OBS-${event.id}`,
  type:rule.type,
  worldEventId:event.id,
  locationId:event.locationId||null,
  gameTime:event.gameTime??state?.meta?.gameTime??0,
  confidence:clamp(event.observability??1),
  known:false,
  public:false,
  witnessIds:uniq((event.witnesses||[]).map(w=>typeof w==='string'?w:w?.entityId)),
  visibility:'ENGINE_OBSERVATION',
  sourceFactIds:[...(constraints.sourceFactIds||[])]
 };
}

export function ingestWorldEventR512(state,event){
 const ep=ensureEpistemic(state);
 const observation=deriveMetaphysicalObservationR512(state,event);
 if(!observation)return {observation:null,memories:[]};
 const previous=ep.observations.find(o=>o.id===observation.id);
 if(!previous)ep.observations.push(observation);
 const memories=[];
 for(const raw of event.witnesses||[]){
  const w=typeof raw==='string'?{entityId:raw}:raw;
  if(!w?.entityId)continue;
  const memory={
   id:`MEM-${observation.id}-${w.entityId}`,
   observationId:observation.id,
   entityId:w.entityId,
   cultureId:w.cultureId||null,
   source:'DIRECT_WITNESS',
   confidence:clamp(observation.confidence*(w.perceptionReliability??1)),
   public:w.public===true,
   acquiredAt:observation.gameTime,
   knowledgeClass:'OBSERVATION_MEMORY'
  };
  if(!ep.memories.some(m=>m.id===memory.id))ep.memories.push(memory);
  memories.push(memory);
 }
 state.eventLog??=[];
 state.eventLog.push({type:'EPISTEMIC_OBSERVATION_CREATED',gameTime:observation.gameTime,observationId:observation.id,observationType:observation.type,witnessCount:memories.length});
 return {observation,memories};
}

export function transmitObservationR512(state,{observationId,fromEntityId,toEntityId,cultureId=null,reliability=.7,public:isPublic=false}={}){
 const ep=ensureEpistemic(state);
 const obs=ep.observations.find(o=>o.id===observationId);if(!obs)throw new Error('EPISTEMIC_OBSERVATION_NOT_FOUND');
 const sourceMemory=ep.memories.find(m=>m.observationId===observationId&&m.entityId===fromEntityId);if(!sourceMemory)throw new Error('EPISTEMIC_SOURCE_DOES_NOT_KNOW');
 if(!toEntityId)throw new Error('EPISTEMIC_RECIPIENT_REQUIRED');
 const tx={id:`TX-${observationId}-${fromEntityId}-${toEntityId}-${ep.transmissions.length+1}`,observationId,fromEntityId,toEntityId,cultureId,reliability:clamp(reliability),gameTime:state?.meta?.gameTime??0};
 ep.transmissions.push(tx);
 const memory={id:`MEM-${tx.id}`,observationId,entityId:toEntityId,cultureId,source:'HEARSAY',fromEntityId,confidence:clamp(sourceMemory.confidence*tx.reliability),public:isPublic===true,acquiredAt:tx.gameTime,knowledgeClass:'TRANSMITTED_MEMORY'};
 ep.memories.push(memory);
 state.eventLog??=[];state.eventLog.push({type:'EPISTEMIC_OBSERVATION_TRANSMITTED',gameTime:tx.gameTime,observationId,fromEntityId,toEntityId});
 return {transmission:tx,memory};
}

export function collectCultureObservationsR512(state,cultureId,{publicOnly=false}={}){
 const ep=ensureEpistemic(state);
 const memories=ep.memories.filter(m=>m.cultureId===cultureId&&(!publicOnly||m.public===true));
 const byObs=new Map();
 for(const m of memories){
  const obs=ep.observations.find(o=>o.id===m.observationId);if(!obs)continue;
  const cur=byObs.get(obs.id)||{id:obs.id,type:obs.type,known:true,public:false,confidence:0,sourceMemoryIds:[]};
  cur.public=cur.public||m.public===true;cur.confidence=Math.max(cur.confidence,clamp(m.confidence));cur.sourceMemoryIds.push(m.id);byObs.set(obs.id,cur);
 }
 return [...byObs.values()].map(o=>({...o,sourceMemoryIds:uniq(o.sourceMemoryIds)}));
}

export function deriveDoctrineSeedsR512(compiled,{minEvidence=2,minConfidence=.65}={}){
 const seeds=[];
 for(const b of compiled?.beliefs||[]){
  const evidenceCount=uniq(b.evidenceIds||[]).length;
  if(evidenceCount<minEvidence||clamp(b.confidence)<minConfidence)continue;
  seeds.push({id:`DOCTRINE-SEED-${b.cultureId}-${b.claimId}`,cultureId:b.cultureId,claimId:b.claimId,topic:b.topic,status:'LATENT',evidenceIds:uniq(b.evidenceIds||[]),confidence:clamp(b.confidence),knowledgeClass:'CULTURAL_DOCTRINE_SEED',religionCreated:false,objectiveTruthDisclosed:false});
 }
 return seeds;
}

export function commitDoctrineSeedsR512(state,seeds=[]){
 const ep=ensureEpistemic(state);
 for(const seed of seeds){if(!ep.doctrineSeeds.some(s=>s.id===seed.id))ep.doctrineSeeds.push(structuredClone(seed));}
 return ep.doctrineSeeds;
}

export function playerSafeEpistemicSnapshotR512(state,cultureId){
 const observations=collectCultureObservationsR512(state,cultureId,{publicOnly:true}).map(({sourceMemoryIds,...o})=>o);
 const seeds=(state?.epistemic?.doctrineSeeds||[]).filter(s=>s.cultureId===cultureId).map(s=>({id:s.id,cultureId:s.cultureId,claimId:s.claimId,topic:s.topic,status:s.status,confidence:s.confidence,religionCreated:s.religionCreated}));
 return {schema:EPISTEMIC_PROPAGATION_R512_SCHEMA,cultureId,observations,seeds};
}
