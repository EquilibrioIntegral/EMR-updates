export const GENESIS_PROGRESSION_R517='EMR_GENESIS_PROGRESSION_R517_v1';
export const GENESIS_R517_DECISION='D-GEN-R5.17-PROGRESSION-HANDOFF01';

function planetsOf(live){return Array.isArray(live?.runtime?.cosmogony?.planets)?live.runtime.cosmogony.planets:[];}
function starOf(live){return live?.runtime?.cosmogony?.star||{};}

export function genesisProgressionR517(live={}){
  const runtime=live.runtime||{},cosmogony=runtime.cosmogony||{},star=starOf(live),planets=planetsOf(live);
  const starIgnited=star.state==='IGNITED'||Boolean(star.family)||cosmogony.phase==='DISK'||cosmogony.phase==='PLANETS'||cosmogony.closed===true;
  const worldsFormed=planets.length>0;
  const selectedPlanetId=runtime.selectedPlanetId||live.selectedPlanetId||null;
  const selectedValid=Boolean(selectedPlanetId)&&planets.some(p=>p.id===selectedPlanetId);
  let stage='STAR_FORMATION';
  if(live.phase==='CLOSED'||runtime.phase==='CLOSED')stage='CLOSED';
  else if(live.phase==='READY_TO_CLOSE'&&starIgnited&&worldsFormed&&selectedValid)stage='HANDOFF_READY';
  else if(live.phase==='SELECT_PLANET'||runtime.phase==='SELECT_PLANET')stage='WORLD_SELECTION';
  else if(worldsFormed||cosmogony.phase==='PLANETS'||cosmogony.closed===true)stage='WORLD_FORMATION';
  else if(starIgnited)stage='DISK_FORMATION';
  return{
    schema:GENESIS_PROGRESSION_R517,
    decisionId:GENESIS_R517_DECISION,
    stage,
    starIgnited,
    starFamily:star.family||null,
    worldsFormed,
    worldCount:planets.length,
    selectedWorld: selectedValid ? {publicIndex:planets.findIndex(p=>p.id===selectedPlanetId)+1} : null,
    readyToClose:stage==='HANDOFF_READY',
    closed:stage==='CLOSED'
  };
}

export function genesisObjectiveR517(live={}){
  const p=genesisProgressionR517(live);
  if(p.stage==='DISK_FORMATION')return{
    title:'Objetivo · Conservar materia para formar mundos',
    text:'La estrella ya ha nacido. La materia que no cayó en ella debe reorganizarse en el disco y conservar suficiente diversidad y masa para que puedan surgir cuerpos y planetas con historias distintas.'
  };
  if(p.stage==='WORLD_FORMATION')return{
    title:'Objetivo · Dejar que el disco forme mundos',
    text:'El sistema ya está transformando la materia remanente en cuerpos. Vuestras decisiones todavía pueden alterar qué mundos terminan existiendo y qué genealogía causal heredarán.'
  };
  if(p.stage==='WORLD_SELECTION')return{
    title:'Objetivo · Elegir el mundo que continuará',
    text:'El sistema ya contiene al menos un planeta formado. Elegid cuál será el mundo que continuará hacia la siguiente edad; la app conservará su composición, órbita, relaciones y memoria causal sin revelar información oculta.'
  };
  if(p.stage==='HANDOFF_READY')return{
    title:'Objetivo cumplido · El sistema tiene un mundo heredero',
    text:'La estrella y sus mundos ya existen y el mundo heredero ha sido elegido. Solo queda cerrar Génesis para compilar su Legado y entregarlo al siguiente BOOT.'
  };
  if(p.stage==='CLOSED')return{
    title:'Génesis completado',
    text:'La creación de este sistema ha terminado. Su estrella, sus cuerpos, sus relaciones y las causas que los formaron quedan incorporados a la memoria del mundo.'
  };
  return{
    title:'Objetivo · Formar una estrella estable',
    text:'La materia del sistema ya está en movimiento. Debéis permitir, favorecer o alterar su evolución hasta que nazca una estrella estable. La materia que no quede atrapada en ella podrá formar después el disco, los planetas y otros cuerpos. Cómo nazca esa estrella cambiará lo que pueda existir después.'
  };
}
