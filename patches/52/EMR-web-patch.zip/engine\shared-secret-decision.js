export const SHARED_SECRET_DECISION_SCHEMA='EMR_SHARED_SECRET_DECISION_v1';

const clone=x=>structuredClone(x);
const key=x=>String(x??'');
const sorted=xs=>[...xs].map(key).sort();

function assertDecision(decision){
 if(!decision||!Array.isArray(decision.participants)||decision.participants.length<1)throw new Error('SSD_PARTICIPANTS_REQUIRED');
 if(!Array.isArray(decision.options)||decision.options.length<1)throw new Error('SSD_OPTIONS_REQUIRED');
 const ids=new Set(decision.participants.map(p=>key(p.playerId)));
 if(ids.size!==decision.participants.length||ids.has(''))throw new Error('SSD_PARTICIPANTS_INVALID');
 return ids;
}

function optionIndex(decision){
 const m=new Map();
 for(const o of decision.options){
  const slot=key(o.slot).toUpperCase();
  if(!slot||m.has(slot))throw new Error('SSD_OPTION_SLOT_INVALID');
  m.set(slot,o);
 }
 return m;
}

function normalizeSelections(decision,selections){
 const ids=assertDecision(decision),bySlot=optionIndex(decision);
 if(!Array.isArray(selections)||selections.length!==ids.size)throw new Error('SSD_SELECTIONS_INCOMPLETE');
 const seen=new Set();
 return selections.map(s=>{
  const playerId=key(s.playerId),slot=key(s.slot).toUpperCase();
  if(!ids.has(playerId)||seen.has(playerId))throw new Error('SSD_SELECTION_PLAYER_INVALID');
  seen.add(playerId);
  if(slot==='N')return{playerId,slot:'N',option:null,noIntervene:true};
  const option=bySlot.get(slot);if(!option)throw new Error('SSD_SELECTION_SLOT_ILLEGAL');
  return{playerId,slot,option:clone(option),noIntervene:false};
 }).sort((a,b)=>a.playerId.localeCompare(b.playerId));
}

function interaction(a,b){
 const ar=a.option?.resolution||{},br=b.option?.resolution||{};
 const at=key(ar.targetKey||a.option?.targetKey),bt=key(br.targetKey||b.option?.targetKey);
 const sameTarget=at!==''&&at===bt;
 const sameCoop=key(ar.cooperationKey)&&key(ar.cooperationKey)===key(br.cooperationKey);
 const sameConflict=key(ar.conflictKey)&&key(ar.conflictKey)===key(br.conflictKey);
 const aEffect=key(ar.effectKey||a.option?.effect),bEffect=key(br.effectKey||b.option?.effect);
 const covert=Boolean(ar.covert||br.covert);
 if(sameCoop&&aEffect===bEffect)return{type:'COOPERATES',sameTarget,covert};
 if(sameConflict&&(aEffect!==bEffect||covert))return{type:covert?'COVERT_CONFLICT':'CONFLICTS',sameTarget,covert};
 if(sameTarget&&covert)return{type:'COVERT_INTERACTION',sameTarget,covert};
 if(sameTarget)return{type:'COEXISTS',sameTarget,covert:false};
 return{type:'INDEPENDENT',sameTarget:false,covert};
}

function testSpec(kind,players,meta={}){
 const participants=sorted(players);
 return{id:`TEST-${kind}-${key(meta.conflictKey||meta.actorPlayerId||meta.targetKey||'X')}-${participants.join('-')}`,kind,participants,...meta};
}

export function planSharedSecretDecision({decision,selections=[]}={}){
 const normalized=normalizeSelections(decision,selections),active=normalized.filter(x=>!x.noIntervene),inactive=normalized.filter(x=>x.noIntervene);
 const edges=[];
 for(let i=0;i<active.length;i++)for(let j=i+1;j<active.length;j++){
  const a=active[i],b=active[j],rel=interaction(a,b);edges.push({from:a.playerId,to:b.playerId,...rel});
 }
 const cooperationGroups=[];
 const coopMap=new Map();
 for(const a of active){const c=key(a.option?.resolution?.cooperationKey);if(!c)continue;if(!coopMap.has(c))coopMap.set(c,[]);coopMap.get(c).push(a.playerId);}
 for(const [cooperationKey,players] of [...coopMap.entries()].sort((a,b)=>a[0].localeCompare(b[0])))if(players.length>1)cooperationGroups.push({cooperationKey,players:sorted(players)});

 const conflictGroups=[];
 const conflictMap=new Map();
 for(const a of active){
  const c=key(a.option?.resolution?.conflictKey);if(!c)continue;
  if(!conflictMap.has(c))conflictMap.set(c,[]);
  conflictMap.get(c).push({playerId:a.playerId,optionId:a.option?.id||null,effectKey:a.option?.resolution?.effectKey||a.option?.effect||null,requiredNature:a.option?.requiredNature||null,covert:Boolean(a.option?.resolution?.covert)});
 }
 for(const [conflictKey,intents] of [...conflictMap.entries()].sort((a,b)=>a[0].localeCompare(b[0]))){
  const distinctEffects=new Set(intents.map(x=>key(x.effectKey))),covertCount=intents.filter(x=>x.covert).length;
  if(distinctEffects.size>1||covertCount>1)conflictGroups.push({conflictKey,intents:intents.sort((a,b)=>a.playerId.localeCompare(b.playerId))});
 }

 const tests=[];
 for(const group of conflictGroups){
  const covert=group.intents.some(x=>x.covert),kind=covert?'COVERT_COMPETITION':'CONFLICT';
  tests.push(testSpec(kind,group.intents.map(x=>x.playerId),{conflictKey:group.conflictKey,contenders:clone(group.intents)}));
 }
 for(const a of active){
  const r=a.option?.resolution||{};
  if(r.covert){
   // N means "do not intervene", not "stop observing". Everyone else in the
   // shared context may still be a witness unless a higher layer filters sight.
   const observers=normalized.filter(x=>x.playerId!==a.playerId).map(x=>x.playerId);
   if(observers.length)tests.push(testSpec('DETECTION',[a.playerId,...observers],{actorPlayerId:a.playerId,observerPlayerIds:sorted(observers),targetKey:r.targetKey||a.option?.targetKey||null}));
  }
  if(r.test?.kind&&r.test?.when==='ALWAYS')tests.push(testSpec(r.test.kind,[a.playerId],{actorPlayerId:a.playerId,targetKey:r.targetKey||a.option?.targetKey||null}));
 }
 const dedup=new Map(tests.map(t=>[t.id,t]));
 return{schema:SHARED_SECRET_DECISION_SCHEMA,decisionId:decision.id||null,actionZone:decision.actionZone||null,participants:decision.participants.map(clone).sort((a,b)=>key(a.playerId).localeCompare(key(b.playerId))),selections:normalized.map(x=>({playerId:x.playerId,slot:x.slot,optionId:x.option?.id||null,noIntervene:x.noIntervene})),activeIntentions:active.map(x=>({playerId:x.playerId,slot:x.slot,option:clone(x.option)})),noIntervenePlayers:sorted(inactive.map(x=>x.playerId)),interactionGraph:{edges,cooperationGroups,conflictGroups},testsRequired:[...dedup.values()].sort((a,b)=>a.id.localeCompare(b.id)),majorityWinner:null,allIntentionsPreserved:true};
}

export function finalizeSharedSecretDecision({plan,testResults={}}={}){
 if(plan?.schema!==SHARED_SECRET_DECISION_SCHEMA)throw new Error('SSD_PLAN_REQUIRED');
 const tests=(plan.testsRequired||[]).map(t=>({test:clone(t),result:testResults[t.id]??null,resolved:testResults[t.id]!=null}));
 const unresolved=tests.filter(x=>!x.resolved).map(x=>x.test.id);
 const deterministic=plan.activeIntentions.filter(x=>{
  const pid=x.playerId;return !tests.some(t=>t.test.participants?.includes(pid));
 }).map(x=>({playerId:x.playerId,optionId:x.option.id,status:'APPLIES_DETERMINISTICALLY'}));
 return{schema:SHARED_SECRET_DECISION_SCHEMA,decisionId:plan.decisionId,actionZone:plan.actionZone,profile:clone(plan.selections),activeIntentions:clone(plan.activeIntentions),noIntervenePlayers:clone(plan.noIntervenePlayers||[]),interactionGraph:clone(plan.interactionGraph),tests,unresolvedTests:unresolved,deterministicOutcomes:deterministic,allIntentionsPreserved:true,majorityWinner:null,ready:unresolved.length===0};
}
