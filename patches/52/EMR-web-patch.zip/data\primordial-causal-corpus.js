// A1 laboratory corpus. Derived from CI03 modular SOURCE→ROLE→RELATION→TRANSFORM authority.
// Content stays declarative: engine filters it by Firma, spatial state and semantic state.
export const PRIMORDIAL_CAUSAL_CORPUS = [
  {id:'S-ATTRACT-STABILIZE-ORBIT',source:'SILENCIO',minForce:3,role:'ATTRACT',relation:'ORBITS',transform:'ORBITAS_ESTABLES',requires:{coPresent:false},physicalOp:'MOVE_OR_PLACE',residues:{clean:'R-S01-ORBITAS-ESTABLES',cost:'R-S01-ORBITAS-TENSIONADAS',fail:'R-S01-COLISION-CICLICA'},consumers:['CI03-S02','BOOT01_FORMACION_MUNDO'],intent:{title:'ESTABILIZAR ÓRBITAS',attempt:'Mantener varios cuerpos separados pero ligados por trayectorias físicas regulares.'}},
  {id:'S-DISPERSE-DIVIDE-BODIES',source:'SILENCIO',minForce:2,role:'DISPERSE',relation:'SEPARATES',transform:'SISTEMA_DISTRIBUIDO',requires:{coPresent:false},physicalOp:'MOVE_OR_PLACE',residues:{clean:'R-S01-SISTEMA-DISTRIBUIDO',cost:'R-S01-DISTRIBUCION-INESTABLE',fail:'R-S01-FRAGMENTACION'},consumers:['CI03-S02','BOOT01_FORMACION_MUNDO'],intent:{title:'DIVIDIR EN VARIOS CUERPOS',attempt:'Evitar un único centro y repartir la materia entre varias estructuras capaces de perdurar.'}},
  {id:'S-ATTRACT-CONCENTRATE-CORE',source:'SILENCIO',minForce:1,role:'ATTRACT',relation:'CONVERGES',transform:'NUCLEO_DOMINANTE',requires:{coPresent:false},physicalOp:'MOVE_OR_PLACE',residues:{clean:'R-S01-NUCLEO-DOMINANTE',cost:'R-S01-NUCLEO-INQUIETO',fail:'R-S01-COLAPSO-PARCIAL'},consumers:['CI03-S02','BOOT01_FORMACION_MUNDO'],intent:{title:'CONCENTRAR EL NÚCLEO',attempt:'Reunir la mayor parte de la materia en una estructura dominante.'}},
  {id:'A-LINK-BIND-REGIONS',source:'ALIENTO',minForce:1,role:'LINK',relation:'BINDS',transform:'VINCULO_IMPERSONAL',requires:{coPresent:false},physicalOp:'LINK_CELLS',residues:{clean:'R-S01-VINCULO-IMPERSONAL',cost:'R-S01-VINCULO-INTERMITENTE',fail:'R-S01-ANOMALIA-DESACOPLADA'},consumers:['CI03-S02','BOOT03','BOOT06','RUNTIME_GUIONISTA'],intent:{title:'TEJER UN VÍNCULO IMPERSONAL',attempt:'Conectar regiones separadas mediante el Aliento sin atribuir intención a la fuerza.'}},
  {id:'V-WILL-IMPRINT-AGENCY',source:'VOLUNTAD',minForce:1,role:'WILL',relation:'IMPRINTS',transform:'HUELLA_CONSCIENTE',requires:{entityKind:'AGENCY'},physicalOp:'MOVE_OR_NAME_AGENCY',residues:{clean:'R-S01-HUELLA-CONSCIENTE',cost:'R-S01-VOLUNTAD-TENSIONADA',fail:'R-S01-VOLUNTAD-FRACTURADA'},consumers:['CI03-S02','BOOT02','BOOT03','RUNTIME_GUIONISTA'],intent:{title:'IMPRIMIR UNA VOLUNTAD',attempt:'Hacer que una agencia ya autorizada por la Firma deje una huella causal consciente.'}}
];

export const PRIMORDIAL_STAGE_CONTRACT = {
  S01:{input:'FIRMA_PRIMORDIAL',outputStage:'S01_OUT'},
  S02:{inputStage:'S01_OUT',match:'class+semanticType+anchors+gates',outputStage:'S02_OUT'},
  S03:{inputStage:'S02_OUT',match:'persistence+class+semanticType+gates',output:'LEGADO_PRIMORDIAL'},
  HANDOFF:{consumer:'BOOT01_FORMACION_MUNDO',rule:'Do not reconsult the original choice; consume persistent causal legacy.'}
};
