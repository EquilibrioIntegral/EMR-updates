export const INTENTION_DECKS = Object.freeze([
  {playerSlot:1,code:'IN-01',name:'ANCLA',colorName:'rojo',colorToken:'red',cards:['IN-01-1','IN-01-2','IN-01-3','IN-01-4','IN-01-N']},
  {playerSlot:2,code:'IN-02',name:'BRÚJULA',colorName:'azul',colorToken:'blue',cards:['IN-02-1','IN-02-2','IN-02-3','IN-02-4','IN-02-N']},
  {playerSlot:3,code:'IN-03',name:'FARO',colorName:'dorado',colorToken:'gold',cards:['IN-03-1','IN-03-2','IN-03-3','IN-03-4','IN-03-N']},
  {playerSlot:4,code:'IN-04',name:'OLA',colorName:'verde',colorToken:'green',cards:['IN-04-1','IN-04-2','IN-04-3','IN-04-4','IN-04-N']}
]);

export const INTENTION_CARD_PHYSICAL = Object.freeze({finishedSizeMm:[63,88],bleedMm:3,artSizeMm:[69,94],artSizePx:[815,1110],dpi:300});

export function assignIntentionDecks(playerNames=[]){
  if(playerNames.length===0)return [];
  if(playerNames.length>4)throw new Error('EMR admite como máximo 4 jugadores en A1.');
  return playerNames.map((name,i)=>({...INTENTION_DECKS[i],playerName:String(name).trim()}));
}

export function playerIntentionLabel(playerName,assignment){
  return assignment?`${playerName} · ${assignment.code} ${assignment.name} · ${assignment.colorName}`:String(playerName);
}

export function intentionSetupInstruction(assignment){
  return `${assignment.playerName}: toma de la bandeja Biblioteca tu juego de Intenciones ${assignment.code} · ${assignment.name} (${assignment.colorName}): ${assignment.cards.join(', ')}.`;
}
