import {LEGACY_SAVE_KEY} from './save-library.js';

export function deleteProfileCascade(lib,profileId){
 if(!lib||!profileId)throw new Error('PROFILE_DELETE_REQUIRED');
 lib.reload();
 const profile=lib.profile(profileId);
 if(!profile)throw new Error('PROFILE_NOT_FOUND');
 const wasActive=lib.data.active?.profileId===profileId;
 const universes=lib.data.universes.filter(u=>u.profileId===profileId);
 const universeIds=new Set(universes.map(u=>u.id));
 const stories=lib.data.stories.filter(s=>s.profileId===profileId||universeIds.has(s.universeId));
 for(const story of stories)lib.storage?.removeItem?.(lib.storySaveKey(story.id));
 for(const universe of universes)lib.storage?.removeItem?.(lib.universeSaveKey(universe.id));
 lib.data.stories=lib.data.stories.filter(s=>!stories.some(x=>x.id===s.id));
 lib.data.universes=lib.data.universes.filter(u=>!universeIds.has(u.id));
 lib.data.profiles=lib.data.profiles.filter(p=>p.id!==profileId);
 if(wasActive||universeIds.has(lib.data.active?.universeId)||stories.some(s=>s.id===lib.data.active?.storyId)){
  lib.data.active={profileId:null,universeId:null,storyId:null};
  lib.storage?.removeItem?.(LEGACY_SAVE_KEY);
 }
 if(!lib.data.profiles.length){
  lib.data.active={profileId:null,universeId:null,storyId:null};
  lib.storage?.removeItem?.(LEGACY_SAVE_KEY);
 }
 lib.commit();
 return {profile,deletedUniverses:universes.length,deletedStories:stories.length};
}
