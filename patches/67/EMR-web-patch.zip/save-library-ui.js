import {SaveLibrary,installLegacySaveBridge} from './engine/save-library.js';
import {deleteProfileCascade} from './engine/profile-management.js';

const bridge=installLegacySaveBridge();
const lib=bridge?.lib||new SaveLibrary(localStorage);
const $=s=>document.querySelector(s);
let originalNew=null,originalContinue=null;

function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function ensureDialog(){
 let d=$('#save-library-dialog');if(d)return d;
 d=document.createElement('dialog');d.id='save-library-dialog';d.className='save-library-dialog';
 d.innerHTML='<div class="save-library-shell"><div id="save-library-body"></div><button id="save-library-close" class="quiet">Cerrar</button></div>';
 document.body.appendChild(d);$('#save-library-close').onclick=()=>d.close();return d;
}
function activeProfile(){lib.reload();return lib.profile();}
function activeUniverse(){return lib.universe();}
function savedStories(universeId){return lib.stories(universeId).filter(s=>s.hasSave&&lib.readStorySave(s.id));}
function universeHasProgress(u){return Boolean(u&&(u.baseSave||lib.readUniverseSave(u.id)||savedStories(u.id).length));}
function profileHasContinuableUniverse(profileId){return lib.data.universes.filter(u=>u.profileId===profileId).some(universeHasProgress);}
function universeStatusText(u){if(u.baseSave||u.status==='ready')return 'Universo formado';if(lib.readUniverseSave(u.id))return 'Génesis en curso';return 'Todavía sin progreso guardado';}

function syncHome(){
 lib.reload();
 const n=$('#home-new'),c=$('#home-continue'),actions=document.querySelector('.home-actions'),hs=$('#home-status');
 const p=lib.profile();
 if(actions)actions.hidden=!p;
 if(n){n.hidden=!p;n.textContent='Nuevo universo';}
 if(c){c.hidden=!p||!profileHasContinuableUniverse(p.id);c.textContent='Continuar universo';}
 if(hs)hs.textContent=p?`Perfil: ${p.name}`:'';
 let manage=$('#home-profile-manager');
 if(!manage&&$('#release-notes-open')){manage=document.createElement('button');manage.id='home-profile-manager';manage.className='quiet';manage.textContent='Cambiar perfil';$('#release-notes-open').before(manage);manage.onclick=()=>renderProfiles('',{allowClose:true});}
 if(manage){manage.textContent='Cambiar perfil';manage.hidden=!p;}
}
function chooseProfile(profileId){lib.activateProfile(profileId);ensureDialog().close();syncHome();}
function renderDeleteProfile(profileId,{allowClose=false}={}){
 lib.reload();const p=lib.profile(profileId);if(!p)return renderProfiles('Ese perfil ya no existe.',{allowClose});
 const d=ensureDialog(),body=$('#save-library-body'),universes=lib.universes(profileId),stories=lib.data.stories.filter(s=>s.profileId===profileId),close=$('#save-library-close');
 if(close)close.hidden=true;
 body.innerHTML=`<p class="eyebrow">PERFILES DE JUGADOR</p><h2>Borrar perfil</h2><p>Vas a borrar el perfil <strong>${esc(p.name)}</strong>.</p><p>También se eliminarán de este dispositivo <strong>${universes.length} universo(s)</strong> y <strong>${stories.length} partida(s)</strong> asociados. Esta acción no se puede deshacer.</p><div class="profile-delete-actions"><button id="save-profile-delete-confirm" class="danger">Borrar definitivamente</button><button id="save-profile-delete-cancel" class="quiet">Cancelar</button></div>`;
 $('#save-profile-delete-cancel').onclick=()=>renderProfiles('',{allowClose});
 $('#save-profile-delete-confirm').onclick=()=>{try{deleteProfileCascade(lib,profileId);syncHome();const canClose=allowClose&&Boolean(activeProfile());renderProfiles(`Perfil ${p.name} borrado.`,{allowClose:canClose});}catch{renderProfiles('No se ha podido borrar el perfil.',{allowClose});}};
 if(!d.open)d.showModal();
}
function renderProfiles(message='',{allowClose=false}={}){
 const d=ensureDialog(),body=$('#save-library-body'),ps=lib.reload().profiles,close=$('#save-library-close');
 if(close)close.hidden=!allowClose;
 body.innerHTML=`<p class="eyebrow">PERFILES DE JUGADOR</p><h2>¿Quién juega?</h2><p>Elige tu perfil. Cada perfil conserva sus propios universos y partidas en este dispositivo.</p>${message?`<p class="status">${esc(message)}</p>`:''}<div class="save-library-list profile-list">${ps.map(p=>`<div class="save-profile-row"><button class="secondary save-profile-select" data-profile="${p.id}">${esc(p.name)}</button><button class="quiet save-profile-delete" data-delete-profile="${p.id}" aria-label="Borrar perfil ${esc(p.name)}" title="Borrar perfil ${esc(p.name)}">Borrar</button></div>`).join('')||'<p>Aún no hay perfiles. Crea el primero para continuar.</p>'}</div><hr><label>Crear perfil<input id="save-profile-name" maxlength="40" placeholder="Nombre del jugador" autocomplete="off"></label><p id="save-profile-error" class="status" aria-live="polite"></p><button id="save-profile-create">Crear perfil</button>`;
 body.querySelectorAll('[data-profile]').forEach(b=>b.onclick=()=>chooseProfile(b.dataset.profile));
 body.querySelectorAll('[data-delete-profile]').forEach(b=>b.onclick=()=>renderDeleteProfile(b.dataset.deleteProfile,{allowClose}));
 const input=$('#save-profile-name'),error=$('#save-profile-error');
 const create=()=>{const v=input.value.trim().replace(/\s+/g,' ');if(!v){error.textContent='Escribe un nombre para crear el perfil.';return;}try{const p=lib.createProfile(v);chooseProfile(p.id);}catch(e){error.textContent=e?.message==='PROFILE_NAME_DUPLICATE'?'Ya existe un perfil con ese nombre. Cada perfil debe tener un nombre único.':'No se ha podido crear el perfil.';}};
 $('#save-profile-create').onclick=create;input.onkeydown=e=>{if(e.key==='Enter')create();};
 if(!d.open)d.showModal();
}
function renderNewUniverse(message=''){
 const p=activeProfile();if(!p)return renderProfiles();const d=ensureDialog(),body=$('#save-library-body');
 body.innerHTML=`<p class="eyebrow">${esc(p.name)}</p><h2>Nuevo universo</h2><p>Pon nombre al universo que vas a crear. Génesis construirá este mundo y el progreso se guardará automáticamente en este universo.</p>${message?`<p class="status">${esc(message)}</p>`:''}<label>Nombre del universo<input id="save-universe-name" maxlength="60" placeholder="Ej. Aetheria" autocomplete="off"></label><p id="save-universe-error" class="status" aria-live="polite"></p><button id="save-universe-create">Crear universo y comenzar</button><button id="save-back-home" class="quiet">Volver</button>`;
 const input=$('#save-universe-name'),error=$('#save-universe-error');
 const create=()=>{const name=input.value.trim().replace(/\s+/g,' ');if(!name){error.textContent='Pon un nombre al universo para continuar.';return;}try{lib.createUniverse({profileId:p.id,name});d.close();syncHome();originalNew?.();}catch{error.textContent='No se ha podido crear el universo.';}};
 $('#save-universe-create').onclick=create;input.onkeydown=e=>{if(e.key==='Enter')create();};$('#save-back-home').onclick=()=>d.close();if(!d.open)d.showModal();
}
function renderUniverses(){
 const p=activeProfile();if(!p)return renderProfiles();const d=ensureDialog(),body=$('#save-library-body');
 const us=lib.universes(p.id).filter(universeHasProgress).sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));
 body.innerHTML=`<p class="eyebrow">${esc(p.name)}</p><h2>Tus universos</h2><p>Continúa la creación de un universo o entra en uno ya formado.</p><div class="save-library-list">${us.map(u=>`<button class="secondary" data-universe="${u.id}"><strong>${esc(u.name)}</strong><span>${esc(universeStatusText(u))}</span></button>`).join('')||'<p>No hay ningún universo con progreso guardado.</p>'}</div><button id="save-new-universe-here">Nuevo universo</button><button id="save-back-profile" class="quiet">Cambiar perfil</button>`;
 body.querySelectorAll('[data-universe]').forEach(b=>b.onclick=()=>{lib.activateUniverse(b.dataset.universe);const u=lib.universe(b.dataset.universe);if(u?.baseSave||savedStories(u?.id).length)return renderUniverseHub();if(lib.readUniverseSave(u?.id)){d.close();syncHome();originalContinue?.();return;}renderUniverseHub();});
 $('#save-new-universe-here').onclick=()=>renderNewUniverse();$('#save-back-profile').onclick=()=>renderProfiles('',{allowClose:false});if(!d.open)d.showModal();
}
function renderUniverseHub(message=''){
 const u=activeUniverse();if(!u)return renderUniverses();const body=$('#save-library-body'),ss=savedStories(u.id);
 if(!u.baseSave&&lib.readUniverseSave(u.id)){ensureDialog().close();syncHome();originalContinue?.();return;}
 body.innerHTML=`<p class="eyebrow">${esc(u.name)}</p><h2>${u.baseSave?'Universo formado':'Universo'}</h2>${message?`<p class="status">${esc(message)}</p>`:''}<p>${u.baseSave?'La creación del universo ha quedado guardada. A partir de aquí las partidas nacen dentro de este mismo mundo sin alterar su estado base.':'Este universo todavía no ha completado su formación.'}</p><div class="save-library-list">${ss.length?`<button id="save-open-stories" class="secondary"><strong>Continuar partida</strong><span>${ss.length} guardada(s)</span></button>`:''}</div>${u.baseSave?'<button id="save-start-story">Nueva partida</button>':'<button id="save-resume-universe">Continuar universo</button>'}<button id="save-back-universes" class="quiet">Volver a universos</button>`;
 const open=$('#save-open-stories');if(open)open.onclick=renderStories;const start=$('#save-start-story');if(start)start.onclick=renderNewStory;const resume=$('#save-resume-universe');if(resume)resume.onclick=()=>{ensureDialog().close();syncHome();originalContinue?.();};$('#save-back-universes').onclick=renderUniverses;
}
function renderStories(){
 const u=activeUniverse();if(!u)return renderUniverses();const body=$('#save-library-body'),ss=savedStories(u.id).sort((a,b)=>String(b.lastPlayedAt||b.updatedAt).localeCompare(String(a.lastPlayedAt||a.updatedAt)));
 body.innerHTML=`<p class="eyebrow">${esc(u.name)}</p><h2>Partidas guardadas</h2><div class="save-library-list">${ss.map(s=>`<button class="secondary" data-story="${s.id}"><strong>${esc(s.name)}</strong><span>${s.lastPlayedAt?'Última sesión '+new Date(s.lastPlayedAt).toLocaleString():'Guardada'}</span></button>`).join('')||'<p>Este universo todavía no tiene partidas guardadas.</p>'}</div>${u.baseSave?'<button id="save-new-story-here">Nueva partida</button>':''}<button id="save-back-universe" class="quiet">Volver al universo</button>`;
 body.querySelectorAll('[data-story]').forEach(b=>b.onclick=()=>{lib.activateStory(b.dataset.story);ensureDialog().close();syncHome();originalContinue?.();});
 const create=$('#save-new-story-here');if(create)create.onclick=renderNewStory;$('#save-back-universe').onclick=renderUniverseHub;
}
function renderNewStory(){
 const u=activeUniverse();if(!u)return renderUniverses();const body=$('#save-library-body');
 if(!u.baseSave)return renderUniverseHub('El universo debe quedar formado antes de empezar una partida.');
 body.innerHTML=`<p class="eyebrow">${esc(u.name)}</p><h2>Nueva partida</h2><label>Nombre de la partida<input id="save-story-name" maxlength="80" placeholder="Ej. La primera memoria" autocomplete="off"></label><p>La partida empieza desde el estado base de este universo y tendrá su propio guardado.</p><button id="save-story-create">Empezar partida</button><button id="save-back-universe" class="quiet">Volver</button>`;
 $('#save-story-create').onclick=()=>{const name=$('#save-story-name').value.trim().replace(/\s+/g,' ')||`Partida ${lib.stories(u.id).length+1}`;const s=lib.forkStory({universeId:u.id,name});lib.activateStory(s.id);ensureDialog().close();syncHome();originalContinue?.();};$('#save-back-universe').onclick=renderUniverseHub;
}
function openLibrary(nextMode){
 lib.reload();const p=lib.profile();if(!p)return renderProfiles();
 if(nextMode==='new')return renderNewUniverse();
 if(!profileHasContinuableUniverse(p.id)){syncHome();return;}
 renderUniverses();
}
function normalizeGenesisCopy(){const b=$('#new-game');if(b&&/Empezar partida/i.test(b.textContent||''))b.textContent='Comenzar Génesis →';}
function installCreationCopyObserver(){const setup=$('#setup');if(!setup)return;normalizeGenesisCopy();new MutationObserver(normalizeGenesisCopy).observe(setup,{childList:true,subtree:true,characterData:true});}
function showUniverseReady(){
 queueMicrotask(()=>{lib.reload();const u=lib.universe();if(!u?.baseSave)return;for(const id of ['setup','boot','game','debug']){const e=$('#'+id);if(e)e.hidden=true;}const home=$('#home');if(home)home.hidden=false;const exit=$('#session-exit');if(exit)exit.hidden=true;syncHome();renderUniverseHub('El universo ha terminado de formarse. Ya puedes empezar una partida dentro de él.');});
}
function install(){
 const n=$('#home-new'),c=$('#home-continue');if(!n||!c)return;
 originalNew=n.onclick;originalContinue=c.onclick;
 n.onclick=e=>{e?.preventDefault?.();openLibrary('new');};
 c.onclick=e=>{e?.preventDefault?.();openLibrary('continue');};
 const exit=$('#session-exit'),originalExit=exit?.onclick;if(exit&&originalExit)exit.onclick=e=>{originalExit.call(exit,e);queueMicrotask(syncHome);};
 window.addEventListener('emr:universe-ready',showUniverseReady);
 const style=document.createElement('style');style.textContent=`.save-library-dialog{width:min(94vw,620px);border:1px solid rgba(255,255,255,.18);border-radius:20px;background:#171d26;color:#f3ede2;padding:0}.save-library-dialog::backdrop{background:rgba(3,6,10,.78);backdrop-filter:blur(5px)}.save-library-shell{padding:24px}.save-library-shell label{display:grid;gap:8px;margin:12px 0}.save-library-shell input{font:inherit;padding:13px;border-radius:12px;border:1px solid rgba(255,255,255,.2);background:#0f141b;color:#fff}.save-library-list{display:grid;gap:10px;margin:16px 0}.save-library-list button{display:flex;justify-content:space-between;gap:14px;align-items:center;text-align:left}.save-library-list span{opacity:.72;font-size:.85em}.save-library-shell hr{border:0;border-top:1px solid rgba(255,255,255,.14);margin:20px 0}.save-profile-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:stretch}.save-profile-row .save-profile-select{width:100%;font-weight:800}.save-profile-delete{min-width:84px;border-color:rgba(225,112,112,.45)!important;color:#ffd5d5!important}.save-profile-delete:hover,.save-profile-delete:focus-visible{background:rgba(139,45,45,.38)!important}.profile-delete-actions{display:grid;gap:10px;margin-top:22px}.save-library-shell .danger{background:#8d3030;color:#fff;border:1px solid #c96868}.save-library-shell .danger:hover,.save-library-shell .danger:focus-visible{background:#a83b3b}#home-status{display:block;width:max-content;max-width:calc(100% - 28px);margin:10px auto 14px;padding:8px 14px;border-radius:999px;background:rgba(10,14,20,.82);border:1px solid rgba(211,172,103,.72);color:#fff3cf!important;font-weight:800;letter-spacing:.01em;text-shadow:0 1px 3px #000}`;document.head.appendChild(style);
 installCreationCopyObserver();syncHome();queueMicrotask(()=>renderProfiles('',{allowClose:false}));
}
function waitForUpdateGate(){
 if(document.documentElement.dataset.updateGate==='ready')return Promise.resolve();
 return new Promise(resolve=>window.addEventListener('emr:update-gate-ready',resolve,{once:true}));
}
async function bootstrap(){await waitForUpdateGate();install();}
bootstrap();
export {lib as saveLibrary};
